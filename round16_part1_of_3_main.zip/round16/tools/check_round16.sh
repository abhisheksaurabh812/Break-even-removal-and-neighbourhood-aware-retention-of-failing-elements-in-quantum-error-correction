#!/usr/bin/env bash
# Round 16 archive check (a few minutes; nothing in the archive is changed):
#  1. MANIFEST.sha256 (every file of the archive);
#  2. every hash list recorded before the runs (round 15's and round 16's);
#  3. verify16.py and verify16_M.py, re-run in a temporary copy, against their stored output;
#  4. every part-I and part-M analysis, re-run in the copy, against the stored output files
#     (only item 9's milliseconds per decision period, a timing, may differ).
# Usage: tools/check_round16.sh
set -u
R="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
bad=0
ok() { echo "  ok    $1"; }
no() { echo "  FAIL  $1"; bad=1; }
hashcheck() { grep -E '^[0-9a-f]{64}  ' "$1" | sha256sum -c --quiet - ; }
have15=1; ls "$R"/qec2/out15/d9_mixed_s*.npz "$R"/qec2/out15/long_mixed_s*.npz > /dev/null 2>&1 || have15=0
[ $have15 -eq 1 ] || echo "Note: round 15's runs (parts 2 and 3 of the archive) are not here; the checks that need them are skipped."

echo "1. Archive manifest"
if [ $have15 -eq 1 ]; then
  ( cd "$R" && sha256sum -c --quiet MANIFEST.sha256 ) && ok "MANIFEST.sha256 ($(wc -l < "$R/MANIFEST.sha256") files)" || no "MANIFEST.sha256"
else
  ( cd "$R" && sha256sum -c --quiet --ignore-missing MANIFEST.sha256 ) && ok "MANIFEST.sha256 (every file present; round 15's runs not unpacked)" || no "MANIFEST.sha256"
fi

echo "2. Hash lists recorded before the runs"
( cd "$R/qec2" && hashcheck out15/hashes_at_start.txt ) && ok "round 15: out15/hashes_at_start.txt" || no "round 15: out15/hashes_at_start.txt"
for h in $(cd "$R/qec2/dev16" && find out16 -name '*hashes_at_start*.txt' | sort); do
  ( cd "$R/qec2/dev16" && hashcheck "$h" ) && ok "round 16: $h" || no "round 16: $h"
done

echo "3. Verification scripts, re-run in a copy"
mkdir -p "$T/r"   # the copy leaves out model caches and scratch folders that spot checks may have created
( cd "$R" && tar cf - --exclude=./qec2/dev16/cacheM --exclude="./qec2/dev16/i16_*" --exclude="./qec2/dev16/f16_*" \
    --exclude="./qec2/dev16/j16_*" --exclude="./qec2/dev16/chk16_*" . ) | ( cd "$T/r" && tar xf - )
D="$T/r/qec2/dev16"
S="$R/qec2/dev16/out16"
( cd "$D" && python3 verify16.py > "$T/verify16.txt" 2>&1 ) && cmp -s "$T/verify16.txt" "$S/verify16.txt" \
  && ok "verify16.py: output identical to out16/verify16.txt" || no "verify16.py (output in $T/verify16.txt)"
( cd "$D" && python3 verify16_M.py > "$T/verify16_M.txt" 2>&1 ) && cmp -s "$T/verify16_M.txt" "$S/M/verify16_M.txt" \
  && ok "verify16_M.py: output identical to out16/M/verify16_M.txt" || no "verify16_M.py"

echo "4. Analyses, re-run in the copy (stored outputs removed first, so each must be written again)"
same() { cmp -s "$D/out16/$1" "$S/$1" && ok "$1 identical" || no "$1 differs"; }
rm -f "$D"/out16/I/I_results.json "$D"/out16/I/I3b_results.* "$D"/out16/I/I10_results.* "$D"/out16/I/I11_results.* \
      "$D"/out16/I/I12_results.json "$D"/out16/I/I13_results.json "$D"/out16/M/M_results.*
( cd "$D" && python3 analyse16_I.py > out16/I/I_results.txt 2> "$T/I_err.txt" ) || no "analyse16_I.py did not run"
python3 - "$D/out16/I/I_results.json" "$S/I/I_results.json" <<'EOF' && ok "I/I_results.json identical apart from the timing of item 9" || no "I/I_results.json differs"
import json, sys
a, b = (json.load(open(f)) for f in sys.argv[1:3])
for x in (a, b):
    x['9_cost'].pop('python_ms_per_period', None)
sys.exit(0 if a == b else 1)
EOF
diff -q <(grep -v python_ms_per_period "$D/out16/I/I_results.txt") <(grep -v python_ms_per_period "$S/I/I_results.txt") > /dev/null \
  && ok "I/I_results.txt identical apart from the timing of item 9" || no "I/I_results.txt differs"
( cd "$D" && python3 analyse16_I3b.py > /dev/null 2>&1 ) || no "analyse16_I3b.py did not run"
same I/I3b_results.json; same I/I3b_results.txt
if [ $have15 -eq 1 ]; then
  ( cd "$D" && python3 analyse16_I10.py > /dev/null 2>&1 ) || no "analyse16_I10.py did not run"
  same I/I10_results.json; same I/I10_results.txt
else
  cp "$S"/I/I10_results.* "$D"/out16/I/; echo "  skip  I/I10_results (needs round 15's runs, parts 2 and 3)"
fi
( cd "$D" && PYTHONPATH=../../pylib python3 analyse16_I11.py > /dev/null 2>&1 ) || no "analyse16_I11.py did not run"
same I/I11_results.json; same I/I11_results.txt
( cd "$D" && python3 analyse16_I12_13.py > /dev/null 2>&1 ) || no "analyse16_I12_13.py did not run"
same I/I12_results.json; same I/I13_results.json
( cd "$D" && python3 analyse16_M.py > /dev/null 2>&1 ) || no "analyse16_M.py did not run"
same M/M_results.json; same M/M_results.txt

echo
if [ $bad -eq 0 ]; then echo "ALL CHECKS PASSED"; else echo "SOME CHECKS FAILED"; fi
exit $bad
