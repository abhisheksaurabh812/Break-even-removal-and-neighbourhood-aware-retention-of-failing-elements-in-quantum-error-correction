"""Round 16 spot check: re-run named jobs from this archive into a temporary folder and compare their counts with
the stored results (timing fields ignored).

    python3 tools/spotcheck16.py --list
    python3 tools/spotcheck16.py H_d7_edge-data-x_plain_L8 C_d7_xbias10_zanc_plain_L1 G_bb_unchanged_L1

Job names and commands are those of qec2/dev16/jobs16_all5.txt (the list as run), with the original workspace path
replaced by this archive's location and the output sent to a temporary folder. Nothing stored in the archive is
changed, except that run16m.py builds its model caches in qec2/dev16/cacheM/ on first use, as in the original runs.
Supports the jobs of ideal16.py, bb16.py, j16.py, f16.py and run16m.py.

Exact equality is expected with the bundled Stim and PyMatching builds on Linux x86-64: Stim's seeded sampling depends
on its version and on the machine's SIMD width (see README_round16.md)."""
import json
import os
import shlex
import subprocess
import sys
import tempfile
import time

import numpy as np

R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEV = os.path.join(R, 'qec2', 'dev16')
OLD = '/tmp/claude-0/-home-claude/3dcb49be-a1d8-5021-976d-e9463a8ac650/scratchpad'


def jobs():
    out = {}
    for line in open(os.path.join(DEV, 'jobs16_all5.txt')):
        if line.startswith('#') or not line.strip():
            continue
        name, est, _req, cmd = line.split(None, 3)
        out[name] = (float(est), cmd.strip().replace(OLD, R))
    return out


def cmp_rows(new_file, old_file):
    """ideal16.py, bb16.py, j16.py: the job's rows (by level) and the settings, against the stored file."""
    new, old = json.load(open(new_file)), json.load(open(old_file))
    bad = [f'setting {k}: {new[k]!r} vs {old.get(k)!r}' for k in new if k not in ('rows', 'elapsed') and new[k] != old.get(k)]
    stored = {r['L']: r for r in old['rows']}
    for r in new['rows']:
        o = stored.get(r['L'])
        if o is None:
            bad.append(f'L={r["L"]}: no stored row')
            continue
        bad += [f'L={r["L"]} {k}: {r.get(k)!r} vs {o.get(k)!r}' for k in sorted(set(r) | set(o)) if r.get(k) != o.get(k)]
    return bad, f'levels {[r["L"] for r in new["rows"]]}'


def cmp_maps(new_file, old_file):
    """f16.py: one record per map, against the stored record of the same map."""
    stored = {}
    for line in open(old_file):
        if line.strip():
            j = json.loads(line)
            stored[(j['map'], j.get('variant'))] = j
    bad, maps = [], []
    for line in open(new_file):
        if not line.strip():
            continue
        j = json.loads(line)
        key = (j['map'], j.get('variant'))
        maps.append(j['map'])
        o = stored.get(key)
        if o is None:
            bad.append(f'map {key}: no stored record')
            continue
        bad += [f'map {key} {k} differs' for k in sorted(set(j) | set(o)) if k != 'elapsed' and j.get(k) != o.get(k)]
    return bad, f'maps {maps}'


def cmp_npz(new_file, old_file):
    """run16m.py: every stored array and record (no timing is stored in the run file)."""
    a, b = np.load(new_file, allow_pickle=True), np.load(old_file, allow_pickle=True)
    bad = []
    for k in sorted(set(a.files) | set(b.files)):
        if k not in a.files or k not in b.files:
            bad.append(f'{k}: only in one file')
        elif a[k].dtype.kind in 'US' or a[k].dtype == object:
            if str(a[k]) != str(b[k]):
                bad.append(f'{k} differs')
        elif not (a[k].shape == b[k].shape and np.array_equal(a[k], b[k])):
            bad.append(f'{k} differs')
    return bad, f'arrays {sorted(a.files)}'


def run(name, est, cmd, tmp):
    tok = shlex.split(cmd)
    script = os.path.basename(tok[1])
    if script == 'run16m.py':
        stored = os.path.join(DEV, tok[3])
        new = os.path.join(tmp, os.path.basename(tok[3]))
        tok[3] = new
        compare = cmp_npz
    elif script in ('ideal16.py', 'bb16.py', 'j16.py', 'f16.py'):
        i = tok.index('--out')
        stored = os.path.join(DEV, tok[i + 1])
        new = os.path.join(tmp, name + os.path.splitext(tok[i + 1])[1])
        tok[i + 1] = new
        compare = cmp_maps if script == 'f16.py' else cmp_rows
    else:
        return f'{name}: {script} is not supported here'
    print(f'{name}: running {script} (about {est / 60:.0f} min in the original run) ...', flush=True)
    t0 = time.time()
    log = os.path.join(tmp, name + '.log')
    p = subprocess.run(tok, cwd=DEV, stdout=open(log, 'w'), stderr=subprocess.STDOUT)
    took = time.time() - t0
    if p.returncode != 0:
        return f'{name}: FAILED to run (exit {p.returncode}); see {log}'
    bad, what = compare(new, stored)
    verdict = 'IDENTICAL to the stored counts' if not bad else 'DIFFERENT: ' + '; '.join(bad[:6])
    return f'{name}: {verdict} ({what}; {took:.0f} s)'


def main():
    J = jobs()
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    if args == ['--list']:
        for n, (est, cmd) in J.items():
            print(f'{n:44s} {est:6.0f} s  {cmd[:110]}')
        return
    unknown = [a for a in args if a not in J]
    if unknown:
        sys.exit(f'unknown job names: {unknown} (see --list)')
    tmp = tempfile.mkdtemp(prefix='spotcheck16_')
    print(f'outputs in {tmp}')
    results = [run(n, *J[n], tmp) for n in args]
    print('\n'.join(['', 'RESULT'] + results))
    sys.exit(0 if all('IDENTICAL' in r for r in results) else 1)


if __name__ == '__main__':
    main()
