"""Write copies of round-16 job lists with the original workspace path replaced by this archive's location.

    cd qec2/dev16 && python3 ../../tools/localise_jobs.py jobs16_all5.txt [more lists]   # -> jobs16_all5_local.txt

The hashed originals are not changed."""
import os
import sys

OLD = '/tmp/claude-0/-home-claude/3dcb49be-a1d8-5021-976d-e9463a8ac650/scratchpad'
NEW = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))          # the archive's root folder (round16/)

if len(sys.argv) < 2:
    sys.exit(__doc__)
for f in sys.argv[1:]:
    s = open(f).read()
    out = f[:-4] + '_local.txt' if f.endswith('.txt') else f + '_local'
    open(out, 'w').write(s.replace(OLD, NEW))
    print(f'{out}: {s.count(OLD)} paths now under {NEW}')
