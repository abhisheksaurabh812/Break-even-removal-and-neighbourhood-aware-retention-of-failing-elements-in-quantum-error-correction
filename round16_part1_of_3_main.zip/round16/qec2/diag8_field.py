"""Post-hoc diagnostic (not pre-registered): is switching out a qubit whose error rate passed the
isolated-qubit crossover still the right call when its whole neighbourhood is elevated?
Rebuilds the true noise field of a realistic run (same seed, same scenario code), takes it at one epoch,
and compares keep vs switch out for one qubit with Stim + PyMatching on the exact error model, (a) in that
full field and (b) with the same qubit at the same absolute rate in an otherwise nominal patch.
python3 diag8_field.py <run.npz> <epoch> <qubit index> <shots> <out.json>"""
import sys, json
import numpy as np
from run3 import base_model
from run7 import make_scenario
from model import P_REF
import rectgen, deform
from ideal_excl import ler

f, e, g, shots, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
z = np.load(f, allow_pickle=True); cfg = json.loads(str(z['cfg'])); ev = json.loads(str(z['events']))
d = cfg['d']; p = cfg['p_base']
base = base_model(d)
F, _, events = make_scenario(base, cfg, np.random.default_rng(cfg['seed']))
assert events['defects'] == ev['defects'] and events['steps'] == ev['steps'], 'scenario rebuild differs from the run'
S = F[e].astype(float) / (p / P_REF)                     # per-qubit factor relative to nominal p
coord = {gg: (int(round(x)), int(round(y))) for gg, (x, y) in enumerate(base.qxy)}
c = coord[g]
full = {coord[gg]: float(S[gg]) for gg in range(len(S))}
nb = [gg for gg in range(len(S)) if gg != g and abs(coord[gg][0] - c[0]) <= 2 and abs(coord[gg][1] - c[1]) <= 2]
res = dict(run=f, epoch=e, round=e * cfg['bpe'] * d, qubit=g, coord=list(c), shots=shots,
           qubit_factor=round(float(S[g]), 2), qubit_factor_vs_calibration=round(float(F[e, g] / F[0, g]), 2),
           neighbour_median_factor=round(float(np.median(S[nb])), 2), patch_median_factor=round(float(np.median(S)), 2))
cases = dict(field_keep=dict(scale=full), field_out=dict(excl=[c], scale={k: v for k, v in full.items() if k != c}),
             isolated_keep=dict(scale={c: float(S[g])}), isolated_out=dict(excl=[c]))
for name, kw in cases.items():
    txt, _ = deform.circuit(d, d, p, **kw)
    res[name], _ = ler(txt, shots)
    print(name, res[name], flush=True)
res['field: out vs keep'] = round((res['field_out'] - res['field_keep']) / res['field_keep'], 4)
res['isolated: out vs keep'] = round((res['isolated_out'] - res['isolated_keep']) / res['isolated_keep'], 4)
json.dump(res, open(out, 'w'), indent=1); print(json.dumps(res))
