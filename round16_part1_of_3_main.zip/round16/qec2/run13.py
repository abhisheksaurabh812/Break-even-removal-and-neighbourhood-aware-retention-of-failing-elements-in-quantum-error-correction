"""
Round-13 runner: run12.py plus the learner kind 'sized7' (arms13.Sized7, the round-13 naming), the gate kind
'policy-field-watch3' (arms13.PolicyArmFieldWatch3: the reshaped circuit's own estimates), the lab-practice baseline kind
'static-generic' (fixed weights from one uniform rate), and a fifth
sample stream: an arm marked "extra": "w3" draws the reshaped-circuit samples it needs from its own stream (seed + 22222)
after every other group, so adding such arms changes nothing that any round-12 arm sees.
(run12.py docstring follows)
Round-12 runner: run11.py plus one arm kind, 'policy-field-watch2' (arms12.PolicyArmFieldWatch2: the round-11 watch
with two changes to its returns), configured like 'policy-field-watch', and a fourth sample stream: an arm marked
"extra": "w2" draws the reshaped-circuit samples it needs from its own stream (seed + 33333) after every other group,
so adding such arms changes nothing that any round-11 arm sees (round-11 arms reproduce run11.py exactly).
(run11.py docstring follows)
Round-11 runner: run10.py plus one arm kind, 'policy-field-watch' (arms11.PolicyArmFieldWatch: the field-aware
gate plus a watch on the hole), configured exactly like 'policy-field' plus an optional dict 'watch'.

Sampling.  An arm marked "extra": "w" draws the reshaped-circuit samples it needs from a stream of its own
(seed + 44444) when no arm of the earlier groups has drawn that configuration in the same epoch; the main
arms and the arms marked "extra": true draw exactly as in run10.py.  So adding 'w' arms to a configuration
never changes what any other arm sees, and every other arm reproduces run10.py exactly.
Scenario generation is run10.make_scenario, unchanged.
Usage:  python3 run12.py cfg.json out.npz [key=json ...]
"""
import sys, json, time, hashlib
from collections import OrderedDict
import numpy as np
from model import P_REF
from sampler import Sampler, build_matching, weights_from_p
from arms import Stats, estimate, WMIN, Static
from run2 import build_arms
from run3 import base_model, deformed_model, to_base
from arms7 import PolicyArm, OraclePolicy
from arms9 import PolicyArmField
from arms11 import PolicyArmFieldWatch, Sized5
from arms12 import PolicyArmFieldWatch2, Sized6
from arms13 import Sized7, PolicyArmFieldWatch3
from run10 import make_scenario
from run10 import make_sized as make_sized10


def make_sized(m, cal, sp):
    if sp.get('kind') == 'sized7':
        return Sized7(sp['name'], m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                      sp.get('tmax'), sp.get('footprint'), sp.get('sizer', {}))
    if sp.get('kind') == 'sized6':
        return Sized6(sp['name'], m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                      sp.get('tmax'), sp.get('footprint'), sp.get('sizer', {}))
    if sp.get('kind') == 'sized5':
        return Sized5(sp['name'], m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                      sp.get('tmax'), sp.get('footprint'), sp.get('sizer', {}))
    return make_sized10(m, cal, sp)


def field_args(sp, cfg, i):
    return (sp['probe'], cfg['seed'] * 1000 + 17 * i, sp['table'], cfg['p_base'] / P_REF, sp.get('radius', 4.0),
            sp.get('WL', 50), sp.get('resize', True), sp.get('ring_min', 2), sp.get('fallback', 'patch'))


def run(cfg, out):
    base = base_model(cfg['d'])
    rng_sc = np.random.default_rng(cfg['seed'])
    F, flags, events = make_scenario(base, cfg, rng_sc)
    n_ep, bpe, T = F.shape[0], cfg['bpe'], base.T
    er = bpe * T
    f_cal = F[0].astype(np.float64)
    pe = base.edge_p(f_cal); qd = base.det_rate(f_cal)
    qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f_cal)
    if any(sp.get('base') == 'est' for sp in cfg['arms']):
        cs = Sampler(base, np.random.default_rng(cfg['seed'] + 77777))
        st = Stats(base); nblk = cfg.get('cal_rounds', 1_000_000) // T
        for _ in range(0, nblk, 5000):
            Xc_, _ = cs.sample(np.tile(f_cal, (5000 // bpe, 1)), bpe); st.add(Xc_)
        pe_e, q_e, _, _ = estimate(base, st, pe, qcl, 10, 10)
        cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in base.int_classes])
    arms = []
    for i, sp in enumerate(cfg['arms']):
        k = sp['kind']
        if k == 'oracle-policy':
            arms.append(OraclePolicy(sp['name'], base, events, er, sp['mode'], sp.get('theta')))
        elif k == 'policy-field':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmField(sp['name'], base, inner, cal, *field_args(sp, cfg, i)))
        elif k == 'policy-field-watch':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch')))
        elif k == 'static-generic':
            # lab-practice baseline: fixed weights from one uniform error rate (the nominal rate) for every qubit
            arms.append(Static(sp['name'], base, dict(pe=base.edge_p(np.full(base.G, cfg['p_base'] / P_REF)))))
        elif k == 'policy-field-watch3':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch3(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch'),
                                             hole=sp.get('hole')))
        elif k == 'policy-field-watch2':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch2(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch')))
        elif k == 'policy':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArm(sp['name'], base, inner, sp['mode'], cal, sp.get('probe'), sp.get('t_rein'),
                                  seed=cfg['seed'] * 1000 + 17 * i, theta=sp.get('theta')))
        elif k in ('sized', 'sized2', 'sized3', 'sized4'):
            arms.append(make_sized(base, cal, sp))
        else:
            arms.append(build_arms(base, cal, [sp])[0])
    A = len(arms); names = [a.name for a in arms]
    sampler = Sampler(base, np.random.default_rng(cfg['seed'] + 99991))
    drng = np.random.default_rng(cfg['seed'] + 55555)
    drng_x = np.random.default_rng(cfg['seed'] + 66666)   # separate stream for arms marked 'extra'
    drng_w = np.random.default_rng(cfg['seed'] + 44444)   # and one for arms marked 'extra': 'w'
    drng_w2 = np.random.default_rng(cfg['seed'] + 33333)  # and one for arms marked 'extra': 'w2'
    drng_w3 = np.random.default_rng(cfg['seed'] + 22222)  # and one for arms marked 'extra': 'w3'
    dmodels = {}; dsamplers = {}; dsamplers_x = {}; dsamplers_w = {}; dsamplers_w2 = {}; dsamplers_w3 = {}
    ex = lambda sp: sp.get('extra', False)
    grp = [4 if ex(sp) == 'w3' else 3 if ex(sp) == 'w2' else 2 if ex(sp) == 'w' else (1 if ex(sp) else 0) for sp in cfg['arms']]

    def dm(key):
        if key not in dmodels:
            dmodels[key] = deformed_model(base, key)
            dsamplers[key] = Sampler(dmodels[key], drng)
            dsamplers_x[key] = Sampler(dmodels[key], drng_x)
        return dmodels[key]

    fails = np.zeros((A, n_ep, bpe), np.uint8); nexcl = np.zeros((A, n_ep), np.uint8)
    mcache = OrderedDict(); builds = 0; decodes = 0
    chunk = cfg.get('chunk', 250); t0 = time.time()
    for c0 in range(0, n_ep, chunk):
        c1 = min(n_ep, c0 + chunk)
        Xc, oc = sampler.sample(F[c0:c1].astype(np.float64), bpe)
        for e in range(c0, c1):
            X0 = Xc[(e - c0) * bpe:(e - c0 + 1) * bpe]; o0 = oc[(e - c0) * bpe:(e - c0 + 1) * bpe]
            fe = F[e].astype(np.float64)
            true_pe = base.edge_p(fe)
            crr0 = (X0.astype(np.float32) @ base.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            keys = {}
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    keys[i] = a.plan(e)
                elif a.kind == 'policy':
                    keys[i] = a.config()
                else:
                    keys[i] = ()
            samples = {(): (X0, o0)}
            for k in sorted(set(keys[i] for i in range(A) if grp[i] == 0)):
                if k and k not in samples:
                    md = dm(k)
                    samples[k] = dsamplers[k].sample(fe[None, :], bpe)
            for k in sorted(set(keys[i] for i in range(A) if grp[i] == 1)):
                if k and k not in samples:
                    md = dm(k)
                    samples[k] = dsamplers_x[k].sample(fe[None, :], bpe)
            for k in sorted(set(keys[i] for i in range(A) if grp[i] == 2)):
                if k and k not in samples:
                    md = dm(k)
                    if k not in dsamplers_w:
                        dsamplers_w[k] = Sampler(md, drng_w)
                    samples[k] = dsamplers_w[k].sample(fe[None, :], bpe)
            for k in sorted(set(keys[i] for i in range(A) if grp[i] == 3)):
                if k and k not in samples:
                    md = dm(k)
                    if k not in dsamplers_w2:
                        dsamplers_w2[k] = Sampler(md, drng_w2)
                    samples[k] = dsamplers_w2[k].sample(fe[None, :], bpe)
            for k in sorted(set(keys[i] for i in range(A) if grp[i] == 4)):
                if k and k not in samples:
                    md = dm(k)
                    if k not in dsamplers_w3:
                        dsamplers_w3[k] = Sampler(md, drng_w3)
                    samples[k] = dsamplers_w3[k].sample(fe[None, :], bpe)
            preds = {}
            for i, a in enumerate(arms):
                k = keys[i]; md = dmodels[k] if k else None; mm = md if k else base
                X, o = samples[k]
                if a.kind == 'oracle-policy':
                    w = weights_from_p(mm.edge_p(fe), WMIN)
                elif a.kind == 'policy':
                    w = a.weights(md, true_pe)
                else:
                    w = a.weights(true_pe)
                w = np.round(w, 3)
                hk = (k, hashlib.md5(w.tobytes()).digest())
                pr = preds.get(hk)
                if pr is None:
                    mt = mcache.get(hk)
                    if mt is None:
                        mt = build_matching(mm, w); builds += 1; mcache[hk] = mt
                        if len(mcache) > 400:
                            mcache.popitem(last=False)
                    else:
                        mcache.move_to_end(hk)
                    pr = mt.decode_batch(X)[:, 0]; decodes += 1; preds[hk] = pr
                fails[i, e] = pr ^ o
                nexcl[i, e] = len(k)
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    continue
                if a.kind == 'policy':
                    k = keys[i]
                    a.update(samples[k][0], crr0 if not k else None, dmodels[k] if k else None, base.AggD, e, T, fe, to_base)
                else:
                    a.update(X0, crr0)
        if cfg.get('verbose'):
            print(f'{c1}/{n_ep} {time.time() - t0:.0f}s builds={builds} dmodels={len(dmodels)}', file=sys.stderr, flush=True)
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, nexcl=nexcl, flags=flags, names=np.array(names), cfg=json.dumps(cfg),
                        events=json.dumps(events), info=json.dumps(info), f0=f_cal)
    tot = fails.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes,
                          deformed_configs=len(dmodels), totals=dict(zip(names, tot.tolist())),
                          excluded_epochs=dict(zip(names, (nexcl > 0).sum(1).tolist())),
                          n_defects=len(events['defects']), n_bursts=len(events['bursts']))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
