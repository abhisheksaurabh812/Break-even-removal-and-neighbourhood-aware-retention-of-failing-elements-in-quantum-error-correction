"""Write the job lists for the next analysis.  python3 gen_jobs.py [--dry]  (dry: tiny runs into out/dry/)
Tokens containing JSON strings are wrapped in single quotes so that xargs passes the double quotes through."""
import sys
dry = '--dry' in sys.argv
o = 'out/dry/' if dry else 'out/'
R = (lambda n: 60000) if dry else (lambda n: n)
C = " cal_rounds=100000" if dry else ""
sch = lambda mode: "'schedule=\"" + mode + "\"'"
s2 = []
for s in (111, 112):                                   # training: pick separate baseline and model form
    for tag, mode, k in (('int', 'interleaved', 100), ('int', 'interleaved', 20), ('fresh', 'fresh', 20)):
        s2.append(f"cfg/surg2_base.json {o}s2_train_{tag}_k{k}_s{s}.npz seed={s} merge_every={k} {sch(mode)} total_rounds={R(3000000)}{C}")
for tag, mode, k, n in (('int', 'interleaved', 100, 20000000), ('int', 'interleaved', 20, 10000000), ('fresh', 'fresh', 20, 10000000)):
    for s in (211, 212, 213):                          # held-out tests
        s2.append(f"cfg/surg2_base.json {o}s2_test_{tag}_k{k}_s{s}.npz seed={s} merge_every={k} {sch(mode)} total_rounds={R(n)}{C}")
tl = [f"cfg/tuneL_{sc}.json {o}tuneL_{sc}_s{s}.npz seed={s} total_rounds={R(3000000)}{C}" for s in (101, 102) for sc in ('defects', 'mixed')]
te = [f"cfg/testL_{sc}.json {o}testL_{sc}_s{s}.npz seed={s} total_rounds={R(10000000)}{C}" for s in (401, 402, 403) for sc in ('defects', 'mixed', 'real1s')]
pre = 'dry_' if dry else ''
for name, lines in (('jobs_s2', s2), ('jobs_tuneL', tl), ('jobs_testL', te)):
    open(f'{pre}{name}.txt', 'w').write('\n'.join(lines) + '\n')
print(len(s2), len(tl), len(te))
