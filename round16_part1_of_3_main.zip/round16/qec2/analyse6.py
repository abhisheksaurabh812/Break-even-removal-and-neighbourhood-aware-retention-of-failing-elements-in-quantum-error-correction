"""Round 6 analysis: twin with analog readouts, reaction-delay curve, naming latency, decision rules.
   python3 analyse6.py test     (reads out6/test_<scen>_s*.npz)
   python3 analyse6.py tune     (reads out6/tune_<scen>_s*.npz, prints the pick)"""
import glob, json, re, sys
import numpy as np
from scipy.special import ndtr

MODE = sys.argv[1] if len(sys.argv) > 1 else 'test'
SCEN = ('ro', 't1m', 't1m_severe', 't1d', 'ro_short', 't1d_severe', 'ro_severe')


def load(files):
    out = []
    for f in files:
        z = np.load(f, allow_pickle=True)
        out.append(dict(names=list(z['names']), fails=z['fails'], info=json.loads(str(z['info'])),
                        events=json.loads(str(z['events'])), cfg=json.loads(str(z['cfg']))))
    return out


def compare(runs, a, b):
    d = np.concatenate([r['fails'][r['names'].index(a)].sum(1).astype(np.int64) -
                        r['fails'][r['names'].index(b)].sum(1).astype(np.int64) for r in runs])
    fa = sum(int(r['fails'][r['names'].index(a)].sum()) for r in runs)
    fb = sum(int(r['fails'][r['names'].index(b)].sum()) for r in runs)
    s = float(np.sqrt((d.astype(float) ** 2).sum()))
    z = float(d.sum() / s) if s > 0 else 0.0
    return dict(fails=fa, ref_fails=fb, rel=round((fa - fb) / max(fb, 1), 5), z=round(z, 2),
                p=float(2 * (1 - ndtr(abs(z)))))


def naming(runs, arm, analog):
    """First correct naming of each failure (time from onset, rounds) by the analog monitor or the
    syndrome localizer of `arm`."""
    per = []
    for r in runs:
        er = r['cfg']['bpe'] * 7
        inf = r['info'][arm]
        hits = []                                   # (time effective, qubit)
        if analog:
            for l in inf['analog']['log']:
                if l[0] == 'on':
                    hits.append((l[1] * er, l[3]))
        else:
            for e in (inf.get('localizations') or []) + (inf.get('episodes') or []):
                if len(e) >= 10 and e[2] == 1 and e[9] > 1.0:
                    hits.append((e[0] * er, e[7]))
        for ev in r['events']:
            t0, dur, q, fac, kind = ev[:5]
            tt = [t for t, g in hits if g == q and t0 <= t < t0 + dur]
            per.append(dict(kind=kind, fac=fac, dur=dur, named=bool(tt), t=(min(tt) - t0) if tt else None))
    return per


def summarize_naming(per):
    out = dict(n=len(per), named_frac=round(float(np.mean([p['named'] for p in per])), 3) if per else None)
    tt = [p['t'] for p in per if p['named']]
    out['median_time_to_name'] = float(np.median(tt)) if tt else None
    return out


def false_alarms(runs, arm):
    fa = sum(r['info'][arm]['analog']['false_alarms'] for r in runs)
    on = [l for r in runs for l in r['info'][arm]['analog']['log'] if l[0] == 'on']
    # activations not matching any active failure on that qubit
    bad = 0
    for r in runs:
        er = r['cfg']['bpe'] * 7
        for l in r['info'][arm]['analog']['log']:
            if l[0] != 'on':
                continue
            t = l[1] * er
            if not any(ev[2] == l[3] and ev[0] <= t < ev[0] + ev[1] for ev in r['events']):
                bad += 1
    return dict(rejected_alarms=fa, activations=len(on), activations_without_failure=bad)


def main():
    res = {}
    pref = f'out6/{MODE}_'
    for scen in SCEN:
        files = sorted(f for f in glob.glob(pref + f'{scen}_s*.npz') if re.fullmatch(rf'{re.escape(scen)}_s\d+\.npz', f[len(pref):]))
        if not files:
            continue
        runs = load(files)
        names = runs[0]['names']
        tot = {n: sum(int(r['fails'][k].sum()) for r in runs) for k, n in enumerate(names)}
        r = dict(seeds=len(files), totals=tot)
        twins = [n for n in names if n.startswith('twin')]
        for t in twins:
            r[f'{t} vs loc'] = compare(runs, t, 'loc')
        for a, b in (('loc', 'static-est'), ('oracle', 'loc'), ('oracle', 'static-est')):
            r[f'{a} vs {b}'] = compare(runs, a, b)
        if 'twin' in names and 'twin_half' in names:
            r['twin_half vs twin'] = compare(runs, 'twin_half', 'twin')
        if MODE == 'test':
            r['oracle vs twin'] = compare(runs, 'oracle', 'twin')
            gap = tot['static-est'] - tot['oracle']
            curve = {}
            for n in names:
                if n.startswith('od') or n in ('loc', 'twin', 'twin_half', 'oracle'):
                    curve[n] = round((tot[n] - tot['oracle']) / gap, 4) if gap else None
            r['share_of_gap_lost'] = curve
            r['gap_static_minus_oracle'] = dict(abs=gap, rel=round(gap / tot['oracle'], 4))
        nm = {}
        for t in twins[:1] if MODE == 'test' else twins:
            nm[f'{t}_analog'] = summarize_naming(naming(runs, t, True))
            nm[f'{t}_falsealarms'] = false_alarms(runs, t)
        per_loc = naming(runs, 'loc', False)
        nm['loc'] = summarize_naming(per_loc)
        if MODE == 'test' and 'twin' in names:
            per_tw = naming(runs, 'twin', True)
            kinds = sorted({p['kind'] for p in per_tw})
            bins = ((1.0, 1.4), (1.4, 2.01), (2.01, 6.01)) if 'ro' in kinds else ((2, 5), (5, 15.1), (15.1, 101))
            for lo, hi in bins:
                sl = [p for p in per_loc if lo <= p['fac'] < hi]; st = [p for p in per_tw if lo <= p['fac'] < hi]
                if sl:
                    nm[f'size_{lo}_{hi}'] = dict(loc=summarize_naming(sl), twin_analog=summarize_naming(st))
        r['naming'] = nm
        res[scen] = r
    if MODE == 'tune':
        cands = sorted({n for s in res.values() for n in s['totals'] if n.startswith('twin')})
        score = {c: round(float(np.mean([res[s]['totals'][c] / res[s]['totals']['loc'] for s in ('ro', 't1m', 't1d')
                                          if s in res])), 5) for c in cands}
        res['score'] = score; res['pick'] = min(score, key=score.get)
    else:
        rules = {}
        def beats(s, pct):
            x = res[s]['twin vs loc']; return bool(x['rel'] <= -pct and x['p'] < 0.01 and x['z'] < 0)
        if 'ro' in res: rules['A1_ro_gain_3pct_p01'] = beats('ro', 0.03)
        if 't1m' in res: rules['A2_t1m_gain_1.5pct_p01'] = beats('t1m', 0.015)
        if 't1d' in res: rules['A3_t1d_no_worse_0.5pct'] = bool(res['t1d']['twin vs loc']['rel'] <= 0.005)
        if 't1m_severe' in res: rules['A4_t1m_severe_gain_3pct_p01'] = beats('t1m_severe', 0.03)
        res['rules'] = rules
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
