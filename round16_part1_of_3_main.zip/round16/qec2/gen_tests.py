"""Build held-out test configs from the tuning picks (out/picks.json)."""
import json, copy

tune = json.load(open('cfg/tune.json'))
picks = json.load(open('out/picks.json'))['best']
by_name = {a['name']: a for a in tune['arms']}


def arm(family, newname):
    a = copy.deepcopy(by_name[picks[family]['choice']]); a['name'] = newname
    return a


arms = [dict(kind='static', name='static'), dict(kind='oracle', name='oracle'), dict(kind='slow', name='slow', R=100000),
        arm('regional', 'regional'), arm('twobuffer', 'twobuffer'), arm('slow+off', 'slow+off'),
        arm('slow+off+rs', 'slow+off+rs'), arm('gated', 'gated')]
# controls on the gated arm's own detector settings: isolate gating and re-seeding
g = by_name[picks['gated']['choice']]
arms.append(dict(kind='slow', name='slow+off@g', R=g['R'], cusum=copy.deepcopy(g['cusum'])))
arms.append(dict(kind='slow', name='gated-nors', R=g['R'], cusum=copy.deepcopy(g['cusum']), gating=True))

base = {k: v for k, v in tune.items() if k != 'arms'}
base['arms'] = arms
base['verbose'] = True
scen = {
    'bursts':  dict(bursts=True, defects=False, steps=[], drift_frac=0.0),
    'defects': dict(bursts=False, defects=True, steps=[], drift_frac=0.0),
    'steps':   dict(bursts=False, defects=False, steps=[0.15, 0.4, 0.65], drift_frac=0.0),
    'mixed':   dict(),
}
for name, over in scen.items():
    c = copy.deepcopy(base); c.update(over); c['total_rounds'] = 10_000_000
    json.dump(c, open(f'cfg/test_{name}.json', 'w'), indent=1)
# simplified-noise cross-check (heterogeneity sweep) and distance scaling
c = copy.deepcopy(base); c.update(noise='phenom', p_base=0.01, total_rounds=3_000_000)
json.dump(c, open('cfg/phenom_mixed.json', 'w'), indent=1)
for d in (3, 5):
    c = copy.deepcopy(base); c.update(d=d, total_rounds=3_000_000)
    json.dump(c, open(f'cfg/dist_d{d}.json', 'w'), indent=1)
print(json.dumps({a['name']: {k: v for k, v in a.items() if k not in ('name',)} for a in arms}, indent=1))
