"""Test L (fault localizer): LER comparisons, localization accuracy and latency, decision rules.
   python3 analyse_loc.py            (reads out/testL_{defects,mixed,real1s}_s*.npz)"""
import glob, json, sys
PREFIX = sys.argv[1] if len(sys.argv) > 1 else 'out/'
import numpy as np
from analyse2 import compare

ER = None


def load(files):
    F, names, infos, evs, cfgs = [], None, [], [], []
    for f in files:
        z = np.load(f, allow_pickle=True)
        nm = list(z['names']); names = names or nm; assert nm == names
        F.append(z['fails'].reshape(len(nm), -1)); infos.append(json.loads(str(z['info'])))
        evs.append(json.loads(str(z['events']))); cfgs.append(json.loads(str(z['cfg'])))
    return names, F, infos, evs, cfgs


def localization(infos, evs, cfgs, arm='loc'):
    rows = []; per_defect = []
    for inf, ev, cfg in zip(infos, evs, cfgs):
        er = cfg['bpe'] * 7
        D = ev['defects']
        named = {}
        for e in (inf[arm].get('localizations') or inf[arm]['episodes']):
            if e[2] != 1 or e[5] == 1 or len(e) < 10 or e[9] <= 1.0:
                continue                     # local, decided during the alarm, qubit named significantly
            t = (e[0] - 1 + 0.5) * er
            act = [d for d in D if d[0] <= t < d[0] + d[1]]
            q_act = {d[2] for d in act}
            g, top3, rhat = e[7], e[8], e[9]
            if act:
                match = [d for d in act if d[2] == g]
                lat = t - max(d[0] for d in (match or act))
                fac = max((d[3] for d in match), default=None)
            else:
                lat = None; fac = None
            rows.append(dict(t=t, active=bool(act), top1=g in q_act, top3=bool(set(top3) & q_act),
                             latency=lat, rhat=rhat, fac=fac))
            if g in q_act:
                for d in act:
                    if d[2] == g:
                        named.setdefault(id(d), t)
        for d in D:
            per_defect.append(dict(fac=d[3], dur=d[1], named=id(d) in named,
                                   time_to_name=(named[id(d)] - d[0]) if id(d) in named else None))
    act = [r for r in rows if r['active']]
    out = dict(local_decisions=len(rows), with_active_defect=len(act),
               no_active_defect=len(rows) - len(act),
               top1_accuracy=round(np.mean([r['top1'] for r in act]), 3) if act else None,
               top3_accuracy=round(np.mean([r['top3'] for r in act]), 3) if act else None)
    lats = [r['latency'] for r in act if r['top1'] and r['latency'] is not None]
    out['median_onset_to_decision_rounds'] = float(np.median(lats)) if lats else None
    ratio = [r['rhat'] / r['fac'] for r in act if r['top1'] and r['fac']]
    out['median_rhat_over_true_factor'] = round(float(np.median(ratio)), 3) if ratio else None
    out['_times_fac_ge3'] = [p['time_to_name'] for p in per_defect if p['fac'] >= 3 and p['named']]
    out['named_frac_fac_ge3'] = round(np.mean([p['named'] for p in per_defect if p['fac'] >= 3]), 3) if per_defect else None
    for lo, hi in ((2, 3), (3, 5), (5, 15.1)):
        sel = [p for p in per_defect if lo <= p['fac'] < hi]
        if sel:
            tt = [p['time_to_name'] for p in sel if p['named']]
            out[f'defects_fac_{lo}_{hi}'] = dict(n=len(sel), named_frac=round(np.mean([p['named'] for p in sel]), 3),
                                                 median_time_to_name=float(np.median(tt)) if tt else None)
    return out


def main():
    res = {}
    for scen in ('defects', 'mixed', 'real1s'):
        files = sorted(glob.glob(PREFIX + f'testL_{scen}_s*.npz'))
        if not files:
            continue
        names, F, infos, evs, cfgs = load(files)
        ix = names.index
        r = dict(seeds=len(files), totals={n: int(sum(f[k].sum() for f in F)) for k, n in enumerate(names)})
        for a, b in (('loc', 'gated-fp'), ('loc', 'slow+off@g'), ('loc', 'fp-nooff'), ('fp-nooff', 'gated-fp'),
                     ('gated-fp', 'slow+off@g'), ('loc', 'static-est'), ('oracle', 'loc'), ('slow+off@g', 'static-est')):
            if a in names and b in names:
                r[f'{a} vs {b}'] = compare(names, F, ix(a), ix(b))
        r['localization'] = localization(infos, evs, cfgs)
        r['overrides'] = sum(inf['loc'].get('overrides', 0) for inf in infos)
        res[scen] = r
    rules = {}
    if 'defects' in res:
        x = res['defects']['loc vs gated-fp']
        rules['L1_defects_gain_1.5pct_p01'] = bool(x['rel'] <= -0.015 and x['p'] < 0.01)
        loc = res['defects']['localization']
        rules['L3a_top1_accuracy_ge_0.80'] = bool(loc['top1_accuracy'] is not None and loc['top1_accuracy'] >= 0.80)
        tt = loc.get('_times_fac_ge3') or []
        rules['L3b_median_time_to_name_le_25k_rounds'] = bool(tt and float(np.median(tt)) <= 25000)
        nn = loc['local_decisions']
        rules['L4_false_namings_le_5pct'] = bool(nn and loc['no_active_defect'] / nn <= 0.05)
    for scen in ('mixed', 'real1s'):
        if scen in res:
            x = res[scen]['loc vs slow+off@g']
            rules[f'L2_{scen}_no_worse_0.5pct'] = bool(x['rel'] <= 0.005)
    res['rules'] = rules
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
