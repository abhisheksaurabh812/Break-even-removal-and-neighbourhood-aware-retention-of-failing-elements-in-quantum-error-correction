"""Test A configs.  python3 gen_testsA.py <picked fp variant name>
  cfg/testA_{bursts,defects,steps,mixed}.json : arms gated + gated-fp (merged later with existing runs)
  cfg/testA_real1s.json, testA_real10s.json   : mixed scenario with realistic burst spacing, key arms
"""
import sys, json, copy

pick = sys.argv[1]
tune = json.load(open('cfg/tuneA_mixed.json'))
fp = copy.deepcopy([a for a in tune['arms'] if a['name'] == pick][0]); fp['name'] = 'gated-fp'
gated = [a for a in tune['arms'] if a['name'] == 'gated'][0]
for scen in ('bursts', 'defects', 'steps', 'mixed'):
    c = json.load(open(f'cfg/test_{scen}.json'))
    c['arms'] = [gated, fp]; c['verbose'] = False
    json.dump(c, open(f'cfg/testA_{scen}.json', 'w'), indent=1)
mixed = json.load(open('cfg/test_mixed.json'))
supp = json.load(open('cfg/supp_mixed.json'))
by = {a['name']: a for a in mixed['arms'] + supp['arms']}
arms = [by['static-est'], by['twobuffer-est'], by['slow'], by['slow+off@g'], gated, fp]
for nm, gap in (('real1s', [500000, 1500000]), ('real10s', [5000000, 15000000])):
    c = copy.deepcopy(mixed); c['arms'] = arms; c['burst_gap'] = gap; c['verbose'] = False
    json.dump(c, open(f'cfg/testA_{nm}.json', 'w'), indent=1)
print(json.dumps([a['name'] for a in arms]))
