"""Round 10 configurations (rules in PREREG_round10.md).     python3 make_cfg10.py
Writes cfg10/*.json:
  d9_{realistic,mixed,severe,moderate}  round 9's test configurations (the 8 round-7b arms plus sz_field) at
      d = 9.  As in round 8's d = 9 runs, the old gate and the gated oracle use the d = 9 clean-patch
      crossovers (13.9 data, 8.0 Z ancilla) and every probe runs every 50 epochs (9,000 rounds, like 64 epochs
      at d = 7).  sz_field gets the same probe period and the d = 9 table (out10/field_table_d9_*.json, from
      ideal_field9.py with exactly round 9's settings).  Nothing else changes.
  pairs_mixed  round 9's mixed configuration (d = 7) with pair_frac 0.5 (run10.py).
  long_{severe,mixed}  round 8's long-failure configurations plus sz_field exactly as in round 9 (d = 7 table)."""
import json, copy, os
from make_cfg9 import field_arm, dump

THETA9 = {'data': 13.9, 'zanc': 8.0}


def table(prefix):
    t = {}
    for k in ('data', 'zanc'):
        j = json.load(open(f'{prefix}_{k}.json'))
        t[k] = [[r['L'], r['crossover']] for r in j['rows']]
    return t


def strip_field(c):
    c = copy.deepcopy(c); c['arms'] = [a for a in c['arms'] if a['name'] != 'sz_field']; return c


if __name__ == '__main__':
    os.makedirs('cfg10', exist_ok=True)
    t9 = table('out10/field_table_d9'); t7 = table('out9/field_table')
    for s in ('realistic', 'mixed', 'severe', 'moderate'):
        c = json.load(open(f'cfg9/test_{s}.json'))
        c['d'] = 9
        for a in c['arms']:
            if a['name'] in ('sz_gated', 'oracle_gated', 'sz_field'):
                a['theta'] = dict(THETA9)                 # sz_field ignores theta; reports use it (failures past the crossover)
            if a['name'] in ('sz_all', 'sz_gated', 'sz_field'):
                a['probe']['period'] = 50
            if a['name'] == 'sz_field':
                a['table'] = t9
        if s in ('mixed', 'severe'):                   # must equal round 8's d = 9 configuration plus sz_field
            r8 = json.load(open(f'cfg8/d9_{s}.json'))
            assert strip_field(c) == r8, f'd9_{s} differs from cfg8/d9_{s}.json'
        dump(c, f'cfg10/d9_{s}.json')
    c = json.load(open('cfg9/test_mixed.json')); c['pair_frac'] = 0.5
    dump(c, 'cfg10/pairs_mixed.json')
    for s in ('severe', 'mixed'):
        c = json.load(open(f'cfg8/long_{s}.json'))
        g = [a for a in c['arms'] if a['name'] == 'sz_gated'][0]
        c['arms'] = c['arms'] + [field_arm(g, t7)]
        dump(c, f'cfg10/long_{s}.json')
    print(json.dumps(t9))
