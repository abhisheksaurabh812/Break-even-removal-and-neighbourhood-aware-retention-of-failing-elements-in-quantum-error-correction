"""Round 11 configurations.   python3 make_cfg11.py dev     -> dev11/*.json (development, used seeds only)
The new arm is round 10's sz_field arm exactly (same learner, table, theta, probe, radius, window), with kind
'policy-field-watch' (arms11.PolicyArmFieldWatch), its own sample stream ("extra": "w") and a 'watch' dict.
Every other arm is copied unchanged from the round-10 (or round-9) configuration, so on a used seed every other
arm reproduces its earlier result exactly."""
import json, copy, os, sys
from make_cfg9 import dump


def watch_arm(c, name='sz_watch', **watch):
    f = [a for a in c['arms'] if a['name'] == 'sz_field'][0]
    a = copy.deepcopy(f)
    a['name'] = name; a['kind'] = 'policy-field-watch'; a['extra'] = 'w'
    keep = watch.pop('keep', True)
    if keep:
        a['inner']['kind'] = 'sized5'
    w = dict(rho=2.0, h=15.0, hold=int(f['probe']['period']), weights=True, watch=True, level=True)
    w.update(watch)
    a['watch'] = w
    return a


def with_watch(src, variants):
    c = json.load(open(src))
    c['arms'] = c['arms'] + [watch_arm(c, n, **kw) for n, kw in variants]
    return c


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'dev'
    if what == 'dev':
        os.makedirs('dev11', exist_ok=True)
        both = [('sz_watch', {}), ('sz_zone', dict(mode='zone')), ('sz_zone_nl', dict(mode='zone', level=False)),
                ('sz_view', dict(watch=False))]
        two = [('sz_watch', {}), ('sz_zone', dict(mode='zone')), ('sz_zone_nl', dict(mode='zone', level=False))]
        dump(with_watch('cfg10/d9_mixed.json', both), 'dev11/d9_mixed.json')
        dump(with_watch('cfg10/pairs_mixed.json', both), 'dev11/pairs_mixed.json')
        dump(with_watch('cfg10/d9_realistic.json', two), 'dev11/d9_realistic.json')
        dump(with_watch('cfg9/test_moderate.json', two), 'dev11/d7_moderate.json')
        print(json.dumps(watch_arm(json.load(open('cfg10/d9_mixed.json')))['watch']))


# ---------------------------------------------------------------- round-11 test configurations
# FINAL: the variant chosen after the development runs on used seeds (dev11/); set before PREREG_round11.md is frozen.
FINAL = dict()           # mode "return", keep (Sized5), weights from the view, level; rho 2, h 15, hold = probe period


def write_tests():
    assert FINAL is not None, 'choose the variant first'
    os.makedirs('cfg11', exist_ok=True)
    for t in ('d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed'):
        c = json.load(open(f'cfg10/{t}.json'))
        c['arms'] = c['arms'] + [watch_arm(c, 'sz_watch', **dict(FINAL))]
        dump(c, f'cfg11/{t}.json')
    print('wrote cfg11/*.json with sz_watch =', json.dumps(watch_arm(json.load(open('cfg10/d9_mixed.json')), 'sz_watch', **dict(FINAL))['watch']))


if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == 'test':
    write_tests()
