"""Test A: merge the footprint arm into the existing runs and apply the decision rules.
  python3 analyseA.py merge            -> out/mergedA_{scen}_s{seed}.npz
  python3 analyseA.py report           -> JSON with rule checks and diagnostics
"""
import sys, glob, json, os
import numpy as np
from analyse2 import compare, PHASES

SCEN = ('bursts', 'defects', 'steps', 'mixed')


def merge():
    for scen in SCEN:
        for f in sorted(glob.glob(f'out/merged_{scen}_s*.npz')):
            seed = f.split('_s')[-1].split('.')[0]
            g = f'out/testA_{scen}_s{seed}.npz'
            if not os.path.exists(g):
                print('missing', g); continue
            a = np.load(f, allow_pickle=True); b = np.load(g, allow_pickle=True)
            na, nb = list(a['names']), list(b['names'])
            assert np.array_equal(a['fails'][na.index('gated')], b['fails'][nb.index('gated')]), 'runs differ'
            j = nb.index('gated-fp')
            np.savez_compressed(f'out/mergedA_{scen}_s{seed}.npz', fails=np.concatenate([a['fails'], b['fails'][[j]]]),
                                werr=np.concatenate([a['werr'], b['werr'][[j]]]), flags=a['flags'],
                                names=np.array(na + ['gated-fp']), cfg=a['cfg'], events=a['events'], info=b['info'])
            print('merged', scen, seed)


def load(files):
    F, FL, names, infos = [], [], None, []
    for f in files:
        z = np.load(f, allow_pickle=True)
        nm = list(z['names']); names = names or nm; assert nm == names
        F.append(z['fails'].reshape(len(nm), -1)); FL.append(np.repeat(z['flags'], z['fails'].shape[2]))
        infos.append(json.loads(str(z['info'])))
    return names, F, FL, infos


def episodes_summary(infos, arm='gated-fp'):
    ep = sum((inf[arm].get('episodes', []) for inf in infos), [])
    if not ep:
        return {}
    loc = [e for e in ep if e[2] == 1]
    return dict(episodes=len(ep), released_local=len(loc), gated_spread=len(ep) - len(loc),
                frac_released=round(len(loc) / len(ep), 3),
                decided_at_episode_end=sum(e[5] for e in ep))


def episodes_by_cause(files, arm='gated-fp'):
    """Classify each episode by what was active at its decision epoch (from the scenario flags)."""
    out = dict(burst=[0, 0], defect_only=[0, 0], step=[0, 0], quiet=[0, 0])
    for f in files:
        z = np.load(f, allow_pickle=True)
        fl = z['flags']; inf = json.loads(str(z['info']))
        for e in inf[arm].get('episodes', []):
            ep = min(e[0] - 1, len(fl) - 1); x = int(fl[ep])
            key = 'burst' if x & 1 else ('step' if x & 8 else ('defect_only' if x & 4 else 'quiet'))
            out[key][e[2]] += 1          # [gated as spread, released as local]
    return {k: dict(gated=v[0], released=v[1]) for k, v in out.items()}


def report():
    res = {}
    ctl = 'slow+off@g'
    for scen in SCEN:
        files = sorted(glob.glob(f'out/mergedA_{scen}_s*.npz'))
        if not files:
            continue
        names, F, FL, infos = load(files)
        i, c, g = names.index('gated-fp'), names.index(ctl), names.index('gated')
        r = dict(seeds=len(files), fp_vs_control=compare(names, F, i, c), gated_vs_control=compare(names, F, g, c),
                 fp_vs_gated=compare(names, F, i, g))
        for other in ('static-est', 'twobuffer-est', 'regional-est', 'slow', 'oracle'):
            if other in names:
                r[f'fp_vs_{other}'] = compare(names, F, i, names.index(other))
        r['by_phase_fp_vs_control'] = {}
        for ph, bit in PHASES:
            msk = [(fl & bit) > 0 for fl in FL]
            if sum(m.sum() for m in msk):
                r['by_phase_fp_vs_control'][ph] = compare(names, F, i, c, msk)
        r['episodes'] = episodes_summary(infos); r['episodes_by_cause'] = episodes_by_cause(files)
        r['gated_blocks'] = dict(fp=sum(inf['gated-fp']['gated_blocks'] for inf in infos),
                                 reseeds_fp=sum(inf['gated-fp']['reseeds'] for inf in infos))
        res[scen] = r
    for scen in ('real1s', 'real10s'):
        files = sorted(glob.glob(f'out/testA_{scen}_s*.npz'))
        if not files:
            continue
        names, F, FL, infos = load(files)
        i = names.index('gated-fp')
        r = dict(seeds=len(files), totals={n: int(sum(f[k].sum() for f in F)) for k, n in enumerate(names)})
        for other in names:
            if other != 'gated-fp':
                r[f'fp_vs_{other}'] = compare(names, F, i, names.index(other))
        r['gated_vs_control'] = compare(names, F, names.index('gated'), names.index(ctl))
        r['episodes'] = episodes_summary(infos); r['episodes_by_cause'] = episodes_by_cause(files)
        r['n_bursts'] = [len(json.loads(str(np.load(f, allow_pickle=True)['events']))['bursts']) for f in files]
        res[scen] = r
    # decision rules (vs the no-gating control on the same detector settings; p < 0.01 where a gain is claimed)
    rules = {}
    if 'defects' in res:
        x = res['defects']['fp_vs_control']; rules['R1_defects_no_worse_0.5pct'] = bool(x['rel'] <= 0.005)
    if 'mixed' in res:
        x = res['mixed']['fp_vs_control']; rules['R2_mixed_better_1pct_p01'] = bool(x['rel'] <= -0.01 and x['p'] < 0.01)
    for scen in ('real1s', 'real10s'):
        if scen in res:
            x = res[scen]['fp_vs_slow+off@g']
            rules[f'R3_{scen}_not_worse'] = bool(not (x['rel'] > 0 and x['p'] < 0.01))
    for scen in ('bursts', 'steps'):
        if scen in res:
            x = res[scen]['fp_vs_control']; rules[f'R4_{scen}_no_worse_0.5pct'] = bool(x['rel'] <= 0.005)
    res['rules'] = rules
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    {'merge': merge, 'report': report}[sys.argv[1]]()
