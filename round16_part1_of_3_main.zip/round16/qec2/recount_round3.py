"""Independent recount of the round-3 headline comparisons straight from the raw failure arrays
(no shared analysis code; normal-approximation z for the paired sign test)."""
import glob, math
import numpy as np


def pair(files, a, b, key):
    x = y = fa = fb = 0
    for f in files:
        z = np.load(f, allow_pickle=True); n = list(z['names'])
        F = z[key].reshape(len(n), -1).astype(np.int64)
        A, B = F[n.index(a)], F[n.index(b)]
        x += int(((A == 1) & (B == 0)).sum()); y += int(((A == 0) & (B == 1)).sum())
        fa += int(A.sum()); fb += int(B.sum())
    zz = (abs(x - y) - 1) / math.sqrt(x + y) if x + y else 0.0
    return f'{a:>12} vs {b:<12} {fa:>8} vs {fb:<8} ({fa / fb - 1:+.4f})  discordant {x}/{y}  z={zz:.1f}'


groups = [('S interleaved 1%', 'out/s2_test_int_k100_s*.npz'), ('S interleaved 5%', 'out/s2_test_int_k20_s*.npz'),
          ('S fresh 5%', 'out/s2_test_fresh_k20_s*.npz'), ('X interleaved 1%', 'out/x_int_k100_s*.npz'),
          ('X fresh 5%', 'out/x_fresh_k20_s*.npz')]
for name, pat in groups:
    fs = sorted(glob.glob(pat))
    if not fs:
        continue
    print(f'== {name} ({len(fs)} seeds)')
    for a, b in (('shared', 'sep-own'), ('model-qt', 'static-model'), ('hybrid-qt', 'shared'), ('oracle', 'static-est'),
                 ('shared', 'static-est'), ('static-model', 'static-est')):
        print('  merged  ', pair(fs, a, b, 'failM'))
    for a, b in (('shared', 'sep-own'), ('hybrid-qt', 'sep-own'), ('static-model', 'static-est')):
        print('  unmerged', pair(fs, a, b, 'failU'))
for scen in ('defects', 'mixed', 'real1s'):
    fs = sorted(glob.glob(f'out/testL_{scen}_s*.npz'))
    if not fs:
        continue
    print(f'== L {scen} ({len(fs)} seeds)')
    for a, b in (('loc', 'gated-fp'), ('loc', 'slow+off@g'), ('loc', 'fp-nooff'), ('oracle', 'loc'), ('loc', 'static-est')):
        print('  ', pair(fs, a, b, 'fails'))
