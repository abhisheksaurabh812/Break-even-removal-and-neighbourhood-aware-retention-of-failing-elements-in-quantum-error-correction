"""Round-14 test configurations (PREREG_round14.md).   python3 make_cfg14.py test
Round 13's configuration of each test (cfg13/<test>.json: scenario unchanged).
cfg14/<test>.json, the main runs (all 70 seeds):
  loc, sz, sz_all       the localizer, reweighting and switch-out-all, as in rounds 10-13 (main sample stream);
  sz_w13                round 13's gate, unchanged ("extra": "w3");
  sz_w14                the round-14 gate: sz_w13 with the twin's fast adjustments kept on top of the reshaped
                        circuit's own estimates (arms14.PolicyArmFieldWatch4); "extra": "w4", and the probe-noise stream
                        of sz_w13 ("seed_i"), so the two gates take the same decisions unless their learning differs;
  cut                   a fixed cutoff: a named qubit is switched out once the learner's size reaches 13x (data qubit)
                        or 7x (Z ancilla), and back in when a probe finds it below 1/1.5 of that (arms7.PolicyArm
                        'gated' with the reweighting arm's learner, as sz_all); "extra": "w5".
cfg14/prior_<test>.json, detect and quarantine after Siegel et al. 2023 (arms14.Quarantine), run separately on the
first four seeds of each test (32 runs; they visit hundreds of reshaped circuits per run):
  sz                    reweighting again, as the check that both files decode the same main stream;
  sieg                  as published: more than 3 flips within 6 rounds, isolated flags dropped, reintegration after
                        100 rounds, fixed weights from the calibration experiment; "extra": "w5";
  sieg_rw               the detection rule tuned offline on calibration noise (a cluster counts when one of its
                        stabilisers is flagged in at least 2 shots of an epoch; dev14/prior/tune_sieg.py), with the
                        reweighting arm's learner and adaptive weights (as sz and sz_all); "extra": "w5".
Dropped (no rule uses them): sz_field, sz_w12r.
Lab-practice baselines (reported, no rule), as round 13: cfg14/base_<test>.json with fix_gen, fix_cal, refit_1s."""
import json, copy, os, sys
from make_cfg9 import dump

TESTS = ('d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed', 'long_severe', 'long_mixed', 'd9_hwlike')
KEEP = ('loc', 'sz', 'sz_all', 'sz_w13')


def arms14(c):
    arms = [copy.deepcopy(a) for a in c['arms'] if a['name'] in KEEP]
    names = [a['name'] for a in arms]
    a13 = arms[names.index('sz_w13')]
    a14 = copy.deepcopy(a13)
    a14.update(name='sz_w14', kind='policy-field-watch4', extra='w4', seed_i=names.index('sz_w13'))
    a13 = copy.deepcopy(a13); a13['seed_i'] = names.index('sz_w13')
    arms[names.index('sz_w13')] = a13
    inner4 = copy.deepcopy(arms[names.index('sz_all')]['inner'])          # the reweighting arm's learner (Sized4)
    cut = dict(kind='policy', name='cut', mode='gated', inner=copy.deepcopy(inner4), probe=dict(a13['probe']),
               extra='w5')
    return arms + [a14, cut]


def prior14(c):
    sz = copy.deepcopy([a for a in c['arms'] if a['name'] == 'sz'][0])
    inner4 = copy.deepcopy([a for a in c['arms'] if a['name'] == 'sz_all'][0]['inner'])
    sieg = dict(kind='quarantine', name='sieg', base='est', q=dict(n_flips=3, dt=6, k=1, t_back=100), extra='w5')
    sieg_rw = dict(kind='quarantine', name='sieg_rw', base='est', q=dict(n_flips=3, dt=6, k=2, t_back=100),
                   inner=inner4, extra='w5')
    return [sz, sieg, sieg_rw]


BASELINES = [dict(kind='static-generic', name='fix_gen'), dict(kind='static', name='fix_cal', base='est'),
             dict(kind='slow', name='refit_1s', R=1000000, s=0)]


def write_tests():
    os.makedirs('cfg14', exist_ok=True)
    for t in TESTS:
        c = json.load(open(f'cfg13/{t}.json'))
        c['arms'] = arms14(c)
        dump(c, f'cfg14/{t}.json')
        p = json.load(open(f'cfg13/{t}.json'))
        p['arms'] = prior14(p)
        dump(p, f'cfg14/prior_{t}.json')
        b = json.load(open(f'cfg13/{t}.json'))
        b['arms'] = [dict(a) for a in BASELINES]
        dump(b, f'cfg14/base_{t}.json')
    c = json.load(open('cfg14/d9_mixed.json'))
    print('cfg14 arms:', [(a['name'], a.get('extra', False), a.get('seed_i')) for a in c['arms']])
    print('cfg14 baseline arms:', [a['name'] for a in BASELINES])
    p = json.load(open('cfg14/prior_d9_mixed.json'))
    print('cfg14 prior arms:', [(a['name'], a.get('extra', False)) for a in p['arms']])


if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == 'test':
    write_tests()
