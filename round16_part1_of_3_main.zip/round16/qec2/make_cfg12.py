"""Round 12 configurations.   python3 make_cfg12.py dev    -> dev12/*.json (development, used seeds only)
New arms are round 11's sz_watch arm exactly (learner Sized5, watch mode 'return', rho 2, h 15, hold = probe period,
weights and level from the view), with kind 'policy-field-watch2' (arms12), their own sample stream ("extra": "w2")
and the watch switches 'once' (no second look at the same signal) and 'light' (light return).  Every other arm is
copied unchanged from the round-11 configuration, so on a used seed it reproduces its round-11 result exactly."""
import json, copy, os, sys
from make_cfg9 import dump


def watch2_arm(c, name, recheck=None, **sw):
    w = [a for a in c['arms'] if a['name'] == 'sz_watch'][0]
    a = copy.deepcopy(w)
    a['name'] = name; a['kind'] = 'policy-field-watch2'; a['extra'] = 'w2'
    a['watch'] = dict(a['watch'], once=True, light=True, learn=20)
    a['watch'].update(sw)
    if recheck:
        a['inner']['kind'] = 'sized6'
        a['inner']['sizer'] = dict(a['inner'].get('sizer', {}), recheck=int(recheck))
    return a


VARIANTS = [('sz_w12', {}), ('sz_w12_l', dict(once=False)), ('sz_w12_o', dict(light=False)), ('sz_w12_r', dict(recheck=50))]

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'dev'
    if what == 'dev':
        os.makedirs('dev12', exist_ok=True)
        for t in ('d9_mixed', 'd9_severe', 'd9_realistic', 'pairs_mixed'):
            c = json.load(open(f'cfg11/{t}.json'))
            c['arms'] = c['arms'] + [watch2_arm(c, n, **kw) for n, kw in VARIANTS]
            dump(c, f'dev12/{t}.json')
        print([(n, watch2_arm(json.load(open('cfg11/d9_mixed.json')), n, **kw)['watch']) for n, kw in VARIANTS])


# ---------------------------------------------------------------- round-12 test configurations
# Round 10's configuration of each test, minus three reference arms that no round-12 rule uses (static-est, the old
# gate sz_gated, oracle_all; dropped to save time), plus round 11's fix (sz_watch, "extra": "w") and the two round-12
# gates (sz_w12: once + light; sz_w12r: once + light + re-check of stuck alarms), both "extra": "w2".
TESTS = ('d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed', 'long_severe', 'long_mixed')
# d9_hwlike: round 10's d9_realistic (heterogeneity, drift, bursts, regional steps) with the failure process of round 10's
# d9_severe (factor 20-100 uniform, duration 100k-600k rounds, mean gap 400k) in place of the 2-15x failures.
HWLIKE = dict(defect_gap=400000, defect_fac=[20.0, 100.0], defect_dur=[100000, 600000])
DROP = ('static-est', 'sz_gated', 'oracle_all')
FINAL12 = dict(sz_w12=dict(), sz_w12r=dict(recheck=50))


def write_tests():
    from make_cfg11 import watch_arm, FINAL
    os.makedirs('cfg12', exist_ok=True)
    for t in TESTS:
        c = json.load(open(f'cfg10/{t}.json'))
        c['arms'] = [a for a in c['arms'] if a['name'] not in DROP]
        c['arms'].append(watch_arm(c, 'sz_watch', **dict(FINAL)))
        for n, kw in FINAL12.items():
            c['arms'].append(watch2_arm(c, n, **kw))
        dump(c, f'cfg12/{t}.json')
    c = json.load(open('cfg12/d9_realistic.json'))
    sev = json.load(open('cfg10/d9_severe.json'))
    assert all(sev[k] == v for k, v in HWLIKE.items()) and not sev.get('defect_logfac')
    c.update(HWLIKE)
    dump(c, 'cfg12/d9_hwlike.json')
    c = json.load(open('cfg12/d9_mixed.json'))
    print('cfg12 arms:', [(a['name'], a.get('extra', False)) for a in c['arms']])


if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == 'test':
    write_tests()
