"""
Round-15 checks on the extended models (light; run with nice):
  1. Sampler15's Z-type events and observable flips are identical to sampler.Sampler's (same seed, heterogeneous
     rates with a failing qubit), for the base model and one reshaped model.
  2. mapped_probs reproduces an arm's Z-edge probabilities: for exact edge weights, the merged Z-edge probabilities of
     the mapped sources against the weights' probabilities.
  3. Decoding the same samples, d = 9, data qubit or Z ancilla nearest the centre failing by factor f (uniform
     p = 0.003 elsewhere):
       plain14   round 14's decoder (Z detectors, check matrix, exact weights rounded to 3 decimals)
       plainDEM  the round-15 text DEM with exact probabilities, X and Z detectors, plain matching
       corr      the same DEM, correlated matching
       corr_map  correlated matching with the probabilities mapped from exact Z-edge weights (what an arm that knew
                 its Z edges exactly would get)
       corr_nom / plain14_nom   the same decoders with weights that do not know the failure
usage: python3 check15.py d shots seed kind f [f ...]
"""
import sys, os, time, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))
from model15 import base15, deformed15                                   # noqa: E402
from corr15 import (Sampler15, dem_text, corr_matching, plain_matching, exact_probs, mapped_probs, y_of,
                    p_of)                                                 # noqa: E402
from run3 import base_model, deformed_model                              # noqa: E402
from sampler import Sampler, build_matching, weights_from_p              # noqa: E402
from arms import WMIN                                                    # noqa: E402
import deform                                                            # noqa: E402
from model import P_REF                                                  # noqa: E402

CH = 250   # epochs per sampling chunk, as round 14
BPE = 20


def nearest(cs, d):
    return sorted(cs, key=lambda c: ((c[0] - d) ** 2 + (c[1] - d) ** 2, c))[0]


def check_sampler(b, md, seed):
    rng = np.random.default_rng(seed)
    f = np.exp(rng.normal(0, 0.35, b.G)) * 3.0
    f[rng.integers(b.G)] *= 40
    fq = np.tile(f, (60, 1))
    out = {}
    for name, m in (('base', b), ('reshaped', md)):
        s14 = Sampler(m, np.random.default_rng(seed + 1))
        s15 = Sampler15(m, np.random.default_rng(seed + 1), np.random.default_rng(seed + 2))
        same = True; nx = 0
        for _ in range(3):
            X14, o14 = s14.sample(fq, BPE)
            Xz, Xx, o15 = s15.sample(fq, BPE)
            same &= bool((X14 == Xz).all() and (o14 == o15).all())
            nx += int(Xx.sum())
        out[name] = dict(z_and_obs_identical=same, x_events=nx)
    return out


def check_map(m, f):
    w = np.round(weights_from_p(m.edge_p(f), WMIN), 3)
    pe = 1 / (1 + np.exp(w))
    p = mapped_probs(m, w, np.full(m.G, 3.0))
    Pe = p_of(m.C @ y_of(p[:m.K]))
    one = np.asarray((m.C > 0).sum(0)).ravel() == 1            # sources with one Z-type piece
    pure = np.asarray(((m.C > 0).astype(np.int32) @ (~one).astype(np.int32))).ravel() == 0   # edges of such only
    rel = np.abs(Pe / pe - 1)
    return dict(edges=int(m.E), pure_edges=int(pure.sum()), max_rel_pure=float(rel[pure].max()),
                max_rel_all=float(rel.max()), median_rel_all=float(np.median(rel)))


def run(d, shots, seed, kind, fs):
    t0 = time.time()
    b = base15(d, m=base_model(d))
    q = nearest(deform.bulk_data(d) if kind == 'data' else deform.bulk_zanc(d), d)
    g = b.qgroup[q]
    md = deformed15(b, deformed_model(b, (q,)))
    res = dict(d=d, kind=kind, qubit=q, build_s=round(time.time() - t0, 1), sampler=check_sampler(b, md, seed))
    print(json.dumps(res), flush=True)
    f_nom = np.full(b.G, 0.003 / P_REF)
    w_nom = np.round(weights_from_p(b.edge_p(f_nom), WMIN), 3)
    m14_nom = build_matching(b, w_nom)
    mc_nom = corr_matching(dem_text(b, exact_probs(b, f_nom)))
    for fac in fs:
        f = f_nom.copy(); f[g] *= fac
        w = np.round(weights_from_p(b.edge_p(f), WMIN), 3)
        t1 = time.time()
        dec = dict(plain14=('14', build_matching(b, w)),
                   plainDEM=('pd', plain_matching(dem_text(b, exact_probs(b, f)))),
                   corr=('c', corr_matching(dem_text(b, exact_probs(b, f)))),
                   corr_map=('c', corr_matching(dem_text(b, mapped_probs(b, w, f_nom)))),
                   corr_nom=('c', mc_nom), plain14_nom=('14', m14_nom))
        tb = time.time() - t1
        s = Sampler15(b, np.random.default_rng(seed + int(fac) * 7 + 3), np.random.default_rng(seed + int(fac) * 7 + 4))
        fails = {k: 0 for k in dec}; tdec = {k: 0.0 for k in dec}; same_pd = 0; n = 0
        while n < shots:
            ne = min(CH, (shots - n) // BPE)
            Xz, Xx, o = s.sample(np.tile(f, (ne, 1)), BPE)
            D = np.ascontiguousarray(np.concatenate([Xz, Xx], 1))
            pr = {}
            for k, (typ, mt) in dec.items():
                t2 = time.time()
                if typ == '14':
                    pr[k] = mt.decode_batch(Xz)[:, 0]
                elif typ == 'pd':
                    pr[k] = mt.decode_batch(D)[:, 0]
                else:
                    pr[k] = mt.decode_batch(D, enable_correlations=True)[:, 0]
                tdec[k] += time.time() - t2
                fails[k] += int((pr[k] != o).sum())
            same_pd += int((pr['plain14'] == pr['plainDEM']).sum())
            n += ne * BPE
        r = dict(d=d, kind=kind, f=fac, shots=n, fails=fails, plain14_eq_plainDEM=same_pd / n,
                 map=check_map(b, f), build_s=round(tb, 2), us_per_shot={k: round(1e6 * v / n, 1) for k, v in tdec.items()})
        print(json.dumps(r), flush=True)


if __name__ == '__main__':
    d, shots, seed = map(int, sys.argv[1:4]); kind = sys.argv[4]
    run(d, shots, seed, kind, [float(x) for x in sys.argv[5:]])
