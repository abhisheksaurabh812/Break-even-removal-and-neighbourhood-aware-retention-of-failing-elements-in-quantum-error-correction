"""ideal_field15's sampler and decoder with --plain must reproduce ideal_field9's count (d = 9, data, L = 1, excl: 1963 in 2e6)."""
import sys
sys.argv = ['x', '--plain']
import ideal_field15 as I
import deform
from rectgen import layout
d, c = 9, (9, 9)
data, xm, zm = layout(d, d)
region = [q for q in list(data) + list(xm) + list(zm) if q != c and max(abs(q[0] - c[0]), abs(q[1] - c[1])) <= 4]
txt, _ = deform.circuit(d, d, 0.003, excl=[c], scale={q: 1.0 for q in region})
print('plain excl count', I.ler(txt, 2000000)[0], '(ideal_field9: 1963)', 'corr flag', I.CORR, flush=True)
import os
for f in os.listdir(I.TMP): os.remove(os.path.join(I.TMP, f))
os.rmdir(I.TMP)
