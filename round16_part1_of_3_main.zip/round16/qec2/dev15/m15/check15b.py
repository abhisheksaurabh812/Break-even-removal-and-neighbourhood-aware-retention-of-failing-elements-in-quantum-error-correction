"""
Where does the mapping lose against exact rates?  Same samples, d = 9, one centre qubit failing by factor f:
  corr        exact rates for every source
  corr_zx     exact rates for sources with Z-type pieces, reference rates for X-only sources
  corr_map    the mapping from exact Z-edge weights (X-only sources at reference rates)
  corr_map_x  the mapping, plus the failing qubit's X-only sources at its true factor (a twin that names the qubit
              and applies its size to every channel of it)
usage: python3 check15b.py d shots seed kind f [f ...]
"""
import sys, os, time, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))
from model15 import base15                                              # noqa: E402
from corr15 import Sampler15, dem_text, corr_matching, exact_probs, mapped_probs   # noqa: E402
from run3 import base_model                                             # noqa: E402
from sampler import weights_from_p                                      # noqa: E402
from arms import WMIN                                                   # noqa: E402
from model import P_REF                                                 # noqa: E402
from check15 import nearest, CH, BPE                                    # noqa: E402
import deform                                                           # noqa: E402


def run(d, shots, seed, kind, fs):
    b = base15(d, m=base_model(d)); b.__dict__.pop('pieces15', None)
    q = nearest(deform.bulk_data(d) if kind == 'data' else deform.bulk_zanc(d), d)
    g = b.qgroup[q]
    f_nom = np.full(b.G, 0.003 / P_REF)
    xo = np.arange(b.K15) >= b.K
    for fac in fs:
        f = f_nom.copy(); f[g] *= fac
        w = np.round(weights_from_p(b.edge_p(f), WMIN), 3)
        pe, pn = exact_probs(b, f), exact_probs(b, f_nom)
        p_zx = np.where(xo, pn, pe)
        p_map = mapped_probs(b, w, f_nom)
        p_mapx = p_map.copy(); sel = xo & (b.src_g15 == g); p_mapx[sel] = pe[sel]
        dec = {k: corr_matching(dem_text(b, p)) for k, p in
               (('corr', pe), ('corr_zx', p_zx), ('corr_map', p_map), ('corr_map_x', p_mapx))}
        s = Sampler15(b, np.random.default_rng(seed + int(fac) * 7 + 3), np.random.default_rng(seed + int(fac) * 7 + 4))
        fails = {k: 0 for k in dec}; n = 0
        pr_all = {k: [] for k in dec}; o_all = []
        while n < shots:
            ne = min(CH, (shots - n) // BPE)
            Xz, Xx, o = s.sample(np.tile(f, (ne, 1)), BPE)
            D = np.ascontiguousarray(np.concatenate([Xz, Xx], 1))
            for k, mt in dec.items():
                pr = mt.decode_batch(D, enable_correlations=True)[:, 0]
                fails[k] += int((pr != o).sum()); pr_all[k].append(pr != o)
            n += ne * BPE
        F = {k: np.concatenate(v) for k, v in pr_all.items()}
        pair = {}
        for k in ('corr_zx', 'corr_map', 'corr_map_x'):
            b_ = int((F['corr'] & ~F[k]).sum()); c_ = int((~F['corr'] & F[k]).sum())
            pair[k] = dict(only_exact=b_, only_this=c_, z=round((c_ - b_) / max(1.0, np.sqrt(b_ + c_)), 2))
        print(json.dumps(dict(d=d, kind=kind, f=fac, shots=n, fails=fails, paired_vs_exact=pair)), flush=True)


if __name__ == '__main__':
    d, shots, seed = map(int, sys.argv[1:4]); kind = sys.argv[4]
    run(d, shots, seed, kind, [float(x) for x in sys.argv[5:]])
