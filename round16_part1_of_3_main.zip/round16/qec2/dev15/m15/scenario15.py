"""Scenarios for round 15: run10.make_scenario, plus an optional targeted case for round 14's hole rule.

make_scenario(m, cfg, rng) returns run10.make_scenario(m, cfg, rng) unchanged unless cfg has 'follow'.  With
'follow' = dict(frac, delay or delay_rounds, fac, [dur]): after run10's scenario is drawn, each of its failures (in
order) draws, from the same generator and always in the same number, whether it is followed (probability frac), when
(U(delay_rounds) rounds after it starts, or a fraction U(delay) of its duration), on which qubit (one sharing a
stabilizer with it, run10.partners), how strongly (log-uniform in fac) and for how long (U(dur), default
U(defect_dur)).  A followed failure gets a second failure on that neighbour, starting while the first lasts: the case
round 14's rule handles (a new failure next to a qubit that may be switched out, after the reshaped circuit's own
estimates have settled without it)."""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
if QEC2 not in sys.path:
    sys.path.insert(0, QEC2)
from run10 import make_scenario as make_scenario10, partners          # noqa: E402


def make_scenario(m, cfg, rng):
    if 'follow' not in cfg:
        return make_scenario10(m, cfg, rng)
    F, flags, events = make_scenario10(m, {k: v for k, v in cfg.items() if k != 'follow'}, rng)
    fo = cfg['follow']
    er = cfg['bpe'] * m.T
    n_ep = F.shape[0]
    t = (np.arange(n_ep) + 0.5) * er
    lo, hi = fo['fac']
    absolute = 'delay_rounds' in fo
    dlo, dhi = fo['delay_rounds'] if absolute else fo['delay']
    nb = partners(m)
    events['follows'] = []
    for t0, dur, q, fac in list(events['defects']):
        u = rng.random(); x = rng.uniform(dlo, dhi); k = rng.random()
        fac2 = float(np.exp(rng.uniform(np.log(lo), np.log(hi)))); dur2 = float(rng.uniform(*fo.get('dur', cfg['defect_dur'])))
        if u >= fo['frac']:
            continue
        cand = nb[int(q)]
        q2 = int(cand[min(int(k * len(cand)), len(cand) - 1)])
        t1 = float(t0 + (x if absolute else x * dur))
        on = (t >= t1) & (t < t1 + dur2)
        F[on, q2] *= fac2
        flags[on] |= 4
        events['defects'].append([t1, dur2, q2, fac2])
        events['follows'].append([float(t0), int(q), t1, q2])
    return F, flags, events
