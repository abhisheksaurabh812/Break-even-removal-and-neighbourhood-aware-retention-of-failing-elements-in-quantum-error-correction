"""Round 15 (design input): ideal_field9.py's keep/switch-out crossover table with correlated matching.

Identical to ideal_field9.py (same region, grid, crossover rule, shot counts and resume behaviour; Stim sampling and
Stim's own detector error model of each circuit) except the decoder: PyMatching 2.4 with enable_correlations=True on
the X- and Z-type detectors (ideal_field9.py used plain matching, which ignores the X-type detectors).  With
--plain it reproduces ideal_field9.py's decoder, as a check.  Temporary files go to a private folder.
python3 ideal_field15.py <d> <data|zanc> <p> <L,L,...> <shots,shots,...> <out.json> [--plain]"""
import sys, os, json, time, subprocess, tempfile
import numpy as np
import pymatching
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, QEC2)
import deform                                   # noqa: E402
from rectgen import layout                      # noqa: E402
STIM = os.path.join(os.path.dirname(QEC2), 'bin', 'stim')

# ---- copied verbatim from ideal_field9.py (importing it would import ideal_excl, which makes a temp folder)
REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30)
FMAX = 300.0


def crossover(grid, keep, excl):
    prev = None
    for f, k in zip(grid, keep):
        if k >= excl:
            if prev is None:
                return float(f)
            f0, k0 = prev
            t = (np.log(excl) - np.log(k0)) / (np.log(k) - np.log(k0))
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 2)
        prev = (f, k)
    return None
# ----
CORR = '--plain' not in sys.argv
TMP = tempfile.mkdtemp(prefix='if15_', dir=HERE)


def ler(circ, shots, chunk=200000):
    """As ideal_excl.ler (same seeds 1, 2, ... per chunk), decoded with correlated matching unless --plain."""
    cf = os.path.join(TMP, 'c.stim'); df = os.path.join(TMP, 'c.dem'); of = os.path.join(TMP, 's.b8')
    open(cf, 'w').write(circ)
    subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
    m = pymatching.Matching.from_detector_error_model_file(df, enable_correlations=CORR)
    nd = m.num_detectors
    fails = 0; done = 0; seed = 1
    while done < shots:
        n = min(chunk, shots - done)
        subprocess.run([STIM, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        nb = (nd + 1 + 7) // 8
        raw = np.fromfile(of, dtype=np.uint8).reshape(n, nb)
        bits = np.unpackbits(raw, axis=1, bitorder='little')[:, :nd + 1]
        pred = m.decode_batch(bits[:, :nd], enable_correlations=CORR)[:, 0]
        fails += int((pred != bits[:, nd]).sum()); done += n; seed += 1
    return fails, shots


if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if x != '--plain']
    d = int(a[0]); kind = a[1]; p = float(a[2])
    Ls = [float(x) for x in a[3].split(',')]; shots = [int(float(x)) for x in a[4].split(',')]
    out = a[5]
    c = (d, d) if kind == 'data' else (d - 1, d - 1)
    assert c in (deform.bulk_data(d) if kind == 'data' else deform.bulk_zanc(d))
    data, xm, zm = layout(d, d)
    allq = list(data) + list(xm) + list(zm)
    region = [q for q in allq if q != c and max(abs(q[0] - c[0]), abs(q[1] - c[1])) <= 4]
    res = dict(d=d, kind=kind, qubit=list(c), p=p, region_size=len(region), rounds_per_shot=d, rows=[],
               decoder='correlated' if CORR else 'plain')
    if os.path.exists(out):
        prev = json.load(open(out))
        if prev.get('kind') == kind and prev.get('d') == d and prev.get('p') == p and prev.get('decoder') == res['decoder']:
            res['rows'] = prev['rows']
    have = {r['L'] for r in res['rows']}
    t0 = time.time()
    for L, n in zip(Ls, shots):
        if L in have:
            continue
        sc = {q: L for q in region}
        txt, _ = deform.circuit(d, d, p, excl=[c], scale=sc)
        ex, _ = ler(txt, n)
        grid = sorted(set(min(FMAX, round(L * r, 3)) for r in REL))
        keep = []
        for f in grid:
            txt, _ = deform.circuit(d, d, p, scale={**sc, c: f})
            k, _ = ler(txt, n)
            keep.append(k)
            print(kind, L, f, k, 'excl', ex, round(time.time() - t0), flush=True)
            if k >= ex:
                break
        row = dict(L=L, shots=n, excl=ex, grid=grid[:len(keep)], keep=keep, crossover=crossover(grid, keep, ex))
        res['rows'].append(row); res['rows'].sort(key=lambda r: r['L'])
        print(json.dumps(row), flush=True)
        json.dump(res, open(out, 'w'), indent=1)
    res['elapsed'] = round(time.time() - t0, 1)
    json.dump(res, open(out, 'w'), indent=1)
    for f in os.listdir(TMP):
        os.remove(os.path.join(TMP, f))
    os.rmdir(TMP)
