"""
Round-15 runner: run14.py with every arm decoded twice on the same samples, by round 14's plain matching and by
correlated matching.

Nothing an arm sees changes: the arms learn from the Z-type detection events only, as in round 14, those events are
drawn exactly as run14.py draws them (corr15.Sampler15 makes the same generator calls), and decoder outputs are never
fed back.  So every arm takes round 14's decisions, `fails` reproduces run14.py's output array for array, and
`fails_c` is the same run decoded with correlated matching.

Correlated decoding (corr15): the X-type detection events come from the X-type pieces of the same sources plus the
sources that flip only X-type detectors, which are drawn from separate generators (seed + offset + 1000003 for each
of run14's streams), so they change nothing else.  Each arm's decoder model is its round-14 Z-edge weights mapped to
per-source probabilities (corr15.mapped_probs) with the field the arm started from as the reference: the generic
fixed-weight arm (static-generic) starts from one uniform rate, every other arm from the calibration field.  The
oracle arms (oracle-policy) get the exact per-source probabilities.  Decoders are cached by (circuit, weights), as
in round 14.

Scenario: run10.make_scenario, unchanged, unless the configuration has 'follow' (scenario15.py: the targeted test of
round 14's hole rule, failures followed by a failure on a neighbouring qubit).

Usage:  python3 run15.py cfg.json out.npz [key=json ...]      cfg key 'decode': ['plain', 'corr'] (default both)
Everything else is run14.py's (see its docstring).
"""
import sys, os, json, time, hashlib
from collections import OrderedDict
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE); sys.path.insert(0, QEC2)
from model import P_REF                                                              # noqa: E402
from sampler import Sampler, build_matching, weights_from_p                          # noqa: E402
from arms import Stats, estimate, WMIN, Static                                       # noqa: E402
from run2 import build_arms                                                          # noqa: E402
from run3 import base_model, deformed_model, to_base                                 # noqa: E402
from arms7 import PolicyArm, OraclePolicy                                            # noqa: E402
from arms9 import PolicyArmField                                                     # noqa: E402
from arms11 import PolicyArmFieldWatch, Sized5                                       # noqa: E402
from arms12 import PolicyArmFieldWatch2, Sized6                                      # noqa: E402
from arms13 import Sized7, PolicyArmFieldWatch3                                      # noqa: E402
from arms14 import PolicyArmFieldWatch4, Quarantine                                  # noqa: E402
from scenario15 import make_scenario       # run10's, unless the configuration has 'follow'        # noqa: E402
from run10 import make_sized as make_sized10                                         # noqa: E402
from run14 import make_sized, field_args                                             # noqa: E402
from model15 import base15, deformed15                                               # noqa: E402
from corr15 import Sampler15, dem_text, corr_matching, exact_probs, mapped_probs     # noqa: E402
import model as _model, run3 as _run3                                                # noqa: E402
if os.environ.get('CACHE14'):        # a private copy of the round-14 model cache (new models are written there only)
    _model.CACHE = _run3.CACHE = os.environ['CACHE14']

XOFF = 1_000_003


def run(cfg, out):
    modes = cfg.get('decode', ['plain', 'corr'])
    do_plain, do_corr = 'plain' in modes, 'corr' in modes
    base = base_model(cfg['d'])
    t_b = time.time(); base15(cfg['d'], m=base); base.__dict__.pop('pieces15', None); t_b = time.time() - t_b
    rng_sc = np.random.default_rng(cfg['seed'])
    F, flags, events = make_scenario(base, cfg, rng_sc)
    n_ep, bpe, T = F.shape[0], cfg['bpe'], base.T
    er = bpe * T
    f_cal = F[0].astype(np.float64)
    pe = base.edge_p(f_cal); qd = base.det_rate(f_cal)
    qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f_cal)
    if any(sp.get('base') == 'est' for sp in cfg['arms']):
        cs = Sampler(base, np.random.default_rng(cfg['seed'] + 77777))
        st = Stats(base); nblk = cfg.get('cal_rounds', 1_000_000) // T
        for _ in range(0, nblk, 5000):
            Xc_, _ = cs.sample(np.tile(f_cal, (5000 // bpe, 1)), bpe); st.add(Xc_)
        pe_e, q_e, _, _ = estimate(base, st, pe, qcl, 10, 10)
        cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in base.int_classes])
    arms = []
    for i, sp in enumerate(cfg['arms']):
        k = sp['kind']
        if k == 'oracle-policy':
            arms.append(OraclePolicy(sp['name'], base, events, er, sp['mode'], sp.get('theta')))
        elif k == 'policy-field':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmField(sp['name'], base, inner, cal, *field_args(sp, cfg, i)))
        elif k == 'policy-field-watch':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch')))
        elif k == 'static-generic':
            arms.append(Static(sp['name'], base, dict(pe=base.edge_p(np.full(base.G, cfg['p_base'] / P_REF)))))
        elif k == 'quarantine':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner')) if sp.get('inner') else None
            arms.append(Quarantine(sp['name'], base, cal, inner=inner, **sp.get('q', {})))
        elif k == 'policy-field-watch4':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch4(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch'),
                                             hole=sp.get('hole')))
        elif k == 'policy-field-watch3':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch3(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch'),
                                             hole=sp.get('hole')))
        elif k == 'policy-field-watch2':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmFieldWatch2(sp['name'], base, inner, cal, *field_args(sp, cfg, i), watch=sp.get('watch')))
        elif k == 'policy':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArm(sp['name'], base, inner, sp['mode'], cal, sp.get('probe'), sp.get('t_rein'),
                                  seed=cfg['seed'] * 1000 + 17 * i, theta=sp.get('theta')))
        elif k in ('sized', 'sized2', 'sized3', 'sized4'):
            arms.append(make_sized(base, cal, sp))
        else:
            arms.append(build_arms(base, cal, [sp])[0])
    A = len(arms); names = [a.name for a in arms]
    # the field each arm's decoder starts from (reference for the X-type rates and for mapping its Z-edge weights)
    fref = [np.full(base.G, cfg['p_base'] / P_REF) if sp['kind'] == 'static-generic' else f_cal for sp in cfg['arms']]
    fref_id = [1 if sp['kind'] == 'static-generic' else 0 for sp in cfg['arms']]
    S = cfg['seed']
    xr = lambda off: np.random.default_rng(S + off + XOFF)
    sampler = Sampler15(base, np.random.default_rng(S + 99991), xr(99991))
    drng = np.random.default_rng(S + 55555); drng_X = xr(55555)
    drng_x = np.random.default_rng(S + 66666); drng_xX = xr(66666)     # separate stream for arms marked 'extra'
    drng_w = np.random.default_rng(S + 44444); drng_wX = xr(44444)     # and one for arms marked 'extra': 'w'
    drng_w2 = np.random.default_rng(S + 33333); drng_w2X = xr(33333)   # and one for arms marked 'extra': 'w2'
    drng_w3 = np.random.default_rng(S + 22222); drng_w3X = xr(22222)   # and one for arms marked 'extra': 'w3'
    drng_w4 = np.random.default_rng(S + 11111); drng_w4X = xr(11111)   # and one for arms marked 'extra': 'w4'
    drng_w5 = np.random.default_rng(S + 13131); drng_w5X = xr(13131)   # and one for arms marked 'extra': 'w5'
    drng_w6 = np.random.default_rng(S + 12121); drng_w6X = xr(12121)   # round 15: 'w6' and 'w7', drawn after all of
    drng_w7 = np.random.default_rng(S + 14141); drng_w7X = xr(14141)   # round 14's groups (they change nothing there)
    dmodels = {}; dsamplers = {}; dsamplers_x = {}; dsamplers_w = {}; dsamplers_w2 = {}; dsamplers_w3 = {}; dsamplers_w4 = {}; dsamplers_w5 = {}
    dsamplers_w6 = {}; dsamplers_w7 = {}
    ex = lambda sp: sp.get('extra', False)
    grp = [8 if ex(sp) == 'w7' else 7 if ex(sp) == 'w6' else 6 if ex(sp) == 'w5' else 5 if ex(sp) == 'w4' else 4 if ex(sp) == 'w3' else 3 if ex(sp) == 'w2' else 2 if ex(sp) == 'w' else (1 if ex(sp) else 0) for sp in cfg['arms']]

    max_models = int(cfg.get('max_models', 200)); dused = OrderedDict(); nbuilt = [0]; dseen = set(); t_m = [0.0]

    def dm(key):
        if key not in dmodels:
            t1 = time.time()
            md = deformed_model(base, key); deformed15(base, md); md.__dict__.pop('pieces15', None)
            dmodels[key] = md; nbuilt[0] += 1; dseen.add(key); t_m[0] += time.time() - t1
            for att in ('esig', 'dsig'):
                if hasattr(dmodels[key], att):
                    delattr(dmodels[key], att)
            dsamplers[key] = Sampler15(dmodels[key], drng, drng_X)
            dsamplers_x[key] = Sampler15(dmodels[key], drng_x, drng_xX)
        dused[key] = None; dused.move_to_end(key)
        return dmodels[key]

    def drop_models(in_use):
        for key in list(dused):
            if len(dmodels) <= max_models:
                break
            if key in in_use:
                continue
            del dused[key]; del dmodels[key]
            for D in (dsamplers, dsamplers_x, dsamplers_w, dsamplers_w2, dsamplers_w3, dsamplers_w4, dsamplers_w5,
                      dsamplers_w6, dsamplers_w7):
                D.pop(key, None)
            for C in (mcache, ccache):
                for hk in [hk for hk in C if hk[0] == key]:
                    del C[hk]

    fails = np.zeros((A, n_ep, bpe), np.uint8); fails_c = np.zeros((A, n_ep, bpe), np.uint8)
    nexcl = np.zeros((A, n_ep), np.uint8)
    mcache = OrderedDict(); ccache = OrderedDict(); builds = 0; decodes = 0; cbuilds = 0; cdecodes = 0
    t_cb = 0.0; t_cd = 0.0; t_pd = 0.0
    chunk = cfg.get('chunk', 250); t0 = time.time()
    for c0 in range(0, n_ep, chunk):
        c1 = min(n_ep, c0 + chunk)
        Xc, Xxc, oc = sampler.sample(F[c0:c1].astype(np.float64), bpe)
        for e in range(c0, c1):
            X0 = Xc[(e - c0) * bpe:(e - c0 + 1) * bpe]; o0 = oc[(e - c0) * bpe:(e - c0 + 1) * bpe]
            XX0 = Xxc[(e - c0) * bpe:(e - c0 + 1) * bpe]
            fe = F[e].astype(np.float64)
            true_pe = base.edge_p(fe)
            crr0 = (X0.astype(np.float32) @ base.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            keys = {}
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    keys[i] = a.plan(e)
                elif a.kind == 'policy':
                    keys[i] = a.config()
                else:
                    keys[i] = ()
            samples = {(): (X0, o0, XX0)}
            groups = ((0, None, None, None), (1, None, None, None), (2, dsamplers_w, drng_w, drng_wX),
                      (3, dsamplers_w2, drng_w2, drng_w2X), (4, dsamplers_w3, drng_w3, drng_w3X),
                      (5, dsamplers_w4, drng_w4, drng_w4X), (6, dsamplers_w5, drng_w5, drng_w5X),
                      (7, dsamplers_w6, drng_w6, drng_w6X), (8, dsamplers_w7, drng_w7, drng_w7X))
            for gnum, dsd, rz, rx in groups:
                for k in sorted(set(keys[i] for i in range(A) if grp[i] == gnum)):
                    if k and k not in samples:
                        md = dm(k)
                        if gnum == 0:
                            smp = dsamplers[k]
                        elif gnum == 1:
                            smp = dsamplers_x[k]
                        else:
                            if k not in dsd:
                                dsd[k] = Sampler15(md, rz, rx)
                            smp = dsd[k]
                        Xz, Xx, o = smp.sample(fe[None, :], bpe)
                        samples[k] = (Xz, o, Xx)
            preds = {}; cpreds = {}; Dfull = {}
            for i, a in enumerate(arms):
                k = keys[i]; md = dmodels[k] if k else None; mm = md if k else base
                X, o, XX = samples[k]
                if a.kind == 'oracle-policy':
                    w = weights_from_p(mm.edge_p(fe), WMIN)
                elif a.kind == 'policy':
                    w = a.weights(md, true_pe)
                else:
                    w = a.weights(true_pe)
                w = np.round(w, 3)
                wh = hashlib.md5(w.tobytes()).digest()
                if do_plain:
                    hk = (k, wh)
                    pr = preds.get(hk)
                    if pr is None:
                        mt = mcache.get(hk)
                        if mt is None:
                            mt = build_matching(mm, w); builds += 1; mcache[hk] = mt
                            if len(mcache) > 400:
                                mcache.popitem(last=False)
                        else:
                            mcache.move_to_end(hk)
                        t2 = time.time(); pr = mt.decode_batch(X)[:, 0]; t_pd += time.time() - t2
                        decodes += 1; preds[hk] = pr
                    fails[i, e] = pr ^ o
                if do_corr:
                    ck = (k, wh, 'o' if a.kind == 'oracle-policy' else fref_id[i])
                    pr = cpreds.get(ck)
                    if pr is None:
                        mt = ccache.get(ck)
                        if mt is None:
                            t2 = time.time()
                            ps = exact_probs(mm, fe) if a.kind == 'oracle-policy' else mapped_probs(mm, w, fref[i])
                            mt = corr_matching(dem_text(mm, ps)); cbuilds += 1; ccache[ck] = mt
                            t_cb += time.time() - t2
                            if len(ccache) > int(cfg.get('max_corr_decoders', 150)):
                                ccache.popitem(last=False)
                        else:
                            ccache.move_to_end(ck)
                        if k not in Dfull:
                            Dfull[k] = np.ascontiguousarray(np.concatenate([X, XX], 1))
                        t2 = time.time(); pr = mt.decode_batch(Dfull[k], enable_correlations=True)[:, 0]
                        t_cd += time.time() - t2; cdecodes += 1; cpreds[ck] = pr
                    fails_c[i, e] = pr ^ o
                nexcl[i, e] = len(k)
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    continue
                if a.kind == 'policy':
                    k = keys[i]
                    a.update(samples[k][0], crr0 if not k else None, dmodels[k] if k else None, base.AggD, e, T, fe, to_base)
                else:
                    a.update(X0, crr0)
            if len(dmodels) > max_models:
                drop_models(set(keys.values()))
        if cfg.get('verbose'):
            print(f'{c1}/{n_ep} {time.time() - t0:.0f}s builds={builds} cbuilds={cbuilds} dmodels={len(dmodels)}',
                  file=sys.stderr, flush=True)
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, fails_c=fails_c, nexcl=nexcl, flags=flags, names=np.array(names),
                        cfg=json.dumps(cfg), events=json.dumps(events), info=json.dumps(info), f0=f_cal)
    tot = fails.reshape(A, -1).sum(1); tot_c = fails_c.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes, cbuilds=cbuilds,
                          cdecodes=cdecodes, t_base15=round(t_b, 2), t_models15=round(t_m[0], 1),
                          t_plain_decode=round(t_pd, 1), t_corr_build=round(t_cb, 1), t_corr_decode=round(t_cd, 1),
                          deformed_configs=len(dseen), model_loads=nbuilt[0], totals=dict(zip(names, tot.tolist())),
                          totals_corr=dict(zip(names, tot_c.tolist())),
                          excluded_epochs=dict(zip(names, (nexcl > 0).sum(1).tolist())),
                          n_defects=len(events['defects']), n_bursts=len(events['bursts']))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
