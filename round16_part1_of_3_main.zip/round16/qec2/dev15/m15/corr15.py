"""
Round-15 sampling and correlated decoding on model15's extended models.

Sampler15  Draws the round-14 sources exactly as sampler.Sampler does (same generator, same calls, so the Z-type
           detection events and observable flips are identical to round 14's for the same stream), adds their
           X-type detection events, then draws the X-only sources from a second generator.
dem_text   A decomposed detector error model for given per-source probabilities: sources with identical graphlike
           pieces are merged into one line (p = (1 - prod(1 - 2 p_k)) / 2), one line per group, in a fixed order.
corr_matching / plain_matching   PyMatching 2.4 graphs from that text (no file; pymatching's own DEM parser).
mapped_probs  Per-source probabilities for an arm known only through its Z-edge weights (every round-14 arm):
           in y = -log(1 - 2p) units, which add over the sources of an edge, each source with Z-type pieces is
           scaled by the arm's ratio y_e(arm) / y_e(reference) on its Z-type edges (geometric mean over its pieces),
           so the arm's Z-edge probabilities are reproduced exactly for sources with one Z-type piece; X-only
           sources keep the reference rate.  The reference is the field the arm started from.
"""
import numpy as np
from scipy.sparse import csr_matrix
import pymatching
from pymatching import _cpp_pymatching as _cpp_pm


class Sampler15:
    def __init__(self, m, rng, rng_x):
        self.m, self.rng, self.rng_x = m, rng, rng_x
        self.O = m.src_obs.astype(np.int32)
        self.SXz = m.SX[:m.K].tocsr(); self.SXx = m.SX[m.K:].tocsr()
        self.px = m.p_ref15[m.K:]; self.gx = m.src_g15[m.K:]

    @staticmethod
    def _draw(rng, p_ref, src_g, fq_ep, bpe):
        """sampler.Sampler.sample's draw, line for line."""
        K = len(p_ref)
        n_ep = fq_ep.shape[0]; N = n_ep * bpe
        pk = np.clip(p_ref[None, :] * fq_ep[:, src_g], 0, 0.45).astype(np.float32)
        pmax = np.maximum(pk.max(0), 1e-12)
        c = rng.binomial(N, pmax)
        kk = np.repeat(np.arange(K), c)
        pos = rng.integers(0, N, size=kk.size)
        while True:
            key = kk.astype(np.int64) * N + pos
            order = np.argsort(key, kind='stable')
            ks = key[order]
            dup = np.zeros(ks.size, bool); dup[1:] = ks[1:] == ks[:-1]
            if not dup.any():
                break
            idx = order[dup]
            pos[idx] = rng.integers(0, N, size=idx.size)
        acc = rng.random(kk.size) < pk[pos // bpe, kk] / pmax[kk]
        return kk[acc], pos[acc], N

    def sample(self, fq_ep, bpe):
        """Returns Z-type events (N, nZ) uint8, X-type events (N, nX) uint8, observable flips (N,) uint8."""
        m = self.m
        kk, pos, N = self._draw(self.rng, m.p_ref, m.src_g, fq_ep, bpe)
        A = csr_matrix((np.ones(kk.size, np.int32), (pos, kk)), shape=(N, m.K))
        X = A @ m.S
        X.data %= 2
        obs = (A @ self.O) % 2
        XX = A @ self.SXz
        kx, px, _ = self._draw(self.rng_x, self.px, self.gx, fq_ep, bpe)
        Ax = csr_matrix((np.ones(kx.size, np.int32), (px, kx)), shape=(N, m.Kx))
        XX = XX + Ax @ self.SXx
        XX.data %= 2
        return (X.toarray().astype(np.uint8), XX.toarray().astype(np.uint8),
                np.asarray(obs).ravel().astype(np.uint8))


def y_of(p):
    return -np.log1p(-2 * np.clip(p, 0, 0.4999999))


def p_of(y):
    return -0.5 * np.expm1(-y)


def dem_text(m, p):
    """p: per-source probabilities (K15)."""
    Y = np.bincount(m.dem_group, y_of(p), m.ndem)
    P = p_of(Y)
    body = [f'error({a:.6e}) {b}' for a, b in zip(P, m.dem_lines) if a > 1e-12]
    body.append(f'detector D{m.ndet - 1}')
    return '\n'.join(body) + '\n'


def corr_matching(text):
    mt = pymatching.Matching()
    mt._matching_graph = _cpp_pm.detector_error_model_to_matching_graph(text, enable_correlations=True)
    return mt


def plain_matching(text):
    mt = pymatching.Matching()
    mt._matching_graph = _cpp_pm.detector_error_model_to_matching_graph(text, enable_correlations=False)
    return mt


def exact_probs(m, f):
    return np.clip(m.p_ref15 * f[m.src_g15], 0, 0.45)


def mapped_probs(m, w, f_ref):
    """w: the arm's Z-edge weights on model m (round 14's decoder: w = max(log((1-p)/p), WMIN), rounded)."""
    pe = 1.0 / (1.0 + np.exp(w))
    p0 = exact_probs(m, f_ref)
    y0 = y_of(p0)
    Ye0 = m.C @ y0[:m.K]
    lt = np.log(y_of(pe)) - np.log(np.maximum(Ye0, 1e-300))
    num = m.C.T @ lt
    den = np.asarray(m.C.sum(0)).ravel()
    ls = np.where(den > 0, num / np.maximum(den, 1), 0.0)
    y = y0.copy()
    y[:m.K] *= np.exp(ls)
    return p_of(y)
