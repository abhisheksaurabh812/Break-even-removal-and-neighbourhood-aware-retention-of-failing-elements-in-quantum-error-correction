"""Independent recount of round-15 decision numbers straight from the raw files (no code shared with analyse15.py /
analyse8.py): correlated matching (fails_c), which the rules use.
python3 dev15/m15/recount15.py > out15/recount15.json   (from qec2/; OUT=... for mock tests)"""
import json, os, math
import numpy as np

OUT = os.environ.get('OUT', 'out15')
KEY = 'fails_c'


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z[KEY][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b, paths_b=None):
    paths_b = paths if paths_b is None else paths_b
    if not all(os.path.exists(p) for p in paths + paths_b):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths_b]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    n = len(paths)
    pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
    st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
    return dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
                p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()],
                boot95=[round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)])


P = lambda t, r: [f'{OUT}/{t}_s{x}.npz' for x in r]
T = dict(d9_mixed=range(11101, 11111), d9_severe=range(11201, 11206), d9_moderate=range(11301, 11306),
         d9_realistic=range(11001, 11011), pairs_mixed=range(11401, 11411), long_severe=range(11501, 11511),
         long_mixed=range(11601, 11611), d9_hwlike=range(11701, 11711))
g = 'sz_w15'
LIST = [('d9_mixed', g, 'sz'), ('d9_mixed', g, 'sz_all'), ('d9_severe', g, 'sz'), ('d9_moderate', g, 'sz'),
        ('d9_realistic', g, 'loc'), ('pairs_mixed', g, 'sz'), ('long_severe', g, 'sz'), ('long_mixed', g, 'sz'),
        ('long_mixed', g, 'sz_all'), ('d9_hwlike', g, 'sz')]
LIST += [(t, g, ref) for t in T for ref in ('sz_w14', 'cut', 'cut15')]
res = {}
for t, a, b in LIST:
    res[f'{t}: {a} vs {b}'] = pair(P(t, T[t]), a, b)
allp = sum((P(t, T[t]) for t in T), [])
res['C1_pooled_all: sz_w15 vs sz_w14'] = pair(allp, g, 'sz_w14')
res['P1_pooled_all: sz_w15 vs cut'] = pair(allp, g, 'cut')
res['P1b_pooled_all: sz_w15 vs cut15'] = pair(allp, g, 'cut15')
sub = sum(([f'{OUT}/{t}_s{x}.npz' for x in list(T[t])[:4]] for t in T), [])
subp = sum(([f'{OUT}/prior_{t}_s{x}.npz' for x in list(T[t])[:4]] for t in T), [])
for i, q in ((2, 'sieg'), (3, 'sieg_rw')):
    res[f'P{i}_pooled_prior_subset: sz_w15 vs {q}'] = pair(sub, g, q, subp)
T2 = dict(d7_holenbr=range(11801, 11811))                  # targeted test of round 14's hole rule (C2b)
for t, r in T2.items():
    res[f'C2b_{t}: sz_w14 vs sz_w13'] = pair(P(t, r), 'sz_w14', 'sz_w13')
print(json.dumps(res, indent=1))
