"""Round 15, lab-practice baselines (reported, no rule; PREREG_round15.md).
python3 dev15/m15/analyse15b.py > out15/res_15b.json   (from qec2/)
As analyse14b.py, for both decoders: the baseline runs (out15/base_<test>_s<seed>.npz: fix_gen, fix_cal, refit_1s)
decode the same main-stream detection events as the main runs of the same seed; per seed the two files' arms are
combined and compared epoch by epoch.  A test is reported only when every seed has both files."""
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, QEC2); sys.path.insert(0, HERE)
import analyse8 as A                                     # noqa: E402
from analyse15 import SEEDS, OUT, DEC                    # noqa: E402

GATES = ('sz_w15', 'sz_w14', 'sz', 'loc', 'cut', 'cut15')
BASES = ('fix_gen', 'fix_cal', 'refit_1s')


def merged(test):
    out = {d: [] for d in DEC}
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not (os.path.exists(f'{OUT}/done/{n}') and os.path.exists(f'{OUT}/done/base_{n}')):
            return None
        r = np.load(f'{OUT}/{n}.npz', allow_pickle=True); b = np.load(f'{OUT}/base_{n}.npz', allow_pickle=True)
        names = [str(x) for x in r['names']] + [str(x) for x in b['names']]
        for d, k in DEC.items():
            assert r[k].shape[1:] == b[k].shape[1:], n
            F = np.concatenate([r[k].sum(2, keepdims=True), b[k].sum(2, keepdims=True)]).astype(np.int64)
            out[d].append(dict(names=names, fails=F))
        del r, b
    return out


def main():
    res = {d: {} for d in DEC}
    pool = {d: [] for d in DEC}
    for test in SEEDS:
        m = merged(test)
        if not m:
            continue
        for d in DEC:
            rs = m[d]
            R = dict(seeds=len(rs), totals=A.totals(rs))
            for g in GATES + ('fix_cal', 'refit_1s'):
                for b in BASES:
                    if g == b or (g in BASES and BASES.index(g) <= BASES.index(b)):
                        continue
                    x = A.compare(rs, g, b); x['boot95'] = A.bootstrap(rs, g, b)
                    R[f'{g} vs {b}'] = x
            res[d][test] = R
            pool[d] += rs
    for d in DEC:
        if len(res[d]) == len(SEEDS):
            P = dict(seeds=len(pool[d]), totals=A.totals(pool[d]))
            for g in GATES:
                for b in BASES:
                    x = A.compare(pool[d], g, b); x['boot95'] = A.bootstrap(pool[d], g, b)
                    P[f'{g} vs {b}'] = x
            res[d]['all_tests_pooled'] = P
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
