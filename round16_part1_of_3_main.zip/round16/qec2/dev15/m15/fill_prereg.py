"""Fill the round-15 pre-registration draft's remaining fields from the final tables and write PREREG_round15.md.
python3 dev15/m15/fill_prereg.py "<date and time>" [devcheck text file]      (from qec2/)"""
import json, os, sys, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
s = open(os.path.join(HERE, 'PREREG_round15_draft.md')).read()
tables = subprocess.run([sys.executable, os.path.join(HERE, 'tables_md.py')], capture_output=True, text=True,
                        check=True, cwd=QEC2).stdout
lines = tables.strip().split('\n')
md = [l for l in lines if l.startswith('|')]
extra = [l for l in lines if l.startswith('Switched-out failures')]
one = {}
for d in (9, 7):
    for k in ('data', 'zanc'):
        j = json.load(open(os.path.join(HERE, 'tables', f'field_table15_d{d}_{k}.json')))
        one[(d, k)] = [r['crossover'] for r in j['rows'] if r['L'] == 1.0][0]
tab_text = ('Crossovers (failure size f*, in units of the base rate, above which switching the qubit out beats keeping it\n'
            'with exact rates), plain matching (round 9-10 tables, used by `sz_w14`) -> correlated matching (used by\n'
            '`sz_w15`):\n\n' + '\n'.join(md) + '\n\n' + '\n'.join(extra) + '.')
cut = (f"d = 9: {one[(9, 'data')]:g}x data qubit, {one[(9, 'zanc')]:g}x Z ancilla; d = 7: {one[(7, 'data')]:g}x data qubit, "
       f"{one[(7, 'zanc')]:g}x Z ancilla")
s = s.replace('{{DATE}}', sys.argv[1]).replace('{{TABLES}}', tab_text).replace('{{CUT15}}', cut)
if len(sys.argv) > 2:
    s = s.replace('{{DEVCHECK}}', open(sys.argv[2]).read().rstrip())
assert '{{' not in s, [x for x in ('{{DATE}}', '{{TABLES}}', '{{CUT15}}', '{{DEVCHECK}}') if x in s]
open(os.path.join(QEC2, 'PREREG_round15.md'), 'w').write(s)
print('PREREG_round15.md written;', cut)
