"""Markdown for the pre-registration: the correlated-matching crossover tables (tables/field_table15_*.json) beside
round 9-10's plain-matching tables (the ones sz_w14 uses).   python3 dev15/m15/tables_md.py   (from qec2/)"""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
PLAIN = {(9, 'data'): 'out10/field_table_d9_data.json', (9, 'zanc'): 'out10/field_table_d9_zanc.json',
         (7, 'data'): 'out9/field_table_data.json', (7, 'zanc'): 'out9/field_table_zanc.json'}


def rows(fn):
    j = json.load(open(fn))
    return {r['L']: r for r in j['rows']}, j


cols = []
for d in (9, 7):
    for k in ('data', 'zanc'):
        p, _ = rows(os.path.join(QEC2, PLAIN[(d, k)]))
        c, jc = rows(os.path.join(HERE, 'tables', f'field_table15_d{d}_{k}.json'))
        assert jc['decoder'] == 'correlated'
        cols.append((d, k, p, c, jc.get('elapsed')))
Ls = sorted(cols[0][3])
name = dict(data='data qubit', zanc='Z ancilla')
print('| L | ' + ' | '.join(f'd = {d} {name[k]}: plain -> correlated' for d, k, *_ in cols) + ' |')
print('|---|' + '---|' * len(cols))
f = lambda x: '-' if x is None else f'{x:g}'
for L in Ls:
    print(f'| {L:g} | ' + ' | '.join(f"{f(p[L]['crossover'])} -> **{f(c[L]['crossover'])}**" for d, k, p, c, _ in cols) + ' |')
print()
print('Switched-out failures at L = 1 (2,000,000 shots), plain -> correlated: ' +
      '; '.join(f"d = {d} {name[k]} {p[1.0]['excl']:,} -> {c[1.0]['excl']:,}" for d, k, p, c, _ in cols))
print('Elapsed (s):', {f'd{d}_{k}': e for d, k, p, c, e in cols})
one = {d: {k: c[1.0]['crossover'] for dd, k, p, c, _ in cols if dd == d} for d in (9, 7)}
print('cut15 thresholds (L = 1):', one)
