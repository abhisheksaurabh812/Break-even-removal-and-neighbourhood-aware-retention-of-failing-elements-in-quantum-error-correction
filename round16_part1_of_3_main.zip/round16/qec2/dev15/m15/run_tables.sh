#!/bin/bash
# Correlated-matching crossover tables for round 15 (ideal_field15.py), same levels and shot counts as rounds 9-10:
# L = 1, 1.5, 2 at 2e6 shots, L = 3, 4, 6, 8 at 1e6.  One table per call; run d9 data and d9 zanc side by side, then
# d7 data and d7 zanc.  Resumable: rows already in the output file are skipped (a level in progress is redone).
# usage: run_tables.sh <d> <data|zanc> [autogroup nice]      (PYTHONPATH must hold the libraries)
cd "$(dirname "$0")"
D=$1; K=$2; NICE=${3:-0}
echo $NICE > /proc/self/autogroup
mkdir -p tables
echo "$(date '+%d %H:%M:%S') start d$D $K" >> tables/log_$K.txt
python3 ideal_field15.py $D $K 0.003 1,1.5,2,3,4,6,8 2e6,2e6,2e6,1e6,1e6,1e6,1e6 tables/field_table15_d${D}_$K.json >> tables/log_$K.txt 2>&1
rc=$?
echo "$(date '+%d %H:%M:%S') end d$D $K rc=$rc" >> tables/log_$K.txt
exit $rc
