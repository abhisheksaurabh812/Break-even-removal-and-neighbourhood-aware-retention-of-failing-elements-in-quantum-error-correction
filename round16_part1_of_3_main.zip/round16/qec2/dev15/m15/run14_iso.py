"""run14.py, unchanged, with its model cache pointed at a private copy (env CACHE14), so that a development run can
never write into the cache round 14's jobs are reading.  usage: CACHE14=dir python3 run14_iso.py cfg.json out.npz [k=v]"""
import os, sys, json
QEC2 = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, QEC2)
import model, run3        # noqa: E402
model.CACHE = run3.CACHE = os.environ['CACHE14']
import run14              # noqa: E402

if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run14.run(cfg, sys.argv[2])
