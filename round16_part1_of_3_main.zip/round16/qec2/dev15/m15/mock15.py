"""Mock round-15 output for testing analyse15 / analyse15b / recount15 / verify15 (no round-15 run is used).
python3 dev15/m15/mock15.py out_dir [n_epochs]       (from qec2/; reads finished round-14 main runs only)
Every round-15 slot (main, prior, base) is built from a finished round-14 main run: the same test and seed position
when that run has finished, else another finished run of the same distance.  Arms: loc, sz, sz_all, sz_w14, cut from
the same arms; sz_w15 from sz_w13; cut15 from cut with sparse random flips.  Prior files: sz (identical to the main
file's), sieg <- loc, sieg_rw <- sz_all.  Baseline files: fix_gen <- loc, fix_cal <- sz, refit_1s <- sz_all.
fails_c keeps each plain failure with probability 0.4 under one mask per seed (shared by every file of the seed, so
the main-stream check holds); arrays are cut to the first n_epochs epochs (default 6000)."""
import os, sys, json, copy
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from analyse15 import SEEDS, PRIOR_SEEDS, TARGET         # noqa: E402

R14 = dict(d9_mixed=range(10101, 10111), d9_severe=range(10201, 10206), d9_moderate=range(10301, 10306),
           d9_realistic=range(10001, 10011), pairs_mixed=range(10401, 10411), long_severe=range(10501, 10511),
           long_mixed=range(10601, 10611), d9_hwlike=range(10701, 10711))
D7 = ('pairs_mixed', 'long_severe', 'long_mixed')


def finished(t):
    return [f'out14/{t}_s{s}.npz' for s in R14[t] if os.path.exists(f'out14/done/{t}_s{s}')]


def source(t, i):
    own = f'out14/{t}_s{list(R14[t])[i]}.npz'
    if os.path.exists(own) and os.path.exists(f'out14/done/{t}_s{list(R14[t])[i]}'):
        return own
    pool = sum((finished(u) for u in R14 if (u in D7) == (t in D7)), [])
    return pool[i % len(pool)]


def write(fn, src, arms, n_ep, keep, rng_x, extra_flip=()):
    z = np.load(src, allow_pickle=True)
    names = [str(x) for x in z['names']]
    cfg = json.loads(str(z['cfg'])); info = json.loads(str(z['info']))
    F = z['fails'][:, :n_ep]; N = z['nexcl'][:, :n_ep]
    rows = []; rows_c = []; nx = []; acfg = []; ainfo = {}
    for new, old in arms:
        k = names.index(old)
        f = F[k].copy()
        if new in extra_flip:
            f ^= (rng_x.random(f.shape) < 0.002).astype(np.uint8)
        rows.append(f); rows_c.append(f & keep); nx.append(N[k])
        a = copy.deepcopy([x for x in cfg['arms'] if x['name'] == old][0]); a['name'] = new
        if new == 'cut15':
            a['theta'] = {'data': 14.5, 'zanc': 9.0}
        acfg.append(a); ainfo[new] = info.get(old, {})
    cfg['arms'] = acfg; cfg['decode'] = ['plain', 'corr']
    np.savez_compressed(fn, fails=np.array(rows), fails_c=np.array(rows_c), nexcl=np.array(nx), flags=z['flags'][:n_ep],
                        names=np.array([a for a, _ in arms]), cfg=json.dumps(cfg), events=str(z['events']),
                        info=json.dumps(ainfo), f0=z['f0'])


def main(out, n_ep=6000):
    os.makedirs(f'{out}/done', exist_ok=True)
    MAIN = [('loc', 'loc'), ('sz', 'sz'), ('sz_all', 'sz_all'), ('sz_w14', 'sz_w14'), ('cut', 'cut'), ('sz_w15', 'sz_w13'),
            ('cut15', 'cut')]
    PRI = [('sz', 'sz'), ('sieg', 'loc'), ('sieg_rw', 'sz_all')]
    BAS = [('fix_gen', 'loc'), ('fix_cal', 'sz'), ('refit_1s', 'sz_all')]
    n = 0
    for t, seeds in SEEDS.items():
        for i, s in enumerate(seeds):
            src = source(t, i)
            keep = (np.random.default_rng(s).random((n_ep, 20)) < 0.4).astype(np.uint8)
            jobs = [(f'{t}_s{s}', MAIN, ('cut15',)), (f'base_{t}_s{s}', BAS, ())]
            if s in PRIOR_SEEDS[t]:
                jobs.append((f'prior_{t}_s{s}', PRI, ()))
            for name, arms, xf in jobs:
                write(f'{out}/{name}.npz', src, arms, n_ep, keep, np.random.default_rng(s + 1), xf)
                open(f'{out}/done/{name}', 'w').write('1\n'); n += 1
    for t, seeds in TARGET.items():                  # targeted test: round-14 neighbouring-failure runs, sz_w13 kept
        for i, s in enumerate(seeds):
            src = source('pairs_mixed', i)
            keep = (np.random.default_rng(s).random((n_ep, 20)) < 0.4).astype(np.uint8)
            write(f'{out}/{t}_s{s}.npz', src, MAIN + [('sz_w13', 'sz_w13')], n_ep, keep, np.random.default_rng(s + 1),
                  ('cut15',))
            open(f'{out}/done/{t}_s{s}', 'w').write('1\n'); n += 1
    print(n, 'mock files in', out)


if __name__ == '__main__':
    main(sys.argv[1], *(int(x) for x in sys.argv[2:3]))
