"""Writes jobs15.txt (round 15): the 70 main runs, the 10 runs of the targeted test (round 14's hole rule; estimate
from round 14's long-severe runs, the same length, one arm more), the 32 prior-art runs (first four seeds of each test), then
the 70 lab-practice baseline runs, in round 14's order.   python3 dev15/m15/gen_jobs15.py   (run from qec2/)
Every job is dev15/m15/run15.py, which decodes every arm by plain and by correlated matching.
Estimated seconds per job: round 14's mean run time for the test (out14/done/, the same machine) times the round-15
factor for the kind of run (FACTOR below; from the development runs), rounded up to 50 s.  A batch's
budget check (elapsed + 1.3 x estimate < budget) keeps every batch inside the 2-hour limit on background work."""
import os, sys, json, math
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
from analyse15 import SEEDS, PRIOR_SEEDS, TARGET  # noqa: E402

# round-15 time / round-14 time, by kind of run: correlated decoding about 6x plain, and for the prior-art runs, which
# visit hundreds of reshaped circuits, rebuilding models and decoders (at most 40 models kept, against 200 in round
# 14); the realistic and hardware-like prior-art runs visited about 1,100 reshaped circuits each in round 14
FACTOR = dict(main=2.4, prior=3.5, prior_heavy=5.0, base=3.8)
HEAVY = ('d9_realistic', 'd9_hwlike')
RUN = 'python3 dev15/m15/run15.py'


def r14_mean(prefix, test):
    """Mean round-14 run time (s) of <prefix><test>_s<seed> from out14/done/ (if none has finished: round 14's
    estimate for it in jobs14.txt)."""
    ts = []
    d = os.path.join(QEC2, 'out14', 'done')
    for f in os.listdir(d):
        if f.startswith(f'{prefix}{test}_s') and (prefix or not f.startswith(('prior_', 'base_'))):
            ts.append(float(open(os.path.join(d, f)).read()))
    if ts:
        return sum(ts) / len(ts)
    for line in open(os.path.join(QEC2, 'jobs14.txt')):
        if line.startswith(f'{prefix}{test}_s'):
            return float(line.split()[1])
    raise KeyError((prefix, test))


def est(kind, test):
    prefix = dict(main='', prior='prior_', base='base_')[kind]
    f = FACTOR['prior_heavy'] if kind == 'prior' and test in HEAVY else FACTOR[kind]
    return int(50 * math.ceil(f * r14_mean(prefix, test) / 50))


def interleave(a, b):
    out = []
    for i in range(max(len(a), len(b))):
        out += ([a[i]] if i < len(a) else []) + ([b[i]] if i < len(b) else [])
    return out


def main(fn='jobs15.txt'):
    L = lambda t: [(t, s) for s in SEEDS[t]]
    order = interleave(L('long_severe'), L('long_mixed'))
    order += interleave(L('d9_mixed'), L('d9_severe'))
    order += interleave(L('d9_realistic'), L('pairs_mixed'))
    order += interleave(L('d9_hwlike'), L('d9_moderate'))
    assert len(order) == 70 and len(set(order)) == 70
    prior = [(t, s) for t, s in order if s in PRIOR_SEEDS[t]]
    assert len(prior) == 32
    tot = 0; longest = 0
    with open(fn, 'w') as f:
        target = [(t, s) for t in TARGET for s in TARGET[t]]
        for kind, pre, lst in (('main', '', order), ('target', '', target), ('prior', 'prior_', prior), ('base', 'base_', order)):
            for t, s in lst:
                n = f'{pre}{t}_s{s}'
                e = est(kind, t) if kind != 'target' else int(50 * math.ceil(FACTOR['main'] * 8 / 7 * r14_mean('', 'long_severe') / 50))
                tot += e; longest = max(longest, e)
                f.write(f'{n} {e} - {RUN} cfg15/{pre}{t}.json out15/{n}.npz seed={s} > out15/{n}.json\n')
    print(f'{len(order) + len(target) + len(prior) + len(order)} jobs; factors {FACTOR}; total estimate {tot / 3600:.1f} h of CPU, '
          f'{tot / 7200:.1f} h on two workers; longest job {longest / 60:.0f} min')


if __name__ == '__main__':
    main(*(sys.argv[1:2]))
