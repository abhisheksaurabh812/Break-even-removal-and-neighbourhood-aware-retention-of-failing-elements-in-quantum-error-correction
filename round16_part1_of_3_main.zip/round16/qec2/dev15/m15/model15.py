"""
Round-15 models: round 14's per-qubit-tagged source models with the X-type detectors and every source kept.

Round 14 (model.circuit_model, run3.deformed_model) keeps only the Z-type detectors and the sources that flip one of
them.  Correlated matching also needs the X-type detectors, the sources that flip only X-type detectors, and each
source's decomposition into graphlike pieces.  This module adds them without touching the round-14 part:

  * detectors 0..nZ-1 are round 14's Z-type detectors, in round 14's order; nZ..nZ+nX-1 are the X-type detectors;
  * sources 0..K-1 are round 14's sources, in round 14's order, with the same p_ref, qubit and observable flip;
    sources K..K+Kx-1 flip only X-type detectors;
  * each source keeps its graphlike pieces as `stim analyze_errors --decompose_errors` gives them.

One Stim call per circuit: every noise channel is split by qubit and tagged with it (two-qubit channels half to each
qubit, exactly as model.filter_for_qubit does), and Stim keeps errors with different tags apart.  `extend` checks that
the tagged analysis reproduces round 14's sources (qubit, Z-type detectors, observable, probability), in round 14's
order, before it adds anything; any mismatch raises.

Nothing here writes outside dev15/ (the round-14 caches are only read).
"""
import os, sys, subprocess, hashlib
import numpy as np
from scipy.sparse import csr_matrix

HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
if QEC2 not in sys.path:
    sys.path.insert(0, QEC2)
from model import circuit_model, gen_circuit, unroll, _split, P_REF, STIM   # noqa: E402
import deform                                                                 # noqa: E402

CACHE15 = os.path.join(HERE, 'cache15')
NOISE1 = ('DEPOLARIZE1', 'X_ERROR', 'Z_ERROR', 'Y_ERROR')


def tag_circuit(lines):
    out = []
    for l in lines:
        name, arg, tg = _split(l)
        if name in NOISE1:
            for t in tg:
                out.append(f'{name}[q{t}]({arg}) {t}')
        elif name == 'DEPOLARIZE2':
            t = list(map(int, tg))
            for a, b in zip(t[0::2], t[1::2]):
                out.append(f'DEPOLARIZE2[q{a}]({float(arg) / 2}) {a} {b}')
                out.append(f'DEPOLARIZE2[q{b}]({float(arg) / 2}) {a} {b}')
        else:
            out.append(l)
    return out


def analyze_tagged(lines):
    r = subprocess.run([STIM, 'analyze_errors', '--decompose_errors'], input='\n'.join(tag_circuit(lines)) + '\n',
                       capture_output=True, text=True, check=True)
    return r.stdout


def parse_tagged(text):
    """Flat DEM with tagged errors -> [(tag, p, [[tokens], ...])], {detector: coords}."""
    errs, dets = [], {}
    off = np.zeros(3); doff = 0
    for l in text.splitlines():
        l = l.strip()
        if l.startswith('error'):
            if l[5] == '[':
                tag = l[6:l.index(']')]; rest = l[l.index(']') + 1:]
            else:
                tag = None; rest = l[5:]
            p = float(rest[1:rest.index(')')])
            comps = [[]]
            for tok in rest[rest.index(')') + 1:].split():
                if tok == '^':
                    comps.append([])
                elif tok[0] == 'D':
                    comps[-1].append('D' + str(int(tok[1:]) + doff))
                else:
                    comps[-1].append(tok)
            errs.append((tag, p, comps))
        elif l.startswith('detector'):
            c = np.array([float(x) for x in l[l.index('(') + 1:l.index(')')].split(',')])
            c = tuple((c + off[:len(c)]).tolist())
            dets[int(l.split()[-1][1:]) + doff] = c
        elif l.startswith('shift_detectors'):
            if '(' in l.split()[0]:
                sh = [float(x) for x in l[l.index('(') + 1:l.index(')')].split(',')]
                off[:len(sh)] += sh
                rest = l[l.index(')') + 1:].split()
            else:
                rest = l.split()[1:]
            if rest:
                doff += int(rest[0])
        elif l.startswith('repeat'):
            raise ValueError('DEM contains repeat blocks')
    return errs, dets


def extend(m, lines, gmap, zpick):
    """Add X-type detectors, X-only sources and graphlike pieces to round-14 model m.
    lines: the flat circuit m was built from; gmap: circuit qubit index -> m's qubit index (src_g);
    zpick(dets): DEM detector ids of m's Z-type detectors, in m's order, as round 14 picks them."""
    errs, dets = parse_tagged(analyze_tagged(lines))
    zdets = zpick(dets)
    zmap = {k: i for i, k in enumerate(zdets)}
    xdets = sorted(k for k in dets if k not in zmap)
    nZ, nX = len(zdets), len(xdets)
    assert nZ == m.nZ, (nZ, m.nZ)
    full = dict(zmap); full.update({k: nZ + i for i, k in enumerate(xdets)})
    per_q = {}; xonly = []; bad = 0
    for tag, p, comps in errs:
        g = gmap[int(tag[1:])]
        zall, xall, obs, pieces = set(), set(), 0, []
        for comp in comps:
            ds = sorted(full[int(t[1:])] for t in comp if t[0] == 'D')
            lo = sum(1 for t in comp if t == 'L0') % 2
            obs ^= lo
            pieces.append((tuple(ds), lo))
            for x in ds:
                (zall if x < nZ else xall).symmetric_difference_update({x})
        if zall:
            per_q.setdefault(g, []).append((p, tuple(sorted(zall)), obs, tuple(sorted(xall)), tuple(pieces)))
        elif xall:
            assert not obs
            xonly.append((g, p, tuple(sorted(xall)), tuple(pieces)))
        else:
            bad += int(obs)
    # ---- check against round 14, source by source, in round 14's order
    zsets = [[] for _ in range(m.K)]
    for k, u in zip(m.src_det_k, m.src_det_u):
        zsets[k].append(int(u))
    pos = {g: 0 for g in per_q}
    xs, pieces = [None] * m.K, [None] * m.K
    for k in range(m.K):
        g = int(m.src_g[k]); i = pos.get(g, 0)
        p, zs, obs, xa, pc = per_q[g][i]
        if not (abs(p - m.p_ref[k]) <= 1e-12 * max(1.0, p) and zs == tuple(sorted(zsets[k])) and obs == int(m.src_obs[k])):
            raise AssertionError(f'source {k} (qubit {g}, #{i}) differs from round 14: {(p, zs, obs)} vs '
                                 f'{(m.p_ref[k], tuple(sorted(zsets[k])), int(m.src_obs[k]))}')
        xs[k], pieces[k] = xa, pc; pos[g] = i + 1
    left = sum(len(v) - pos.get(g, 0) for g, v in per_q.items())
    assert left == 0, f'{left} tagged sources with Z-type detectors have no round-14 counterpart'
    # ---- arrays
    Kx = len(xonly); K15 = m.K + Kx
    m.nX = nX; m.ndet = nZ + nX; m.K15 = K15; m.Kx = Kx; m.bad15 = bad
    m.p_ref15 = np.concatenate([m.p_ref, np.array([x[1] for x in xonly])])
    m.src_g15 = np.concatenate([m.src_g, np.array([x[0] for x in xonly], dtype=m.src_g.dtype)])
    m.src_obs15 = np.concatenate([m.src_obs, np.zeros(Kx, np.uint8)])
    m.xdet_coords = np.array([dets[k] for k in xdets])
    rk, ru = [], []
    for k in range(m.K):
        for x in xs[k]:
            rk.append(k); ru.append(x - nZ)
    for j, x in enumerate(xonly):
        for u in x[2]:
            rk.append(m.K + j); ru.append(u - nZ)
    SX = csr_matrix((np.ones(len(rk), np.int32), (rk, ru)), shape=(K15, nX))
    SX.sum_duplicates(); SX.data %= 2; SX.eliminate_zeros()
    m.SX = SX                                         # K15 x nX (rows K.. are the X-only sources)
    m.pieces15 = pieces + [x[3] for x in xonly]       # per source: ((detectors...), obs), ...
    m.has_x = np.zeros(K15, bool); m.has_x[np.unique(np.array(rk, int))] = True
    piece_text(m)
    return m


def piece_text(m):
    """DEM text of each source's pieces (without the probability), and the grouping of sources with identical pieces."""
    txt = []
    for pc in m.pieces15:
        txt.append(' ^ '.join(' '.join([f'D{x}' for x in ds] + (['L0'] if lo else [])) for ds, lo in pc))
    u = sorted(set(txt)); ix = {s: i for i, s in enumerate(u)}
    m.dem_lines = u                                       # one DEM line per group of sources with the same pieces
    m.dem_group = np.array([ix[s] for s in txt], np.int64)   # source -> line
    m.ndem = len(u)


# ------------------------------------------------------------------ builders
CACHE_VERSION = 'v1'


def _save(m, fn):
    """The extension only (round 14's arrays stay in round 14's cache).  Written to a temporary name and renamed, so a
    reader never sees a partial file."""
    os.makedirs(os.path.dirname(fn), exist_ok=True)
    tmp = f'{fn[:-4]}.{os.getpid()}.tmp.npz'
    np.savez_compressed(tmp, nX=m.nX, K15=m.K15, Kx=m.Kx, K=m.K, nZ=m.nZ, bad15=m.bad15, p_tail=m.p_ref15[m.K:],
                        g_tail=m.src_g15[m.K:], xdet_coords=m.xdet_coords, sx_data=m.SX.data, sx_indices=m.SX.indices,
                        sx_indptr=m.SX.indptr, has_x=m.has_x, dem_lines=np.array('\n'.join(m.dem_lines)),
                        dem_group=m.dem_group)
    os.replace(tmp, fn)


def _load(m, fn):
    z = np.load(fn)
    assert int(z['K']) == m.K and int(z['nZ']) == m.nZ, f'{fn} does not belong to this model'
    m.nX = int(z['nX']); m.ndet = m.nZ + m.nX; m.K15 = int(z['K15']); m.Kx = int(z['Kx']); m.bad15 = int(z['bad15'])
    m.p_ref15 = np.concatenate([m.p_ref, z['p_tail']])
    m.src_g15 = np.concatenate([m.src_g, z['g_tail'].astype(m.src_g.dtype)])
    m.src_obs15 = np.concatenate([m.src_obs, np.zeros(m.Kx, np.uint8)])
    m.xdet_coords = z['xdet_coords']
    m.SX = csr_matrix((z['sx_data'], z['sx_indices'], z['sx_indptr']), shape=(m.K15, m.nX))
    m.has_x = z['has_x']
    m.dem_lines = str(z['dem_lines']).split('\n'); m.dem_group = z['dem_group']; m.ndem = len(m.dem_lines)
    return m


def base15(d, rounds=None, m=None, cache=CACHE15):
    """m: the round-14 base model to extend (run3.base_model(d)); built with model.circuit_model when not given.
    cache: folder for the extension (None: always rebuild and check against round 14)."""
    rounds = rounds or d
    m = m if m is not None else circuit_model(d, rounds)
    fn = os.path.join(cache, f'base_d{d}_r{rounds}_{CACHE_VERSION}.npz') if cache else None
    if fn and os.path.exists(fn):
        return _load(m, fn)
    lines = unroll(gen_circuit(d, rounds))
    coords = {}
    for l in lines:
        if l.startswith('QUBIT_COORDS'):
            coords[int(l.split()[-1])] = tuple(float(x) for x in l[l.index('(') + 1:l.index(')')].split(','))
    qubits = sorted(coords)
    gmap = {q: i for i, q in enumerate(qubits)}

    def zpick(dets):     # as model.circuit_model: positions of the round-0 detectors
        zset = {(c[0], c[1]) for k, c in dets.items() if c[2] == 0}
        return sorted(k for k, c in dets.items() if (c[0], c[1]) in zset)
    extend(m, lines, gmap, zpick)
    if fn:
        _save(m, fn)
    return m


def deformed15(base, md, cache=CACHE15):
    """md: a round-14 reshaped-circuit model (run3.deformed_model(base, excl)); base: run3.base_model(d)."""
    tag = '_'.join(f'{x}-{y}' for x, y in tuple(sorted(md.excl)))
    fn = os.path.join(cache, f'excl_d{base.d}_r{base.T}_{tag}_{CACHE_VERSION}.npz') if cache else None
    if fn and os.path.exists(fn):
        return _load(md, fn)
    txt, meta = deform.circuit(base.d, base.T, P_REF, excl=list(md.excl))
    lines = txt.splitlines()
    coords = {}
    for l in lines:
        if l.startswith('QUBIT_COORDS'):
            coords[int(l.split()[-1])] = tuple(int(float(x)) for x in l[l.index('(') + 1:l.index(')')].split(','))
    gmap = {q: base.qgroup[c] for q, c in coords.items()}
    zpick = lambda dets: sorted(k for k, c in dets.items() if (int(c[0]), int(c[1])) in base.anc_id)
    extend(md, lines, gmap, zpick)
    if fn:
        _save(md, fn)
    return md
