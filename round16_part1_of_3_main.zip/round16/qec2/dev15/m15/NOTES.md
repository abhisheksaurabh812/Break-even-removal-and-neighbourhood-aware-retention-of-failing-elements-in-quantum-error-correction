# Round 15 development notes: correlated matching (started 06 Nov 2026, evening, while round 14 runs)

Nothing here touches round 14's frozen files.  Tests run in their own scheduler group at low priority
(`setsid` + autogroup nice 10), and any run that needs reshaped-circuit models uses a hard-linked private copy of the
round-14 model cache (`cache14/`, env `CACHE14`), so it can never write into the cache round 14's jobs read.

## Code (this folder)
| File | What it does |
|---|---|
| `model15.py` | Extends a round-14 model (base or reshaped) with X-type detectors, the sources that flip only X-type detectors, and each source's graphlike pieces. One Stim call per circuit: every noise channel split by qubit and tagged (`DEPOLARIZE1[q12](p) 12`; two-qubit channels half to each qubit, as `model.filter_for_qubit`); Stim keeps differently tagged errors apart. Checks source by source that the tagged analysis reproduces round 14's sources (qubit, Z-type detectors, observable, probability, order) and raises otherwise. |
| `corr15.py` | `Sampler15` (round 14's draw, line for line, plus X-type events; X-only sources from a separate generator), `dem_text` (decomposed DEM from per-source probabilities, identical pieces merged), `corr_matching` / `plain_matching` (PyMatching 2.4 from the text, no file), `exact_probs`, `mapped_probs` (an arm's Z-edge weights -> per-source probabilities). |
| `run15.py` | run14.py with every arm decoded twice on the same samples: `fails` (round 14's plain matching) and `fails_c` (correlated matching). Arms learn from Z-type events only and decoder output is never fed back, so every arm takes round 14's decisions. |
| `run14_iso.py` | run14.py unchanged, with its model cache pointed at the private copy. |
| `check15.py` | Sampler identity, mapping accuracy, and the decoders compared on the same samples (d = 9, one failing qubit). |
| `ideal_field15.py` | ideal_field9.py's crossover table with correlated matching (`--plain` reproduces ideal_field9's decoder). |
| `eq/` | run15 against run14 on shortened round-14 configurations with early failures. |

## The mapping (every non-oracle arm)
Round-14 arms are known to the decoder only through their Z-edge weights.  In y = -log(1 - 2p) units, which add over
the sources of an edge, each source with Z-type pieces is scaled by y_e(arm) / y_e(reference) on its Z-type edges
(geometric mean over its pieces); X-only sources keep the reference rate.  Reference: the field the arm started from
(the calibration field; one uniform rate for the generic fixed-weight baseline).  The arm's Z-edge probabilities are
reproduced exactly for sources with one Z-type piece.  Oracle arms get the exact per-source probabilities.

## Verified so far
- Tagged analysis reproduces round 14's sources exactly: d = 5, 7, 9 base models; d = 5 reshaped (3) and d = 9 reshaped (4 random cached configurations, pairs included).  0.1-0.7 s per model (round 14: one Stim call per qubit).
- `Sampler15`: Z-type events and observable flips identical to `sampler.Sampler` (same seed; heterogeneous rates with a 40x qubit), base and reshaped.
- Plain matching from the round-15 DEM text (X and Z detectors) gives the same prediction as round 14's decoder on every shot (d = 9, 200,000 shots per point).
- Mapping: Z-edge probabilities reproduced to 1e-15 on edges whose sources have one Z-type piece (1,845 of 1,945 at d = 9), worst 6e-5 elsewhere.
- run15 reproduces run14 array for array on a 36,000-round d = 9 run (no failures in it).
- Correlated decoder at d = 9: 0.8 MB each, about 0.04 s to build at full speed; decoding about 6x plain.

## Results (check15, d = 9, p = 0.003 elsewhere, one centre qubit failing by f; failures in 200,000 shots, same samples per row)
| Qubit, f | Plain, exact (round 14) | Plain, DEM text | Correlated, exact | Correlated, mapped | Correlated, nominal | Plain, nominal |
|---|---|---|---|---|---|---|
| data, 10 | 140 | 140 | 49 | 50 | 55 | 163 |
| data, 20 | 195 | 195 | 59 | 58 | 81 | 233 |
| data, 50 | 300 | 301 | 108 | 109 | 183 | 472 |
| data, 200 | 659 | 659 | 269 | 282 | 1,575 | 2,473 |
| Z ancilla, 10 | 162 | 162 | 52 | 49 | 61 | 198 |
| Z ancilla, 20 | 264 | 264 | 95 | 95 | 162 | 429 |
| Z ancilla, 50 | 607 | 607 | 213 | 231 | 1,732 | 2,858 |
| Z ancilla, 200 | 1,255 | 1,257 | 532 | 537 | 4,911 | 7,812 |

- Plain from the DEM text equals round 14's decoder on 100% of shots in 6 of 8 points, 99.9995% and 99.984% in the
  other two (1 and 32 shots).  Expected: PyMatching scales weights to integers by the largest weight in the graph,
  and the X-type edges change that scale, so rare ties break differently.  run15's `fails` uses round 14's decoder
  itself, so it is unaffected.
- Correlated matching: 58-70% fewer failures than plain with exact rates.
- Knowing the failure (exact vs nominal) is worth about as much under correlated matching at 10x (data -11% vs -14%
  plain; Z ancilla -15% vs -18%) and more from 20x up (data 50x -41% vs -36%; Z ancilla 50x -88% vs -79%).
- The mapping is within a few failures of exact rates except data 200x (+5%) and Z ancilla 50x (+8%); check15b
  splits that loss into X-only rates and redistribution.

## Where the mapping loses (check15b, 400,000 shots per point, same samples; paired z against exact rates)
| Qubit, f | Exact | Exact Z-type rates, reference X-only | Mapped (what every arm gets) | Mapped + failing qubit's X-only at true rate |
|---|---|---|---|---|
| Z ancilla, 50 | 422 | 421 (z -0.2) | 424 (z +0.2) | 423 (z +0.1) |
| Z ancilla, 200 | 1,046 | 1,036 (z -1.2) | 1,082 (z +2.1) | 1,095 (z +3.0) |
| data, 50 | 209 | 205 (z -1.0) | 205 (z -0.7) | 203 (z -1.0) |
| data, 200 | 563 | 571 (z +1.1) | 575 (z +0.8) | 585 (z +1.6) |

- The Z ancilla 50x gap in check15 (213 against 231) was chance: with twice the shots, no difference.
- Rates of the errors that only X checks see are worth nothing measurable (exact Z-type + reference X-only = exact),
  so a twin need not feed them to the decoder.
- At 200x the mapping loses about 3%: it spreads an edge's increase over every source on the edge, not just the
  failing qubit's.  An arm that only has edge weights cannot do better; the oracle arms get exact rates.

## run15 against run14 (eq/compare.jsonl; 400,000 rounds, seeds with early failures)
| Configuration | Every saved array identical | Switch-outs exercised | Failures, plain -> correlated |
|---|---|---|---|
| d9_mixed, seed 900027 | yes (fails, nexcl, flags, names, cfg, events, info, f0) | 2,027 epochs out for each switching arm | loc 84->35, sz 86->30, sz_all 87->37, sz_w13 94->36, sz_w14 94->36, cut 90->37 |
| prior_d9_mixed, seed 900027 | yes | sieg 1,470 epochs, sieg_rw 1,325 | sz 86->30, sieg 129->66, sieg_rw 115->47 |
| base_d9_mixed, seed 900027 | yes | none (fixed and refit arms) | fix_gen 174->82, fix_cal 178->86, refit_1s 167->85 |
| d9_severe, seed 900023 | yes | 2,001 epochs out for each switching arm | loc 90->24, sz 86->25, sz_all 56->12, sz_w13 54->13, sz_w14 54->13, cut 56->12 |

Time (run15 / run14, both at low priority, so only roughly): d9_mixed 1.8x, d9_severe 1.8x; prior_d9_mixed 5.5x
before the extension cache (74 reshaped circuits, each extended from scratch); the cache now loads an extension in
about 0.1 s.  Correlated decoding is about 6x plain decoding and is the main added cost.

## Round-15 pipeline (06 Nov, 23:00; written while round 14 runs)
| File | What it does |
|---|---|
| `make_cfg15.py` | cfg15 from cfg14: loc, sz, sz_all, sz_w14, cut kept; sz_w15 (correlated tables, w6, sz_w14's probe stream) and cut15 (L = 1 correlated crossovers, w7) added; sz_w13 dropped; prior and baseline configurations unchanged plus `decode`. |
| `gen_jobs15.py` | jobs15.txt, round 14's order, fresh seeds 11xxx; estimates = round 14's mean run time per test x a factor per kind of run. |
| `queue15.py` | queue14.py with out15, and each estimate scaled by the observed run time / estimate of the same kind of job (scheduling only). |
| `analyse15.py` | Rules on `fails_c` for sz_w15 (R1-R8 at round 14's bars, C1 against sz_w14, P1 cut, P1b cut15, P2/P3 sieg/sieg_rw); every comparison also on `fails`; plain repeat of round 14's rules for sz_w14; decoder effect per arm; decisions. |
| `analyse15b.py` | Baselines against gates, both decoders. |
| `recount15.py`, `verify15.py` | Independent recount of the correlated numbers from the raw arrays; comparison and re-derived verdicts. |
| `freeze15.py` | sha256 of every file round 15 reads -> out15/hashes_at_start.txt. |
| `mock15.py` | Mock round-15 output from finished round-14 runs (6,000 epochs each; fails_c = plain failures kept with probability 0.4 under one mask per seed). |

Mock test (172 mock files from round 14's finished runs): `analyse15`, `recount15`, `verify15`, `analyse15b` ran
without error; 273 values compared, no mismatch; all 15 verdicts agree; main-stream check passes for both decoders.
`queue15.py` tested on dummy jobs (requirements, budget, failed job, adaptive estimates).

## Roadmap (user, 07 Nov 02:16)
Round 15: correlated matching, option A (70 main + 32 prior-art + 70 baseline runs) plus the targeted hole-rule test
(C2b, approved 02:10).  Round 16: distances 11 and 13.  Round 17: Willow real-data test.  Then the new provisional,
then the preprint.

## Correlated crossover tables (07 Nov 03:03-05:08; tables/, ideal_field15.py, 2e6 / 1e6 shots)
| L | d9 data plain -> corr | d9 zanc | d7 data | d7 zanc |
|---|---|---|---|---|
| 1 | 13.25 -> 15.74 | 8.53 -> 8.61 | 13.77 -> 12.94 | 6.44 -> 6.12 |
| 1.5 | 15.07 -> 15.82 | 10.74 -> 10.16 | 14.04 -> 13.53 | 8.28 -> 8.52 |
| 2 | 14.92 -> 15.54 | 12.5 -> 11.51 | 15.34 -> 15.07 | 9.34 -> 9.78 |
| 3 | 16.34 -> 17.62 | 15.09 -> 15.35 | 15.81 -> 15.6 | 12 -> 11.39 |
| 4 | 16.54 -> 19.06 | 17.89 -> 18.24 | 14.23 -> 14.79 | 13.9 -> 13.49 |
| 6 | 14.94 -> 16.16 | 21.06 -> 21.14 | 12.75 -> 12.95 | 16.93 -> 16.91 |
| 8 | 12.57 -> 12.66 | 22.05 -> 20.04 | 11.72 -> 11.64 | 18.04 -> 17.58 |
Only the d = 9 data-qubit values move clearly (up 1-2.5 at L <= 6); sampling noise is roughly +-1-2 on the correlated
data values.  cut15: d9 15.74 / 8.61, d7 12.94 / 6.12.

## Memory (found in the development check, 05:08)
The bash session's memory cgroup allows 5.8 GiB for everything started from it.  A run15 process at d = 9 holds about
1.4 GB (sampling) plus about 20 MB per reshaped model kept (13 MB in round 14) and 1 MB per correlated decoder; a
prior-art development run reached 2.1 GB and was killed (OOM) with three other runs beside it.  Round 15's
configurations keep at most 40 models and 100 correlated decoders (round 14: 200 models); with 3 models and 5 decoders
a 400,000-round prior-art run was identical, array for array, to the default (eq/prior_d9_mixed_15_caps.npz).
