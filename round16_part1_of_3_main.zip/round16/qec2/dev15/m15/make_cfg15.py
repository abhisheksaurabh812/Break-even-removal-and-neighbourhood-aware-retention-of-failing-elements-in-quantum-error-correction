"""Round-15 test configurations (PREREG_round15.md).   python3 dev15/m15/make_cfg15.py cfg15   (from qec2/)
Round 14's configuration of each test (cfg14/<test>.json: scenario and arms unchanged); every arm is decoded by plain
and by correlated matching (run15.py, "decode": ["plain", "corr"]).  Seeds are set per job.
<out>/<test>.json, the main runs (all 70 seeds):
  loc, sz, sz_all   the localizer, reweighting and switch-out-all, as in rounds 10-14 (main sample stream);
  sz_w14            round 14's gate, unchanged (its crossover tables were computed with plain matching); "extra": "w4",
                    probe-noise stream "seed_i": 3;
  cut               round 14's fixed cutoff (13x data qubit, 7x Z ancilla); "extra": "w5";
  sz_w15            the gate under test: sz_w14 with the crossover tables recomputed for correlated matching
                    (ideal_field15.py, round 9's procedure and grid; tables/field_table15_d<d>_<kind>.json for the
                    test's distance); the same probe-noise stream as sz_w14, so the two take the same decisions
                    wherever their tables agree; "extra": "w6"; "theta" (used by reports only) = its L = 1 row;
  cut15             the fixed cutoff at the correlated-matching crossover of a lone failing qubit (the L = 1 row of
                    the same tables); "extra": "w7".
<out>/prior_<test>.json: sz, sieg, sieg_rw as round 14 (first four seeds of each test).
<out>/base_<test>.json: fix_gen, fix_cal, refit_1s as round 14.
<out>/d7_holenbr.json, the targeted test of round 14's hole rule (C2b): round 14's neighbouring-failure configuration
  (d = 7) for 20,000,000 rounds, without simultaneous pairs, with failures of 20-100x (log-uniform) lasting 1-2 M
  rounds, one every 1.5 M rounds on average, each followed 200,000-800,000 rounds after it starts by a failure of
  5-100x lasting 300,000-1,000,000 rounds on a qubit sharing a stabilizer with it (scenario15.py), so the second
  failure starts after the reshaped circuit's own estimates have settled without it; the main arms plus round 13's
  gate sz_w13 (round 14's: "extra": "w3", sz_w14's probe-noise stream).
Dropped from the main runs: sz_w13.
Every configuration sets "max_models": 40 and "max_corr_decoders": 100, the most reshaped-circuit models and
correlated decoders run15.py keeps in memory (round 14 kept 200 models): with the X-type part a reshaped model at
d = 9 takes about 20 MB (13 MB in round 14), and two workers must fit in the 5.8 GB the session allows.  Least
recently used ones are dropped and rebuilt when needed; this changes no result (dev15/m15/eq: identical arrays with
3 models and 5 decoders kept)."""
import json, copy, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
TESTS = ('d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed', 'long_severe', 'long_mixed', 'd9_hwlike')
TABLES = os.environ.get('TABLES15', os.path.join(HERE, 'tables'))      # env only for development smoke tests
KEEP = ('loc', 'sz', 'sz_all', 'sz_w14', 'cut')


def table(d):
    """{'data': [[L, crossover|None], ...], 'zanc': [...]} from ideal_field15.py's output for distance d."""
    tab = {}
    for k in ('data', 'zanc'):
        j = json.load(open(os.path.join(TABLES, f'field_table15_d{d}_{k}.json')))
        assert j['decoder'] == 'correlated' and j['d'] == d and j['kind'] == k, (d, k)
        rows = sorted(j['rows'], key=lambda r: r['L'])
        assert [r['L'] for r in rows] == [1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0], (d, k)
        tab[k] = [[float(r['L']), r['crossover']] for r in rows]
    return tab


def arms15(c):
    names = [a['name'] for a in c['arms']]
    keep = [copy.deepcopy(c['arms'][names.index(n)]) for n in KEEP]
    w14, cut = keep[3], keep[4]
    assert w14['kind'] == 'policy-field-watch4' and w14['extra'] == 'w4' and w14['seed_i'] == 3
    assert cut['kind'] == 'policy' and cut['mode'] == 'gated' and cut['extra'] == 'w5' and not cut.get('theta')
    tab = table(c['d'])
    one = {k: dict((L, f) for L, f in tab[k])[1.0] for k in ('data', 'zanc')}
    assert all(v is not None for v in one.values()), one
    w15 = copy.deepcopy(w14); w15.update(name='sz_w15', extra='w6', table=tab, theta=dict(one))
    cut15 = copy.deepcopy(cut); cut15.update(name='cut15', extra='w7', theta=dict(one))
    return keep + [w15, cut15]


FOLLOW = dict(frac=1.0, delay_rounds=[200000, 800000], fac=[5.0, 100.0], dur=[300000, 1000000])


def holenbr():
    c = json.load(open(os.path.join(QEC2, 'cfg14', 'pairs_mixed.json')))
    w13 = copy.deepcopy([a for a in c['arms'] if a['name'] == 'sz_w13'][0])
    assert w13['kind'] == 'policy-field-watch3' and w13['extra'] == 'w3' and w13['seed_i'] == 3
    c['arms'] = arms15(c) + [w13]; c['decode'] = ['plain', 'corr']
    assert c['defect_logfac'] and c['defect_fac'] == [2.0, 100.0] and c['pair_frac'] == 0.5
    c.update(total_rounds=20_000_000, pair_frac=0.0, defect_gap=1_500_000, defect_fac=[20.0, 100.0],
             defect_dur=[1_000_000, 2_000_000], follow=dict(FOLLOW))
    return c


CAPS = dict(max_models=40, max_corr_decoders=100)


def capped(c):
    c.update(CAPS)
    return c


def write(out):
    os.makedirs(out, exist_ok=True)
    json.dump(capped(holenbr()), open(os.path.join(out, 'd7_holenbr.json'), 'w'), indent=1)
    for t in TESTS:
        c = json.load(open(os.path.join(QEC2, 'cfg14', f'{t}.json')))
        c['arms'] = arms15(c); c['decode'] = ['plain', 'corr']
        json.dump(capped(c), open(os.path.join(out, f'{t}.json'), 'w'), indent=1)
        for pre in ('prior_', 'base_'):
            p = json.load(open(os.path.join(QEC2, 'cfg14', f'{pre}{t}.json')))
            p['decode'] = ['plain', 'corr']
            json.dump(capped(p), open(os.path.join(out, f'{pre}{t}.json'), 'w'), indent=1)
    for t in ('d9_mixed', 'pairs_mixed'):
        c = json.load(open(os.path.join(out, f'{t}.json')))
        print(t, 'arms:', [(a['name'], a.get('extra', False), a.get('seed_i'), a.get('theta')) for a in c['arms']])
        print('  sz_w14 table:', [a for a in c['arms'] if a['name'] == 'sz_w14'][0]['table'])
        print('  sz_w15 table:', [a for a in c['arms'] if a['name'] == 'sz_w15'][0]['table'])


if __name__ == '__main__':
    write(sys.argv[1])
