"""Round 15 analysis (rules in PREREG_round15.md).   python3 dev15/m15/analyse15.py > out15/res_15.json   (from qec2/)
Every run decodes every arm twice on the same samples: correlated matching (`fails_c`), which the rules use, and
round 14's plain matching (`fails`), reported for every comparison; on these fresh seeds the plain numbers repeat
round 14's tests.  A rule is evaluated only when every seed of the tests it uses has finished (done marker in
out15/done/).  OUT may be changed (mock tests: OUT=dev15/m15/mock15/out15 python3 dev15/m15/analyse15.py)."""
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, QEC2)
import analyse8 as A          # noqa: E402

OUT = os.environ.get('OUT', 'out15')
GATE = 'sz_w15'               # the gate under test: round 14's gate with crossover tables for correlated matching
G14 = 'sz_w14'                # round 14's gate, unchanged (tables computed with plain matching)
SEEDS = dict(d9_mixed=range(11101, 11111), d9_severe=range(11201, 11206), d9_moderate=range(11301, 11306),
             d9_realistic=range(11001, 11011), pairs_mixed=range(11401, 11411), long_severe=range(11501, 11511),
             long_mixed=range(11601, 11611), d9_hwlike=range(11701, 11711))
PRIOR_SEEDS = {t: list(r)[:4] for t, r in SEEDS.items()}        # prior_<test>_s<seed> runs (sieg, sieg_rw): 32
# targeted test of round 14's hole rule (C2b): every failure followed by one on a neighbouring qubit while it lasts;
# round 13's gate (sz_w13) runs alongside; not part of the 70 runs any pooled rule uses
TARGET = dict(d7_holenbr=range(11801, 11811))
ALL = dict(SEEDS, **TARGET)
# prior-art arms and the margin by which the gate must beat each, pooled: the two fixed cutoffs over all 70 runs
# (P1, P1b), sieg and sieg_rw over the 32 runs that have them (P2, P3)
PRIOR = dict(cut=0.03, cut15=0.03, sieg=0.15, sieg_rw=0.15)
C1_MAX = 0.0025
DEC = dict(corr='fails_c', plain='fails')                       # decoder -> array in the run files


def done(n):
    return os.path.exists(f'{OUT}/done/{n}')


def load(f):
    """{decoder: run} with the failures summed over the shots of each epoch (every statistic here uses per-epoch
    counts only; this keeps 70 runs of seven arms, both decoders, in memory)."""
    z = np.load(f, allow_pickle=True)
    ev = json.loads(str(z['events']))
    common = dict(file=f, names=[str(x) for x in z['names']], nexcl=z['nexcl'], info=json.loads(str(z['info'])),
                  cfg=json.loads(str(z['cfg'])), defects=ev['defects'], follows=ev.get('follows', []))
    return {d: dict(common, fails=z[k].sum(2, keepdims=True).astype(np.int64)) for d, k in DEC.items()}


_cache = {}


def runs(test):
    """{decoder: [run per seed]} once every seed of the test has finished, else None."""
    if test in _cache:
        return _cache[test]
    out = {d: [] for d in DEC}
    for s in ALL[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        r = load(f'{OUT}/{n}.npz')
        for d in DEC:
            out[d].append(r[d])
    _cache[test] = out
    return out


REFS = ('loc', 'sz', 'sz_all')
CUTS = ('cut', 'cut15')
PAIRS = [(g, r) for g in (GATE, G14) for r in REFS] + [(GATE, G14)]
PAIRS += [(g, c) for g in (GATE, G14) for c in CUTS] + [('cut15', 'cut')] + [(c, r) for c in CUTS for r in REFS]
QPAIRS = [(g, q) for g in (GATE, G14, 'sz', 'sz_all', 'cut', 'cut15', 'loc') for q in ('sieg', 'sieg_rw')]
QPAIRS += [('sieg_rw', 'sieg')]
TPAIRS = [(G14, 'sz_w13'), (GATE, 'sz_w13'), (GATE, G14)] + [(g, r) for g in (GATE, G14, 'sz_w13') for r in REFS + CUTS]


def merged_prior(test):
    """{decoder: per seed of the prior subset, the main run's arms with the prior run's sieg and sieg_rw (its
    reweighting arm, which must equal the main run's epoch by epoch, is kept as 'sz_prior')}; None until every seed
    has both."""
    out = {d: [] for d in DEC}
    for s in PRIOR_SEEDS[test]:
        n = f'{test}_s{s}'
        if not (done(n) and done(f'prior_{n}')):
            return None
        rr = runs(test)
        main = {d: [x for x in rr[d] if x['file'].endswith(f'/{n}.npz')][0] for d in DEC} if rr else load(f'{OUT}/{n}.npz')
        pr = load(f'{OUT}/prior_{n}.npz')
        for d in DEC:
            r, p = main[d], pr[d]
            assert r['fails'].shape[1:] == p['fails'].shape[1:], n
            names = r['names'] + [x if x != 'sz' else 'sz_prior' for x in p['names']]
            info = dict(r['info']); info.update({k: v for k, v in p['info'].items() if k != 'sz'})
            out[d].append(dict(file=r['file'], names=names, fails=np.concatenate([r['fails'], p['fails']]), info=info,
                               cfg=dict(r['cfg'], arms=r['cfg']['arms'] + [a for a in p['cfg']['arms'] if a['name'] != 'sz']),
                               defects=r['defects'], nexcl=None))
    return out


def returns(rs, g):
    n = 0
    for r in rs:
        n += sum(1 for l in r['info'][g].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch')
    return n


def rules_for(g, res):
    """R1-R8 for arm g from one decoder's per-test results (round 14's bars)."""
    c = lambda t, k: res[t][k]
    out = {}
    if 'd9_mixed' in res:
        out[f'R1_{g}_mixed_beats_sz_5pct'] = A.beats(c('d9_mixed', f'{g} vs sz'), 0.05)
        out[f'R1_{g}_mixed_beats_all_3pct'] = A.beats(c('d9_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_severe' in res:
        out[f'R2_{g}_severe_beats_sz_10pct'] = A.beats(c('d9_severe', f'{g} vs sz'), 0.10)
    if 'd9_moderate' in res:
        out[f'R3_{g}_moderate_vs_sz_within_1pct'] = bool(c('d9_moderate', f'{g} vs sz')['rel'] <= 0.01)
    if 'd9_realistic' in res:
        x = c('d9_realistic', f'{g} vs loc')
        out[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'pairs_mixed' in res:
        out[f'R5_{g}_pairs_vs_sz_within_1pct'] = bool(c('pairs_mixed', f'{g} vs sz')['rel'] <= 0.01)
    if 'long_severe' in res:
        out[f'R6_{g}_long_severe_beats_sz_10pct'] = A.beats(c('long_severe', f'{g} vs sz'), 0.10)
    if 'long_mixed' in res:
        out[f'R7_{g}_long_mixed_beats_sz_5pct'] = A.beats(c('long_mixed', f'{g} vs sz'), 0.05)
        out[f'R7_{g}_long_mixed_beats_all_3pct'] = A.beats(c('long_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_hwlike' in res:
        out[f'R8_{g}_hwlike_beats_sz_10pct'] = A.beats(c('d9_hwlike', f'{g} vs sz'), 0.10)
    return out


def pooled(tests, dec, a, b):
    rs = sum((runs(t)[dec] for t in tests), [])
    x = A.compare(rs, a, b); x['boot95'] = A.bootstrap(rs, a, b)
    return x


def beats_by(x, thr):
    return bool(x['rel'] <= -thr and x['z'] < 0 and x['p'] < 0.01)


def main():
    res = {d: {} for d in DEC}; dec_effect = {}; decisions = {}; prior_res = {d: {} for d in DEC}
    rules = {}; plain_repeat = {}
    for test in SEEDS:
        rr = runs(test)
        if not rr:
            continue
        for d in DEC:
            rs = rr[d]
            R = dict(seeds=len(rs), totals=A.totals(rs))
            for a, b in PAIRS:
                R[f'{a} vs {b}'] = A.compare(rs, a, b)
                R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
            res[d][test] = R
        tc, tp = res['corr'][test]['totals'], res['plain'][test]['totals']
        dec_effect[test] = {a: dict(plain=tp[a], corr=tc[a], rel=round((tc[a] - tp[a]) / max(tp[a], 1), 4)) for a in tc}
        rs = rr['corr']                       # the arms' decisions do not depend on the decoder
        D = dict(watch_returns={g: returns(rs, g) for g in (G14, GATE)},
                 hole_named={g: [r['info'][g].get('hole_named') for r in rs] for g in (G14, GATE)},
                 out_epochs={a: int(sum((r['nexcl'][r['names'].index(a)] > 0).sum() for r in rs)) for a in rs[0]['names']})
        for g in (G14, GATE) + CUTS:
            pc = A.policy_checks(rs, g)
            pc['failures'] = pc['failures'][:40]
            D[f'policy_{g}'] = pc
        decisions[test] = D
        mp = merged_prior(test)
        if mp:
            for d in DEC:
                m = mp[d]
                Q = dict(seeds=len(m), totals=A.totals(m))
                Q['main_stream_check: sz == sz_prior'] = bool(all((r['fails'][r['names'].index('sz')] ==
                                                                    r['fails'][r['names'].index('sz_prior')]).all() for r in m))
                for a, b in QPAIRS:
                    Q[f'{a} vs {b}'] = A.compare(m, a, b); Q[f'{a} vs {b}']['boot95'] = A.bootstrap(m, a, b)
                prior_res[d][test] = Q
            for g in ('sieg', 'sieg_rw'):
                pc = A.policy_checks(mp['corr'], g)
                pc['failures'] = pc['failures'][:40]
                decisions[test][f'policy_{g}'] = pc
    rules.update(rules_for(GATE, res['corr']))
    plain_repeat.update(rules_for(G14, res['plain']))
    pool = {d: {} for d in DEC}
    if all(t in res['corr'] for t in SEEDS):
        for d in DEC:
            for a, b in ((GATE, G14), (GATE, 'cut'), (GATE, 'cut15'), (G14, 'cut'), (G14, 'cut15'), (GATE, 'sz'),
                         (G14, 'sz'), (GATE, 'sz_all'), (GATE, 'loc'), ('cut15', 'cut')):
                pool[d][f'{a} vs {b}'] = pooled(SEEDS, d, a, b)
        x = pool['corr'][f'{GATE} vs {G14}']
        rules[f'C1_{GATE}_vs_{G14}_all_within_0.25pct'] = bool(x['rel'] <= C1_MAX)
        for key, c in (('P1', 'cut'), ('P1b', 'cut15')):
            rules[f'{key}_{GATE}_beats_{c}_all_{round(100 * PRIOR[c])}pct'] = beats_by(pool['corr'][f'{GATE} vs {c}'], PRIOR[c])
        plain_repeat[f'P1_{G14}_beats_cut_all_3pct'] = beats_by(pool['plain'][f'{G14} vs cut'], PRIOR['cut'])
    mps = {t: merged_prior(t) for t in SEEDS}
    if all(mps.values()):
        for d in DEC:
            rs = sum((mps[t][d] for t in SEEDS), [])
            pool[d]['main_stream_check: sz == sz_prior (32 runs)'] = all(prior_res[d][t]['main_stream_check: sz == sz_prior']
                                                                          for t in SEEDS)
            for g in (GATE, G14):
                for p in ('sieg', 'sieg_rw'):
                    x = A.compare(rs, g, p); x['boot95'] = A.bootstrap(rs, g, p)
                    pool[d][f'prior_subset: {g} vs {p}'] = x
        for i, p in ((2, 'sieg'), (3, 'sieg_rw')):
            rules[f'P{i}_{GATE}_beats_{p}_subset_{round(100 * PRIOR[p])}pct'] = beats_by(pool['corr'][f'prior_subset: {GATE} vs {p}'], PRIOR[p])
            plain_repeat[f'P{i}_{G14}_beats_{p}_subset_{round(100 * PRIOR[p])}pct'] = beats_by(pool['plain'][f'prior_subset: {G14} vs {p}'], PRIOR[p])
    target = {d: {} for d in DEC}
    for test in TARGET:
        rr = runs(test)
        if not rr:
            continue
        for d in DEC:
            rs = rr[d]
            R = dict(seeds=len(rs), totals=A.totals(rs))
            for a, b in TPAIRS:
                R[f'{a} vs {b}'] = A.compare(rs, a, b)
                R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
            target[d][test] = R
        tc, tp = target['corr'][test]['totals'], target['plain'][test]['totals']
        dec_effect[test] = {a: dict(plain=tp[a], corr=tc[a], rel=round((tc[a] - tp[a]) / max(tp[a], 1), 4)) for a in tc}
        rs = rr['corr']
        D = dict(watch_returns={g: returns(rs, g) for g in ('sz_w13', G14, GATE)},
                 hole_named={g: [r['info'][g].get('hole_named') for r in rs] for g in ('sz_w13', G14, GATE)},
                 follows=[len(r.get('follows', [])) for r in rs],
                 out_epochs={a: int(sum((r['nexcl'][r['names'].index(a)] > 0).sum() for r in rs)) for a in rs[0]['names']})
        for g in ('sz_w13', G14, GATE):
            pc = A.policy_checks(rs, g)
            pc['failures'] = pc['failures'][:40]
            D[f'policy_{g}'] = pc
        decisions[test] = D
        x = target['corr'][test][f'{G14} vs sz_w13']
        rules[f'C2b_{G14}_fewer_failures_than_sz_w13_{test}'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    return dict(corr=res['corr'], plain=res['plain'], prior_corr=prior_res['corr'], prior_plain=prior_res['plain'],
                pooled_corr=pool['corr'], pooled_plain=pool['plain'], target_corr=target['corr'],
                target_plain=target['plain'], decoder_effect=dec_effect, decisions=decisions,
                rules=rules, plain_repeat_of_round14=plain_repeat)


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
