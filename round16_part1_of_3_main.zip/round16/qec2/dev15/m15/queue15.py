"""Round-15 job queue (queue14.py with out15).   python3 dev15/m15/queue15.py jobs15.txt <budget_minutes> <workers>
(run from qec2/; OUT=dir for tests)
Job lines:  name  est_seconds  requires(comma list or -)  command ...
A job is skipped if out15/done/<name> exists.  It starts only when its requirements are done and it is
expected to finish inside the budget (elapsed + 1.3 x est x r < budget), so a batch never has to cut a job
short.  r: the median of (run time / estimate) over the finished jobs of the same test and kind (the job name without
its seed), within [0.6, 3], once two have finished (else 1); it changes only which job starts when, never a result.
stdout/stderr -> out15/logs/<name>.{out,err}; exit status 0 -> done marker (holding the run time)."""
import sys, os, time, subprocess, statistics

OUT = os.environ.get('OUT', 'out15')


def kind(n):
    return n.rsplit('_s', 1)[0]                     # test and kind, e.g. prior_d9_hwlike


def ratios(jobs):
    r = {}
    for k in sorted(set(kind(j['name']) for j in jobs)):
        xs = [float(open(f'{OUT}/done/{j["name"]}').read()) / j['est'] for j in jobs
              if kind(j['name']) == k and done(j['name'])]
        r[k] = min(3.0, max(0.6, statistics.median(xs))) if len(xs) >= 2 else 1.0
    return r


def load(fn):
    jobs = []
    for line in open(fn):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        name, est, req, cmd = line.split(None, 3)
        jobs.append(dict(name=name, est=float(est), req=[] if req == '-' else req.split(','), cmd=cmd))
    return jobs


def done(n):
    return os.path.exists(f'{OUT}/done/{n}')


def main():
    jobs = load(sys.argv[1]); budget = float(sys.argv[2]) * 60; W = int(sys.argv[3])
    for d in ('done', 'logs'):
        os.makedirs(f'{OUT}/{d}', exist_ok=True)
    t0 = time.time(); running = {}; failed = set()
    log = open(f'{OUT}/queue.log', 'a')

    def L(msg):
        log.write(f'{time.strftime("%d %H:%M:%S")} {msg}\n'); log.flush()

    R = ratios(jobs)
    L(f'batch start, budget {budget / 60:.0f} min, {W} workers, run time / estimate so far '
      f'{ {k: round(v, 2) for k, v in R.items() if v != 1.0} }')
    while True:
        for n, (p, ts) in list(running.items()):
            rc = p.poll()
            if rc is not None:
                del running[n]
                if rc == 0:
                    open(f'{OUT}/done/{n}', 'w').write(f'{time.time() - ts:.0f}\n'); L(f'done {n} {time.time() - ts:.0f}s')
                    R = ratios(jobs)
                else:
                    failed.add(n); L(f'FAILED {n} rc={rc}')
        while len(running) < W:
            el = time.time() - t0
            cand = [j for j in jobs if not done(j['name']) and j['name'] not in running and j['name'] not in failed
                    and all(done(r) for r in j['req']) and el + 1.3 * j['est'] * R[kind(j['name'])] < budget]
            if not cand:
                break
            j = cand[0]
            out = open(f'{OUT}/logs/{j["name"]}.out', 'w'); err = open(f'{OUT}/logs/{j["name"]}.err', 'w')
            p = subprocess.Popen(j['cmd'], shell=True, stdout=out, stderr=err)
            running[j['name']] = (p, time.time())
            L(f'start {j["name"]} (est {j["est"]:.0f}s x {R[kind(j["name"])]:.2f})')
        if not running:
            break
        time.sleep(5)
    left = [j['name'] for j in jobs if not done(j['name'])]
    L(f'batch end; {len(left)} left: {" ".join(left)}')
    print(f'{len(left)} jobs left:', ' '.join(left), '| failed:', ' '.join(sorted(failed)) or 'none')


if __name__ == '__main__':
    main()
