"""Round 15 freeze: list every file the round-15 code reads and write their sha256 to out15/hashes_at_start.txt.
python3 dev15/m15/freeze15.py      (run from qec2/, after make_cfg15.py cfg15 and gen_jobs15.py)
Python modules: everything under qec2/ that run15.py, analyse15.py, analyse15b.py, make_cfg15.py and gen_jobs15.py
import (found by importing them in a fresh interpreter); plus the scripts run as programs, the CUSUM kernel, the Stim
command-line tool, the crossover tables, the configurations (and round 14's, which make_cfg15.py reads), the job
list and the pre-registration.  Paths are relative to qec2/."""
import glob, hashlib, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
M = os.path.relpath(HERE, QEC2)                     # dev15/m15
probe = ("import sys, os, json; sys.path.insert(0, %r); sys.path.insert(0, %r); "
         "import run15, analyse15, analyse15b, make_cfg15, gen_jobs15; "
         "print(json.dumps(sorted(os.path.relpath(m.__file__, %r) for m in list(sys.modules.values()) "
         "if getattr(m, '__file__', None) and os.path.abspath(m.__file__).startswith(%r + os.sep))))") % (
    QEC2, HERE, QEC2, QEC2)
mods = json.loads(subprocess.run([sys.executable, '-c', probe], capture_output=True, text=True, check=True,
                                 cwd=QEC2).stdout)
files = set(mods)
files |= {f'{M}/{f}' for f in ('run15.py', 'model15.py', 'corr15.py', 'scenario15.py', 'analyse15.py', 'analyse15b.py', 'recount15.py',
                               'verify15.py', 'queue15.py', 'gen_jobs15.py', 'make_cfg15.py', 'freeze15.py',
                               'ideal_field15.py', 'run_tables.sh')}
files |= {'kernel.c', 'libkernel.so', 'jobs15.txt', 'PREREG_round15.md', '../bin/stim'}
if os.path.exists(os.path.join(HERE, 'devcheck', 'factors.json')):
    files.add(f'{M}/devcheck/factors.json')                                                       # read by gen_jobs15.py
files |= set(os.path.relpath(f, QEC2) for f in glob.glob(os.path.join(QEC2, 'cfg15', '*.json')))
files |= set(os.path.relpath(f, QEC2) for f in glob.glob(os.path.join(QEC2, 'cfg14', '*.json')))   # read by make_cfg15.py
files |= set(os.path.relpath(f, QEC2) for f in glob.glob(os.path.join(HERE, 'tables', 'field_table15_*.json')))
missing = [f for f in files if not os.path.exists(os.path.join(QEC2, f))]
assert not missing, missing
assert len(glob.glob(os.path.join(QEC2, 'cfg15', '*.json'))) == 25, 'cfg15: 8 main, 8 prior, 8 baseline, 1 targeted'
assert len(glob.glob(os.path.join(HERE, 'tables', 'field_table15_*.json'))) == 4, 'four crossover tables expected'
os.makedirs(os.path.join(QEC2, 'out15'), exist_ok=True)
with open(os.path.join(QEC2, 'out15', 'hashes_at_start.txt'), 'w') as out:
    for f in sorted(files):
        h = hashlib.sha256(open(os.path.join(QEC2, f), 'rb').read()).hexdigest()
        out.write(f'{h}  {f}\n')
print(len(files), 'files hashed:', ' '.join(sorted(files)))
