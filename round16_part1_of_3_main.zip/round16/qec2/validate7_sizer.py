"""V1: accuracy of the likelihood sizer (arms7.Sized.fit) on synthetic data with a known factor."""
import json, sys
import numpy as np
from run3 import base_model
from sampler import Sampler
from arms7 import Sized

base = base_model(7)
rng = np.random.default_rng(12345)
G = base.G
f0 = np.exp(0.35 * rng.standard_normal(G)); f0 /= np.median(f0); f0 = np.clip(f0, 0.25, 4.0) * 3.0
pe = base.edge_p(f0); qd = base.det_rate(f0)
qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f0)
fp = {"conc": 0.7, "emin": 60, "zs": 2.0, "radius": 6.0, "anc": {"rho": 2.0, "h": 15, "holdoff": 1500, "emin": 60}}
S = Sized('v', base, cal, 100000, {"rho": 3.0, "h": 25.0, "holdoff": 1500}, True, True, 200000, fp, {})
z = np.load('roles_d7.npz')
c = base.center
pick = lambda arr: int(arr[np.argmin(np.hypot(*(base.qxy[arr] - c).T))])
edge_data = int(z['data'][np.argmax(np.hypot(*(base.qxy[z['data']] - c).T))])
qubits = {'data(bulk)': pick(z['data']), 'Z anc(bulk)': pick(z['zq']), 'X anc(bulk)': pick(z['xanc']), 'data(corner)': edge_data}
smp = Sampler(base, np.random.default_rng(7))
res = {}
for nm, g in qubits.items():
    for r in [2, 3, 5, 10, 30, 100]:
        for rounds in [1400, 14000]:
            ests = []
            for rep in range(5):
                n_ep = rounds // 140
                F = np.tile(f0, (n_ep, 1)); F[:, g] *= r
                X, _ = smp.sample(F, 20)
                n = (X.astype(np.float32) @ base.A_int).sum(0).astype(float)
                N = X.shape[0] * S.nint
                ests.append(S.fit(g, n, N))
            e = np.array(ests)
            res[f'{nm} r={r} rounds={rounds}'] = dict(median=round(float(np.median(e)), 2), lo=round(float(e.min()), 2), hi=round(float(e.max()), 2))
            print(f'{nm:13s} r={r:<4} rounds={rounds:<6} estimates {np.round(e, 1)}', flush=True)
json.dump(res, open('out7/validate_sizer.json', 'w'), indent=1)
