"""Writes jobs12.txt (round 12).  Estimated seconds per job from round-10 timings (round 12 has as many arms as
round 10).  Every job uses run12.py."""
est = dict(d9_hwlike=1500, d9_mixed=900, d9_severe=900, d9_moderate=950, d9_realistic=1400, pairs_mixed=650, long_severe=900, long_mixed=850)
seeds = dict(d9_mixed=range(8101, 8111), d9_severe=range(8201, 8206), d9_moderate=range(8301, 8306),
             d9_realistic=range(8001, 8011), pairs_mixed=range(8401, 8411), long_severe=range(8501, 8507),
             long_mixed=range(8601, 8607), d9_hwlike=range(8701, 8711))


def interleave(a, b):
    out = []
    for i in range(max(len(a), len(b))):
        out += ([a[i]] if i < len(a) else []) + ([b[i]] if i < len(b) else [])
    return out


order = interleave([('d9_mixed', s) for s in seeds['d9_mixed']], [('d9_severe', s) for s in seeds['d9_severe']])
order += interleave([('d9_realistic', s) for s in seeds['d9_realistic']], [('pairs_mixed', s) for s in seeds['pairs_mixed']])
order += interleave([('d9_hwlike', s) for s in seeds['d9_hwlike']], [('long_severe', s) for s in seeds['long_severe']] + [('long_mixed', s) for s in seeds['long_mixed']])
order += [('d9_moderate', s) for s in seeds['d9_moderate']]
with open('jobs12.txt', 'w') as f:
    for t, s in order:
        n = f'{t}_s{s}'
        f.write(f'{n} {est[t]} - python3 run12.py cfg12/{t}.json out12/{n}.npz seed={s} > out12/{n}.json\n')
print(len(order), 'jobs; total estimate', round(sum(est[t] for t, _ in order) / 3600, 2), 'h of CPU')
