"""
Round-10 runner: run9.py plus one scenario option, written for round 10's neighbouring-failure test.
  pair_frac (default 0): each failure, with this probability, also strikes a second qubit that shares a
  stabilizer with the first (another qubit of a plaquette the first belongs to: for a data qubit, the
  ancillas of its plaquettes and their other data qubits; for an ancilla, its data qubits).  Same start and
  duration; its own factor, drawn from the same distribution.  Logged as an ordinary failure, and the pair
  in events['pairs'] as [start, qubit, partner].  With pair_frac = 0 no extra random numbers are drawn, so a
  run is identical to run9.py's.  Nothing else differs from run9.py.
Usage:  python3 run10.py cfg.json out.npz [key=json ...]

(run9.py docstring follows)
Round-9 runner: run7.py plus arm kind "policy-field" (arms9.PolicyArmField, the field-aware size gate).

(run7.py docstring follows)
Round-7 runner: response policies for faulty qubits (reweight vs switch out), with likelihood sizing.

Built on run3.py (round 4): arms that never change the circuit decode the same samples; arms that
switch a qubit out decode samples of the deformed circuit for the epochs where they do so (shared by
all arms in the same configuration).  Scenario as run2.py, plus cfg['defect_logfac'] (defect factors
log-uniform over defect_fac instead of uniform; same number of random draws).

Arm kinds: static / oracle / slow (run2), sized (arms7.Sized, reweight only), policy (arms7.PolicyArm
wrapping a sized learner: mode 'gated' or 'all', re-inclusion by 'probe' or 'timer'), oracle-policy
(true rates and defects, mode 'gated' or 'all').
"""
import sys, json, time, hashlib
from collections import OrderedDict
import numpy as np
from model import P_REF
from sampler import Sampler, build_matching, weights_from_p
from arms import Stats, estimate, WMIN
from run2 import build_arms
from run3 import base_model, deformed_model, to_base
from arms7 import Sized, PolicyArm, OraclePolicy
from arms9 import PolicyArmField


_partners = {}


def partners(m):
    """For every qubit, the other qubits it shares a stabilizer with (rotated layout, lattice coordinates)."""
    if m.d not in _partners:
        import rectgen
        data, xm, zm = rectgen.layout(m.d, m.d)
        qg = {(int(round(x)), int(round(y))): g for g, (x, y) in enumerate(m.qxy)}
        dset = set(data)
        stabs = [[a] + [(a[0] + dx, a[1] + dy) for dx in (-1, 1) for dy in (-1, 1) if (a[0] + dx, a[1] + dy) in dset]
                 for a in list(xm) + list(zm)]
        nb = {g: set() for g in range(m.G)}
        for st in stabs:
            gs = [qg[c] for c in st]
            for g in gs:
                nb[g].update(h for h in gs if h != g)
        for st in stabs:                                   # an ancilla shares a stabilizer only with its own data qubits
            a = qg[st[0]]; nb[a] = set(qg[c] for c in st[1:])
        _partners[m.d] = {g: np.array(sorted(v), int) for g, v in nb.items()}
    return _partners[m.d]


def make_scenario(m, cfg, rng):
    """run2.make_scenario, with an optional log-uniform defect factor (identical random draws otherwise)."""
    bpe = cfg['bpe']; T = m.T; er = bpe * T
    n_ep = cfg['total_rounds'] // er
    t = (np.arange(n_ep) + 0.5) * er
    tot = n_ep * er
    G, xy, lat = m.G, m.qxy, m.lattice
    f0 = np.exp(cfg['het_sigma'] * rng.standard_normal(G)); f0 /= np.median(f0)
    f0 = np.clip(f0, 0.25, 4.0)
    F = np.tile((f0 * cfg['p_base'] / P_REF).astype(np.float32), (n_ep, 1))
    flags = np.zeros(n_ep, np.uint8)
    events = dict(bursts=[], defects=[], steps=[])
    half = (m.d * lat) / 2
    if cfg.get('drift_frac', 0) > 0:
        sel = rng.random(G) < cfg['drift_frac']
        fac = rng.uniform(1.0, cfg['drift_fac'], G)
        F[:, sel] *= (fac[sel][None, :] ** (t / tot)[:, None]).astype(np.float32)
    if cfg.get('bursts', False):
        t0 = 0.0
        while True:
            t0 += rng.uniform(*cfg['burst_gap'])
            tau = rng.uniform(*cfg['burst_tau']); peak = rng.uniform(*cfg['burst_peak'])
            if t0 + 5 * tau > tot:
                break
            cen = m.center + rng.uniform(-half, half, 2)
            space = np.exp(-((xy - cen) ** 2).sum(1) / (2 * (cfg['burst_sigma'] * lat) ** 2))
            on = (t >= t0) & (t < t0 + 5 * tau)
            amp = np.where(on, np.exp(-(t - t0) / tau), 0.0)
            F *= (1 + (peak - 1) * amp[:, None] * space[None, :]).astype(np.float32)
            flags[on] |= 1
            flags[(t >= t0 + 5 * tau) & (t < t0 + 5 * tau + 60000)] |= 2
            events['bursts'].append([float(t0), float(tau), float(peak), cen.tolist()])
            t0 += 5 * tau
    if cfg.get('defects', False):
        t0 = 0.0
        lo, hi = cfg['defect_fac']
        while True:
            t0 += rng.exponential(cfg['defect_gap'])
            if t0 > tot:
                break
            if cfg.get('defect_logfac'):
                q = int(rng.integers(G)); fac = float(np.exp(rng.uniform(np.log(lo), np.log(hi)))); dur = rng.uniform(*cfg['defect_dur'])
            else:
                q = int(rng.integers(G)); fac = rng.uniform(lo, hi); dur = rng.uniform(*cfg['defect_dur'])
            on = (t >= t0) & (t < t0 + dur)
            F[on, q] *= fac
            flags[on] |= 4
            events['defects'].append([float(t0), float(dur), q, float(fac)])
            if cfg.get('pair_frac', 0) > 0 and rng.random() < cfg['pair_frac']:
                nb = partners(m)[q]
                q2 = int(nb[rng.integers(len(nb))])
                if cfg.get('defect_logfac'):
                    fac2 = float(np.exp(rng.uniform(np.log(lo), np.log(hi))))
                else:
                    fac2 = float(rng.uniform(lo, hi))
                F[on, q2] *= fac2
                events['defects'].append([float(t0), float(dur), q2, float(fac2)])
                events.setdefault('pairs', []).append([float(t0), q, q2])
    for frac in cfg.get('steps', []):
        ts = frac * tot
        cen = m.center + rng.uniform(-half * 0.6, half * 0.6, 2)
        space = np.exp(-((xy - cen) ** 2).sum(1) / (2 * (cfg['step_sigma'] * lat) ** 2))
        on = t >= ts
        F[on] *= (1 + (cfg['step_fac'] - 1) * space)[None, :].astype(np.float32)
        flags[(t >= ts) & (t < ts + 200000)] |= 8
        flags[on] |= 16
        events['steps'].append([float(ts), cen.tolist()])
    return F, flags, events


def make_sized(m, cal, sp):
    cls = Sized
    if sp.get('kind') == 'sized2':
        from arms7b import Sized2
        cls = Sized2
    elif sp.get('kind') == 'sized3':
        from arms7b import Sized3
        cls = Sized3
    elif sp.get('kind') == 'sized4':
        from arms7b import Sized4
        cls = Sized4
    return cls(sp['name'], m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
               sp.get('tmax'), sp.get('footprint'), sp.get('sizer', {}))


def run(cfg, out):
    base = base_model(cfg['d'])
    rng_sc = np.random.default_rng(cfg['seed'])
    F, flags, events = make_scenario(base, cfg, rng_sc)
    n_ep, bpe, T = F.shape[0], cfg['bpe'], base.T
    er = bpe * T
    f_cal = F[0].astype(np.float64)
    pe = base.edge_p(f_cal); qd = base.det_rate(f_cal)
    qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f_cal)
    if any(sp.get('base') == 'est' for sp in cfg['arms']):
        cs = Sampler(base, np.random.default_rng(cfg['seed'] + 77777))
        st = Stats(base); nblk = cfg.get('cal_rounds', 1_000_000) // T
        for _ in range(0, nblk, 5000):
            Xc_, _ = cs.sample(np.tile(f_cal, (5000 // bpe, 1)), bpe); st.add(Xc_)
        pe_e, q_e, _, _ = estimate(base, st, pe, qcl, 10, 10)
        cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in base.int_classes])
    arms = []
    for i, sp in enumerate(cfg['arms']):
        k = sp['kind']
        if k == 'oracle-policy':
            arms.append(OraclePolicy(sp['name'], base, events, er, sp['mode'], sp.get('theta')))
        elif k == 'policy-field':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArmField(sp['name'], base, inner, cal, sp['probe'], cfg['seed'] * 1000 + 17 * i,
                                       sp['table'], cfg['p_base'] / P_REF, sp.get('radius', 4.0), sp.get('WL', 50),
                                       sp.get('resize', True), sp.get('ring_min', 2), sp.get('fallback', 'patch')))
        elif k == 'policy':
            inner = make_sized(base, cal, dict(sp['inner'], name='inner'))
            arms.append(PolicyArm(sp['name'], base, inner, sp['mode'], cal, sp.get('probe'), sp.get('t_rein'),
                                  seed=cfg['seed'] * 1000 + 17 * i, theta=sp.get('theta')))
        elif k in ('sized', 'sized2', 'sized3', 'sized4'):
            arms.append(make_sized(base, cal, sp))
        else:
            arms.append(build_arms(base, cal, [sp])[0])
    A = len(arms); names = [a.name for a in arms]
    sampler = Sampler(base, np.random.default_rng(cfg['seed'] + 99991))
    drng = np.random.default_rng(cfg['seed'] + 55555)
    drng_x = np.random.default_rng(cfg['seed'] + 66666)   # separate stream for arms marked 'extra'
    dmodels = {}; dsamplers = {}; dsamplers_x = {}
    extra = [bool(sp.get('extra', False)) for sp in cfg['arms']]

    def dm(key):
        if key not in dmodels:
            dmodels[key] = deformed_model(base, key)
            dsamplers[key] = Sampler(dmodels[key], drng)
            dsamplers_x[key] = Sampler(dmodels[key], drng_x)
        return dmodels[key]

    fails = np.zeros((A, n_ep, bpe), np.uint8); nexcl = np.zeros((A, n_ep), np.uint8)
    mcache = OrderedDict(); builds = 0; decodes = 0
    chunk = cfg.get('chunk', 250); t0 = time.time()
    for c0 in range(0, n_ep, chunk):
        c1 = min(n_ep, c0 + chunk)
        Xc, oc = sampler.sample(F[c0:c1].astype(np.float64), bpe)
        for e in range(c0, c1):
            X0 = Xc[(e - c0) * bpe:(e - c0 + 1) * bpe]; o0 = oc[(e - c0) * bpe:(e - c0 + 1) * bpe]
            fe = F[e].astype(np.float64)
            true_pe = base.edge_p(fe)
            crr0 = (X0.astype(np.float32) @ base.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            keys = {}
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    keys[i] = a.plan(e)
                elif a.kind == 'policy':
                    keys[i] = a.config()
                else:
                    keys[i] = ()
            samples = {(): (X0, o0)}
            # main arms draw deformed samples exactly as before; 'extra' arms reuse those when their
            # configuration matches and otherwise draw from their own stream, so they never change
            # the samples seen by the main arms
            for k in sorted(set(keys[i] for i in range(A) if not extra[i])):
                if k and k not in samples:
                    md = dm(k)
                    samples[k] = dsamplers[k].sample(fe[None, :], bpe)
            for k in sorted(set(keys[i] for i in range(A) if extra[i])):
                if k and k not in samples:
                    md = dm(k)
                    samples[k] = dsamplers_x[k].sample(fe[None, :], bpe)
            preds = {}
            for i, a in enumerate(arms):
                k = keys[i]; md = dmodels[k] if k else None; mm = md if k else base
                X, o = samples[k]
                if a.kind == 'oracle-policy':
                    w = weights_from_p(mm.edge_p(fe), WMIN)
                elif a.kind == 'policy':
                    w = a.weights(md, true_pe)
                else:
                    w = a.weights(true_pe)
                w = np.round(w, 3)
                hk = (k, hashlib.md5(w.tobytes()).digest())
                pr = preds.get(hk)
                if pr is None:
                    mt = mcache.get(hk)
                    if mt is None:
                        mt = build_matching(mm, w); builds += 1; mcache[hk] = mt
                        if len(mcache) > 400:
                            mcache.popitem(last=False)
                    else:
                        mcache.move_to_end(hk)
                    pr = mt.decode_batch(X)[:, 0]; decodes += 1; preds[hk] = pr
                fails[i, e] = pr ^ o
                nexcl[i, e] = len(k)
            for i, a in enumerate(arms):
                if a.kind == 'oracle-policy':
                    continue
                if a.kind == 'policy':
                    k = keys[i]
                    a.update(samples[k][0], crr0 if not k else None, dmodels[k] if k else None, base.AggD, e, T, fe, to_base)
                else:
                    a.update(X0, crr0)
        if cfg.get('verbose'):
            print(f'{c1}/{n_ep} {time.time() - t0:.0f}s builds={builds} dmodels={len(dmodels)}', file=sys.stderr, flush=True)
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, nexcl=nexcl, flags=flags, names=np.array(names), cfg=json.dumps(cfg),
                        events=json.dumps(events), info=json.dumps(info), f0=f_cal)
    tot = fails.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes,
                          deformed_configs=len(dmodels), totals=dict(zip(names, tot.tolist())),
                          excluded_epochs=dict(zip(names, (nexcl > 0).sum(1).tolist())),
                          n_defects=len(events['defects']), n_bursts=len(events['bursts']))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
