"""Writes jobs10.txt (round 10).  Estimated seconds per job come from round 8/9 timings and the d = 9 check run."""
import sys
est = dict(d9_realistic=int(sys.argv[1]), d9_mixed=1100, d9_severe=950, d9_moderate=1000, pairs_mixed=750,
           long_severe=950, long_mixed=900)
seeds = dict(d9_realistic=range(6001, 6011), d9_mixed=range(6101, 6106), d9_severe=range(6201, 6204),
             d9_moderate=range(6301, 6306), pairs_mixed=range(6401, 6411), long_severe=range(6501, 6507),
             long_mixed=range(6601, 6607))
runner = lambda t: 'run10.py' if t == 'pairs_mixed' else 'run9.py'
order = []
r = list(seeds['d9_realistic']); p = list(seeds['pairs_mixed'])
for i in range(10):                                       # longest jobs first, interleaved with the pairs test
    order += [('d9_realistic', r[i]), ('pairs_mixed', p[i])]
for t in ('d9_mixed', 'd9_moderate', 'd9_severe', 'long_severe', 'long_mixed'):
    order += [(t, s) for s in seeds[t]]
with open('jobs10.txt', 'w') as f:
    for t, s in order:
        n = f'{t}_s{s}'
        f.write(f'{n} {est[t]} - python3 {runner(t)} cfg10/{t}.json out10/{n}.npz seed={s} > out10/{n}.json\n')
print(len(order), 'jobs; total estimate', sum(est[t] for t, _ in order) / 3600, 'h of CPU')
