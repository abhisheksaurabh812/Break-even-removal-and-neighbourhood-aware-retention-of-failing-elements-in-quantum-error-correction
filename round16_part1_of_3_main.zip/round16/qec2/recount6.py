"""Independent recount of round-6 headline numbers straight from the raw per-block failure arrays
(no shared code with analyse6.py): totals, twin vs loc (per-epoch paired), delay-curve shares,
and a spot check that every analog activation names an ancilla that is really failing."""
import glob, json, re
import numpy as np
from math import erf, sqrt

out = {}
for scen in ('ro', 't1m', 't1m_severe', 't1d', 'ro_short', 't1d_severe', 'ro_severe'):
    files = sorted(f for f in glob.glob(f'out6/test_{scen}_s*.npz') if re.fullmatch(rf'test_{re.escape(scen)}_s\d+\.npz', f.split('/')[-1]))
    if not files:
        continue
    tot = {}; diff = []
    act = 0; act_ok = 0
    for f in files:
        z = np.load(f, allow_pickle=True)
        names = [str(x) for x in z['names']]
        fails = z['fails'].astype(np.int64)                    # (arms, epochs, blocks)
        for i, n in enumerate(names):
            tot[n] = tot.get(n, 0) + int(fails[i].sum())
        diff.append(fails[names.index('twin')].sum(1) - fails[names.index('loc')].sum(1))
        ev = json.loads(str(z['events'])); info = json.loads(str(z['info']))
        er = json.loads(str(z['cfg']))['bpe'] * 7
        for l in info['twin']['analog']['log']:
            if l[0] == 'on':
                act += 1
                t = l[1] * er
                act_ok += any(e[2] == l[3] and e[0] <= t <= e[0] + e[1] + 20 * er for e in ev)
    d = np.concatenate(diff).astype(float)
    zz = d.sum() / np.sqrt((d ** 2).sum()) if (d ** 2).sum() > 0 else 0.0
    p = 1 - erf(abs(zz) / sqrt(2))
    gap = tot['static-est'] - tot['oracle']
    out[scen] = dict(seeds=len(files), totals=tot,
                     twin_vs_loc=dict(rel=round((tot['twin'] - tot['loc']) / tot['loc'], 5), z=round(float(zz), 2), p=float(p)),
                     gap_static_oracle_rel=round(gap / tot['oracle'], 4),
                     share_lost={n: round((tot[n] - tot['oracle']) / gap, 3) for n in tot if n.startswith('od') or n in ('loc', 'twin')} if gap else None,
                     analog_activations=act, activations_on_failing_qubit=act_ok)
print(json.dumps(out, indent=1))
