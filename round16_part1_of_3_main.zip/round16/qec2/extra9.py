"""Round 9, reported only (written after the pre-registration, while the test jobs ran; no rule uses it):
time spent with a qubit switched out that had no active failure, per arm, for every finished scenario.
python3 extra9.py > out9/extra9.json"""
import json
import analyse8 as A
from analyse9 import SEEDS, runs

res = {}
for scen in SEEDS:
    rs = runs(scen)
    if not rs:
        continue
    R = {}
    for arm in ('sz_field', 'sz_gated', 'sz_all'):
        per = []
        for r in rs:
            er = r['cfg']['bpe'] * r['cfg']['d']; tot = r['fails'].shape[1] * er
            n = h = 0; rounds = 0.0; longest = 0.0
            for g, a, b, t in A.out_intervals(r['info'][arm].get('policy_log', []), er):
                n += 1
                if any(dd[2] == g and dd[0] <= t < dd[0] + dd[1] for dd in r['defects']):
                    continue
                h += 1
                dur = (tot if b is None else b) - a
                rounds += dur; longest = max(longest, dur)
            per.append(dict(seed=r['cfg']['seed'], switch_outs=n, without_failure=h,
                            rounds_out_without_failure=int(rounds), longest=int(longest)))
        R[arm] = dict(switch_outs=sum(p['switch_outs'] for p in per),
                      without_failure=sum(p['without_failure'] for p in per),
                      rounds_out_without_failure=sum(p['rounds_out_without_failure'] for p in per),
                      longest=max(p['longest'] for p in per), per_seed=per)
    res[scen] = R
print(json.dumps(res, indent=1))
