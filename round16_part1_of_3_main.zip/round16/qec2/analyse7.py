"""Round 7 analysis.
   python3 analyse7.py p2   -> Part 2 (response policies): rules G1-G4 and reported metrics
   python3 analyse7.py p1   -> Part 1 (sizing vs readout twin): rules C1-C3 and reported metrics"""
import glob, json, re, sys
import numpy as np
from scipy.special import ndtr

MODE = sys.argv[1] if len(sys.argv) > 1 else 'p2'
THETA = {'D': 13.0, 'Z': 7.0}
roles = np.load('roles_d7.npz')
ROLE = {}
for g in roles['zq']: ROLE[int(g)] = 'Z'
for g in roles['xanc']: ROLE[int(g)] = 'X'
for g in roles['data']: ROLE[int(g)] = 'D'


def files(prefix, scen):
    return sorted(f for f in glob.glob(f'{prefix}{scen}_s*.npz') if re.fullmatch(rf'{re.escape(scen)}_s\d+\.npz', f[len(prefix):]))


def load(fs):
    out = []
    for f in fs:
        z = np.load(f, allow_pickle=True)
        ev = json.loads(str(z['events']))
        out.append(dict(file=f, names=[str(x) for x in z['names']], fails=z['fails'].astype(np.int64),
                        info=json.loads(str(z['info'])), cfg=json.loads(str(z['cfg'])),
                        defects=ev['defects'] if isinstance(ev, dict) else [e[:4] for e in ev]))
    return out


def per_epoch(r, arm):
    return r['fails'][r['names'].index(arm)].sum(1)


def compare(runs, a, b, masks=None):
    d = []; fa = fb = 0
    for i, r in enumerate(runs):
        x, y = per_epoch(r, a), per_epoch(r, b)
        if masks is not None:
            x, y = x[masks[i]], y[masks[i]]
        d.append(x - y); fa += int(x.sum()); fb += int(y.sum())
    d = np.concatenate(d).astype(float)
    s = float(np.sqrt((d ** 2).sum()))
    z = float(d.sum() / s) if s > 0 else 0.0
    return dict(fails=fa, ref_fails=fb, rel=round((fa - fb) / max(fb, 1), 5), z=round(z, 2), p=float(2 * (1 - ndtr(abs(z)))))


def beats(x, pct):
    return bool(x['rel'] <= -pct and x['p'] < 0.01 and x['z'] < 0)


def active_defect(defects, g, t):
    return [d for d in defects if d[2] == g and d[0] <= t < d[0] + d[1]]


def policy_checks(runs, arm):
    """Switch-outs of qubits with no active failure; switch-out delay vs onset for failures past the
    crossover; fraction of crossover-passing failures switched out."""
    outs = 0; false_out = 0; delays = []; n_cross = 0; n_cross_out = 0
    for r in runs:
        er = r['cfg']['bpe'] * 7
        log = r['info'][arm].get('policy_log', [])
        first_out = {}
        for l in log:
            if l[0] != 'out':
                continue
            outs += 1
            t = (l[1] + 0.5) * er; g = l[3]
            act = active_defect(r['defects'], g, t)
            if not act:
                false_out += 1
            else:
                key = (g, act[0][0])
                first_out.setdefault(key, t)
        for d in r['defects']:
            g = d[2]; rl = ROLE[g]
            if rl in THETA and d[3] >= THETA[rl]:
                n_cross += 1
                t = first_out.get((g, d[0]))
                if t is not None:
                    n_cross_out += 1; delays.append(t - d[0])
    return dict(switch_outs=outs, switch_outs_without_failure=false_out,
                crossover_failures=n_cross, of_which_switched_out=n_cross_out,
                median_delay_rounds=float(np.median(delays)) if delays else None)


def sizing(runs, arm):
    """Fitted factor at naming / true factor of the active failure on that qubit."""
    rat = {'D': [], 'Z': [], 'X': []}
    for r in runs:
        er = r['cfg']['bpe'] * 7
        inf = r['info'][arm]
        for l in inf.get('sized', {}).get('log', []):
            if l[0] != 'on':
                continue
            t = (l[1] - 0.5) * er; g = l[2]
            act = active_defect(r['defects'], g, t)
            if act:
                rat[ROLE[g]].append(l[3] / float(np.prod([d[3] for d in act])))
    return {k: dict(n=len(v), median=round(float(np.median(v)), 3) if v else None) for k, v in rat.items()}


def p2():
    res = {}
    for scen in ('severe', 'mixed', 'moderate', 'none', 'realistic'):
        fs = files('out7/test_', scen)
        if not fs:
            continue
        runs = load(fs); names = runs[0]['names']
        tot = {n: sum(int(r['fails'][k].sum()) for r in runs) for k, n in enumerate(names)}
        R = dict(seeds=len(fs), totals=tot)
        for a, b in (('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz_all', 'sz'), ('sz', 'loc'), ('sz_gated', 'loc'),
                     ('sz_gated_timer', 'sz_gated'), ('oracle_gated', 'oracle'), ('oracle_all', 'oracle'),
                     ('oracle_gated', 'oracle_all'), ('oracle', 'sz'), ('oracle_gated', 'sz_gated')):
            R[f'{a} vs {b}'] = compare(runs, a, b)
        R['policy_sz_gated'] = policy_checks(runs, 'sz_gated')
        R['policy_sz_all'] = policy_checks(runs, 'sz_all')
        R['sizing_sz'] = sizing(runs, 'sz')
        res[scen] = R
    rules = {}
    if 'severe' in res: rules['G1_severe_gated_beats_sz_10pct'] = beats(res['severe']['sz_gated vs sz'], 0.10)
    if 'mixed' in res:
        rules['G2_mixed_gated_beats_sz_5pct'] = beats(res['mixed']['sz_gated vs sz'], 0.05)
        rules['G2_mixed_gated_beats_all_3pct'] = beats(res['mixed']['sz_gated vs sz_all'], 0.03)
    if 'moderate' in res: rules['G3_moderate_no_worse_1pct'] = bool(res['moderate']['sz_gated vs sz']['rel'] <= 0.01)
    if 'none' in res: rules['G4_none_no_worse_0.5pct'] = bool(res['none']['sz_gated vs sz']['rel'] <= 0.005)
    res['rules'] = rules
    return res


def p1():
    res = {}
    r6 = json.load(open('out6/res_test.json'))
    for scen in ('t1m_severe', 't1d_severe', 't1m', 't1d'):
        fs = files('out7/p1_', scen)
        if not fs:
            continue
        runs = load(fs); names = runs[0]['names']
        tot = {n: sum(int(r['fails'][k].sum()) for r in runs) for k, n in enumerate(names)}
        R = dict(seeds=len(fs), totals=tot)
        if len(fs) == 3:
            R['reproduces_round6'] = {a: tot[a] == r6[scen]['totals'][a] for a in ('static-est', 'loc', 'twin', 'oracle')}
        for a, b in (('sz', 'loc'), ('sz', 'twin'), ('twin', 'loc'), ('oracle', 'sz')):
            R[f'{a} vs {b}'] = compare(runs, a, b)
        # per-role failure windows (onset to end + 20 epochs)
        for rl in ('Z', 'X', 'D'):
            masks = []
            for r in runs:
                er = r['cfg']['bpe'] * 7; n_ep = r['fails'].shape[1]
                mk = np.zeros(n_ep, bool)
                for d in r['defects']:
                    if ROLE[d[2]] == rl:
                        mk[int(d[0] // er):min(n_ep, int((d[0] + d[1]) // er) + 20)] = True
                masks.append(mk)
            if not any(m.any() for m in masks):
                continue
            Fl = sum(int(per_epoch(r, 'loc')[m].sum()) for r, m in zip(runs, masks))
            Fs = sum(int(per_epoch(r, 'sz')[m].sum()) for r, m in zip(runs, masks))
            Ft = sum(int(per_epoch(r, 'twin')[m].sum()) for r, m in zip(runs, masks))
            Fo = sum(int(per_epoch(r, 'oracle')[m].sum()) for r, m in zip(runs, masks))
            R[f'windows_{rl}'] = dict(epochs=int(sum(m.sum() for m in masks)), loc=Fl, sz=Fs, twin=Ft, oracle=Fo,
                                      share_of_twin_gain=round((Fl - Fs) / (Fl - Ft), 3) if Fl != Ft else None,
                                      sz_vs_loc=compare(runs, 'sz', 'loc', masks), twin_vs_loc=compare(runs, 'twin', 'loc', masks))
        R['sizing_sz'] = sizing(runs, 'sz')
        res[scen] = R
    rules = {}
    if 't1m_severe' in res and 'windows_Z' in res['t1m_severe']:
        w = res['t1m_severe']['windows_Z']
        rules['C1_t1m_severe_Z_sz_recovers_2/3_of_twin_gain'] = bool(w['share_of_twin_gain'] is not None and w['share_of_twin_gain'] >= 0.667)
    if 't1d_severe' in res: rules['C2_t1d_severe_sz_beats_loc_10pct'] = beats(res['t1d_severe']['sz vs loc'], 0.10)
    for s in ('t1m', 't1d'):
        if s in res: rules[f'C3_{s}_sz_no_worse_0.5pct'] = bool(res[s]['sz vs loc']['rel'] <= 0.005)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(p2() if MODE == 'p2' else p1(), indent=1))
