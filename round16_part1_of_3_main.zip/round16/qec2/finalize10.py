"""Fill the d = 9 table and the time into PREREG_round10.md (run once, after the table finished, before any test job)."""
import json, time, sys
rows = {k: json.load(open(f'out10/field_table_d9_{k}.json'))['rows'] for k in ('data', 'zanc')}
Ls = [r['L'] for r in rows['data']]
assert Ls == [r['L'] for r in rows['zanc']] == [1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0], Ls
fmt = lambda v: 'none on the grid' if v is None else f'{v:g}'
tab = ('| L (neighbours, x nominal) | ' + ' | '.join(f'{L:g}' for L in Ls) + ' |\n|---|' + '---|' * len(Ls) + '\n'
       + '| data qubit crossover, d = 9 | ' + ' | '.join(fmt(r['crossover']) for r in rows['data']) + ' |\n'
       + '| Z ancilla crossover, d = 9 | ' + ' | '.join(fmt(r['crossover']) for r in rows['zanc']) + ' |\n\n'
       + 'For comparison, round 9 (d = 7): data 13.77, 14.04, 15.34, 15.81, 14.23, 12.75, 11.72; Z ancilla 6.44, 8.28, '
       + '9.34, 12.0, 13.9, 16.93, 18.04.')
p = open('PREREG_round10.md').read()
assert '«TABLE»' in p and '«WRITTEN»' in p
p = p.replace('«TABLE»', tab).replace('«WRITTEN»', time.strftime('written %d %b %Y, %H:%M IST') + '; no round-10 test job had started when this file was written')
open('PREREG_round10.md', 'w').write(p)
print(tab)
