"""Round 10: compare analyse10.py's numbers (out10/res_10.json) with the independent recount
(out10/recount10.json) and re-derive every verdict from the recount alone.   python3 check10.py > out10/check10.json"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out10/res_10.json'))
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out10/recount10.json'))
mism = []; n = 0
for key, c in C.items():
    if c is None:
        continue
    test, pair = key.split(': ')
    a = R[test][pair]
    for name, x, y in (('fails', a['fails'], c['a']), ('ref_fails', a['ref_fails'], c['b']), ('rel', a['rel'], c['rel']),
                       ('z', a['z'], c['z']), ('per_seed', a['per_seed'], c['per_seed']),
                       ('boot_lo', a['boot95']['lo'], c['boot95'][0]), ('boot_hi', a['boot95']['hi'], c['boot95'][1])):
        n += 1
        if x != y:
            mism.append(dict(key=key, field=name, analyse=x, recount=y))


def beats(c, pct):
    return c['rel'] <= -pct and c['p'] < 0.01 and c['z'] < 0 and max(c['per_seed']) <= 0.01


g = lambda k: C.get(k)
v = {}
if g('d9_realistic: sz_field vs loc'):
    c = g('d9_realistic: sz_field vs loc'); v['D9a'] = c['rel'] <= 0.01 and c['boot95'][1] <= 0.02
if g('d9_mixed: sz_field vs sz') and g('d9_mixed: sz_field vs sz_all'):
    v['D9b_sz'] = beats(g('d9_mixed: sz_field vs sz'), 0.05); v['D9b_all'] = beats(g('d9_mixed: sz_field vs sz_all'), 0.03)
if g('d9_severe: sz_field vs sz'):
    v['D9c'] = beats(g('d9_severe: sz_field vs sz'), 0.10)
if g('d9_moderate: sz_field vs sz'):
    v['D9d'] = g('d9_moderate: sz_field vs sz')['rel'] <= 0.01
if g('pairs_mixed: sz_field vs sz'):
    v['P1'] = g('pairs_mixed: sz_field vs sz')['rel'] <= 0.01
if g('long_severe: sz_field vs sz'):
    v['L1'] = beats(g('long_severe: sz_field vs sz'), 0.10)
if g('long_mixed: sz_field vs sz') and g('long_mixed: sz_field vs sz_all'):
    v['L2_sz'] = beats(g('long_mixed: sz_field vs sz'), 0.05); v['L2_all'] = beats(g('long_mixed: sz_field vs sz_all'), 0.03)
names = dict(D9a='D9a_realistic_field_vs_loc_within_1pct_and_upper95_within_2pct', D9b_sz='D9b_mixed_field_beats_sz_5pct',
             D9b_all='D9b_mixed_field_beats_all_3pct', D9c='D9c_severe_field_beats_sz_10pct',
             D9d='D9d_moderate_field_vs_sz_within_1pct', P1='P1_pairs_field_vs_sz_within_1pct',
             L1='L1_long_severe_field_beats_sz_10pct', L2_sz='L2_long_mixed_field_beats_sz_5pct',
             L2_all='L2_long_mixed_field_beats_all_3pct')
ra = R.get('rules', {})
print(json.dumps(dict(values_compared=n, mismatches=mism, recount_verdicts=v, analyse_verdicts=ra,
                      verdicts_agree={k: v[k] == ra.get(names[k]) for k in v}), indent=1))
