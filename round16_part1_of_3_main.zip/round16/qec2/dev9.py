"""Round 9 development check on seeds already used in rounds 7b and 8 (not a test).
python3 dev9.py [prefix: dev (version 1) | dev2 (version 2)] > out9/<prefix>_res.json"""
import json, os, glob, sys
import numpy as np
import analyse8 as A
from analyse9 import split_by_switchout

PFX = sys.argv[1] if len(sys.argv) > 1 else 'dev'
res = {}
for scen in ('realistic', 'mixed', 'severe'):
    fs = sorted(f for f in glob.glob(f'out9/{PFX}_{scen}_s*.npz') if os.path.exists(f'out9/done/{os.path.basename(f)[:-4]}'))
    if not fs:
        continue
    rs = [A.load(f) for f in fs]
    names = rs[0]['names']
    R = dict(seeds=[r['cfg']['seed'] for r in rs], totals=A.totals(rs))
    for ref in ('loc', 'sz', 'sz_all', 'sz_gated'):
        if ref in names:
            c = A.compare(rs, 'sz_field', ref); R[f'sz_field vs {ref}'] = dict(rel=c['rel'], z=c['z'], per_seed=c['per_seed'])
    for a, b in (('sz_gated', 'loc'), ('sz_gated', 'sz')):
        if b in names:
            c = A.compare(rs, a, b); R[f'{a} vs {b}'] = dict(rel=c['rel'], z=c['z'], per_seed=c['per_seed'])
    for arm in ('sz_field', 'sz_gated'):
        pc = A.policy_checks(rs, arm)
        R[f'policy_{arm}'] = {k: pc[k] for k in ('switch_outs', 'switch_outs_without_failure', 'crossover_failures', 'switched_out')}
        R[f'split_{arm}_vs_sz'] = split_by_switchout(rs, arm, 'sz')
    outs = [l for r in rs for l in r['info']['sz_field'].get('policy_log', []) if l[0] == 'out']
    R['field_out_levels'] = [l[6] for l in outs]
    R['field_out_fabs_thr'] = [[l[3], l[5], l[7]] for l in outs][:40]
    res[scen] = R
print(json.dumps(res, indent=1))
