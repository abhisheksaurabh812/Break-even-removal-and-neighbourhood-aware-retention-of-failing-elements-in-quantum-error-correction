"""
Decisive-test runner.  Usage:  python3 run2.py config.json out.npz

Scenario factors are per qubit and per epoch (an epoch = `bpe` decoding blocks of T rounds).
Every arm decodes the same detection events; weights for an epoch use only earlier epochs.
Phase flags per epoch (bitmask):
  1 burst active, 2 post-burst (60k rounds after a burst), 4 single-qubit defect active,
  8 within 200k rounds after a persistent step began, 16 after any persistent step began.
"""
import sys, json, time, hashlib
from collections import OrderedDict
import numpy as np
from model import circuit_model, phenom_model, P_REF
from sampler import Sampler, build_matching
from arms import prepare, Static, Oracle, Window, Slow, Stats, estimate


def make_scenario(m, cfg, rng):
    bpe = cfg['bpe']; T = m.T; er = bpe * T
    n_ep = cfg['total_rounds'] // er
    t = (np.arange(n_ep) + 0.5) * er
    tot = n_ep * er
    G, xy, lat = m.G, m.qxy, m.lattice
    f0 = np.exp(cfg['het_sigma'] * rng.standard_normal(G)); f0 /= np.median(f0)
    f0 = np.clip(f0, 0.25, 4.0)
    F = np.tile((f0 * cfg['p_base'] / P_REF).astype(np.float32), (n_ep, 1))
    flags = np.zeros(n_ep, np.uint8)
    events = dict(bursts=[], defects=[], steps=[])
    half = (m.d * lat) / 2
    if cfg.get('drift_frac', 0) > 0:
        sel = rng.random(G) < cfg['drift_frac']
        fac = rng.uniform(1.0, cfg['drift_fac'], G)
        F[:, sel] *= (fac[sel][None, :] ** (t / tot)[:, None]).astype(np.float32)
    if cfg.get('bursts', False):
        t0 = 0.0
        while True:
            t0 += rng.uniform(*cfg['burst_gap'])
            tau = rng.uniform(*cfg['burst_tau']); peak = rng.uniform(*cfg['burst_peak'])
            if t0 + 5 * tau > tot:
                break
            cen = m.center + rng.uniform(-half, half, 2)
            space = np.exp(-((xy - cen) ** 2).sum(1) / (2 * (cfg['burst_sigma'] * lat) ** 2))
            on = (t >= t0) & (t < t0 + 5 * tau)
            amp = np.where(on, np.exp(-(t - t0) / tau), 0.0)
            F *= (1 + (peak - 1) * amp[:, None] * space[None, :]).astype(np.float32)
            flags[on] |= 1
            flags[(t >= t0 + 5 * tau) & (t < t0 + 5 * tau + 60000)] |= 2
            events['bursts'].append([float(t0), float(tau), float(peak), cen.tolist()])
            t0 += 5 * tau
    if cfg.get('defects', False):
        t0 = 0.0
        while True:
            t0 += rng.exponential(cfg['defect_gap'])
            if t0 > tot:
                break
            q = int(rng.integers(G)); fac = rng.uniform(*cfg['defect_fac']); dur = rng.uniform(*cfg['defect_dur'])
            on = (t >= t0) & (t < t0 + dur)
            F[on, q] *= fac
            flags[on] |= 4
            events['defects'].append([float(t0), float(dur), q, float(fac)])
    for frac in cfg.get('steps', []):
        ts = frac * tot
        cen = m.center + rng.uniform(-half * 0.6, half * 0.6, 2)
        space = np.exp(-((xy - cen) ** 2).sum(1) / (2 * (cfg['step_sigma'] * lat) ** 2))
        on = t >= ts
        F[on] *= (1 + (cfg['step_fac'] - 1) * space)[None, :].astype(np.float32)
        flags[(t >= ts) & (t < ts + 200000)] |= 8
        flags[on] |= 16
        events['steps'].append([float(ts), cen.tolist()])
    return F, flags, events


def build_arms(m, cal, specs):
    arms = []
    for sp in specs:
        k = sp['kind']; nm = sp['name']
        est = sp.get('base') == 'est'          # base weights from an estimated calibration run
        c = dict(pe=cal['pe_est'], mu=cal['mu_est']) if est else cal
        if k == 'static':
            arms.append(Static(nm, m, c))
        elif k == 'oracle':
            arms.append(Oracle(nm, m, cal))
        elif k == 'window':
            arms.append(Window(nm, m, c, sp['k'], sp.get('k_long'), sp.get('z')))
        elif k == 'slow':
            arms.append(Slow(nm, m, cal, sp['R'], sp.get('s', 1), sp.get('cusum'), sp.get('gating', False),
                             sp.get('reseed', False), sp.get('tmax'), sp.get('footprint')))
        else:
            raise ValueError(k)
    return arms


def run(cfg, out):
    m = circuit_model(cfg['d']) if cfg['noise'] == 'circuit' else phenom_model(cfg['d'])
    prepare(m)
    rng_sc = np.random.default_rng(cfg['seed'])
    F, flags, events = make_scenario(m, cfg, rng_sc)
    n_ep, bpe, T = F.shape[0], cfg['bpe'], m.T
    f_cal = F[0].astype(np.float64)
    pe = m.edge_p(f_cal); qd = m.det_rate(f_cal)
    qcl = np.bincount(m.dclass, qd, m.nclass) / m.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in m.int_classes]), f0=f_cal)
    if any(sp.get('base') == 'est' for sp in cfg['arms']):
        # calibration experiment at the t = 0 rates, separate random stream, same estimator as the slow arms
        cs = Sampler(m, np.random.default_rng(cfg['seed'] + 77777))
        st = Stats(m); nblk = cfg.get('cal_rounds', 1_000_000) // T
        for _ in range(0, nblk, 5000):
            Xc_, _ = cs.sample(np.tile(f_cal, (5000 // bpe, 1)), bpe); st.add(Xc_)
        pe_e, q_e, _, _ = estimate(m, st, pe, qcl, 10, 10)
        cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in m.int_classes])
    arms = build_arms(m, cal, cfg['arms'])
    A = len(arms)
    sampler = Sampler(m, np.random.default_rng(cfg['seed'] + 99991))
    fails = np.zeros((A, n_ep, bpe), np.uint8)
    werr = np.zeros((A, n_ep), np.float32)
    mcache = OrderedDict(); builds = 0; decodes = 0
    chunk = cfg.get('chunk', 250)
    t0 = time.time()
    for cs in range(0, n_ep, chunk):
        ce = min(n_ep, cs + chunk)
        Xc, oc = sampler.sample(F[cs:ce].astype(np.float64), bpe)
        for e in range(cs, ce):
            X = Xc[(e - cs) * bpe:(e - cs + 1) * bpe]; obs = oc[(e - cs) * bpe:(e - cs + 1) * bpe]
            true_pe = m.edge_p(F[e].astype(np.float64))
            lt = np.log(true_pe)
            crr = (X.astype(np.float32) @ m.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            preds = {}
            for i, arm in enumerate(arms):
                w = np.round(arm.weights(true_pe), 3)
                key = hashlib.md5(w.tobytes()).digest()
                pr = preds.get(key)
                if pr is None:
                    mt = mcache.get(key)
                    if mt is None:
                        mt = build_matching(m, w); builds += 1
                        mcache[key] = mt
                        if len(mcache) > 300:
                            mcache.popitem(last=False)
                    else:
                        mcache.move_to_end(key)
                    pr = mt.decode_batch(X)[:, 0]; decodes += 1
                    preds[key] = pr
                fails[i, e] = pr ^ obs
                werr[i, e] = np.mean(np.abs(-np.log1p(np.exp(w)) - lt))   # |ln p_eff - ln p_true|
            for arm in arms:
                arm.update(X, crr)
        if cfg.get('verbose'):
            print(f'{ce}/{n_ep} epochs {time.time() - t0:.0f}s builds={builds} decodes={decodes}', file=sys.stderr, flush=True)
    names = [a.name for a in arms]
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, werr=werr, flags=flags, names=np.array(names),
                        cfg=json.dumps(cfg), events=json.dumps(events), info=json.dumps(info))
    tot = fails.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes,
                          totals=dict(zip(names, tot.tolist())), info=info,
                          n_bursts=len(events['bursts']), n_defects=len(events['defects']))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
