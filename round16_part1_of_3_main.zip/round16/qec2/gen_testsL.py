"""After localizer tuning: pick the variant (pre-registered rule) and write the test configs.
Rule: the candidate minimising the mean over {defects, mixed} of fails / fails(gated-fp), training seeds 101, 102."""
import json, glob, copy
import numpy as np
tot = {}
for scen in ('defects', 'mixed'):
    for f in sorted(glob.glob(f'out/tuneL_{scen}_s*.npz')):
        z = np.load(f, allow_pickle=True); nm = list(z['names']); F = z['fails'].reshape(len(nm), -1).sum(1)
        for n, v in zip(nm, F):
            tot.setdefault(n, {}).setdefault(scen, 0); tot[n][scen] += int(v)
cands = [n for n in tot if n.startswith('aloc') or n == 'fp-loc']
score = {n: np.mean([tot[n][s] / tot['gated-fp'][s] - 1 for s in ('defects', 'mixed')]) for n in cands}
pick = min(score, key=score.get)
tune = json.load(open('cfg/tuneL_defects.json'))
by = {a['name']: a for a in tune['arms']}
loc = copy.deepcopy(by[pick]); loc['name'] = 'loc'
nooff = copy.deepcopy(by['gated-fp']); nooff['name'] = 'fp-nooff'; nooff['footprint']['local_nooff'] = True
base = json.load(open('cfg/testL_defects.json'))
static = [a for a in base['arms'] if a['name'] == 'static-est'][0]
arms = [static, by['slow+off@g'], by['gated-fp'], nooff, loc, dict(kind='oracle', name='oracle')]
for scen in ('defects', 'mixed', 'real1s'):
    c = json.load(open(f'cfg/testL_{scen}.json')); c['arms'] = arms; c['verbose'] = False
    json.dump(c, open(f'cfg/testL_{scen}.json', 'w'), indent=1)
json.dump(dict(pick=pick, score={k: round(v, 5) for k, v in score.items()}, totals=tot), open('out/pickL.json', 'w'), indent=1)
print('picked', pick, {k: round(v, 4) for k, v in score.items()})
