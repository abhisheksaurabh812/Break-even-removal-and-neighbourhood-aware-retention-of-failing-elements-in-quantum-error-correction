"""Post-hoc diagnostic (round 9, not pre-registered): failures on which the new and old gates disagreed.
For every failure on a switchable qubit in the moderate, mixed and severe runs (no regional noise, so the
neighbourhood level is close to 1), compares how much of the failure each gate had the qubit switched out. Where
the two out-fractions differ by more than 0.2, it records the qubit's true factor relative to nominal noise at
the failure's onset (rebuilt from the run's own scenario) and the new-minus-old failure count during the
failure. Rows are binned by the true factor divided by the clean-patch crossover f*(kind, L = 1).
python3 diag9_disagree.py > out9/diag9_disagree.json"""
import json
import numpy as np
import analyse8 as A
from analyse9 import SEEDS
from run3 import base_model
from run7 import make_scenario
from model import P_REF

_, EX = A.roles(7)
TAB = {k: dict((r['L'], r['crossover']) for r in json.load(open(f'out9/field_table_{k}.json'))['rows'])[1.0]
       for k in ('data', 'zanc')}
BINS = [(0, 0.75), (0.75, 1.0), (1.0, 1.25), (1.25, 1.5), (1.5, 1e9)]
base = base_model(7)


def cover(iv, q, t0, t1, tot):
    c = 0.0
    for g, a, b, _ in iv:
        if g == q:
            b = tot if b is None else b
            c += max(0.0, min(b, t1) - max(a, t0))
    return c / max(t1 - t0, 1)


res = {}
for scen in ('moderate', 'mixed', 'severe'):
    rows = []
    for s in SEEDS[scen]:
        r = A.load(f'out9/test_{scen}_s{s}.npz'); cfg = r['cfg']; er = cfg['bpe'] * cfg['d']
        F, _, ev = make_scenario(base, cfg, np.random.default_rng(cfg['seed']))
        assert ev['defects'] == r['defects']
        fn = cfg['p_base'] / P_REF; tot = r['fails'].shape[1] * er
        fa, fb = A.per_epoch(r, 'sz_field'), A.per_epoch(r, 'sz_gated')
        ivf = A.out_intervals(r['info']['sz_field']['policy_log'], er)
        ivg = A.out_intervals(r['info']['sz_gated']['policy_log'], er)
        for t0, dur, q, fac in r['defects']:
            if q not in EX:
                continue
            t1 = min(t0 + dur, tot); e0 = int(t0 // er); e1 = min(int(t1 // er), len(fa) - 1)
            cf, cg = cover(ivf, q, t0, t1, tot), cover(ivg, q, t0, t1, tot)
            if abs(cf - cg) <= 0.2:
                continue
            fabs = float(F[min(e0 + 1, len(F) - 1), q] / fn)
            rows.append(dict(seed=s, q=int(q), kind=EX[q], fac_vs_cal=round(fac, 2), fabs=round(fabs, 2),
                             rel_to_crossover=round(fabs / TAB[EX[q]], 3), rounds=int(t1 - t0),
                             new_out=round(cf, 2), old_out=round(cg, 2), who_out='new' if cf > cg else 'old',
                             new_minus_old=int(fa[e0:e1 + 1].sum() - fb[e0:e1 + 1].sum())))
    summ = {}
    for who in ('new', 'old'):
        for lo, hi in BINS:
            sel = [x for x in rows if x['who_out'] == who and lo <= x['rel_to_crossover'] < hi]
            if sel:
                summ[f'{who} switched out, factor {lo}-{hi if hi < 1e8 else "inf"} x crossover'] = dict(
                    failures=len(sel), new_minus_old=sum(x['new_minus_old'] for x in sel))
    res[scen] = dict(rows=rows, summary=summ, total_new_minus_old=int(sum(x['new_minus_old'] for x in rows)))
print(json.dumps(dict(crossover_L1=TAB, **res), indent=1))
