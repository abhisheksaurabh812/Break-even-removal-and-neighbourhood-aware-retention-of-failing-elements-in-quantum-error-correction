"""Round 9: markdown tables for RESULTS_round9.md from out9/res_9.json and out9/extra9.json (reporting only).
python3 tables9.py [res extra]"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out9/res_9.json'))
X = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out9/extra9.json'))
pc = lambda v: f'{100 * v:+.1f}%'
pc2 = lambda v: f'{100 * v:+.2f}%'


def iv(c):
    return f"[{pc2(c['boot95']['lo'])}, {pc2(c['boot95']['hi'])}]"


print('### realistic per seed')
r = R['realistic']
seeds = [p['seed'] for p in X['realistic']['sz_field']['per_seed']]
print('| Seed | New gate vs localizer | Old gate vs localizer | Reweighting vs localizer | New vs old gate | '
      'No-failure switch-outs, new (rounds) | Same, old gate (rounds) |')
print('|---|---|---|---|---|---|---|')
for i, s in enumerate(seeds):
    a = X['realistic']['sz_field']['per_seed'][i]; b = X['realistic']['sz_gated']['per_seed'][i]
    print(f"| {s} | {pc(r['sz_field vs loc']['per_seed'][i])} | {pc(r['sz_gated vs loc']['per_seed'][i])} | "
          f"{pc(r['sz vs loc']['per_seed'][i])} | {pc(r['sz_field vs sz_gated']['per_seed'][i])} | "
          f"{a['without_failure']} ({a['rounds_out_without_failure'] / 1000:.0f}k) | "
          f"{b['without_failure']} ({b['rounds_out_without_failure'] / 1000:.0f}k) |")
print(f"| All | {pc2(r['sz_field vs loc']['rel'])} | {pc2(r['sz_gated vs loc']['rel'])} | {pc2(r['sz vs loc']['rel'])} | "
      f"{pc2(r['sz_field vs sz_gated']['rel'])} | {X['realistic']['sz_field']['without_failure']} "
      f"({X['realistic']['sz_field']['rounds_out_without_failure'] / 1000:.0f}k) | "
      f"{X['realistic']['sz_gated']['without_failure']} ({X['realistic']['sz_gated']['rounds_out_without_failure'] / 1000:.0f}k) |")
print()
print('### new gate vs old gate, every scenario')
for s in ('realistic', 'mixed', 'severe', 'moderate'):
    if s in R:
        c = R[s]['sz_field vs sz_gated']
        print(f"| {s} | {pc2(c['rel'])} | {iv(c)} | z {c['z']} | seeds {', '.join(pc(v) for v in c['per_seed'])} |")
print()
print('### all pairs')
for s in ('realistic', 'mixed', 'severe', 'moderate'):
    if s not in R:
        continue
    print('#', s, R[s]['seeds'], 'seeds; totals', R[s]['totals'])
    for k, c in R[s].items():
        if ' vs ' in k:
            print(f"  {k:26s} {pc2(c['rel'])} {iv(c)} z {c['z']} p {c['p']:.2g} worst {pc(c['worst_seed'])}")
    for arm in ('sz_field', 'sz_gated'):
        p = R[s][f'policy_{arm}']
        print(f"  {arm}: outs {p['switch_outs']}, without failure {p['switch_outs_without_failure']}, past-crossover failures "
              f"{p['crossover_failures']}, switched out {p['switched_out']}, median out fraction {p['median_out_fraction']}, "
              f"median delay {p['median_delay_rounds']}")
        sp = R[s][f'split_{arm}_vs_sz']
        print('   split vs sz', {k: (v['epochs'], v['diff'], v['rel_within']) for k, v in sp.items()})
    for arm in ('sz_field', 'sz_gated', 'sz_all'):
        x = X[s][arm]
        print(f"  time out without failure {arm}: {x['without_failure']} switch-outs, {x['rounds_out_without_failure']} rounds, longest {x['longest']}")
    print('  field decisions', R[s]['field_decisions'])
print('rules', R['rules'])
