"""
Round 9: field-aware size gate (fix for the round-8 realistic failure).

PolicyArmField is PolicyArm (arms7) in 'gated' mode with three changes, all on the decision side:
 1. Absolute reference.  The learner's fitted factor r is relative to the qubit's own t = 0 calibration;
    the gate converts it to a factor relative to nominal noise, f = r * f_cal / f_nom, before comparing
    it with a crossover (the crossovers are defined against nominal noise).
 2. Local level.  The twin estimates the noise level L around the qubit from the recent detection rates
    of the Z ancillas within Chebyshev distance 4 of it that lie outside its own footprint (no share of
    its error mass >= 1%): median over those ancillas of u_obs / u_nom, with u = -ln(1 - 2q) / 2 and q
    the interior detection fraction over the last WL epochs (u_nom: nominal noise everywhere).
 3. Level-dependent crossover.  Switch out when f >= f*(kind, L), with f*(kind, L) from a table computed
    offline (ideal_field9.py: Stim + PyMatching, region of radius 4 at level L), interpolated linearly in
    (ln L, ln f*); L is clamped to the table's range; beyond the last L with a crossing, never switch out.
The probe reads the qubit's absolute factor (same 15% log-normal error) and puts it back below
f*(kind, L) / 1.5, with L estimated at that moment; the learner is then pinned at the probed value
converted back to its calibration-relative scale.  Everything else (learner, at most two compatible
exclusions, probe period, logging layout of the first four fields) is unchanged.

Version 2 (after the development runs on old seeds, 4 Nov 04:40; version 1 = resize False, ring_min 3,
fallback 'one'):
 4. Size against the neighbourhood.  At decision time the qubit is re-sized from the learner's own window
    of counts, with every other qubit's contribution taken at the local level L (model detection rates
    with all qubits at L x nominal and the qubit at its calibration value) instead of the snapshot taken
    when it was named.  In v1 the snapshot-based fit put a whole regional rise (step, burst) onto the
    named qubit (fitted 30-300x for qubits truly at 3-11x).
 5. A ring with 2 ancillas is used (v1 needed 3 and otherwise assumed L = 1, which kept one Z ancilla out
    for 760k rounds); with fewer than 2, L is the median over every Z ancilla outside the qubit's footprint.
"""
from collections import deque
import numpy as np
import deform
from arms7 import PolicyArm


class PolicyArmField(PolicyArm):
    kind = 'policy'

    def __init__(self, name, base, inner, cal, probe, seed, table, fnom, radius=4.0, WL=50, resize=True,
                 ring_min=2, fallback='patch'):
        super().__init__(name, base, inner, 'gated', cal, probe, None, seed=seed)
        m = base
        self.resize, self.ring_min, self.fallback = bool(resize), int(ring_min), fallback
        self.cal_f0 = np.asarray(cal['f0'], float)
        self.fnom = float(fnom)
        self.fcal_abs = np.asarray(cal['f0'], float) / self.fnom
        self.radius = float(radius)
        self.win = deque(maxlen=int(WL))
        self.tab = {}
        for kind, rows in table.items():
            rows = sorted(rows)
            L = np.array([r[0] for r in rows], float)
            f = np.array([np.inf if r[1] is None else r[1] for r in rows], float)
            self.tab[kind] = (L, f)
        W = m.fp_W                                                    # G x nA error mass on Z ancillas
        self.apos = (W.T @ m.qxy) / np.maximum(W.sum(0)[:, None], 1e-30)
        qd = m.det_rate(np.full(m.G, self.fnom))
        ints = [np.nonzero((m.danc == b) & (m.dcls == 1))[0] for b in range(m.nA)]
        self.ints = ints
        qn = np.array([qd[u].mean() if len(u) else np.nan for u in ints])
        self.unom = -0.5 * np.log1p(-2 * np.clip(qn, 1e-9, 0.49))
        self.rings = {}

    # ------------------------------------------------------------ twin's view of the field
    def ring(self, g):
        r = self.rings.get(g)
        if r is None:
            foot = set(int(b) for b in self.inner._st(g)['anc'])
            dx = np.abs(self.apos - self.base.qxy[g][None, :]).max(1)
            r = np.array([b for b in np.nonzero(dx <= self.radius + 1e-9)[0] if int(b) not in foot
                          and np.isfinite(self.unom[b])], int)
            self.rings[g] = r
        return r

    def _ratio(self, idx):
        n = np.sum([w[0] for w in self.win], 0)[idx]; N = np.sum([w[1] for w in self.win], 0)[idx]
        ok = N > 0
        q = np.clip(n[ok] / np.maximum(N[ok], 1), 1e-9, 0.49)
        return -0.5 * np.log1p(-2 * q) / self.unom[idx][ok]

    def level(self, g):
        if not self.win:
            return 1.0
        v = self._ratio(self.ring(g))
        if len(v) >= self.ring_min:
            return float(np.median(v))
        if self.fallback == 'patch':
            foot = set(int(b) for b in self.inner._st(g)['anc'])
            v = self._ratio(np.array([b for b in range(self.base.nA) if b not in foot and np.isfinite(self.unom[b])], int))
            if len(v) >= 2:
                return float(np.median(v))
        return 1.0

    def size_local(self, g, o, L):
        """Calibration-relative factor of g re-fitted with every other qubit at L x nominal."""
        inn = self.inner
        if not o['win'] and o.get('init') is None:
            return None
        nn = np.sum([w[0] for w in o['win']], 0) if o['win'] else 0.0
        NN = np.sum([w[1] for w in o['win']], 0) if o['win'] else 0.0
        if len(o['win']) < inn.Wmin and o.get('init') is not None:
            nn = nn + o['init'][0]; NN = NN + o['init'][1]
        f = np.full(self.base.G, L * self.fnom); f[g] = self.cal_f0[g]
        qd = self.base.det_rate(f)
        qb = np.array([qd[u].mean() if len(u) else 0.0 for u in self.ints])
        return float(inn.fit_base(g, np.asarray(nn, float), np.asarray(NN, float), qb))

    def fstar(self, kind, L):
        Ls, fs = self.tab[kind]
        L = min(max(L, Ls[0]), Ls[-1])
        i = int(np.searchsorted(Ls, L))
        if i == 0:
            return float(fs[0])
        if not (np.isfinite(fs[i - 1]) and np.isfinite(fs[i])):
            return float(np.inf) if L > Ls[i - 1] or not np.isfinite(fs[i - 1]) else float(fs[i - 1])
        t = (np.log(L) - np.log(Ls[i - 1])) / (np.log(Ls[i]) - np.log(Ls[i - 1]))
        return float(np.exp(np.log(fs[i - 1]) + t * (np.log(fs[i]) - np.log(fs[i - 1]))))

    # ------------------------------------------------------------ policy
    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        m = self.base; inn = self.inner
        if md is None:
            Xo = X; off = None
            inn.update(X, crr)
        else:
            Xo = to_base(X, md, m); off = md.mask['anc_off']
            crr_o = (Xo.astype(np.float32) @ base_AggD).reshape(-1, 4).astype(np.float64)
            inn.update(Xo, crr_o, md.mask)
        n = (Xo.astype(np.float32) @ m.A_int).sum(0).astype(float)
        N = Xo.shape[0] * inn.nint
        if off is not None:
            n = np.where(off, 0.0, n); N = np.where(off, 0.0, N)
        self.win.append((n, N))
        self.rounds += X.shape[0] * T
        # switch out
        for g, o in sorted(inn.sovr.items(), key=lambda kv: -kv[1]['r']):
            if o['susp'] or o.get('cool', 0) > 0 or g not in m.excludable:
                continue
            kind, c = m.excludable[g]
            if c in self.cur or len(self.cur) >= 2 or not deform.compatible(list(self.cur) + [c], m.d):
                continue
            L = self.level(g); thr = self.fstar(kind, L)
            r_use = o['r']
            if self.resize:
                r_use = self.size_local(g, o, L)
                if r_use is None:
                    continue
            fabs = r_use * self.fcal_abs[g]
            if fabs < thr:
                continue
            self.cur[c] = dict(g=g, kind=kind, start=self.rounds, next=epoch + self.probe['period'])
            inn.suspend(g)
            inn.reset_local(g)
            self.log.append(['out', epoch, list(c), int(g), round(o['r'], 2), round(fabs, 2), round(L, 2),
                             round(thr, 2), round(r_use, 2)])
        # probe and switch back in
        for c in list(self.cur):
            st = self.cur[c]; g = st['g']
            if epoch < st['next']:
                continue
            f_true = float(ftrue[g]) / self.fnom
            fp = f_true * float(np.exp(self.probe['sigma'] * self.rng.standard_normal()))
            L = self.level(g); thr_in = self.fstar(st['kind'], L) / 1.5
            if fp < thr_in:
                del self.cur[c]
                inn.reset_local(g)
                inn.resume(g, fp / self.fcal_abs[g])
                self.log.append(['in', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), round(L, 2),
                                 round(thr_in, 2)])
            else:
                st['next'] = epoch + self.probe['period']
                self.log.append(['probe', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), round(L, 2),
                                 round(thr_in, 2)])
