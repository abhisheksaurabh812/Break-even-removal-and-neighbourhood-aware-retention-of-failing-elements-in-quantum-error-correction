"""Round-13 development comparison (used seeds only): new arms in dev13/<test>_s<seed>.npz against the round-12 arms of
the same seed in out12/<test>_s<seed>.npz.     python3 compare13.py <test>:<seed>[,<seed>...] [<test>:<seeds> ...]
For each run: totals; each new arm's relative difference against sz_w12r, sz_w12, sz_watch, sz, sz_all, loc; the failures
where the new arm and sz_w12r differ most (their failures over the failure's epochs), with the epochs to the first
switch-out of that qubit under each; the naming counters of the new arms.  Pooled per test at the end."""
import sys, json
import numpy as np
import analyse8 as A

REF = ('sz_w12r', 'sz_w12', 'sz_watch', 'sz', 'sz_all', 'loc')


def first_out(log, er, q, t0, t1):
    for g, x, y, _ in A.out_intervals(log, er):
        y = 1e18 if y is None else y
        if g == q and y > t0 and x < t1:
            return int(max(x, t0) - t0)
    return None


def one(test, seed):
    d = A.load(f'dev13/{test}_s{seed}.npz'); r = A.load(f'out12/{test}_s{seed}.npz')
    er = r['cfg']['bpe'] * r['cfg']['d']
    new = d['names']
    tot = {n: int(d['fails'][i].sum()) for i, n in enumerate(new)}
    tot.update({n: int(r['fails'][r['names'].index(n)].sum()) for n in REF})
    rel = {n: {ref: round(tot[n] / tot[ref] - 1, 4) for ref in REF} for n in new}
    fa = {n: A.per_epoch(d, n) for n in new}; fr = {n: A.per_epoch(r, n) for n in REF}
    rows = []
    for t0, dur, q, fac in r['defects']:
        e0 = int(t0 // er); e1 = min(int((t0 + dur) // er), len(fr['sz']) - 1)
        row = dict(q=int(q), fac=round(float(fac), 1), start=int(t0), rounds=int(dur))
        for n in new:
            row[n] = int(fa[n][e0:e1 + 1].sum()) - int(fr['sz_w12r'][e0:e1 + 1].sum())
            row[f'{n}_first'] = first_out(d['info'][n].get('policy_log', []), er, q, t0, t0 + dur)
        row['w12r_first'] = first_out(r['info']['sz_w12r'].get('policy_log', []), er, q, t0, t0 + dur)
        rows.append(row)
    rows.sort(key=lambda x: -max(abs(x[n]) for n in new))
    n13 = {n: d['info'][n].get('sized', {}).get('name13') for n in new}
    return dict(test=test, seed=seed, totals=tot, rel=rel, top=rows[:6], name13=n13)


if __name__ == '__main__':
    pooled = {}
    for arg in sys.argv[1:]:
        test, seeds = arg.split(':')
        for s in seeds.split(','):
            o = one(test, int(s))
            print(json.dumps(o))
            p = pooled.setdefault(test, {})
            for k, v in o['totals'].items():
                p[k] = p.get(k, 0) + v
    for test, p in pooled.items():
        new = [k for k in p if k not in REF]
        print(test, 'pooled', {n: {ref: round(p[n] / p[ref] - 1, 4) for ref in REF} for n in new})
