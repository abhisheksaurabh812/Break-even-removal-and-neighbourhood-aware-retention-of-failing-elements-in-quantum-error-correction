"""Circuit-level surgery test v2: training picks, paired comparisons, decision rules.
   python3 analyse_surg2.py   (reads out/s2_train_*.npz, out/s2_test_*.npz)"""
import glob, json, sys
PREFIX = sys.argv[1] if len(sys.argv) > 1 else 'out/'
import numpy as np
from analyse2 import sign_test


def cmp(a, b):
    x = int(((a == 1) & (b == 0)).sum()); y = int(((a == 0) & (b == 1)).sum())
    fa, fb = int(a.sum()), int(b.sum())
    return dict(fails=fa, ref_fails=fb, rel=round(fa / fb - 1, 5) if fb else None, arm_only=x, ref_only=y, p=sign_test(x, y))


def load(pat):
    files = sorted(glob.glob(pat))
    if not files:
        return None
    names = None; FM = []; FU = []; W = []
    for f in files:
        z = np.load(f, allow_pickle=True); nm = list(z['names']); names = names or nm; assert nm == names
        FM.append(z['failM'].reshape(len(nm), -1)); FU.append(z['failU'].reshape(len(nm), -1)); W.append(z['werrM'].mean(1))
    return dict(files=len(files), names=names, FM=np.concatenate(FM, 1), FU=np.concatenate(FU, 1), W=np.mean(W, 0))


def tot(d, key):
    return dict(zip(d['names'], d[key].sum(1).tolist()))


def main():
    out = {}
    # ---- training picks (seeds 111, 112): best separate table (interleaved), best model parameterisation (fresh)
    tr_i = [load(PREFIX + f's2_train_int_k{k}_s*.npz') for k in (100, 20)]
    tr_f = load(PREFIX + 's2_train_fresh_k20_s*.npz')
    picks = {}
    if all(tr_i):
        sep = {n: sum(tot(d, 'FM')[n] for d in tr_i) for n in ('sep-own', 'sep-clock')}
        picks['best_sep'] = min(sep, key=sep.get); picks['sep_train_merged_fails'] = sep
    if tr_f:
        mod = {n: tot(tr_f, 'FM')[n] for n in ('model-q', 'model-qt')}
        picks['best_model'] = min(mod, key=mod.get); picks['model_train_merged_fails'] = mod
    out['picks'] = picks
    bs = picks.get('best_sep', 'sep-clock'); bm = picks.get('best_model', 'model-qt'); hb = 'hybrid-' + bm.split('-')[1]
    # ---- test runs (seeds 211-213)
    groups = {'interleaved_1pct': PREFIX + 's2_test_int_k100_s*.npz', 'interleaved_5pct': PREFIX + 's2_test_int_k20_s*.npz',
              'fresh_5pct': PREFIX + 's2_test_fresh_k20_s*.npz'}
    pairs_m = [('shared', bs), (bm, 'shared'), (hb, 'shared'), (bm, 'static-model'), (hb, 'static-model'),
               ('shared', 'static-model'), (bs, 'static-est'), ('shared', 'static-est'), ('static-model', 'static-est'),
               ('oracle', 'shared'), ('oracle', hb), (hb, bm), ('sep-clock', 'sep-own'), ('model-qt', 'model-q')]
    for gname, pat in groups.items():
        d = load(pat)
        if d is None:
            continue
        ix = d['names'].index
        r = dict(files=d['files'], merged_blocks=int(d['FM'].shape[1]), unmerged_blocks=int(d['FU'].shape[1]),
                 totals_merged=tot(d, 'FM'), totals_unmerged=tot(d, 'FU'),
                 merged_weight_error=dict(zip(d['names'], np.round(d['W'], 4).tolist())), merged={}, unmerged={})
        for a, b in pairs_m:
            if a in d['names'] and b in d['names'] and a != b:
                r['merged'][f'{a} vs {b}'] = cmp(d['FM'][ix(a)], d['FM'][ix(b)])
                r['unmerged'][f'{a} vs {b}'] = cmp(d['FU'][ix(a)], d['FU'][ix(b)])
        for a in ('shared', hb, bm):
            if a in d['names']:
                r['unmerged'][f'{a} vs {bs}'] = cmp(d['FU'][ix(a)], d['FU'][ix(bs)])
        out[gname] = r
    # ---- decision rules (fixed before the runs)
    rules = {}
    c1 = []
    for g in ('interleaved_1pct', 'interleaved_5pct'):
        if g in out:
            x = out[g]['merged'][f'shared vs {bs}']
            c1.append(x['rel'] <= -0.03 and x['p'] < 0.01)
            for a in ('shared', hb):
                y = out[g]['unmerged'].get(f'{a} vs {bs}')
                if y:
                    rules[f'C2_{g}_{a}_unmerged_no_worse_0.5pct'] = bool(y['rel'] <= 0.005)
    if c1:
        rules['C1_shared_beats_best_sep_3pct_at_1_or_5pct'] = bool(any(c1))
    if 'fresh_5pct' in out:
        x = out['fresh_5pct']['merged'][f'{bm} vs static-model']
        rules['M2a_model_beats_device_calibration_3pct'] = bool(x['rel'] <= -0.03 and x['p'] < 0.01)
        y = out['fresh_5pct']['merged'][f'{hb} vs shared']
        rules['M2b_hybrid_beats_entry_copy_1pct'] = bool(y['rel'] <= -0.01 and y['p'] < 0.01)
    out['rules'] = rules
    out['arms_used_in_rules'] = dict(best_sep=bs, best_model=bm, hybrid=hb)
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
