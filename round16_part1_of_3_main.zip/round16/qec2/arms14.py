"""
Round 14 (PREREG_round14.md): the gate's change over round 13, and a prior-art baseline.

PolicyArmFieldWatch4 = round 13's gate (arms13.PolicyArmFieldWatch3) with the twin's fast adjustments kept on top of
the reshaped circuit's own estimates.

Found on round-13 long-severe seed 9502 (RESULTS_round13.md, dev14/): a 70x failure started on q52, a boundary Z
ancilla next to q27; the watch returned q27 within an epoch, the twin named q52 (57x) on the base circuit, and the gate
switched q27 out again.  In the reshaped circuit every detector of q52 changes (all of its footprint is on ancillas
the reshaped circuit switches off), and on the edges the hole affects the round-13 gate replaced the decoder's weights
with the reshaped circuit's slow estimates, which held no trace of the failure; until q27 came back 380 epochs later
the decoder did not see it (about four times reweighting's failures).

Here the twin's fast sizes bridge the lag of the reshaped circuit's estimates, as the twin's own sizes bridge the lag
of its slow estimates on the base circuit (arms7b.Sized3):
 - while the twin names a qubit, the reshaped estimates on that qubit's edges of the reshaped circuit are frozen at
   their values when the name is first seen in the configuration, and the qubit's current factor is composed on top
   of them, as the twin composes it on the base circuit; the estimator keeps running underneath;
 - once the estimates complete an update on a window (100,000 rounds of the configuration's data) of which at least
   half came after that moment, they hold the failure, and they take over on the qubit's edges with that update's own
   values (round-13 seed 9401,
   neighbouring failures: a 128x name on q81, which had no failure, given on the base circuit just before q67 went out
   again, cost 26 failures when composed until a second update; the first update already held the true failure);
 - if the twin ends the name before that, the frozen values are restored; if it hands the qubit over to its slow
   estimator, the composed value is kept;
 - a name the twin gives, during the configuration, to a qubit the hole hides (half or more of its footprint on
   ancillas the reshaped circuit switches off) rests on partial evidence and is left to the estimates, as in round 13;
 - the twin's regional offsets (CUSUM alarms) apply on the affected edges that map to base edges, where round 12's
   gate applied them.
At the start of a configuration, the frozen values of qubits already named are the twin's values without its fast
adjustments: its slow (or frozen) base estimates on edges that map to base edges, the gate's view without the named
factors on new edges.

Quarantine: the prior-art baseline (end of this file).
"""
import numpy as np
from arms import WMIN, estimate
from arms7 import CAP
from sampler import weights_from_p
from arms12 import PolicyArmFieldWatch2
from arms13 import PolicyArmFieldWatch3
import deform
import rectgen


def compose(p, lf):
    """Edge flip probability p combined with independent extra flips whose summed log(1 - 2p) is lf."""
    return 0.5 * (1 - (1 - 2 * np.clip(p, 0, 0.499)) * np.exp(lf))


class PolicyArmFieldWatch4(PolicyArmFieldWatch3):
    kind = 'policy'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.qe = {}; self.qe_name = None; self.Cc = None
        self.slog_i = 0; self.handed = set()
        self.cnt14 = dict(frozen=0, frozen_hidden=0, restored=0, kept=0, released=0)

    # ------------------------------------------------------------ named qubits in a configuration
    def _qedges(self, md, g):
        """Edges of the reshaped circuit md that qubit g's error sources reach."""
        if self.qe_name != md.name:
            self.qe = {}; self.qe_name = md.name; self.Cc = md.C.tocsc()
        e = self.qe.get(g)
        if e is None:
            Cc = self.Cc
            ks = np.nonzero(md.src_g == g)[0]
            e = (np.unique(np.concatenate([Cc.indices[Cc.indptr[k]:Cc.indptr[k + 1]] for k in ks])).astype(int)
                 if len(ks) else np.zeros(0, int))
            self.qe[g] = e
        return e

    def _named(self, md):
        """{g: (factor, hidden)} for the qubits the twin sizes now (learner names not suspended, zone names); hidden:
        half or more of the qubit's footprint on ancillas that configuration md switches off."""
        off = np.asarray(md.mask['anc_off'], bool)
        out = {}
        for g, o in self.inner.sovr.items():
            if not o['susp']:
                out[int(g)] = out.get(int(g), 1.0) * float(o['r'])
        for g, r in self.zov.items():
            out[int(g)] = out.get(int(g), 1.0) * float(r)
        return {g: (r, float(self.Wn[g][off].sum()) >= 0.5) for g, r in out.items() if r != 1.0}

    def _v(self):
        return self._view if self._view is not None else self.view()

    def _lf(self, md, fac, inview=True):
        """Per edge of md: log(1 - 2p) with the qubits in fac at their factors, minus log(1 - 2p) without them, the
        rest of the gate's current view unchanged (inview: the view already holds the factors)."""
        if not fac:
            return np.zeros(md.E)
        f = self._v()
        a = f.copy()
        for g, r in fac.items():
            a[g] = f[g] / r if inview else f[g] * r
        fw, fo = (f, a) if inview else (a, f)
        d = np.log1p(-2 * md.source_p(fw)) - np.log1p(-2 * md.source_p(fo))
        return np.asarray(md.C @ d).ravel()

    def _freeze(self, hs, md, g, r, hid, src):
        e = self._qedges(md, g)
        new = e[hs['fref'][e] == 0]
        hs['fval'][new] = src[new]; hs['fref'][e] += 1
        hs['named'][g] = dict(e=e, r=r, hid=hid, u0=hs['nupd'], r0=hs['rounds'], rel=False)
        self.cnt14['frozen_hidden' if hid else 'frozen'] += 1

    def _unfreeze(self, hs, e, val):
        hs['fref'][e] -= 1
        done = e[hs['fref'][e] == 0]
        hs['p'][done] = val[done]

    def _events(self):
        sl = self.inner.slog
        for ev in sl[self.slog_i:]:
            if ev[0] == 'handover':
                self.handed.add(int(ev[2]))
            elif ev[0] in ('on', 'resume'):
                self.handed.discard(int(ev[2]))
        self.slog_i = len(sl)

    def _sync(self, md, hs):
        """Bring the frozen edges of configuration md up to date with the twin's current names."""
        self._events()
        named = self._named(md)
        reg = hs['named']
        for g in [g for g in reg if g not in named]:
            o = reg.pop(g)
            if o['rel']:
                continue
            e = o['e']
            if g in self.handed:          # handed over to the slow estimator: the failure stays in the estimates
                hs['fval'][e] = np.clip(compose(hs['fval'][e], self._lf(md, {g: o['r']}, inview=False)[e]),
                                        1e-7, 0.45)
                self.cnt14['kept'] += 1
            else:
                self.cnt14['restored'] += 1
            self._unfreeze(hs, e, hs['fval'])
        fresh = hs.pop('fresh', False)
        for g, (r, hid) in named.items():
            o = reg.get(g)
            if o is None:
                if hid and not fresh:
                    continue          # named while hidden in this configuration: left to the estimates, as round 13
                self._freeze(hs, md, g, r, hid, hs['p'])
                continue
            o['r'] = r
            if not o['rel'] and (hs['nupd'] >= o['u0'] + 2 or
                                 (hs['nupd'] == o['u0'] + 1 and hs['last_R'] - o['r0'] >= 0.5 * hs['last_R'])):
                # the estimates behind the hole have completed an update on a window whose data lie at least half
                # after the name was first seen here: they hold the failure now
                val = np.where(hs['ok_raw'], hs['p_raw'], hs['p'])
                self._unfreeze(hs, o['e'], val)
                o['rel'] = True; self.cnt14['released'] += 1

    # ------------------------------------------------------------ hole estimates
    def _hole_start(self, md):
        old = self.hcache.get(md.name)
        hs = super()._hole_start(md)
        hs['fresh'] = True                # the first sync registers every name given before this configuration
        if hs is old:
            return hs
        hs['fref'] = np.zeros(md.E, int); hs['fval'] = hs['p'].copy(); hs['named'] = {}
        hs['p_raw'] = hs['p'].copy(); hs['ok_raw'] = np.zeros(md.E, bool); hs['last_R'] = 0.0
        named = self._named(md)
        if named:
            inn = self.inner
            pb = np.clip(np.where(inn.frozen, inn.fval, inn.p), 1e-7, CAP)
            f = self._v(); fu = f.copy()
            for g, (r, hid) in named.items():
                fu[g] = f[g] / r
            pu = md.edge_p(fu)
            ok = md.emap >= 0
            pu[ok] = pb[md.emap[ok]]
            for g, (r, hid) in named.items():
                self._freeze(hs, md, g, r, hid, pu)
        return hs

    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        if md is not None:
            hs = self.hs if (self.hs is not None and self.hs['name'] == md.name) else self._hole_start(md)
            self.hs = hs
            hs['st'].add(X); hs['rounds'] += X.shape[0] * T
            if hs['rounds'] >= self.h_R:
                minN = 0.25 * self.h_R / md.T
                p_new, q_new, okp, okq = estimate(md, hs['st'], hs['p'], hs['q'], minN, minN)
                a = self.h_alpha
                hs['p'][okp] += a * (p_new[okp] - hs['p'][okp]); hs['q'][okq] += a * (q_new[okq] - hs['q'][okq])
                hs['p_raw'] = p_new; hs['ok_raw'] = okp; hs['last_R'] = hs['rounds']
                hs['valid'] |= okp; hs['st'].reset(); hs['rounds'] = 0.0; hs['nupd'] += 1; self.n_hupd += 1
        else:
            self.hs = None
        PolicyArmFieldWatch2.update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base)
        if md is None:
            self._events()
            return
        hs = self.hs; hs['t_last'] = self.rounds
        self._sync(md, hs)
        if len(hs['drift']):
            ph = np.where(hs['fref'] > 0, hs['fval'], hs['p'])
            val = hs['pin'].copy()
            if hs['nupd']:
                ok = hs['dmap'] >= 0
                ok[ok] = hs['valid'][hs['dmap'][ok]]
                val[ok] = ph[hs['dmap'][ok]]
            self.inner.p[hs['drift']] = val

    def weights(self, md, true_pe):
        w = PolicyArmFieldWatch2.weights(self, md, true_pe)
        hs = self.hs
        if md is None or hs is None or hs['name'] != md.name or not hs['nupd']:
            return w
        sel = hs['aff'] & hs['valid']
        if not sel.any():
            return w
        ph = np.where(hs['fref'] > 0, hs['fval'], hs['p'])
        fac = {g: o['r'] for g, o in hs['named'].items() if not o['rel']}
        if fac:
            ph = compose(ph, self._lf(md, fac))
        wh = weights_from_p(np.clip(ph, 1e-7, 0.45), WMIN)
        inn = self.inner
        if inn.cusum:
            off = inn.off
            if inn.fp and inn.nooff:
                off = np.where(inn.fstate == 3, 0.0, off)
            ok = md.emap >= 0
            wh[ok] = np.maximum(wh[ok] - off[self.base.ereg[md.emap[ok]]], WMIN)
        w = np.array(w, float)
        w[sel] = wh[sel]
        return w

    def info(self):
        d = super().info()
        d['hole_named'] = dict(self.cnt14)
        return d


# ---------------------------------------------------------------------------------------------------------------------
# Prior-art baseline: detect and quarantine.
class Quarantine:
    """Detect-and-quarantine after Siegel, Strikis, Flatters and Benjamin, "Adaptive surface code for quantum error
    correction in the presence of temporary or permanent defects", Quantum 7, 1065 (2023).
    Detection as in the paper: a stabiliser is flagged in a shot when it flips (detection events) more than `n_flips`
    times within `dt` consecutive rounds (paper: more than 3 within 6).  The paper clusters flagged stabilisers with
    DBSCAN, drops isolated ones, and leaves the clustering parameters to be chosen offline; here a flag is kept when a
    neighbouring Z stabiliser (sharing a data qubit) is flagged in the same shot, or the same stabiliser in the shot
    before or after, and a cluster of neighbouring stabilisers with kept flags is a defect when one of them has kept
    flags in at least `k` shots of the epoch (k = 1: every cluster).
    Quarantine, per defect: the data qubit adjacent to the most flagged stabilisers (at least two), or, for a
    stabiliser flagged on its own, its ancilla; only qubits the deformation code can remove (bulk), at most two out and
    compatible, as for every switching arm.
    Reintegration after a fixed time, as in the paper (100 stabiliser cycles; here at the first epoch end at least
    `t_back` rounds after the switch-out; None: never).
    Decoder: without `inner`, fixed weights, from the calibration experiment (as the lab baseline fix_cal) on the base
    circuit; with `inner` (a learner), that learner's adaptive weights, fed and switched as by every switching arm
    (arms7.PolicyArm), and a quarantined qubit the learner had named comes back in with its last size.  For a
    reshaped circuit, those weights on the edges that map to base edges and the calibration rates on its new edges.
    The paper's weight-zero zone during detection is not used."""
    kind = 'policy'

    def __init__(self, name, base, cal, n_flips=3, dt=6, k=1, t_back=100, est=True, inner=None):
        self.name, self.base, self.cal = name, base, cal
        m = base
        self.n_flips = int(n_flips); self.dt = int(dt); self.k = int(k); self.t_back = t_back
        self.inner = inner
        pe = cal['pe_est'] if (est and 'pe_est' in cal) else cal['pe']
        self.w_base = weights_from_p(pe, WMIN)
        self.wcache = {}
        self.nA = len(m.zanc); self.nt = int(m.dt.max()) + 1
        self.slot = (m.dt * self.nA + m.danc).astype(int)          # detector -> (round, ancilla)
        data, _, _ = rectgen.layout(m.d, m.d)
        ds = set(tuple(c) for c in data)
        self.adj = []                                              # data qubits next to each Z ancilla
        for b, (x, y) in enumerate(m.zanc):
            self.adj.append([c for c in ((x - 1, y - 1), (x - 1, y + 1), (x + 1, y - 1), (x + 1, y + 1)) if c in ds])
        nb = np.zeros((self.nA, self.nA), np.int32)
        for b in range(self.nA):
            for b2 in range(self.nA):
                if b2 != b and set(self.adj[b]) & set(self.adj[b2]):
                    nb[b, b2] = 1
        self.Zadj = nb
        self.prev = np.zeros(self.nA, bool)
        self.cur = {}; self.rounds = 0; self.log = []; self.n_flag = 0; self.n_kept = 0; self.n_def = 0

    def config(self):
        return tuple(sorted(self.cur))

    def weights(self, md, true_pe):
        if self.inner is not None:
            wb = self.inner.weights(true_pe)
            if md is None:
                return wb
            w = weights_from_p(md.edge_p(self.cal['f0']), WMIN)
            ok = md.emap >= 0
            w[ok] = wb[md.emap[ok]]
            return w
        if md is None:
            return self.w_base
        w = self.wcache.get(md.name)
        if w is None:
            w = weights_from_p(md.edge_p(self.cal['f0']), WMIN)
            ok = md.emap >= 0
            w[ok] = self.w_base[md.emap[ok]]
            self.wcache[md.name] = w
        return w

    def _flags(self, Xb, off):
        """(shots, ancillas): more than n_flips detection events within dt consecutive rounds."""
        B = Xb.shape[0]
        E = np.zeros((B, self.nt * self.nA), np.int16)
        E[:, self.slot] = Xb
        E = E.reshape(B, self.nt, self.nA)
        c = np.concatenate([np.zeros((B, 1, self.nA), np.int16), np.cumsum(E, axis=1, dtype=np.int16)], axis=1)
        W = min(self.dt, self.nt)
        F = ((c[:, W:, :] - c[:, :-W, :]) > self.n_flips).any(1)
        if off is not None:
            F[:, off] = False
        return F

    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        m = self.base; inn = self.inner
        self.rounds += X.shape[0] * T
        if md is None:
            Xb = X; off = None
            if inn is not None:
                inn.update(X, crr)
        else:
            Xo = to_base(X, md, m)
            if inn is not None:
                crr_o = (Xo.astype(np.float32) @ base_AggD).reshape(-1, 4).astype(np.float64)
                inn.update(Xo, crr_o, md.mask)
            Xb = Xo * (md.mask['det_ok'] > 0)[None, :].astype(np.uint8)
            off = np.asarray(md.mask['anc_off'], bool)
        # reintegration after a fixed time
        for c in list(self.cur):
            st = self.cur[c]; g = st['g']
            if self.t_back is not None and self.rounds - st['start'] >= self.t_back:
                del self.cur[c]
                if inn is not None:
                    inn.reset_local(g)
                    o = inn.sovr.get(g)
                    if o is not None:
                        inn.resume(g, o['r'])         # back in with the learner's last size of it
                self.log.append(['in', epoch, list(c), int(g), round(float(ftrue[g] / self.cal['f0'][g]), 2)])
        F = self._flags(Xb, off)
        self.n_flag += int(F.sum())
        Fx = np.vstack([self.prev[None, :], F])
        sup = (Fx.astype(np.int32) @ self.Zadj) > 0
        tp = np.zeros_like(Fx); tp[1:] = Fx[:-1]
        tn = np.zeros_like(Fx); tn[:-1] = Fx[1:]
        keep = (Fx & (sup | tp | tn))[1:]
        self.prev = F[-1].copy()
        cnt = keep.sum(0)
        S = [int(b) for b in np.nonzero(cnt)[0]]
        self.n_kept += int(keep.sum())
        if not S:
            return
        left = set(S); clusters = []
        while left:
            b = left.pop(); comp = {b}; todo = [b]
            while todo:
                u = todo.pop()
                for v in list(left):
                    if self.Zadj[u, v]:
                        left.discard(v); comp.add(v); todo.append(v)
            clusters.append(comp)
        for comp in sorted(clusters, key=lambda s: -sum(cnt[b] for b in s)):
            if max(cnt[b] for b in comp) < self.k:
                continue
            self.n_def += 1
            score = {}
            for b in comp:
                for c in self.adj[b]:
                    s = score.setdefault(c, [0, 0]); s[0] += 1; s[1] += int(cnt[b])
            best = max(score.items(), key=lambda kv: (kv[1][0], kv[1][1])) if score else None
            if best is not None and best[1][0] >= 2:
                c = best[0]
            else:
                b = max(comp, key=lambda u: cnt[u]); c = tuple(int(v) for v in m.zanc[b])
            g = m.qgroup.get(tuple(c))
            if g is None or g not in m.excludable:
                continue
            c = m.excludable[g][1]
            if c in self.cur or len(self.cur) >= 2 or not deform.compatible(list(self.cur) + [c], m.d):
                continue
            self.cur[c] = dict(g=g, start=self.rounds)
            if inn is not None:
                if g in inn.sovr:
                    inn.suspend(g)
                inn.reset_local(g)
            self.log.append(['out', epoch, list(c), int(g), round(float(ftrue[g] / self.cal['f0'][g]), 2),
                             int(sum(cnt[b] for b in comp))])

    def info(self):
        d = self.inner.info() if self.inner is not None else {}
        d.update(policy_log=self.log[:20000], flagged=self.n_flag, kept_flags=self.n_kept, defects=self.n_def,
                 switch_outs=sum(1 for x in self.log if x[0] == 'out'))
        return d
