"""Post-hoc diagnostic (not a pre-registered rule): where does sz_gated gain or lose against sz in the
realistic scenario? Each epoch is labelled by what sz_gated has switched out at that epoch:
  none        - nothing switched out
  defect      - every switched-out qubit has an active failure (defect event) at that epoch
  no_defect   - at least one switched-out qubit has no active failure (it is out because of heterogeneity,
                regional steps, bursts or drift, which the absolute crossover does not distinguish)
python3 diag8_realistic.py > out8/diag_realistic.json"""
import json
import numpy as np
import analyse8 as A

paths = [f'out7b/test_realistic_s{s}.npz' for s in (2001, 2002, 2003)] + [f'out8/more_realistic_s{s}.npz' for s in range(2004, 2011)]
res = {}
tot = {k: dict(epochs=0, gated_minus_sz=0, sz=0) for k in ('none', 'defect', 'no_defect')}
for p in paths:
    r = A.load(p)
    er = r['cfg']['bpe'] * r['cfg']['d']; E = r['fails'].shape[1]
    g = A.per_epoch(r, 'sz_gated'); s = A.per_epoch(r, 'sz')
    out = [set() for _ in range(E)]
    for q, a, b, _ in A.out_intervals(r['info']['sz_gated'].get('policy_log', []), er):
        e0 = int(round(a / er)); e1 = E if b is None else int(round(b / er))
        for e in range(e0, min(e1, E)):
            out[e].add(q)
    lab = []
    for e in range(E):
        if not out[e]:
            lab.append('none'); continue
        t = (e + 0.5) * er
        ok = all(any(dd[2] == q and dd[0] <= t < dd[0] + dd[1] for dd in r['defects']) for q in out[e])
        lab.append('defect' if ok else 'no_defect')
    lab = np.array(lab)
    row = {}
    for k in tot:
        m = lab == k
        row[k] = dict(epochs=int(m.sum()), gated_minus_sz=int((g[m] - s[m]).sum()), sz=int(s[m].sum()))
        for x in ('epochs', 'gated_minus_sz', 'sz'):
            tot[k][x] += row[k][x]
    row['total_rel'] = round(float((g.sum() - s.sum()) / s.sum()), 4)
    res[p] = row
for k in tot:
    tot[k]['rel_within'] = round(tot[k]['gated_minus_sz'] / max(tot[k]['sz'], 1), 4)
res['all_10_seeds'] = tot
print(json.dumps(res, indent=1))
