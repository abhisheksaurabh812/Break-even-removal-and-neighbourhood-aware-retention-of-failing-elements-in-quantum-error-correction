"""Detect-name-exclude test: tuning pick, paired-by-epoch comparisons, rules.
   python3 analyse_excl.py pick          -> writes out/pickX.json and the test configs
   python3 analyse_excl.py report [prefix]"""
import sys, glob, json, math, copy
import numpy as np

PRE = sys.argv[2] if len(sys.argv) > 2 else 'out/'


def load(pat):
    fs = sorted(glob.glob(pat))
    if not fs:
        return None
    names = None; F = []; NX = []; infos = []; evs = []; cfgs = []
    for f in fs:
        z = np.load(f, allow_pickle=True); nm = list(z['names']); names = names or nm; assert nm == names
        F.append(z['fails'].sum(2)); NX.append(z['nexcl']); infos.append(json.loads(str(z['info'])))
        evs.append(json.loads(str(z['events']))); cfgs.append(json.loads(str(z['cfg'])))
    return dict(files=len(fs), names=names, F=np.concatenate(F, 1), NX=np.concatenate(NX, 1), infos=infos, evs=evs, cfgs=cfgs)


def paired(d, a, b):
    i, j = d['names'].index(a), d['names'].index(b)
    x, y = d['F'][i].astype(float), d['F'][j].astype(float)
    diff = x - y; n = len(diff)
    se = diff.std(ddof=1) / math.sqrt(n)
    z = diff.mean() / se if se > 0 else 0.0
    return dict(fails=int(x.sum()), ref_fails=int(y.sum()), rel=round(x.sum() / y.sum() - 1, 5), z=round(z, 2),
                p=math.erfc(abs(z) / math.sqrt(2)))


def excl_stats(d, arm='excl'):
    out = dict(exclusions=0, hit_defect=0, factors=[], excluded_epoch_frac=None)
    i = d['names'].index(arm)
    out['excluded_epoch_frac'] = round(float((d['NX'][i] > 0).mean()), 4)
    for inf, ev, cfg in zip(d['infos'], d['evs'], d['cfgs']):
        er = cfg['bpe'] * 7
        for ent in inf[arm].get('excl_log', []):
            if ent[0] != 'out':
                continue
            out['exclusions'] += 1
            t = (ent[1] + 0.5) * er; g = ent[3]
            act = [x for x in ev['defects'] if x[0] <= t < x[0] + x[1] and x[2] == g]
            if act:
                out['hit_defect'] += 1; out['factors'].append(round(max(x[3] for x in act), 1))
    f = out.pop('factors')
    out['median_factor_when_hit'] = float(np.median(f)) if f else None
    return out


def pick():
    tot = {}
    for scen in ('severe', 'moderate'):
        d = load(f'out/tuneX_{scen}_s*.npz')
        for k, n in enumerate(d['names']):
            tot.setdefault(n, {})[scen] = int(d['F'][k].sum())
    cands = [n for n in tot if n.startswith('excl_')]
    score = {n: float(np.mean([tot[n][s] / tot['loc'][s] - 1 for s in ('severe', 'moderate')])) for n in cands}
    best = min(score, key=score.get)
    tune = json.load(open('cfg/excl_severe.json'))
    by = {a['name']: a for a in tune['arms']}
    arms = [by['static-est'], by['oracle'], by['oracle-excl'], by['loc']]
    a = copy.deepcopy(by[best]); a['name'] = 'excl'; arms.append(a)
    for scen in ('severe', 'moderate', 'none', 'realistic'):
        src = {'severe': 'cfg/excl_severe.json', 'moderate': 'cfg/excl_moderate.json',
               'none': 'cfg/excl_moderate.json', 'realistic': 'cfg/testL_real1s.json'}[scen]
        c = json.load(open(src)); c['arms'] = arms; c['verbose'] = False
        if scen == 'none':
            c.update(defects=False, drift_frac=0.15)
        json.dump(c, open(f'cfg/testX_{scen}.json', 'w'), indent=1)
    json.dump(dict(pick=best, score={k: round(v, 5) for k, v in score.items()}, totals=tot), open('out/pickX.json', 'w'), indent=1)
    print('picked', best, {k: round(v, 4) for k, v in score.items()})


def report():
    res = {}
    for scen in ('severe', 'moderate', 'none', 'realistic'):
        d = load(f'{PRE}testX_{scen}_s*.npz')
        if d is None:
            continue
        r = dict(seeds=d['files'], totals={n: int(d['F'][k].sum()) for k, n in enumerate(d['names'])})
        for a, b in (('excl', 'loc'), ('excl', 'oracle'), ('oracle-excl', 'oracle'), ('excl', 'oracle-excl'),
                     ('loc', 'static-est'), ('excl', 'static-est'), ('oracle', 'loc')):
            r[f'{a} vs {b}'] = paired(d, a, b)
        r['excl_stats'] = excl_stats(d, 'excl'); r['oracle_excl_epoch_frac'] = round(float((d['NX'][d['names'].index('oracle-excl')] > 0).mean()), 4)
        res[scen] = r
    rules = {}
    if 'severe' in res:
        x = res['severe']['excl vs loc']; rules['X1_severe_gain_10pct_p01'] = bool(x['rel'] <= -0.10 and x['p'] < 0.01)
    for scen in ('none', 'realistic'):
        if scen in res:
            x = res[scen]['excl vs loc']; rules[f'X2_{scen}_no_worse_0.5pct'] = bool(x['rel'] <= 0.005)
    res['rules'] = rules
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    {'pick': pick, 'report': report}[sys.argv[1]]()
