"""Post-hoc diagnostic (written after round 10's d9_mixed result; no rule uses it).
   python3 diag10_blindzone.py [path_prefix] [arm ...] > out10/blindzone10.json
While an arm has qubits switched out, its twin ignores every Z ancilla whose detectors change in the reshaped
circuit (run3.deformed_model mask 'anc_off').  For every failure in every finished run, this counts the rounds
during which most of the failing qubit's error mass (>= 50% of its interior detection share, model fp_W) fell on
ignored ancillas while the arm had a hole elsewhere ('blind'), whether the failure was past the clean-patch
crossover of its kind (switchable qubits only), and the arm's failures minus plain reweighting's ('sz') over the
epochs in which at least one failure was blind (each epoch counted once).  Failures on a switched-out qubit
itself are not counted."""
import sys, os, json, glob
import numpy as np
import analyse8 as A
from model import P_REF
from run3 import base_model, deformed_model
from arms import footprint_prep

prefix = sys.argv[1] if len(sys.argv) > 1 else 'out10/'
arms = sys.argv[2:] or ['sz_field', 'sz_gated']
XO = {7: {k: dict((r['L'], r['crossover']) for r in json.load(open(f'out9/field_table_{k}.json'))['rows'])[1.0]
          for k in ('data', 'zanc')},
      9: {k: dict((r['L'], r['crossover']) for r in json.load(open(f'out10/field_table_d9_{k}.json'))['rows'])[1.0]
          for k in ('data', 'zanc')}}
bases = {}; masks = {}
res = {}
files = sorted(f for f in glob.glob(f'{prefix}*_s*.npz') if os.path.exists(f.replace('.npz', '.json')))
for f in files:
    test = os.path.basename(f).rsplit('_s', 1)[0]
    r = A.load(f); cfg = r['cfg']; d = cfg['d']; er = cfg['bpe'] * d
    if d not in bases:
        bases[d] = footprint_prep(base_model(d), 6.0)
    b = bases[d]
    _, EXd = A.roles(d)
    f0n = np.load(f, allow_pickle=True)['f0'] / (cfg['p_base'] / P_REF)
    W = b.fp_W / np.maximum(b.fp_W.sum(1, keepdims=True), 1e-30)
    n_ep = r['fails'].shape[1]; tot = n_ep * er
    f_sz = r['fails'][r['names'].index('sz')].sum(1)
    for arm in arms:
        if arm not in r['names']:
            continue
        iv = A.out_intervals(r['info'][arm].get('policy_log', []), er)
        cfg_ep = [[] for _ in range(n_ep)]
        for g, a0, a1, _ in iv:
            e0 = int(a0 // er); e1 = n_ep if a1 is None else int(a1 // er)
            for e in range(e0, min(e1, n_ep)):
                cfg_ep[e].append(b.gcoord[g])
        f_arm = r['fails'][r['names'].index(arm)].sum(1)
        R = res.setdefault(test, {}).setdefault(arm, dict(failures_blind=0, failures_blind_past_crossover=0, blind_rounds=0,
                                                          epochs_with_a_blind_failure=0, cost_vs_sz_on_those_epochs=0, worst=[]))
        anyblind = np.zeros(n_ep, bool)
        for t0, dur, q, fac in r['defects']:
            e0 = int(t0 // er); e1 = min(int(min(t0 + dur, tot) // er), n_ep - 1)
            blind = []
            for e in range(e0, e1 + 1):
                key = tuple(sorted(cfg_ep[e]))
                if not key or b.gcoord[q] in key:
                    continue
                if (d, key) not in masks:
                    masks[(d, key)] = deformed_model(b, key).mask['anc_off']
                if W[q][masks[(d, key)]].sum() >= 0.5:
                    blind.append(e)
            if blind:
                anyblind[blind] = True
                past = bool(q in EXd and fac * float(f0n[q]) >= XO[d][EXd[q]])
                R['failures_blind'] += 1; R['blind_rounds'] += len(blind) * er
                R['failures_blind_past_crossover'] += int(past)
                R['worst'].append(dict(seed=cfg['seed'], q=int(q), kind=EXd.get(q, 'not switchable'), factor=round(float(fac), 1),
                                       past_crossover=past, blind_rounds=len(blind) * er,
                                       cost_vs_sz=int(f_arm[blind].sum() - f_sz[blind].sum())))
        R['epochs_with_a_blind_failure'] += int(anyblind.sum())
        R['cost_vs_sz_on_those_epochs'] += int(f_arm[anyblind].sum() - f_sz[anyblind].sum())
for test in res:
    for arm in res[test]:
        res[test][arm]['worst'] = sorted(res[test][arm]['worst'], key=lambda x: -x['cost_vs_sz'])[:5]
print(json.dumps(res, indent=1))
