"""Per-failure breakdown for round 6: failures inside each failure window (onset to end + 20 epochs)
for each arm, grouped by the failing qubit's role (Z ancilla, X ancilla, data) and size.
   python3 analyse6_events.py <prefix> <scen> [arms...]"""
import glob, json, re, sys
import numpy as np

pref, scen = sys.argv[1], sys.argv[2]
arms = sys.argv[3:] or ['static-est', 'loc', 'twin', 'oracle']
roles = np.load('roles_d7.npz')
role = {}
for g in roles['zq']: role[int(g)] = 'Z'
for g in roles['xanc']: role[int(g)] = 'X'
for g in roles['data']: role[int(g)] = 'D'
rows = []
for f in sorted(x for x in glob.glob(f'{pref}{scen}_s*.npz') if re.fullmatch(rf'{re.escape(scen)}_s\d+\.npz', x[len(pref):])):
    z = np.load(f, allow_pickle=True)
    names = [str(x) for x in z['names']]
    fe = z['fails'].sum(2).astype(np.int64)          # (arms, epochs)
    er = json.loads(str(z['cfg']))['bpe'] * 7
    ev = json.loads(str(z['events']))
    info = json.loads(str(z['info']))
    on = {}
    if 'twin' in names:
        for l in info['twin']['analog']['log']:
            if l[0] == 'on':
                on.setdefault(l[3], []).append(l[1] * er)
    for e in ev:
        t0, dur, q, fac, kind = e[:5]
        a, b = int(t0 // er), min(fe.shape[1], int((t0 + dur) // er) + 20)
        r = dict(role=role[q], fac=fac, dur=dur, kind=kind)
        for n in arms:
            if n in names:
                r[n] = int(fe[names.index(n), a:b].sum())
        tt = [t - t0 for t in on.get(q, []) if t0 <= t < t0 + dur]
        r['t_analog'] = min(tt) if tt else None
        rows.append(r)

def group(sel, label):
    if not sel:
        return
    s = {n: sum(r[n] for r in sel if n in r) for n in arms}
    ta = [r['t_analog'] for r in sel if r['t_analog'] is not None]
    rel = {n: round(s[n] / s['loc'] - 1, 3) for n in arms if n != 'loc' and s.get('loc')}
    print(f"{label:28s} n={len(sel):3d}  " + '  '.join(f"{n}={s[n]}" for n in arms) +
          f"   vs loc: {rel}   analog named {len(ta)}/{len(sel)}, median {np.median(ta) if ta else None}")

print(scen)
for rl in ('Z', 'X', 'D'):
    sel = [r for r in rows if r['role'] == rl]
    group(sel, f'role {rl}')
    if sel:
        bins = sorted({0} | {1})
        fs = sorted(r['fac'] for r in sel); med = np.median(fs)
        group([r for r in sel if r['fac'] < med], f'role {rl}, size < {med:.1f}')
        group([r for r in sel if r['fac'] >= med], f'role {rl}, size >= {med:.1f}')
