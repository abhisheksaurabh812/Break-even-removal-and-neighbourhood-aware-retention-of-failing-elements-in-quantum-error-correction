"""Round 10 analysis (rules in PREREG_round10.md).   python3 analyse10.py > out10/res_10.json
A rule is evaluated only when every seed of its test has finished (done marker in out10/done/)."""
import json, os
import analyse8 as A
from analyse9 import split_by_switchout, field_decisions

SEEDS = dict(d9_realistic=range(6001, 6011), d9_mixed=range(6101, 6106), d9_severe=range(6201, 6204),
             d9_moderate=range(6301, 6306), pairs_mixed=range(6401, 6411), long_severe=range(6501, 6507),
             long_mixed=range(6601, 6607))


def done(n):
    return os.path.exists(f'out10/done/{n}')


def runs(test):
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        out.append(A.load(f'out10/{n}.npz'))
    return out


PAIRS = (('sz_field', 'loc'), ('sz_field', 'sz'), ('sz_field', 'sz_all'), ('sz_field', 'sz_gated'),
         ('sz_gated', 'loc'), ('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz', 'loc'), ('oracle_gated', 'oracle'))


def main():
    res = {}; rules = {}
    for test in SEEDS:
        rs = runs(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        for arm in ('sz_field', 'sz_gated'):
            pc = A.policy_checks(rs, arm)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{arm}'] = pc
            R[f'split_{arm}_vs_sz'] = split_by_switchout(rs, arm, 'sz')
        R['field_decisions'] = field_decisions(rs)
        res[test] = R
    c = lambda t, k: res[t][k]
    if 'd9_realistic' in res:
        x = c('d9_realistic', 'sz_field vs loc')
        rules['D9a_realistic_field_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'd9_mixed' in res:
        rules['D9b_mixed_field_beats_sz_5pct'] = A.beats(c('d9_mixed', 'sz_field vs sz'), 0.05)
        rules['D9b_mixed_field_beats_all_3pct'] = A.beats(c('d9_mixed', 'sz_field vs sz_all'), 0.03)
    if 'd9_severe' in res:
        rules['D9c_severe_field_beats_sz_10pct'] = A.beats(c('d9_severe', 'sz_field vs sz'), 0.10)
    if 'd9_moderate' in res:
        rules['D9d_moderate_field_vs_sz_within_1pct'] = bool(c('d9_moderate', 'sz_field vs sz')['rel'] <= 0.01)
    if 'pairs_mixed' in res:
        rules['P1_pairs_field_vs_sz_within_1pct'] = bool(c('pairs_mixed', 'sz_field vs sz')['rel'] <= 0.01)
    if 'long_severe' in res:
        rules['L1_long_severe_field_beats_sz_10pct'] = A.beats(c('long_severe', 'sz_field vs sz'), 0.10)
    if 'long_mixed' in res:
        rules['L2_long_mixed_field_beats_sz_5pct'] = A.beats(c('long_mixed', 'sz_field vs sz'), 0.05)
        rules['L2_long_mixed_field_beats_all_3pct'] = A.beats(c('long_mixed', 'sz_field vs sz_all'), 0.03)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
