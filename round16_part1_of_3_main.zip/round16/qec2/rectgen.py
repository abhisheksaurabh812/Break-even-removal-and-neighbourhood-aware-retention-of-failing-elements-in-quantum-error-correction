"""
Rotated surface-code Z-memory circuit for a W x H patch (W data columns, H data rows), written to
reproduce Stim's own `rotated_memory_z` generator exactly when W == H (checked by text diff), with
optional column offset and a list of columns to treat as idle (for lattice-surgery configurations).

Coordinates follow Stim: data at (2a+1, 2b+1); measurement qubits at (2i, 2j); Z-type when i+j is even;
X-type boundary checks on the top/bottom edges, Z-type boundary checks on the left/right edges.
The Z observable is the bottom data row.
"""
import subprocess, os


def layout(W, H, x0=0):
    """x0: column offset (in data columns) so that several patches share one coordinate frame."""
    data = [(2 * (a + x0) + 1, 2 * b + 1) for b in range(H) for a in range(W)]
    xm, zm = [], []
    for j in range(H + 1):
        for i in range(W + 1):
            z = (i + j) % 2 == 0
            interior = 1 <= i <= W - 1 and 1 <= j <= H - 1
            if z and (interior or ((i == 0 or i == W) and 1 <= j <= H - 1)):
                zm.append((2 * (i + x0), 2 * j))
            if (not z) and (interior or ((j == 0 or j == H) and 1 <= i <= W - 1)):
                xm.append((2 * (i + x0), 2 * j))
    return data, xm, zm


def circuit(W, H, rounds, p, x0=0, row_len=None):
    data, xm, zm = layout(W, H, x0)
    RL = row_len or (2 * (W + x0) + 1)
    idx = lambda c: c[0] + RL * (c[1] // 2)
    dset = set(data)
    data_i = sorted(idx(c) for c in data)
    meas = sorted(xm + zm, key=idx); meas_i = [idx(c) for c in meas]
    xm_i = sorted(idx(c) for c in xm)
    out = []
    for c in sorted(data + xm + zm, key=idx):
        out.append(f'QUBIT_COORDS({c[0]}, {c[1]}) {idx(c)}')
    fmt = lambda v: str(v)
    P = fmt(p)
    out.append('R ' + ' '.join(map(str, data_i)))
    out.append(f'X_ERROR({P}) ' + ' '.join(map(str, data_i)))
    out.append('R ' + ' '.join(map(str, meas_i)))
    out.append(f'X_ERROR({P}) ' + ' '.join(map(str, meas_i)))
    out.append('TICK')
    orders_x = [(1, 1), (-1, 1), (1, -1), (-1, -1)]
    orders_z = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

    def layer(k):
        pairs = []
        for c in sorted(xm):
            dc = (c[0] + orders_x[k][0], c[1] + orders_x[k][1])
            if dc in dset:
                pairs += [idx(c), idx(dc)]
        for c in sorted(zm):
            dc = (c[0] + orders_z[k][0], c[1] + orders_z[k][1])
            if dc in dset:
                pairs += [idx(dc), idx(c)]
        return pairs

    def round_body(first):
        b = []
        b.append(f'DEPOLARIZE1({P}) ' + ' '.join(map(str, data_i)))
        b.append('H ' + ' '.join(map(str, xm_i)))
        b.append(f'DEPOLARIZE1({P}) ' + ' '.join(map(str, xm_i)))
        b.append('TICK')
        for k in range(4):
            pr = ' '.join(map(str, layer(k)))
            b.append('CX ' + pr); b.append(f'DEPOLARIZE2({P}) ' + pr); b.append('TICK')
        b.append('H ' + ' '.join(map(str, xm_i)))
        b.append(f'DEPOLARIZE1({P}) ' + ' '.join(map(str, xm_i)))
        b.append('TICK')
        b.append(f'X_ERROR({P}) ' + ' '.join(map(str, meas_i)))
        b.append('MR ' + ' '.join(map(str, meas_i)))
        b.append(f'X_ERROR({P}) ' + ' '.join(map(str, meas_i)))
        n = len(meas)
        pos = {c: k for k, c in enumerate(meas)}
        if first:
            for c in sorted(zm):
                b.append(f'DETECTOR({c[0]}, {c[1]}, 0) rec[{pos[c] - n}]')
        else:
            b.append('SHIFT_COORDS(0, 0, 1)')
            for c in meas:
                b.append(f'DETECTOR({c[0]}, {c[1]}, 0) rec[{pos[c] - n}] rec[{pos[c] - 2 * n}]')
        return b

    out += round_body(True)
    if rounds > 1:
        out.append(f'REPEAT {rounds - 1} {{')
        out += ['    ' + l for l in ['TICK'] + round_body(False)]
        out.append('}')
    out.append(f'X_ERROR({P}) ' + ' '.join(map(str, data_i)))
    out.append('M ' + ' '.join(map(str, data_i)))
    nd = len(data); n = len(meas)
    dpos = {c: k for k, c in enumerate(sorted(data, key=idx))}
    mpos = {c: k for k, c in enumerate(meas)}
    for c in sorted(zm):
        nb = [(c[0] + dx, c[1] + dy) for dx in (-1, 1) for dy in (-1, 1)]
        recs = sorted([dpos[q] - nd for q in nb if q in dset], reverse=True)
        recs.append(mpos[c] - n - nd)
        out.append(f'DETECTOR({c[0]}, {c[1]}, 1) ' + ' '.join(f'rec[{r}]' for r in recs))
    obs = sorted([dpos[q] - nd for q in data if q[1] == 1], reverse=True)
    out.append('OBSERVABLE_INCLUDE(0) ' + ' '.join(f'rec[{r}]' for r in obs))
    return '\n'.join(out) + '\n'


if __name__ == '__main__':
    STIM = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'bin', 'stim')
    for d in (3, 5, 7):
        ref = subprocess.run([STIM, 'gen', '--code', 'surface_code', '--task', 'rotated_memory_z', '--distance', str(d),
                              '--rounds', str(d), '--after_clifford_depolarization', '0.001',
                              '--before_round_data_depolarization', '0.001', '--before_measure_flip_probability', '0.001',
                              '--after_reset_flip_probability', '0.001'], capture_output=True, text=True).stdout
        ref = '\n'.join(l.strip() if not l.startswith('    ') else l.rstrip() for l in ref.splitlines()
                        if l.strip() and not l.startswith('#')) + '\n'
        mine = circuit(d, d, d, 0.001)
        same = ref == mine
        print(d, 'identical to stim gen' if same else 'DIFFERENT')
        if not same:
            import difflib
            print('\n'.join(list(difflib.unified_diff(ref.splitlines(), mine.splitlines(), lineterm=''))[:40]))
