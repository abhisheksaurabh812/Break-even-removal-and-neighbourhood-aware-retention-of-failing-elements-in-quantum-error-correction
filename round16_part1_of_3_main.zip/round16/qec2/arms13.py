"""
Round 13: naming that accounts for what the twin already knows, and estimates behind the hole.

Round 12 (seeds 8103, 8204; round 11 seed 7109) showed four ways the twin's naming goes wrong:
  - a second failure next to a known one is named from evidence that still contains the known one's signal;
  - two failures visible at once are judged 'spread' (no single qubit explains >= 70% of the excess);
  - while a qubit is switched out, the pair (coincidence) statistics used for naming treat every detector the
    reshaped circuit changes as an all-zero column, so the hidden part of a failure counts as evidence AGAINST
    every qubit whose footprint reaches into it, and a qubit on the visible side (often a boundary qubit that
    cannot be switched out) fits best (d9_mixed 8103);
  - a verdict, once given, is not revisited (re-check of round 12, Sized6), and a qubit that a probe has just found
    healthy can be named again from the same evidence (d9_severe 8204, five epochs after the probe).

Sized7 = Sized5 (round 11's learner) with these changes, each switchable (config sizer['name13']):
 mask_pairs  The naming evidence (pair statistics) skips detectors and edges that the reshaped circuit changes.
 exact       Naming by likelihood with the exact parity model, instead of the linear least-squares fit:
             every candidate's factor is fitted on the learner's grid to the episode's per-ancilla interior counts
             (binomial) and pair-type coincidence rates (Gaussian, variance by the delta method; types whose
             coincidence estimate is ill-conditioned are dropped), over the alarm's neighbourhood, visible ancillas
             only.  Baseline: the slow estimator's current rates (as before).  (Found in development: next to a
             qubit failing at ~50x and more, both detectors of an edge fire so often that the coincidence estimate
             becomes numerically unstable (one type gave -106,782 for a probability); the linear fit then weighted
             that point by its nominal variance and every candidate touching it - the true culprit - lost.)
 nuis        Name from the leftover: every qubit the learner already handles (not switched out) enters the fit
             with its own free factor; a new qubit is named only for what those cannot explain.
 local test  'Local' (a qubit is named) when the fitted model of the best candidate accounts for >= conc of the
             significant leftover excess in the neighbourhood (per ancilla, min(predicted extra counts, excess)),
             instead of the share of excess on its fixed main footprint (a Z ancilla failing at 73x spills excess
             onto ancillas outside its main footprint and was judged 'spread' indefinitely).
 two         One or two at once: when the best single qubit would be judged 'spread', it is fitted jointly with every
             other candidate; the best partner is named with it when the pair beats the best single by >= d2 in
             log-likelihood, the partner adds >= d2 to it and it to the partner, both fitted factors are >= r2min,
             and the pair's fitted model accounts for >= conc of the significant leftover excess.
 kappa       Systematic tolerance: the count likelihood is divided by 1 + kappa^2 E per ancilla (E = expected count),
             and kappa x rate is added to the coincidence and re-check errors, so that model mismatch of a few per
             cent next to a large known failure does not produce names.
 hide        Don't name from hidden evidence: if a candidate whose main footprint holds both significant leftover
             excess and an ancilla hidden during the evidence fits at least `amb` of the best single gain, or the
             best candidate has less than `hide` of its detection share visible, nothing is named and the alarm
             restarts (evidence is collected again, e.g. after a return or once the hole closes); after `hide_wait`
             epochs of waiting at that ancilla the best visible candidate is named anyway.
 veto        A qubit a probe has just found healthy (deactivated 'probe_quiet' / 'resume_quiet') is not named for
             `veto` epochs.
 recheck     Leftover re-check: an ancilla whose alarm is still up `recheck` epochs after its verdict, visible now,
             and whose leftover excess over the last `wr` epochs (after fitting every handled qubit) has z >= zre,
             collects fresh evidence and is classified again (checked every `every` epochs).
 patch       Patch alternative: before a name is given, one common factor on every qubit within distance `patch` of
             the best candidate (other than handled or switched-out qubits; factors up to `patch_rmax`) is fitted on
             top of the handled qubits; if it explains the evidence at least as well as the name(s), nothing is named
             (found on d9_realistic seed 8002: during bursts, single qubits were named at 50-400x, several at once).
With every switch off (exact False, mask_pairs False, nuis False, two False, hide 0, veto 0, recheck 0, patch 0) Sized7
is Sized5 exactly.
The second round-13 change, the reshaped circuit's own estimates while a qubit is out, is PolicyArmFieldWatch3 (end of
this file).
"""
from collections import deque
from itertools import combinations
import numpy as np
from arms import Stats, pair_p
from arms7 import CAP
from arms11 import Sized5

DEFAULT13 = dict(mask_pairs=True, exact=True, nuis=True, two=True, d2=12.5, r2min=2.0, gmin=4.5, hide=0.8, amb=0.5,
                 hide_wait=60, veto=200, recheck=50, every=5, zre=3.0, wr=20, topk=6, cand=0.1, pairs_w=1.0, kappa=0.1,
                 patch=4.1, patch_rmax=30.0)
OFF13 = dict(mask_pairs=False, exact=False, nuis=False, two=False, hide=0.0, veto=0, recheck=0, patch=0.0)


class Sized7(Sized5):
    kind = 'sized7'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        c = dict(DEFAULT13); c.update(self.sz.get('name13', {}))
        self.c13 = c
        m = self.m
        if getattr(self, 'ac', None):
            self.aN = np.zeros((m.nA, m.nA))          # interior trials per ancilla during each episode (masked -> 0)
        self.veto = {}                               # qubit -> epoch until which it may not be named
        self.hwait = {}                              # ancilla -> epoch of its first 'hidden' verdict in this wait
        self.s2 = {}                                 # ancilla -> epoch of its last verdict
        self.rwin = deque(maxlen=int(c['wr']))       # recent per-ancilla interior counts (n, N), masked -> 0
        self._out = set()                            # qubits switched out (by the policy) at the start of update
        self.s13 = {}
        self.log13 = []
        self.cnt13 = dict(one=0, two=0, spread=0, none=0, hidden=0, recheck=0, vetoed=0)

    # ------------------------------------------------------------ bookkeeping
    def deactivate(self, g, why):
        if why in ('probe_quiet', 'resume_quiet') and int(self.c13['veto']) > 0 and g in self.sovr:
            self.veto[int(g)] = self.ep_i + int(self.c13['veto'])
        super().deactivate(g, why)

    def reset_local(self, g):
        super().reset_local(g)
        if getattr(self, 'ac', None):
            for b in self._st(g)['anc']:
                self.aN[b] = 0

    def _convert(self):
        """Sized._convert, with second names ('anc2') taken from the same ancilla evidence."""
        m = self.m
        qb = np.maximum(self.q[m.anc_int_class], 1e-9)
        for key in list(self.ovr):
            o = self.ovr.pop(key)
            g = int(o['q'])
            if g in self.sovr:
                continue
            if key[0] in ('anc', 'anc2'):
                n0 = self.aacc[key[1]].copy(); E0 = self.aE[key[1]].copy()
            else:
                n0 = self.nacc[key[1]].copy(); E0 = self.Eacc[key[1]].copy()
            N0 = E0 / qb
            r = self.fit(g, n0, N0)
            if r >= self.r_on:
                self._activate(g, r, n0, N0, key[0])
            else:
                self.n_rej += 1
                self.slog.append(['reject', self.ep_i, g, round(r, 2), round(float(o['r']), 2)])

    # ------------------------------------------------------------ per-ancilla monitor (Slow._anc_monitor + changes)
    def _anc_monitor(self, X):
        from arms import _lib, _dp, _ip, _up
        m, ac = self.m, self.ac; B = X.shape[0]; Tint = m.T - 1; nA = m.nA
        mask = getattr(self, 'mask', None)
        cra = np.ascontiguousarray((X.astype(np.float32) @ m.AggA).reshape(B * Tint, nA), dtype=np.float64)
        mu_a = self.q[m.anc_int_class]
        if mask is not None:
            mu_a = mu_a * ~mask['anc_off']
        mu_a = np.ascontiguousarray(mu_a, dtype=np.float64)
        nr = B * Tint
        act = np.empty((nr, nA), np.uint8); new = np.empty((nr, nA), np.uint8)
        rho = float(ac['rho']); h = float(ac['h'])
        _lib.cusum_run(nr, nA, cra.ctypes.data_as(_dp), mu_a.ctypes.data_as(_dp), float(np.log(rho)), rho, h, h + 3.0,
                       int(ac.get('holdoff', 1500)), float(ac.get('beta_tau', 2000.0)),
                       self.aS.ctypes.data_as(_dp), self.aal.ctypes.data_as(_ip), self.ahold.ctypes.data_as(_ip),
                       self.alen_a.ctypes.data_as(_dp), self.abr.ctypes.data_as(_dp),
                       act.ctypes.data_as(_up), new.ctypes.data_as(_up))
        bact = act.reshape(B, Tint, nA).any(1); bnew = new.reshape(B, Tint, nA).any(1)
        self.n_aalarm += int(new.sum())
        start = np.zeros(nA, int)
        for a in np.nonzero(bnew.any(0))[0]:
            start[a] = np.nonzero(bnew[:, a])[0][-1]
            self.aacc[a] = 0; self.aE[a] = 0; self.aN[a] = 0; self.astate[a] = 1
            self.astats[int(a)] = Stats(m)
        col = np.nonzero(self.astate == 1)[0]
        if len(col):
            cnt = X.astype(np.float32) @ m.A_int
            eb = self.q[m.anc_int_class] * m.anc_nint
            nt = np.asarray(m.anc_nint, float)
            if mask is not None:
                eb = eb * ~mask['anc_off']; nt = nt * ~mask['anc_off']
            for a in col:
                msk = bact[:, a].copy(); msk[:start[a]] = False
                nb = int(msk.sum())
                if nb:
                    self.aacc[a] += cnt[msk].sum(0); self.aE[a] += nb * eb; self.aN[a] += nb * nt
                    if ac.get('pairs', True):
                        if self.c13['mask_pairs'] and mask is not None:
                            self.astats[int(a)].add(X[msk], None, mask)
                        else:
                            self.astats[int(a)].add(X[msk])
                if self.aE[a, a] >= ac.get('emin', 60):
                    self._decide13(int(a))
        for a in np.nonzero((self.aal == 0) & (self.astate > 0))[0]:
            self.ovr.pop(('anc', int(a)), None); self.ovr.pop(('anc2', int(a)), None)
            self.astate[a] = 0; self.astats.pop(int(a), None)

    def _restart(self, a):
        """Forget ancilla a's alarm and evidence so that it alarms and collects again."""
        self.aS[a] = 0; self.aal[a] = 0; self.ahold[a] = 0; self.alen_a[a] = 0
        self.abr[a] = float(self.ac['rho']); self.astate[a] = 0
        self.aacc[a] = 0; self.aE[a] = 0; self.aN[a] = 0
        self.astats.pop(int(a), None)

    def _decide13(self, a):
        c = self.c13
        if not c['exact']:
            frac, local, gstar, top3, rhat, nsig = self._classify(self.aacc[a], self.aE[a], a)
            if self.ac.get('pairs', True):
                gstar, top3, rhat = self._name_pairs(self.astats[int(a)], self.aacc[a], self.aE[a], a)
            veto = int(c['veto']) > 0 and self.veto.get(gstar, -1) > self.ep_i
            self.astats.pop(int(a), None)
            self.astate[a] = 2
            if local and gstar >= 0 and rhat >= 1.1 and not veto:
                self.ovr[('anc', int(a))] = dict(q=gstar, r=rhat, u=self._shares(gstar), p_dec=self.p.copy())
                self.n_ovr += 1
            elif veto:
                self.cnt13['vetoed'] += 1
            self.loclog.append([self.nupd, int(a), int(local), round(frac, 3), nsig, 0,
                                round(float(self.aE[a, a]), 1), gstar, top3, round(rhat, 2)])
            return
        verdict, names, extra = self._name13(a)
        self.cnt13[verdict] += 1
        self.log13.append([self.ep_i, int(a), verdict, [[int(g), round(float(r), 2)] for g, r in names], extra])
        if verdict == 'hidden':
            self._restart(a)
            return
        self.astats.pop(int(a), None)
        self.astate[a] = 2
        for i, (g, r) in enumerate(names):
            key = ('anc', int(a)) if i == 0 else ('anc2', int(a))
            self.ovr[key] = dict(q=int(g), r=float(r), u=self._shares(int(g)), p_dec=self.p.copy())
            self.n_ovr += 1
        top = [int(t[0]) for t in extra.get('top', [])]
        self.loclog.append([self.nupd, int(a), int(verdict in ('one', 'two')), extra.get('frac', 0.0), 0, 0,
                            round(float(self.aE[a, a]), 1), names[0][0] if names else -1, top[:3],
                            round(float(names[0][1]), 2) if names else 1.0])

    # ------------------------------------------------------------ exact-model naming
    def _init_types(self):
        if getattr(self, 't_anc', None) is not None:
            return
        m = self.m
        nb_t = np.zeros(m.ntype, bool); nb_t[m.etype[m.nb_idx]] = True
        self.t_anc = np.full((m.ntype, 2), -1)
        self.t_anc[m.etype, 0] = m.danc[m.eu]
        self.t_anc[m.etype, 1] = np.where(m.ev >= 0, m.danc[np.maximum(m.ev, 0)], -1)
        self.nb_t = nb_t
        self.t_cnt = np.bincount(m.etype, minlength=m.ntype).astype(float)

    def _s13(self, g):
        s = self.s13.get(g)
        if s is not None:
            return s
        m = self.m; st = self._st(g)
        lg0 = self._lg0(st)
        eds = np.asarray(st['edges'], int)
        nbm = m.ev[eds] >= 0 if len(eds) else np.zeros(0, bool)
        e_nb = eds[nbm]
        Re = np.zeros((len(e_nb), len(self.grid)))
        for i, j in enumerate(np.nonzero(nbm)[0]):
            pk = np.asarray(st['epk'][j], float)
            Re[i] = (np.log1p(-2 * np.minimum(CAP, pk[:, None] * self.grid[None, :])) - np.log1p(-2 * pk)[:, None]).sum(0)
        dets = np.asarray(st['dets'], int)
        s = dict(dets=dets, danc=st['anc'][st['didx']] if len(dets) else np.zeros(0, int),
                 dR=st['Rg'] - lg0[:, None] if len(dets) else np.zeros((0, len(self.grid))),
                 e=e_nb, et=m.etype[e_nb], Re=Re)
        self.s13[g] = s
        return s

    def _data13(self, a, n, N, st=None):
        """Evidence around ancilla a: visible neighbourhood ancillas (counts n, trials N) and, if st is given, the
        neighbourhood's non-boundary edge types with their coincidence-based rates."""
        m = self.m
        nbr = m.fp_nbr[a]
        ancs = np.nonzero(nbr & (N > 0))[0]
        q0 = np.clip(self.q[m.anc_int_class], 1e-6, 0.49)
        idets = np.concatenate([self.int_dets[b] for b in ancs]).astype(int) if len(ancs) else np.zeros(0, int)
        kap = float(self.c13['kappa'])
        Nb = np.asarray(N, float)[ancs]
        D = dict(a=a, nbr=nbr, ancs=ancs, n=np.asarray(n, float)[ancs], N=Nb, q0=q0,
                 idets=idets, ipos=np.searchsorted(ancs, m.danc[idets]), nint=self.nint[ancs],
                 Lq=np.log1p(-2 * q0[m.danc[idets]]), phi=1.0 + kap ** 2 * Nb * q0[ancs])
        if st is not None:
            self._init_types()
            t0, t1 = self.t_anc[:, 0], self.t_anc[:, 1]
            tsel = self.nb_t & (nbr[t0] | ((t1 >= 0) & nbr[np.maximum(t1, 0)]))
            t_nb = m.etype[m.nb_idx]
            Sa = np.bincount(t_nb, st.sa, m.ntype); Sb = np.bincount(t_nb, st.sb, m.ntype)
            Sab = np.bincount(t_nb, st.sab, m.ntype); Sn = np.bincount(t_nb, st.sn, m.ntype)
            tsel &= Sn > 0
            types = np.nonzero(tsel)[0]
            if len(types):
                Snn = np.maximum(Sn[types], 1)
                ra, rb, rab = Sa[types] / Snn, Sb[types] / Snn, Sab[types] / Snn
                ph = pair_p(ra, rb, rab)
                p0 = np.clip(self.p, 1e-7, 0.45)
                ps = (np.bincount(m.etype, p0, m.ntype) / np.maximum(self.t_cnt, 1))[types]
                # variance of the coincidence estimate by the delta method (the estimate is ill-conditioned when both
                # detectors fire often, e.g. next to a badly failing qubit); unusable types are dropped
                den = 1 - 2 * ra - 2 * rb + 4 * rab
                vd = self._pair_var(ra, rb, rab, Snn)
                sig2 = np.maximum(vd, np.maximum(np.maximum(ph, ps), 1e-6) / Snn) + (kap * np.maximum(ph, ps)) ** 2
                ok = np.isfinite(ph) & np.isfinite(sig2) & (ph > -0.1) & (ph < 0.5) & (den > 0.05)
                types, ph, sig2, ps = types[ok], ph[ok], sig2[ok], ps[ok]
            if len(types):
                tedges = np.nonzero(np.isin(m.etype, types))[0]
                D.update(types=types, ph=ph, sig2=sig2, tedges=tedges,
                         tpos=np.searchsorted(types, m.etype[tedges]), tcnt=self.t_cnt[types], Lp=np.log1p(-2 * p0))
        return D

    @staticmethod
    def _pair_var(a, b, ab, n):
        eps = 1e-6
        with np.errstate(all='ignore'):
            f0 = pair_p(a, b, ab)
            ga = (pair_p(a + eps, b, ab) - f0) / eps
            gb = (pair_p(a, b + eps, ab) - f0) / eps
            gc = (pair_p(a, b, ab + eps) - f0) / eps
            v = (ga ** 2 * a * (1 - a) + gb ** 2 * b * (1 - b) + gc ** 2 * ab * (1 - ab) + 2 * ga * gb * (ab - a * b)
                 + 2 * ga * gc * ab * (1 - a) + 2 * gb * gc * ab * (1 - b)) / n
        return np.where(np.isfinite(v), np.maximum(v, 0.0), np.inf)

    def _ll13(self, D, addL, addE):
        n, N = D['n'], D['N']
        ll = 0.0
        if len(D['ancs']):
            qd = -0.5 * np.expm1(D['Lq'] + addL[D['idets']])
            qb = np.clip(np.bincount(D['ipos'], qd, len(D['ancs'])) / D['nint'], 1e-9, 1 - 1e-9)
            ll += float(((n * np.log(qb) + (N - n) * np.log1p(-qb)) / D['phi']).sum())
        if 'types' in D:
            te = D['tedges']
            pe = -0.5 * np.expm1(D['Lp'][te] + addE[te])
            pt = np.bincount(D['tpos'], pe, len(D['types'])) / D['tcnt']
            ll -= 0.5 * self.c13['pairs_w'] * float((((D['ph'] - pt) ** 2) / D['sig2']).sum())
        return ll

    def _best13(self, D, g, addL, addE, ll_now):
        """Grid search of g's factor with every other contribution fixed (g absent from addL / addE)."""
        s = self._s13(g)
        var = np.zeros(len(self.grid))
        A = D['ancs']
        if len(s['dets']) and len(A):
            rows = np.nonzero(np.isin(s['danc'], A))[0]
            if len(rows):
                banc = s['danc'][rows]; dets = s['dets'][rows]
                qd = -0.5 * np.expm1((np.log1p(-2 * D['q0'][banc]) + addL[dets])[:, None] + s['dR'][rows])
                ub, pos = np.unique(banc, return_inverse=True)
                qb = np.zeros((len(ub), len(self.grid))); np.add.at(qb, pos, qd)
                qb /= np.bincount(pos, minlength=len(ub))[:, None]
                qb = np.clip(qb, 1e-9, 1 - 1e-9)
                j = np.searchsorted(A, ub)
                nn = D['n'][j]; NN = D['N'][j]
                var += ((nn[:, None] * np.log(qb) + (NN - nn)[:, None] * np.log1p(-qb)) / D['phi'][j][:, None]).sum(0)
        if 'types' in D and len(s['e']):
            em = np.isin(s['et'], D['types'])
            if em.any():
                e = s['e'][em]; Re = s['Re'][em]
                te = D['tedges']
                St = np.bincount(D['tpos'], -0.5 * np.expm1(D['Lp'][te] + addE[te]), len(D['types']))
                Le = D['Lp'][e] + addE[e]
                pe_now = -0.5 * np.expm1(Le)
                pe_g = -0.5 * np.expm1(Le[:, None] + Re)
                tp = np.searchsorted(D['types'], s['et'][em])
                ut, k = np.unique(tp, return_inverse=True)
                dsum = np.zeros((len(ut), len(self.grid))); np.add.at(dsum, k, pe_g - pe_now[:, None])
                pt = (St[ut][:, None] + dsum) / D['tcnt'][ut][:, None]
                var -= 0.5 * self.c13['pairs_w'] * (((D['ph'][ut][:, None] - pt) ** 2) / D['sig2'][ut][:, None]).sum(0)
        i = int(np.argmax(var))
        return i, ll_now - var[0] + var[i]

    def _fixed13(self, H):
        """Grid index of each known qubit's factor relative to the slow estimator's current rates, fitted on the qubit's
        own sizing window (not on the evidence being named)."""
        m = self.m
        qcur = np.clip(self.q[m.anc_int_class], 1e-6, 0.49)
        idxF = {}
        for h in H:
            o = self.sovr[h]
            nn = np.sum([w[0] for w in o['win']], 0) if o['win'] else np.zeros(m.nA)
            NN = np.sum([w[1] for w in o['win']], 0) if o['win'] else np.zeros(m.nA)
            if len(o['win']) < self.Wmin and o.get('init') is not None:
                nn = nn + o['init'][0]; NN = NN + o['init'][1]
            r_h = self.fit_base(h, np.asarray(nn, float), np.asarray(NN, float), qcur) if np.any(np.asarray(NN) > 0) else 1.0
            idxF[h] = int(np.argmin(np.abs(np.log(self.grid) - np.log(max(r_h, 1.0)))))
        return idxF

    def _pred13(self, D, idx):
        """Expected interior counts on the evidence's visible neighbourhood ancillas with qubits idx = {g: grid index}."""
        addL = np.zeros(self.m.nZ)
        for g, i in idx.items():
            s = self._s13(g)
            if len(s['dets']):
                np.add.at(addL, s['dets'], s['dR'][:, i])
        qd = -0.5 * np.expm1(D['Lq'] + addL[D['idets']])
        return D['N'] * np.bincount(D['ipos'], qd, len(D['ancs'])) / D['nint']

    def _add13(self, g, i, addL, addE, sign=1.0):
        s = self._s13(g)
        if len(s['dets']):
            np.add.at(addL, s['dets'], sign * s['dR'][:, i])
        if len(s['e']):
            np.add.at(addE, s['e'], sign * s['Re'][:, i])

    def _fit13(self, D, gs, init=None, passes=4):
        """Joint fit of the factors of qubits gs by coordinate ascent on the grid; returns (ll, {g: index})."""
        m = self.m
        idx = {g: 0 for g in gs}
        if init:
            idx.update({g: i for g, i in init.items() if g in idx})
        addL = np.zeros(m.nZ); addE = np.zeros(m.E)
        for g in gs:
            self._add13(g, idx[g], addL, addE)
        ll = self._ll13(D, addL, addE)
        for _ in range(passes):
            changed = False
            for g in gs:
                self._add13(g, idx[g], addL, addE, -1.0)
                ll0 = self._ll13(D, addL, addE)
                i, ll = self._best13(D, g, addL, addE, ll0)
                changed |= i != idx[g]
                idx[g] = i
                self._add13(g, i, addL, addE)
            if not changed:
                break
        return self._ll13(D, addL, addE), idx, addL, addE

    def _name13(self, a):
        m, c = self.m, self.c13
        n, N = self.aacc[a], self.aN[a]
        st = self.astats.get(int(a)) if self.ac.get('pairs', True) else None
        D = self._data13(a, n, N, st)
        if not len(D['ancs']):
            return 'none', [], dict(why='nothing visible')
        vis_all = N > 0
        nbr = D['nbr']
        Wn = self.Wn
        H = [g for g in self.sovr if g not in self._out and float(Wn[g][D['ancs']].sum()) >= 0.01] if c['nuis'] else []
        if H:
            llH, idxH, addL, addE = self._fit13(D, H)
        else:
            addL = np.zeros(m.nZ); addE = np.zeros(m.E); idxH = {}
            llH = self._ll13(D, addL, addE)
        # leftover per-ancilla excess (local / spread test, candidate filter) against the known qubits at the sizes
        # their OWN recent windows give (relative to the current baseline), not at sizes refitted to this evidence:
        # refitted freely, a known qubit absorbs a new neighbour's signal and the neighbour never becomes a candidate
        # (d9_severe 8204).  Candidate scores below still refit the known qubits jointly with each candidate.
        idxF = self._fixed13(H)
        A = D['ancs']
        Eb = self._pred13(D, idxF)
        e = D['n'] - Eb; z = e / np.sqrt(np.maximum(Eb + (c['kappa'] * Eb) ** 2, 1e-9))
        es = np.where(z > self.fp.get('zs', 2.0), np.maximum(e, 0), 0.0)
        tot = float(es.sum())
        if tot <= 0:
            return 'none', [], dict(why='no leftover excess', nuis=len(H))
        # candidates: main footprint on an ancilla with significant leftover excess, on the alarmed ancilla, on a
        # neighbourhood ancilla hidden during the evidence, or on a known qubit's main footprint; enough of the
        # qubit's error mass in the neighbourhood
        look = np.zeros(m.nA, bool); look[A[es > 0]] = True; look[a] = True; look |= nbr & ~vis_all
        for h in H:
            look |= m.fp_supp[h] & nbr
        pool = np.nonzero(m.fp_supp[:, look].any(1) & (Wn[:, nbr].sum(1) >= c['cand']))[0].tolist()
        veto = {g for g, t in self.veto.items() if t > self.ep_i}
        skip = set(H) | self._out | set(self.sovr)
        cand = [g for g in pool if g not in skip and g not in veto]
        nveto = sum(1 for g in pool if g in veto)
        if not cand:
            return 'none', [], dict(why='no candidate', nuis=len(H), vetoed=nveto)
        gain = {}; gidx = {}
        # a known qubit whose main footprint overlaps a candidate's footprint is refitted together with it: with its
        # factor fitted alone first it absorbs part of a new neighbour's signal before the neighbour is tried
        # (d9_severe 8204: a boundary data qubit at 82x took the signal of the Z ancilla beside it at 66x, and a
        # healthy neighbour was named instead)
        fpH = {h: m.fp_supp[h] for h in H}
        for g in cand:
            i, ll = self._best13(D, g, addL, addE, llH)
            gain[g] = ll - llH; gidx[g] = i
            if H and any((fpH[h] & (Wn[g] >= 0.05)).any() for h in H):
                init = dict(idxH); init[g] = i
                ll2, idx2, _, _ = self._fit13(D, H + [g], init=init)
                if ll2 - llH > gain[g]:
                    gain[g] = ll2 - llH; gidx[g] = idx2[g]
        order = sorted(cand, key=lambda g: -gain[g])
        top = order[:int(c['topk'])]
        # refine the top singles jointly with the nuisance qubits
        g1 = {}; gi1 = {}
        for g in top:
            init = dict(idxH); init[g] = gidx[g]
            ll, idx, _, _ = self._fit13(D, H + [g], init=init)
            g1[g] = ll - llH; gi1[g] = idx
        best = max(top, key=lambda g: g1[g])

        def frac(idx):
            """Share of the significant leftover excess that the fitted model with qubits idx (on top of the nuisance
            fit) accounts for: per ancilla, min(predicted extra counts, significant excess)."""
            ex = self._pred13(D, idx) - Eb
            return float(np.minimum(np.maximum(ex, 0), es).sum() / tot)

        vshare = lambda g: float(Wn[g][vis_all].sum())
        extra = dict(nuis=len(H), vetoed=nveto, ncand=len(cand),
                     top=[[int(g), round(g1[g], 1), round(vshare(g), 2)] for g in top[:4]])
        if g1[best] < c['gmin']:
            return 'none', [], extra
        # hidden evidence: a candidate whose main footprint holds both significant leftover excess and an ancilla that
        # was hidden during the evidence could be the culprit, half out of sight; if it fits at least `amb` of the best
        # single gain (or the best itself is mostly hidden), wait (at most hide_wait epochs at this ancilla)
        if c['hide'] > 0:
            hid = nbr & ~vis_all
            S = np.zeros(m.nA, bool); S[A[es > 0]] = True
            strad = [g for g in order if gain[g] >= c['amb'] * gain[order[0]]
                     and m.fp_supp[g][S].any() and m.fp_supp[g][hid].any()] if hid.any() else []
            if strad or vshare(best) < c['hide']:
                t0 = self.hwait.get(a)
                if t0 is None or self.ep_i - t0 > 3 * c['hide_wait']:
                    t0 = self.hwait[a] = self.ep_i
                if self.ep_i - t0 < c['hide_wait']:
                    extra['hidden'] = [int(g) for g in strad[:4]]
                    return 'hidden', [], extra
                extra['waited'] = int(self.ep_i - t0)
        self.hwait.pop(a, None)
        f1 = frac(gi1[best])
        names = None
        # two at once only when one qubit does not account for the leftover (it would be judged 'spread'): the best
        # single plus the partner, searched over every candidate, that improves the fit most
        if c['two'] and f1 < self.fp['conc']:
            bp = None
            for h in cand:
                if h == best or gain[h] < c['gmin']:
                    continue
                init = dict(gi1[best]); init[h] = gidx[h]
                ll, idx, _, _ = self._fit13(D, H + [best, h], init=init)
                gp = ll - llH
                if bp is None or gp > bp[0]:
                    bp = (gp, h, idx)
            if bp is not None:
                gp, h, idx = bp
                g1h = g1.get(h)
                if g1h is None:
                    init = dict(idxH); init[h] = gidx[h]
                    g1h = self._fit13(D, H + [h], init=init)[0] - llH
                f2 = frac(idx)
                extra['pair_try'] = [int(best), int(h), round(gp - g1[best], 1), round(gp - g1h, 1), round(f2, 3)]
                if (gp - g1[best] >= c['d2'] and gp - g1h >= c['d2'] and f2 >= self.fp['conc']
                        and min(self.grid[idx[best]], self.grid[idx[h]]) >= c['r2min']
                        and (c['hide'] <= 0 or min(vshare(best), vshare(h)) >= c['hide'])):
                    names = [(best, self.grid[idx[best]]), (h, self.grid[idx[h]])]
                    extra['frac'] = round(f2, 3)
        if names is None:
            extra['frac'] = round(f1, 3)
            if f1 < self.fp['conc']:
                return 'spread', [], extra
            names = [(best, self.grid[gi1[best][best]])]
            verdict = 'one'; g_named = g1[best]
        else:
            verdict = 'two'; g_named = gp
        # patch alternative: a common factor on every qubit near the best candidate (a burst or a regional change)
        # explains the evidence at least as well as the name(s) -> no name (realistic 8002: during bursts single qubits
        # were named at 50-400x, several at once, and the decoder was reweighted around them)
        if c['patch'] > 0:
            gpatch, rpatch, npatch = self._patch13(D, best, H, addL, addE, llH)
            extra['patch'] = [round(gpatch, 1), round(g_named, 1), round(rpatch, 2), npatch]
            if gpatch >= g_named:
                self.cnt13['patch'] = self.cnt13.get('patch', 0) + 1
                return 'spread', [], extra
        names = [(int(g), float(min(r, self.rcap))) for g, r in names]
        return verdict, names, extra

    def _patch13(self, D, best, H, addL, addE, llH):
        """Best common factor (grid values <= patch_rmax) for every qubit within distance `patch` of `best`, other
        than known or switched-out qubits, on top of the nuisance fit: (log-likelihood gain, factor, patch size)."""
        c, m = self.c13, self.m
        dist = np.sqrt(((m.qxy - m.qxy[best]) ** 2).sum(1))
        skip = set(H) | set(self._out)
        P = [g for g in np.nonzero(dist <= c['patch'])[0].tolist() if g not in skip]
        ii = np.nonzero(self.grid <= c['patch_rmax'])[0][::2]
        AL = np.zeros((m.nZ, len(ii))); AE = np.zeros((m.E, len(ii)))
        for g in P:
            s = self._s13(g)
            if len(s['dets']):
                np.add.at(AL, s['dets'], s['dR'][:, ii])
            if len(s['e']):
                np.add.at(AE, s['e'], s['Re'][:, ii])
        lls = [self._ll13(D, addL + AL[:, k], addE + AE[:, k]) for k in range(len(ii))]
        k = int(np.argmax(lls))
        return float(lls[k] - llH), float(self.grid[ii[k]]), len(P)

    # ------------------------------------------------------------ leftover re-check
    def _leftover_z(self, a):
        m = self.m
        n = np.sum([w[0] for w in self.rwin], 0); N = np.sum([w[1] for w in self.rwin], 0)
        if N[a] <= 0:
            return 0.0
        D = self._data13(a, n, N)
        H = [g for g in self.sovr if g not in self._out and float(self.Wn[g][D['ancs']].sum()) >= 0.01]
        addL = np.zeros(m.nZ)
        for g, i in self._fixed13(H).items():         # known qubits at their own windows' sizes (see _name13)
            s = self._s13(g)
            if len(s['dets']):
                np.add.at(addL, s['dets'], s['dR'][:, i])
        u = self.int_dets[a]
        q = float(np.mean(-0.5 * np.expm1(np.log1p(-2 * D['q0'][a]) + addL[u])))
        q = min(max(q, 1e-9), 1 - 1e-9)
        return float((n[a] - N[a] * q) / np.sqrt(N[a] * q * (1 - q) + (self.c13['kappa'] * N[a] * q) ** 2))

    def update(self, X, crr, mask=None):
        self._out = {g for g, o in self.sovr.items() if o['susp']}
        prev = self.astate.copy() if getattr(self, 'ac', None) else None
        super().update(X, crr, mask)
        if prev is None:
            return
        c = self.c13
        K = int(c['recheck'])
        if K <= 0:
            return
        m = self.m
        n = (X.astype(np.float32) @ m.A_int).sum(0).astype(float)
        N = X.shape[0] * self.nint
        off = None
        if mask is not None:
            off = np.asarray(mask['anc_off'], bool)
            n = np.where(off, 0.0, n); N = np.where(off, 0.0, N)
        self.rwin.append((n, N))
        for a in np.nonzero((prev != 2) & (self.astate == 2))[0]:
            self.s2[int(a)] = self.ep_i
        for a in list(self.s2):
            if self.astate[a] != 2:
                del self.s2[a]; continue
            age = self.ep_i - self.s2[a]
            if age < K or self.aal[a] == 0 or age % int(c['every']) or len(self.rwin) < self.rwin.maxlen:
                continue
            if off is not None and off[a]:
                continue
            if self._leftover_z(a) >= c['zre']:
                self.astate[a] = 1; self.aacc[a] = 0; self.aE[a] = 0; self.aN[a] = 0
                self.astats[int(a)] = Stats(m)
                del self.s2[a]
                self.cnt13['recheck'] += 1
                self.slog.append(['recheck', self.ep_i, int(a)])

    def info(self):
        d = super().info()
        d['sized']['name13'] = dict(self.cnt13)
        d['sized']['log13'] = self.log13[:5000]
        return d


# ---------------------------------------------------------------------------------------------------------------------
# Round 13, second change: the reshaped circuit's own estimates while a qubit is switched out.
from arms import estimate, WMIN
from sampler import weights_from_p
from arms12 import PolicyArmFieldWatch2


class PolicyArmFieldWatch3(PolicyArmFieldWatch2):
    """PolicyArmFieldWatch2 (round 12's gate) plus the reshaped circuit's own error estimates while a qubit is out.
    Config 'hole': {'R': rounds per update (100,000), 's': smoothing 2^-s (1), 'keep': rounds for which a
    configuration's estimates are kept after it ends, so that a short return does not lose them (200,000)}.

    Found on round-12 long-severe seed 8502 (dev13/trace, RESULTS_round12.md): with a qubit out, the base twin's
    statistics are masked for every edge that touches a detector the reshaped circuit changes (d = 7, q40 out: 295 of
    the reshaped decoder's 828 edges).  The reshaped circuit's decoder still uses those edges' base estimates, frozen
    at the switch-out, so a change behind the hole is never seen (q73's recovery: weight 3.05 against a true 6.2 for
    1.6 M rounds).  And a base boundary edge whose detector has a masked neighbouring edge is re-estimated by
    subtracting frozen values from a fresh detector rate, so it drifts (weight 7.2 -> 13.5 against a true 3.8).

    Here a slow estimator (arms.estimate, the base twin's) runs on the reshaped circuit's own detection events for as
    long as that configuration lasts.  Once an edge has an estimate, the decoder uses it for every edge of the reshaped
    circuit that is new, maps to a base edge with masked statistics, or maps to a base boundary edge whose detector has
    a masked neighbouring edge.  Meanwhile the base twin's drifting boundary edges are held at their value at the
    switch-out, or set to the reshaped estimate once there is one, so they are sound when the qubit comes back."""
    kind = 'policy'

    def __init__(self, *a, hole=None, **k):
        super().__init__(*a, **k)
        h = dict(hole or {})
        self.h_R = float(h.get('R', 100000)); self.h_alpha = 2.0 ** (-float(h.get('s', 1)))
        self.h_keep = float(h.get('keep', 200000))
        self.hs = None; self.hcache = {}; self.n_hupd = 0; self.n_hstart = 0

    def _hole_start(self, md):
        hs = self.hcache.get(md.name)
        if hs is not None and self.rounds - hs['t_last'] <= self.h_keep:
            return hs
        m = self.base; inn = self.inner
        nbm = md.mask['edge_ok'] == 0                          # base non-boundary edges with masked statistics
        stale = np.zeros(m.E, bool); stale[m.nb_idx] = nbm
        bnd = np.asarray(m.b_idx); bu = m.eu[bnd]
        dok = md.mask['det_ok'] > 0
        badd = np.asarray(m.Inc_nb @ nbm.astype(float)).ravel() > 0
        drift = bnd[dok[bu] & badd[bu]]                       # visible boundary edges derived from masked neighbours
        stale[bnd[~dok[bu]]] = True; stale[drift] = True
        mapped = md.emap >= 0
        aff = ~mapped | stale[np.maximum(md.emap, 0)]
        w0 = np.asarray(PolicyArmFieldWatch2.weights(self, md, None), float)
        p0 = 1.0 / (1.0 + np.exp(w0))
        qd = md.det_rate(self.view())
        q0 = np.bincount(md.dclass, qd, md.nclass) / np.maximum(md.class_count, 1)
        inv = {int(j): i for i, j in enumerate(md.emap) if j >= 0}
        dmap = np.array([inv.get(int(j), -1) for j in drift], int)
        hs = dict(name=md.name, st=Stats(md), p=p0, q=q0, rounds=0.0, valid=np.zeros(md.E, bool), aff=aff,
                  drift=drift, dmap=dmap, pin=np.asarray(inn.p)[drift].copy(), t_last=self.rounds, nupd=0)
        self.hcache = {md.name: hs}; self.n_hstart += 1
        return hs

    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        if md is not None:
            hs = self.hs if (self.hs is not None and self.hs['name'] == md.name) else self._hole_start(md)
            self.hs = hs
            hs['st'].add(X); hs['rounds'] += X.shape[0] * T
            if hs['rounds'] >= self.h_R:
                minN = 0.25 * self.h_R / md.T
                p_new, q_new, okp, okq = estimate(md, hs['st'], hs['p'], hs['q'], minN, minN)
                a = self.h_alpha
                hs['p'][okp] += a * (p_new[okp] - hs['p'][okp]); hs['q'][okq] += a * (q_new[okq] - hs['q'][okq])
                hs['valid'] |= okp; hs['st'].reset(); hs['rounds'] = 0.0; hs['nupd'] += 1; self.n_hupd += 1
        else:
            self.hs = None
        super().update(X, crr, md, base_AggD, epoch, T, ftrue, to_base)
        if md is not None:
            hs = self.hs; hs['t_last'] = self.rounds
            if len(hs['drift']):
                val = hs['pin'].copy()
                if hs['nupd']:
                    ok = hs['dmap'] >= 0
                    ok[ok] = hs['valid'][hs['dmap'][ok]]
                    val[ok] = hs['p'][hs['dmap'][ok]]
                self.inner.p[hs['drift']] = val

    def weights(self, md, true_pe):
        w = super().weights(md, true_pe)
        hs = self.hs
        if md is None or hs is None or hs['name'] != md.name or not hs['nupd']:
            return w
        sel = hs['aff'] & hs['valid']
        if sel.any():
            w = np.array(w, float)
            w[sel] = weights_from_p(hs['p'][sel], WMIN)
        return w

    def info(self):
        d = super().info()
        d.update(hole_starts=self.n_hstart, hole_updates=self.n_hupd)
        return d
