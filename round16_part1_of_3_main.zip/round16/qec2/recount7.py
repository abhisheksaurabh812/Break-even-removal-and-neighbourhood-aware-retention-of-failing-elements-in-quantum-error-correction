"""Independent recount of round-7 decision numbers straight from the raw arrays (no code shared with
analyse7.py): totals and the relative differences behind G1-G4 and C2-C3, plus per-seed signs."""
import json, os
import numpy as np
from math import erf, sqrt

def stats(prefix, scen, seeds, a, b):
    tot_a = tot_b = 0; d_all = []; per_seed = []
    for sd in seeds:
        f = f'{prefix}{scen}_s{sd}.npz'
        if not os.path.exists(f):
            return None
        z = np.load(f, allow_pickle=True)
        names = [str(x) for x in z['names']]
        A = z['fails'][names.index(a)].astype(np.int64).sum(1); B = z['fails'][names.index(b)].astype(np.int64).sum(1)
        tot_a += int(A.sum()); tot_b += int(B.sum()); d_all.append(A - B)
        per_seed.append(round((int(A.sum()) - int(B.sum())) / int(B.sum()), 4))
    d = np.concatenate(d_all).astype(float)
    zz = d.sum() / np.sqrt((d ** 2).sum()) if (d ** 2).sum() > 0 else 0.0
    return dict(a=tot_a, b=tot_b, rel=round((tot_a - tot_b) / tot_b, 5), z=round(float(zz), 2),
                p=1 - erf(abs(zz) / sqrt(2)), per_seed=per_seed)

out = {}
S2 = (1001, 1002, 1003); S1 = (901, 902, 903)
for scen, a, b in (('severe', 'sz_gated', 'sz'), ('mixed', 'sz_gated', 'sz'), ('mixed', 'sz_gated', 'sz_all'),
                   ('moderate', 'sz_gated', 'sz'), ('none', 'sz_gated', 'sz'), ('realistic', 'sz_gated', 'sz'),
                   ('severe', 'sz_gated', 'sz_all'), ('moderate', 'sz_gated', 'sz_all'), ('severe', 'sz', 'loc'),
                   ('severe', 'oracle_gated', 'oracle')):
    out[f'p2 {scen}: {a} vs {b}'] = stats('out7/test_', scen, S2, a, b)
for scen, a, b in (('t1d_severe', 'sz', 'loc'), ('t1m', 'sz', 'loc'), ('t1d', 'sz', 'loc'), ('t1m_severe', 'sz', 'loc'),
                   ('t1m_severe', 'twin', 'loc')):
    out[f'p1 {scen}: {a} vs {b}'] = stats('out7/p1_', scen, S1, a, b)
print(json.dumps(out, indent=1))
