"""Exact sampling of independent error sources with per-epoch, per-qubit rates (thinning)."""
import numpy as np
from scipy.sparse import csr_matrix
import pymatching


class Sampler:
    def __init__(self, m, rng):
        self.m, self.rng = m, rng
        self.O = m.src_obs.astype(np.int32)

    def sample(self, fq_ep, bpe):
        """fq_ep: (n_ep, G) per-qubit factors, constant within an epoch of `bpe` blocks.
        Returns detection events X (n_ep*bpe, nZ) uint8 and observable flips (n_ep*bpe,) uint8."""
        m, rng = self.m, self.rng
        n_ep = fq_ep.shape[0]; N = n_ep * bpe
        pk = np.clip(m.p_ref[None, :] * fq_ep[:, m.src_g], 0, 0.45).astype(np.float32)
        pmax = np.maximum(pk.max(0), 1e-12)
        c = rng.binomial(N, pmax)
        kk = np.repeat(np.arange(m.K), c)
        pos = rng.integers(0, N, size=kk.size)
        while True:                                  # distinct positions per source
            key = kk.astype(np.int64) * N + pos
            order = np.argsort(key, kind='stable')
            ks = key[order]
            dup = np.zeros(ks.size, bool); dup[1:] = ks[1:] == ks[:-1]
            if not dup.any():
                break
            idx = order[dup]
            pos[idx] = rng.integers(0, N, size=idx.size)
        acc = rng.random(kk.size) < pk[pos // bpe, kk] / pmax[kk]   # thinning to the epoch's rate
        kk, pos = kk[acc], pos[acc]
        A = csr_matrix((np.ones(kk.size, np.int32), (pos, kk)), shape=(N, m.K))
        X = A @ m.S
        X.data %= 2
        obs = (A @ self.O) % 2
        return X.toarray().astype(np.uint8), np.asarray(obs).ravel().astype(np.uint8)


def weights_from_p(p, wmin=0.05):
    p = np.clip(p, 1e-7, 0.45)
    return np.maximum(np.log((1 - p) / p), wmin)


def build_matching(m, w):
    mt = pymatching.Matching()
    mt.load_from_check_matrix(m.H, weights=w, faults_matrix=m.F, merge_strategy='smallest-weight',
                              use_virtual_boundary_node=True)
    return mt
