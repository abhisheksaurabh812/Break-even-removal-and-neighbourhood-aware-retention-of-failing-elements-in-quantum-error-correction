"""Post-hoc diagnostic (round 9, not pre-registered): the true noise field around a healthy qubit that the
field-aware gate switched out repeatedly after the second regional step.  Rebuilds the run's field (same seed,
same scenario code) at each logged switch-out of the qubit and prints its true factor, the median true
factor of its footprint neighbours (Chebyshev <= 2) and of the ring the gate uses (Chebyshev <= 4), next to
the gate's own numbers (level L, re-fitted factor, crossover).
python3 diag9_cycle.py <run.npz> <qubit> [max rows]"""
import sys, json
import numpy as np
from run3 import base_model
from run7 import make_scenario
from model import P_REF
import analyse8 as A

f, g = sys.argv[1], int(sys.argv[2]); mx = int(sys.argv[3]) if len(sys.argv) > 3 else 8
z = np.load(f, allow_pickle=True); cfg = json.loads(str(z['cfg'])); ev = json.loads(str(z['events']))
base = base_model(cfg['d'])
F, _, events = make_scenario(base, cfg, np.random.default_rng(cfg['seed']))
assert events['defects'] == ev['defects'] and events['steps'] == ev['steps'], 'scenario rebuild differs from the run'
r = A.load(f)
xy = base.qxy
cheb = np.abs(xy - xy[g][None, :]).max(1)
foot = [q for q in range(len(xy)) if q != g and cheb[q] <= 2]
ring = [q for q in range(len(xy)) if q != g and cheb[q] <= 4]
rows = []
for l in r['info']['sz_field']['policy_log']:
    if l[0] == 'out' and l[3] == g:
        e = l[1]; S = F[e].astype(float) / (cfg['p_base'] / P_REF)
        rows.append(dict(epoch=e, true_factor=round(S[g], 2), footprint_median=round(float(np.median(S[foot])), 2),
                         footprint_max=round(float(S[foot].max()), 2), ring_median_all_qubits=round(float(np.median(S[ring])), 2),
                         gate_level=l[6], gate_refit_factor=l[5], crossover=l[7]))
print(json.dumps(dict(run=f, qubit=g, switch_outs=len(rows), rows=rows[:mx]), indent=1))
