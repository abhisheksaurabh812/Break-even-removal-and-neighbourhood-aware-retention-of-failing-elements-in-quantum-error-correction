"""Round 7b analysis: rules R1-R5 (PREREG_round7b.md).  python3 analyse7b.py"""
import json
import numpy as np
from analyse7 import files, load, compare, beats, policy_checks, sizing


def main():
    res = {}
    for scen in ('severe', 'mixed', 'moderate', 'none', 'realistic'):
        fs = files('out7b/test_', scen)
        if not fs:
            continue
        runs = load(fs); names = runs[0]['names']
        tot = {n: sum(int(r['fails'][k].sum()) for r in runs) for k, n in enumerate(names)}
        R = dict(seeds=len(fs), totals=tot)
        for a, b in (('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz_all', 'sz'), ('sz', 'loc'), ('sz_gated', 'loc'),
                     ('oracle_gated', 'oracle'), ('oracle_all', 'oracle'), ('oracle_gated', 'oracle_all'),
                     ('oracle_gated', 'sz_gated')):
            R[f'{a} vs {b}'] = compare(runs, a, b)
        per_seed = {}
        for a, b in (('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz', 'loc'), ('sz_gated', 'loc')):
            per_seed[f'{a} vs {b}'] = [round((int(r['fails'][names.index(a)].sum()) - int(r['fails'][names.index(b)].sum())) /
                                             max(int(r['fails'][names.index(b)].sum()), 1), 4) for r in runs]
        R['per_seed'] = per_seed
        R['policy_sz_gated'] = policy_checks(runs, 'sz_gated')
        R['policy_sz_all'] = policy_checks(runs, 'sz_all')
        R['sizing_sz'] = sizing(runs, 'sz')
        R['handovers_sz'] = sum(r['info']['sz']['sized'].get('handovers', 0) or 0 for r in runs)
        res[scen] = R
    rules = {}
    if 'severe' in res: rules['R1_severe_gated_beats_sz_10pct'] = beats(res['severe']['sz_gated vs sz'], 0.10)
    if 'mixed' in res:
        rules['R2_mixed_gated_beats_sz_5pct'] = beats(res['mixed']['sz_gated vs sz'], 0.05)
        rules['R2_mixed_gated_beats_all_3pct'] = beats(res['mixed']['sz_gated vs sz_all'], 0.03)
    if 'moderate' in res: rules['R3_moderate_no_worse_1pct'] = bool(res['moderate']['sz_gated vs sz']['rel'] <= 0.01)
    if 'none' in res: rules['R4_none_no_worse_0.5pct'] = bool(res['none']['sz_gated vs sz']['rel'] <= 0.005)
    if 'realistic' in res:
        rules['R5_realistic_sz_no_worse_than_loc_1pct'] = bool(res['realistic']['sz vs loc']['rel'] <= 0.01)
        rules['R5_realistic_gated_no_worse_than_loc_1pct'] = bool(res['realistic']['sz_gated vs loc']['rel'] <= 0.01)
    res['rules'] = rules
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
