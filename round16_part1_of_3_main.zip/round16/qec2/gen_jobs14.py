"""Writes jobs14.txt (round 14): the 70 main runs, the 32 prior-art runs (first four seeds of each test), then the 70
lab-practice baseline runs.  Estimated seconds per job: round-13 run times on this machine and round-14 development
runs (dev14/prior/, scaled to full length), rounded up; a batch's budget check (elapsed + 1.3 x estimate < budget)
keeps every batch inside the 2-hour limit on background work."""
from analyse14 import SEEDS, PRIOR_SEEDS

est = dict(d9_hwlike=1200, d9_mixed=950, d9_severe=900, d9_moderate=850, d9_realistic=1400, pairs_mixed=750,
           long_severe=900, long_mixed=600)
est_prior = dict(d9_hwlike=1300, d9_mixed=600, d9_severe=600, d9_moderate=600, d9_realistic=1400, pairs_mixed=400,
                 long_severe=500, long_mixed=500)


def interleave(a, b):
    out = []
    for i in range(max(len(a), len(b))):
        out += ([a[i]] if i < len(a) else []) + ([b[i]] if i < len(b) else [])
    return out


L = lambda t: [(t, s) for s in SEEDS[t]]
order = interleave(L('long_severe'), L('long_mixed'))
order += interleave(L('d9_mixed'), L('d9_severe'))
order += interleave(L('d9_realistic'), L('pairs_mixed'))
order += interleave(L('d9_hwlike'), L('d9_moderate'))
assert len(order) == 70 and len(set(order)) == 70
prior = [(t, s) for t, s in order if s in PRIOR_SEEDS[t]]
assert len(prior) == 32
with open('jobs14.txt', 'w') as f:
    for t, s in order:
        n = f'{t}_s{s}'
        f.write(f'{n} {est[t]} - python3 run14.py cfg14/{t}.json out14/{n}.npz seed={s} > out14/{n}.json\n')
    # prior art (detect and quarantine), first four seeds of each test
    for t, s in prior:
        n = f'prior_{t}_s{s}'
        f.write(f'{n} {est_prior[t]} - python3 run14.py cfg14/prior_{t}.json out14/{n}.npz seed={s} > out14/{n}.json\n')
    # lab-practice baselines after every main run (same seeds; reported, no rule)
    for t, s in order:
        n = f'base_{t}_s{s}'
        f.write(f'{n} {int(0.15 * est[t])} - python3 run14.py cfg14/base_{t}.json out14/{n}.npz seed={s} > out14/{n}.json\n')
tot = sum(est[t] for t, _ in order) + sum(est_prior[t] for t, _ in prior) + sum(0.15 * est[t] for t, _ in order)
print(70 + 32 + 70, 'jobs; total estimate', round(tot / 3600, 1), 'h of CPU,', round(tot / 7200, 1), 'h on two workers')
