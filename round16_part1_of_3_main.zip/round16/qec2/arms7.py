"""
Round 7 arms: likelihood sizing of a named faulty qubit, and response policies (reweight or switch out).

Sized(Slow)
    Naming is exactly the round-3 localizer (per-ancilla CUSUM, footprint test, pair-based naming).
    What changes is the size estimate.  Instead of the localizer's straight-line rate ratio, the named
    qubit's error factor r is fitted by maximum likelihood to the interior detection-event counts of
    the Z ancillas in the qubit's footprint, with the exact parity formula
        q_u(r) = (1 - prod_k (1 - 2 p_k(r))) / 2      over every error source k touching detector u,
    where the named qubit's sources are scaled by r (capped at 0.45, as in the model), other qubits'
    sources sit at calibration, or at their own fitted factor when they are being handled too.  The
    first fit uses the evidence the localizer collected; afterwards the fit is refreshed every epoch
    on a sliding window (W epochs).  The qubit's decoder edges are recomposed exactly at the fitted r
    from their values frozen at the naming (so the slow estimator's partial absorption of the change
    is not counted twice) and restored when the window fit falls below r_off.

PolicyArm
    Wraps a Sized learner and decides, for excludable qubits (bulk data qubits, bulk Z ancillas), when
    to switch a named qubit out of the circuit:
      mode 'gated' : when its fitted factor reaches the keep/exclude crossover THETA (data 13, Z 7);
      mode 'all'   : as soon as it is named with a fitted factor >= r_on (remove-every-flagged).
    Re-inclusion: 'probe' - while a qubit is out it can be characterised directly (it is no longer
    part of the code); every `period` epochs a probe returns its true current factor times a
    log-normal error (sigma), and the qubit is switched back in when the probe falls below
    THETA / 1.5 (gated) or 1.5 (all), with the probe value as its starting size.  'timer' - switched
    back in after t_rein rounds with its entries reset (round-4 rule).
OraclePolicy
    True rates and true defects; switches out excludable defective qubits whose true factor reaches
    THETA ('gated', the round-4 oracle-excl) or any active defect ('all'); at most two compatible.
"""
from collections import deque
import numpy as np
from arms import Slow, WMIN
from sampler import weights_from_p
import deform

THETA = {'data': 13.0, 'zanc': 7.0}
CAP = 0.45
QS = np.log(2) / 8


def qround(r):
    return float(np.exp(np.round(np.log(max(r, 1e-9)) / QS) * QS))


class Sized(Slow):
    kind = 'sized'

    def __init__(self, name, m, cal, R, cusum, gating, reseed, tmax, footprint, sizer):
        super().__init__(name, m, cal, R, 1, cusum, gating, reseed, tmax, footprint)
        self.sz = sizer
        self.W = int(sizer.get('W', 50)); self.Wmin = int(sizer.get('Wmin', 10))
        self.r_on = float(sizer.get('r_on', 1.25)); self.r_off = float(sizer.get('r_off', 1.25))
        self.rmax = float(sizer.get('rmax', 400.0))
        self.grid = np.exp(np.linspace(0.0, np.log(self.rmax), 241))
        f0 = self.f0
        self.pcal = np.clip(m.p_ref * f0[m.src_g], 0, CAP)
        self.lcal = np.log1p(-2 * self.pcal)
        dx = cal.get('det_extra')
        self.lx = np.log1p(-2 * np.asarray(dx, float)) if dx is not None else np.zeros(m.nZ)
        Dm = m.S.T.tocsr()                                   # detector -> sources
        self.Dm = Dm
        self.Lcal = np.asarray(Dm @ self.lcal).ravel() + self.lx
        self.Ce = m.C.tocsr()                                # edge -> sources
        self.int_dets = [np.nonzero((m.danc == b) & (m.dcls == 1))[0] for b in range(m.nA)]
        self.nint = np.array([len(x) for x in self.int_dets], float)
        self.struct = {}
        self.sovr = {}
        self.frozen = np.zeros(m.E, bool); self.fval = np.zeros(m.E); self.fref = np.zeros(m.E, int)
        self.ep_i = 0
        self.slog = []; self.n_on = 0; self.n_rej = 0

    # ------------------------------------------------------------ structure of one qubit
    def _st(self, g):
        s = self.struct.get(g)
        if s is not None:
            return s
        m = self.m
        W = m.fp_W[g]; tot = W.sum()
        anc = [int(b) for b in np.nonzero(W >= 0.01 * tot)[0]] if tot > 0 else []
        kg = np.nonzero(m.src_g == g)[0]
        isg = np.zeros(m.K, bool); isg[kg] = True
        dets, didx, pk = [], [], []
        for j, b in enumerate(anc):
            for u in self.int_dets[b]:
                ks = self.Dm.indices[self.Dm.indptr[u]:self.Dm.indptr[u + 1]]
                ks = ks[isg[ks]]
                dets.append(int(u)); didx.append(j); pk.append(self.pcal[ks])
        # r-dependent log-product of g's sources on each detector, on the grid
        Rg = np.zeros((len(dets), len(self.grid)))
        base = np.zeros(len(dets))
        for i, (u, p) in enumerate(zip(dets, pk)):
            if len(p):
                Rg[i] = np.log1p(-2 * np.minimum(CAP, p[:, None] * self.grid[None, :])).sum(0)
                base[i] = self.Lcal[u] - np.log1p(-2 * p).sum()
            else:
                base[i] = self.Lcal[u]
        umap = {u: i for i, u in enumerate(dets)}
        # edges carrying g's sources
        Cc = m.C.tocsc()
        ecols = {}
        for k in kg:
            for e in Cc.indices[Cc.indptr[k]:Cc.indptr[k + 1]]:
                ecols.setdefault(int(e), []).append(self.pcal[k])
        edges = np.array(sorted(ecols), int)
        epk = [np.array(ecols[e]) for e in edges]
        s = dict(anc=np.array(anc, int), dets=np.array(dets, int), didx=np.array(didx, int), pk=pk, Rg=Rg,
                 base=base, umap=umap, edges=edges, epk=epk)
        self.struct[g] = s
        return s

    def _others(self, g, s):
        """Log-product correction on g's detectors from other qubits currently handled at r != 1."""
        corr = np.zeros(len(s['dets']))
        for g2, o in self.sovr.items():
            if g2 == g or o['susp']:
                continue
            s2 = self._st(g2)
            common = [u for u in s2['umap'] if u in s['umap']]
            for u in common:
                p = s2['pk'][s2['umap'][u]]
                if len(p):
                    corr[s['umap'][u]] += (np.log1p(-2 * np.minimum(CAP, p * o['r'])) - np.log1p(-2 * p)).sum()
        return corr

    def fit(self, g, n, N):
        """Maximum-likelihood factor of qubit g from per-ancilla interior counts n and trials N (length nA)."""
        s = self._st(g)
        if not len(s['dets']):
            return 1.0
        L = s['base'][:, None] + s['Rg'] + self._others(g, s)[:, None]
        q = 0.5 * (1 - np.exp(L))                                  # (dets, grid)
        nb = len(s['anc'])
        qb = np.zeros((nb, len(self.grid)))
        np.add.at(qb, s['didx'], q)
        cnt = np.bincount(s['didx'], minlength=nb).astype(float)
        qb /= np.maximum(cnt, 1)[:, None]
        qb = np.clip(qb, 1e-12, 1 - 1e-12)
        nn = n[s['anc']]; NN = N[s['anc']]
        ok = NN > 0
        if not ok.any():
            return 1.0
        ll = (nn[ok, None] * np.log(qb[ok]) + (NN[ok] - nn[ok])[:, None] * np.log1p(-qb[ok])).sum(0)
        return float(self.grid[int(np.argmax(ll))])

    # ------------------------------------------------------------ override bookkeeping
    def _freeze(self, g):
        e = self._st(g)['edges']
        new = e[~self.frozen[e]]
        self.fval[new] = self.p[new]; self.frozen[new] = True
        self.fref[e] += 1

    def _unfreeze(self, g):
        e = self._st(g)['edges']
        self.fref[e] -= 1
        done = e[self.fref[e] == 0]
        self.p[done] = self.fval[done]; self.frozen[done] = False

    def _activate(self, g, r, n0, N0, how):
        self._freeze(g)
        self.sovr[g] = dict(r=qround(r), win=deque(maxlen=self.W), init=(n0, N0), start=self.ep_i, susp=False)
        self.n_on += 1
        self.slog.append(['on', self.ep_i, int(g), round(r, 2), how])

    def deactivate(self, g, why):
        o = self.sovr.pop(g, None)
        if o is None:
            return
        self._unfreeze(g)
        self.slog.append(['off', self.ep_i, int(g), why])

    def suspend(self, g):
        if g in self.sovr:
            self.sovr[g]['susp'] = True
            self.slog.append(['susp', self.ep_i, int(g)])

    def resume(self, g, r):
        o = self.sovr.get(g)
        if o is None:
            return
        if r < self.r_off:
            self.deactivate(g, 'resume_quiet')
            return
        o.update(r=qround(r), win=deque(maxlen=self.W), init=None, start=self.ep_i, susp=False)
        self.slog.append(['resume', self.ep_i, int(g), round(r, 2)])

    def reset_local(self, g):
        """Forget the localizer's alarms and collected evidence on the ancillas in qubit g's footprint
        (and provisional regional evidence there).  Used when the circuit around g changes (switched
        out or back in), so evidence gathered before the change is not reused afterwards."""
        if not getattr(self, 'ac', None):
            return
        m = self.m
        core = self._st(g)['anc']
        for b in core:
            self.aS[b] = 0; self.aal[b] = 0; self.ahold[b] = 0; self.alen_a[b] = 0
            self.abr[b] = float(self.ac['rho']); self.astate[b] = 0
            self.aacc[b] = 0; self.aE[b] = 0
            self.astats.pop(int(b), None); self.ovr.pop(('anc', int(b)), None)
        for reg in set(int(m.anc_reg[b]) for b in core):
            if self.fstate[reg] == 1:
                self.nacc[reg] = 0; self.Eacc[reg] = 0
        self.slog.append(['reset', self.ep_i, int(g), len(core)])

    def _convert(self):
        """Turn the localizer's new straight-line overrides into likelihood-sized ones."""
        m = self.m
        qb = np.maximum(self.q[m.anc_int_class], 1e-9)
        for key in list(self.ovr):
            o = self.ovr.pop(key)
            g = int(o['q'])
            if g in self.sovr:
                continue
            if key[0] == 'anc':
                n0 = self.aacc[key[1]].copy(); E0 = self.aE[key[1]].copy()
            else:
                n0 = self.nacc[key[1]].copy(); E0 = self.Eacc[key[1]].copy()
            N0 = E0 / qb
            r = self.fit(g, n0, N0)
            if r >= self.r_on:
                self._activate(g, r, n0, N0, key[0])
            else:
                self.n_rej += 1
                self.slog.append(['reject', self.ep_i, g, round(r, 2), round(float(o['r']), 2)])

    # ------------------------------------------------------------ learner
    def update(self, X, crr, mask=None):
        super().update(X, crr, mask)
        self.ep_i += 1
        self._convert()
        if not self.sovr:
            return
        m = self.m
        n = (X.astype(np.float32) @ m.A_int).sum(0).astype(float)
        N = X.shape[0] * self.nint
        if mask is not None:
            off = mask['anc_off']
            n = np.where(off, 0.0, n); N = np.where(off, 0.0, N)
        for g in list(self.sovr):
            o = self.sovr[g]
            if o['susp']:
                continue
            o['win'].append((n, N))
            nn = np.sum([w[0] for w in o['win']], 0); NN = np.sum([w[1] for w in o['win']], 0)
            if len(o['win']) < self.Wmin and o['init'] is not None:
                nn = nn + o['init'][0]; NN = NN + o['init'][1]
            r = self.fit(g, nn, NN)
            if len(o['win']) >= self.Wmin and r < self.r_off:
                self.deactivate(g, 'quiet')
                continue
            if abs(np.log(max(r, 1e-9)) - np.log(o['r'])) >= 1.5 * QS:
                o['r'] = qround(r)

    def weights(self, true_pe):
        m = self.m
        p = np.where(self.frozen, self.fval, self.p)
        if self.fp and self.ovr:                      # (normally empty: converted in update)
            fac = np.ones_like(p)
            for o in self.ovr.values():
                if o['q'] not in self.sovr:
                    fac *= 1 + o['u'] * (o['r'] - 1)
            p = p * fac
        if self.sovr:
            led = np.zeros(m.E)
            for g, o in self.sovr.items():
                if o['susp']:
                    continue
                s = self._st(g); r = o['r']
                for e, pk in zip(s['edges'], s['epk']):
                    led[e] += (np.log1p(-2 * np.minimum(CAP, pk * r)) - np.log1p(-2 * pk)).sum()
            sel = led != 0
            p[sel] = 0.5 * (1 - (1 - 2 * np.clip(p[sel], 0, 0.499)) * np.exp(led[sel]))
        p = np.clip(p, 1e-7, CAP)
        w = weights_from_p(p, WMIN)
        if self.cusum:
            off = self.off
            if self.fp and self.nooff:
                off = np.where(self.fstate == 3, 0.0, off)
            w = np.maximum(w - off[m.ereg], WMIN)
        return w

    def info(self):
        d = super().info()
        d['sized'] = dict(activations=self.n_on, rejected=self.n_rej, log=self.slog[:20000])
        return d


class PolicyArm:
    kind = 'policy'

    def __init__(self, name, base, inner, mode, cal, probe=None, t_rein=None, seed=0, theta=None):
        self.name, self.base, self.inner, self.mode, self.cal = name, base, inner, mode, cal
        self.probe = probe; self.t_rein = t_rein
        self.theta = dict(theta) if theta else dict(THETA)
        self.rng = np.random.default_rng(seed)
        self.cur = {}; self.rounds = 0; self.log = []

    def config(self):
        return tuple(sorted(self.cur))

    def weights(self, md, true_pe):
        w_base = self.inner.weights(true_pe)
        if md is None:
            return w_base
        w = weights_from_p(md.edge_p(self.cal['f0']), WMIN)
        ok = md.emap >= 0
        w[ok] = w_base[md.emap[ok]]
        return w

    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        if md is None:
            self.inner.update(X, crr)
        else:
            Xo = to_base(X, md, self.base)
            crr_o = (Xo.astype(np.float32) @ base_AggD).reshape(-1, 4).astype(np.float64)
            self.inner.update(Xo, crr_o, md.mask)
        self.rounds += X.shape[0] * T
        inn = self.inner
        # switch out
        for g, o in sorted(inn.sovr.items(), key=lambda kv: -kv[1]['r']):
            if o['susp'] or o.get('cool', 0) > 0 or g not in self.base.excludable:
                continue
            kind, c = self.base.excludable[g]
            thr = self.theta[kind] if self.mode == 'gated' else inn.r_on
            if o['r'] < thr or c in self.cur or len(self.cur) >= 2 or not deform.compatible(list(self.cur) + [c], self.base.d):
                continue
            self.cur[c] = dict(g=g, kind=kind, start=self.rounds, next=epoch + (self.probe or {}).get('period', 0))
            inn.suspend(g)
            inn.reset_local(g)
            self.log.append(['out', epoch, list(c), int(g), round(o['r'], 2)])
        # switch back in
        for c in list(self.cur):
            st = self.cur[c]; g = st['g']
            if self.probe:
                if epoch < st['next']:
                    continue
                r_true = float(ftrue[g] / self.cal['f0'][g])
                rp = r_true * float(np.exp(self.probe['sigma'] * self.rng.standard_normal()))
                thr_in = self.theta[st['kind']] / 1.5 if self.mode == 'gated' else 1.5
                if rp < thr_in:
                    del self.cur[c]
                    inn.reset_local(g)
                    inn.resume(g, rp)
                    self.log.append(['in', epoch, list(c), int(g), round(rp, 2), round(r_true, 2)])
                else:
                    st['next'] = epoch + self.probe['period']
                    self.log.append(['probe', epoch, list(c), int(g), round(rp, 2), round(r_true, 2)])
            elif self.rounds - st['start'] >= self.t_rein:
                del self.cur[c]
                inn.reset_local(g)
                inn.deactivate(g, 'timer')
                self.log.append(['in', epoch, list(c), int(g), None, round(float(ftrue[g] / self.cal['f0'][g]), 2)])

    def info(self):
        d = self.inner.info(); d['policy_log'] = self.log[:20000]
        return d


class OraclePolicy:
    kind = 'oracle-policy'

    def __init__(self, name, base, events, er, mode, theta=None):
        self.name, self.base, self.mode = name, base, mode
        self.theta = dict(theta) if theta else dict(THETA)
        self.D = events['defects']; self.er = er; self.cur = (); self.log = []

    def plan(self, e):
        t = (e + 0.5) * self.er
        act = sorted([d for d in self.D if d[0] <= t < d[0] + d[1]], key=lambda d: -d[3])
        chosen = []
        for d in act:
            g = d[2]
            if g in self.base.excludable:
                kind, c = self.base.excludable[g]
                thr = self.theta[kind] if self.mode == 'gated' else 1.5
                if d[3] >= thr and c not in chosen and len(chosen) < 2 and deform.compatible(chosen + [c], self.base.d):
                    chosen.append(c)
        new = tuple(sorted(chosen))
        if new != self.cur:
            self.log.append([e, list(map(list, new))])
        self.cur = new
        return new

    def info(self):
        return dict(changes=len(self.log), log=self.log[:5000])
