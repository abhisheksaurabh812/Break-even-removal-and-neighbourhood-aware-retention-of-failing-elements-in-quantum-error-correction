"""Round 11 analysis (rules in PREREG_round11.md).   python3 analyse11.py > out11/res_11.json
A rule is evaluated only when every seed of its test has finished (done marker in out11/done/)."""
import json, os
import numpy as np
import analyse8 as A
from analyse9 import split_by_switchout

FIX = 'sz_watch'
SEEDS = dict(d9_mixed=range(7101, 7111), d9_severe=range(7201, 7206), d9_moderate=range(7301, 7306),
             d9_realistic=range(7001, 7011), pairs_mixed=range(7401, 7411))


def done(n):
    return os.path.exists(f'out11/done/{n}')


def runs(test):
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        out.append(A.load(f'out11/{n}.npz'))
    return out


PAIRS = ((FIX, 'loc'), (FIX, 'sz'), (FIX, 'sz_all'), (FIX, 'sz_field'), (FIX, 'sz_gated'),
         ('sz_field', 'loc'), ('sz_field', 'sz'), ('sz_field', 'sz_all'), ('sz_field', 'sz_gated'),
         ('sz_gated', 'loc'), ('sz_gated', 'sz'), ('oracle_gated', 'oracle'))


def watch_summary(rs):
    n = 0
    for r in rs:
        n += sum(1 for l in r['info'][FIX].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch')
    return dict(watch_returns=n)


def main():
    res = {}; rules = {}
    for test in SEEDS:
        rs = runs(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        for arm in (FIX, 'sz_field'):
            pc = A.policy_checks(rs, arm)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{arm}'] = pc
            R[f'split_{arm}_vs_sz'] = split_by_switchout(rs, arm, 'sz')
        R['watch'] = watch_summary(rs)
        res[test] = R
    c = lambda t, k: res[t][k]
    if 'd9_mixed' in res:
        rules['W1_mixed_fix_beats_sz_5pct'] = A.beats(c('d9_mixed', f'{FIX} vs sz'), 0.05)
        rules['W1_mixed_fix_beats_all_3pct'] = A.beats(c('d9_mixed', f'{FIX} vs sz_all'), 0.03)
    if 'd9_severe' in res:
        rules['W2_severe_fix_beats_sz_10pct'] = A.beats(c('d9_severe', f'{FIX} vs sz'), 0.10)
    if 'd9_moderate' in res:
        rules['W3_moderate_fix_vs_sz_within_1pct'] = bool(c('d9_moderate', f'{FIX} vs sz')['rel'] <= 0.01)
    if 'd9_realistic' in res:
        x = c('d9_realistic', f'{FIX} vs loc')
        rules['W4_realistic_fix_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'pairs_mixed' in res:
        rules['W5_pairs_fix_vs_sz_within_1pct'] = bool(c('pairs_mixed', f'{FIX} vs sz')['rel'] <= 0.01)
    if all(t in res for t in ('d9_mixed', 'd9_severe', 'pairs_mixed')):
        rs = runs('d9_mixed') + runs('d9_severe') + runs('pairs_mixed')
        x = A.compare(rs, FIX, 'sz_field')
        res['W6_pooled_mixed_severe_pairs'] = dict(x, boot95=A.bootstrap(rs, FIX, 'sz_field'))
        rules['W6_fix_fewer_failures_than_field_gate_pooled'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
