"""Post-hoc (not pre-registered): while a gate keeps one qubit switched out for a long time, does its decoding of the
reshaped patch get worse over time?  For every switch-out interval of the gate (>= min_rounds) that the oracle-gated
arm also has (same qubit, overlapping), compare gate - oracle_gated failures in successive slices of the interval
(both arms switched out there; samples independent).  Also gate - sz.
   python3 diag12_holedrift.py <npz> <gate> [min_rounds=1e6] [slice_rounds=5e5]"""
import sys
import numpy as np
import analyse8 as A

f, gate = sys.argv[1], sys.argv[2]
minr = float(sys.argv[3]) if len(sys.argv) > 3 else 1e6
sl = float(sys.argv[4]) if len(sys.argv) > 4 else 5e5
r = A.load(f); er = r['cfg']['bpe'] * r['cfg']['d']
names = r['names']
F = {a: A.per_epoch(r, a) for a in (gate, 'oracle_gated', 'sz') if a in names}
n = len(F['sz']); T = n * er
iv = [(int(g), x, T if y is None else y) for g, x, y, _ in A.out_intervals(r['info'][gate].get('policy_log', []), er)]
for g, x, y in iv:
    if y - x < minr:
        continue
    fac = [round(float(fc), 1) for t0, d, q, fc in r['defects'] if int(q) == g and t0 < y and t0 + d > x]
    rows = []
    t = x
    while t < y:
        e0, e1 = int(t // er), min(int(min(t + sl, y) // er), n)
        w = {a: int(F[a][e0:e1].sum()) for a in F}
        rows.append((round(t / 1e6, 2), w[gate] - w['oracle_gated'], w[gate] - w['sz'], w['sz']))
        t += sl
    print(f'{f.split("/")[-1]} {gate} q{g} {fac} out {x/1e6:.2f}-{y/1e6:.2f}M  slices (start M, gate-oracle_gated, gate-sz, sz):', rows)
