"""Round 13: compare analyse13.py's numbers (out13/res_13.json) with the independent recount
(out13/recount13.json) and re-derive every verdict from the recount alone.   python3 check13.py > out13/check13.json"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out13/res_13.json'))
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out13/recount13.json'))
mism = []; n = 0
for key, c in C.items():
    if c is None:
        continue
    test, pair = key.split(': ')
    a = R[key] if test.startswith('C') else R[test][pair]
    for name, x, y in (('fails', a['fails'], c['a']), ('ref_fails', a['ref_fails'], c['b']), ('rel', a['rel'], c['rel']),
                       ('z', a['z'], c['z']), ('per_seed', a['per_seed'], c['per_seed']),
                       ('boot_lo', a['boot95']['lo'], c['boot95'][0]), ('boot_hi', a['boot95']['hi'], c['boot95'][1])):
        n += 1
        if x != y:
            mism.append(dict(key=key, field=name, analyse=x, recount=y))


def beats(c, pct):
    return c['rel'] <= -pct and c['p'] < 0.01 and c['z'] < 0 and max(c['per_seed']) <= 0.01


g_ = lambda k: C.get(k)
v = {}
for g in ('sz_w13',):
    k = lambda t, ref: g_(f'{t}: {g} vs {ref}')
    if k('d9_mixed', 'sz') and k('d9_mixed', 'sz_all'):
        v[f'R1_{g}_mixed_beats_sz_5pct'] = beats(k('d9_mixed', 'sz'), 0.05)
        v[f'R1_{g}_mixed_beats_all_3pct'] = beats(k('d9_mixed', 'sz_all'), 0.03)
    if k('d9_severe', 'sz'):
        v[f'R2_{g}_severe_beats_sz_10pct'] = beats(k('d9_severe', 'sz'), 0.10)
    if k('d9_moderate', 'sz'):
        v[f'R3_{g}_moderate_vs_sz_within_1pct'] = k('d9_moderate', 'sz')['rel'] <= 0.01
    if k('d9_realistic', 'loc'):
        x = k('d9_realistic', 'loc')
        v[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = x['rel'] <= 0.01 and x['boot95'][1] <= 0.02
    if k('pairs_mixed', 'sz'):
        v[f'R5_{g}_pairs_vs_sz_within_1pct'] = k('pairs_mixed', 'sz')['rel'] <= 0.01
    if k('long_severe', 'sz'):
        v[f'R6_{g}_long_severe_beats_sz_10pct'] = beats(k('long_severe', 'sz'), 0.10)
    if k('long_mixed', 'sz') and k('long_mixed', 'sz_all'):
        v[f'R7_{g}_long_mixed_beats_sz_5pct'] = beats(k('long_mixed', 'sz'), 0.05)
        v[f'R7_{g}_long_mixed_beats_all_3pct'] = beats(k('long_mixed', 'sz_all'), 0.03)
    if k('d9_hwlike', 'sz'):
        v[f'R8_{g}_hwlike_beats_sz_10pct'] = beats(k('d9_hwlike', 'sz'), 0.10)
c = g_('C1_pooled: sz_w13 vs sz_w12r')
if c:
    v['C1_sz_w13_fewer_failures_than_sz_w12r_pooled'] = c['rel'] < 0 and c['z'] < 0 and c['p'] < 0.01
c = g_('d9_hwlike: sz_w13 vs sz_w12r')
if c:
    v['C2_sz_w13_hwlike_vs_sz_w12r_within_1pct'] = c['rel'] <= 0.01
c = g_('C3_pooled: sz_w13 vs sz_w12r (long)')
if c:
    v['C3_sz_w13_fewer_failures_than_sz_w12r_long_pooled'] = c['rel'] < 0 and c['z'] < 0 and c['p'] < 0.01
ra = R.get('rules', {})
print(json.dumps(dict(values_compared=n, mismatches=mism, recount_verdicts=v, analyse_verdicts=ra,
                      verdicts_agree={k: v[k] == ra.get(k) for k in v}), indent=1))
