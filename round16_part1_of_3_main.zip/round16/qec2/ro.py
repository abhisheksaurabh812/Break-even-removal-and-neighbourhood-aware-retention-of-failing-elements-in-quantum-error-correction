"""
Analog readout layer for the d = 7 Z-memory simulation (round 6: twin with analog readouts).

Every ancilla (24 Z, 24 X) is read out once per round.  The readout of an ancilla in state s gives
an integrated analog value x (units of the noise sigma):
    s = 0, or s = 1 without decay:  x ~ N(+-snr, 1)
    s = 1 that decays during the readout window (prob q = 1 - exp(-kappa), kappa = t_ro / T1):
        decay at fraction u of the window (truncated exponential), integrated mean snr * (2u - 1)
The reported bit is x > 0; a readout error (bit != s) flips the outcome, i.e. the two detectors
D(a, r) and D(a, r + 1) of a Z ancilla (X-ancilla readout errors do not touch Z detectors).
The stabiliser value s is taken as uniformly random (long runs with Pauli-frame tracking).

These readout errors come on top of the existing circuit-level model, whose before-measure and
after-reset flips are read as state flips that the analog signal cannot see.

The twin sees, per ancilla and epoch, a histogram of |x| (NB bins of width XW, last bin open).
"""
import numpy as np
from scipy.special import ndtr

NB, XW = 64, 0.1
EDGES = np.arange(NB + 1) * XW
SNR0 = 3.2                 # typical baseline separation / sigma
KAP0 = 0.5 / 70.0          # t_ro / T1 for a 0.5 us readout and T1 = 70 us
SNR_HET = 0.06             # per-ancilla log-normal spread of the baseline separation


def _u_nodes(n=48):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * (x + 1), 0.5 * w


_UN, _UW = _u_nodes()


def u_density(kap):
    """Density on [0, 1] of the decay time fraction for rate kap (truncated exponential); kap -> 0 gives uniform."""
    kap = np.asarray(kap, float)[..., None]
    small = kap < 1e-6
    k = np.where(small, 1.0, kap)
    dens = np.where(small, 1.0, k * np.exp(-k * _UN) / -np.expm1(-k))
    return dens


def p_err(snr, kap):
    """Exact readout error probability (truncated-exponential decay time)."""
    snr = np.asarray(snr, float); kap = np.asarray(kap, float)
    q = -np.expm1(-kap)
    dens = u_density(kap)
    e_dec = (ndtr(-snr[..., None] * (2 * _UN - 1)) * dens * _UW).sum(-1)
    return ndtr(-snr) * (1 - q / 2) + (q / 2) * e_dec


def _fold_bins(mu):
    """Bin probabilities of |x| for x ~ N(mu, 1), mu >= 0 (array of mu -> (..., NB))."""
    mu = np.asarray(mu, float)[..., None]
    a = EDGES[:-1]; b = EDGES[1:].copy(); b[-1] = np.inf
    pos = ndtr(b - mu) - ndtr(a - mu)
    neg = ndtr(-a - mu) - ndtr(-b - mu)
    return pos + neg


def bin_probs(snr, q, kap=None):
    """|x| bin probabilities.  kap=None: uniform decay time (the twin's working model);
    otherwise the truncated-exponential density for that kap."""
    snr = np.asarray(snr, float); q = np.asarray(q, float)
    nd = _fold_bins(snr)
    if kap is None:
        dens = np.ones(np.shape(snr) + (len(_UN),))
    else:
        dens = u_density(np.broadcast_to(kap, np.shape(snr)))
    mm = np.abs(snr[..., None] * (2 * _UN - 1))                     # decayed means, folded
    fb = _fold_bins(mm)                                              # (..., nu, NB)
    dec = (fb * (dens * _UW)[..., None]).sum(-2)
    return (1 - q[..., None] / 2) * nd + (q[..., None] / 2) * dec


class Grid:
    """Maximum-likelihood fit of (snr, q) to an |x| histogram on a fixed grid.  The twin's model is the
    physical one above (two unknowns per ancilla: separation snr and decay probability q)."""
    def __init__(self):
        self.snr = np.round(np.arange(0.2, 4.6001, 0.01), 4)
        self.q = np.concatenate([[0.0], np.geomspace(1e-4, 0.9, 160)])
        kap = -np.log1p(-self.q)
        nd = _fold_bins(self.snr)                                        # (nS, NB)
        fb = _fold_bins(np.abs(self.snr[:, None] * (2 * _UN - 1)))       # (nS, nu, NB)
        dens = u_density(kap) * _UW                                      # (nQ, nu)
        dec = np.einsum('sub,qu->sqb', fb, dens)                         # (nS, nQ, NB)
        P = (1 - self.q[None, :, None] / 2) * nd[:, None, :] + (self.q[None, :, None] / 2) * dec
        S, Q = np.meshgrid(self.snr, self.q, indexing='ij')
        self.L = np.log(np.maximum(P.reshape(-1, NB), 1e-300)).astype(np.float32)
        self.S, self.Q = S.ravel(), Q.ravel()

    def fit(self, h):
        ll = self.L @ np.asarray(h, np.float32)
        i = int(np.argmax(ll))
        return float(self.S[i]), float(self.Q[i])

    def index(self, snr0, q0):
        return int(np.argmin(np.abs(self.snr - snr0))), int(np.argmin(np.abs(self.q - q0)))

    def fit_sel(self, h, i0, j0, tau=4.0):
        """Model selection between no change, separation only, decay only and both (penalty tau per
        freed parameter, natural-log likelihood units).  Returns (snr, q, model) with model in
        {0: none, 1: separation, 2: decay, 3: both}."""
        ll = (self.L @ np.asarray(h, np.float32)).reshape(len(self.snr), len(self.q)).astype(np.float64)
        cand = [(ll[i0, j0], i0, j0, 0)]
        i1 = int(np.argmax(ll[:, j0])); cand.append((ll[i1, j0] - tau, i1, j0, 1))
        j2 = int(np.argmax(ll[i0, :])); cand.append((ll[i0, j2] - tau, i0, j2, 2))
        k = int(np.argmax(ll)); i3, j3 = divmod(k, len(self.q)); cand.append((ll[i3, j3] - 2 * tau, i3, j3, 3))
        best = max(cand, key=lambda c: c[0])
        return float(self.snr[best[1]]), float(self.q[best[2]]), best[3]


_GRID = None


def grid():
    global _GRID
    if _GRID is None:
        _GRID = Grid()
    return _GRID


def p_err_model(snr, q):
    """Readout error implied by a fitted (snr, q)."""
    q = np.asarray(q, float)
    return p_err(snr, -np.log1p(-np.minimum(q, 0.999)))


def sample(rng, snr, kap, bpe, T, nZ_anc):
    """snr, kap: (n_ep, nAnc).  Returns flips (n_ep*bpe, nZ_anc, T) uint8 for the Z ancillas and
    |x| histograms (n_ep, nAnc, NB) int32."""
    n_ep, nA = snr.shape
    shp = (n_ep, bpe * T, nA)
    s = rng.random(shp) < 0.5
    q = -np.expm1(-kap)[:, None, :]
    dec = s & (rng.random(shp) < q)
    mean = np.where(s, 1.0, -1.0) * snr[:, None, :]
    nd = int(dec.sum())
    if nd:
        kd = np.broadcast_to(kap[:, None, :], shp)[dec]
        U = rng.random(nd)
        small = kd < 1e-6
        u = np.where(small, U, -np.log1p(-U * -np.expm1(-np.where(small, 1.0, kd))) / np.where(small, 1.0, kd))
        mean[dec] = np.broadcast_to(snr[:, None, :], shp)[dec] * (2 * u - 1)
    x = mean + rng.standard_normal(shp)
    err = ((x > 0) != s)
    flips = err[:, :, :nZ_anc].reshape(n_ep, bpe, T, nZ_anc).transpose(0, 1, 3, 2).reshape(n_ep * bpe, nZ_anc, T)
    bi = np.minimum((np.abs(x) / XW).astype(np.int32), NB - 1)
    idx = (np.arange(n_ep)[:, None, None] * nA + np.arange(nA)[None, None, :]) * NB + bi
    hist = np.bincount(idx.ravel(), minlength=n_ep * nA * NB).reshape(n_ep, nA, NB).astype(np.int32)
    return flips.astype(np.uint8), hist
