"""Post-hoc (not pre-registered): for one round-12 run, attribute the difference between two arms to the failures
active at the time.   python3 diag12_seed.py <test> <seed> <armA> <armB> [arm ...]
For each failure on any qubit: its true factor (x nominal) and kind, the fraction of it during which each listed gate
had the qubit switched out, the delay to the first switch-out of that qubit inside the failure, and armA - armB logical
failures over the epochs it spans; plus the difference outside every failure window, and the watch returns of each gate."""
import sys, json
import numpy as np
import analyse8 as A

test, seed, a, b = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
show = sys.argv[5:] or ['sz_field', 'sz_watch', 'sz_w12', 'sz_w12r']
r = A.load(f'out12/{test}_s{seed}.npz')
cfg = r['cfg']; d = cfg['d']; er = cfg['bpe'] * d
_, EX = A.roles(d)
fa, fb = A.per_epoch(r, a), A.per_epoch(r, b)
tot = len(fa) * er
iv = {arm: A.out_intervals(r['info'][arm].get('policy_log', []), er) for arm in show}


def cover(arm, q, t0, t1):
    c = 0.0; first = None
    for g, x, y, _ in iv[arm]:
        if g == q:
            y = tot if y is None else y
            ov = max(0.0, min(y, t1) - max(x, t0))
            c += ov
            if ov > 0:
                st = max(x, t0) - t0
                first = st if first is None else min(first, st)
    return round(c / max(t1 - t0, 1), 2), (None if first is None else int(first))


used = np.zeros(len(fa), bool); rows = []
for t0, dur, q, fac in r['defects']:
    t1 = min(t0 + dur, tot); e0 = int(t0 // er); e1 = min(int(t1 // er), len(fa) - 1)
    used[e0:e1 + 1] = True
    row = dict(q=int(q), kind=EX.get(q, 'not switchable'), factor=round(float(fac), 2), start=int(t0), rounds=int(t1 - t0),
               diff=int(fa[e0:e1 + 1].sum() - fb[e0:e1 + 1].sum()))
    for arm in show:
        c, f = cover(arm, q, t0, t1)
        row[arm] = dict(out=c, first=f)
    rows.append(row)
rows.sort(key=lambda x: -abs(x['diff']))
ret = {arm: [l for l in r['info'][arm].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch'] for arm in show}
print(json.dumps(dict(test=test, seed=seed, a=a, b=b, total_a=int(fa.sum()), total_b=int(fb.sum()),
                      outside_failures=int(fa[~used].sum() - fb[~used].sum()), top=rows[:8],
                      watch_returns={k: len(v) for k, v in ret.items()}), indent=1, default=str))
