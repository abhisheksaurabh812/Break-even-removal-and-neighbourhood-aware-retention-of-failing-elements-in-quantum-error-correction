"""
Rotated surface-code Z-memory (Stim layout and schedule, as rectgen.py) with qubits switched out of the code.

Supported exclusions (bulk only):
  * data qubit q: q is not operated at all.  Its two Z plaquettes and two X plaquettes become weight-3
    gauge operators.  Z gauges are measured in even rounds, X gauges in odd rounds (they anticommute
    pairwise, so they cannot share a round).  Detectors: each Z gauge individually in round 0 and at
    the final data readout (when the last round is a Z-gauge round); in between, the Z super-stabilizer
    (product of the two Z gauges) compared with two rounds earlier; likewise the X super-stabilizer.
  * Z ancilla a: a is not operated; its plaquette is never measured during the block.  Its value is
    read from the final data measurement and compared with the prepared +1 (one detector per block).
X ancillas are not excluded here (in a Z-memory experiment their cost would not be visible; a mirrored
X-memory test would be needed).

Returns the circuit text and metadata.  Coordinates are absolute (x, y, t); no REPEAT blocks.
`scale` optionally multiplies every noise channel touching a given data/ancilla coordinate (for the
independent Stim check only; the per-qubit-tagged models use uniform p and scale per qubit later).
"""
from rectgen import layout

DIAG = ((-1, -1), (-1, 1), (1, -1), (1, 1))


def bulk_data(d):
    data, xm, zm = layout(d, d)
    return [c for c in data if 1 < c[0] < 2 * d - 1 and 1 < c[1] < 2 * d - 1]


def bulk_zanc(d):
    data, xm, zm = layout(d, d)
    return [c for c in zm if 0 < c[0] < 2 * d and 0 < c[1] < 2 * d]


def footprint(c, d):
    """Plaquettes (ancilla coordinates) whose gauges/structure an exclusion changes."""
    data, xm, zm = layout(d, d)
    if c in set(zm):
        return {c}
    return {(c[0] + dx, c[1] + dy) for dx, dy in DIAG if (c[0] + dx, c[1] + dy) in set(xm) | set(zm)}


def compatible(cs, d):
    """True when the exclusions' changed plaquettes do not overlap and none touches another excluded qubit."""
    seen = set()
    for c in cs:
        fp = footprint(c, d) | {c}
        if fp & seen:
            return False
        seen |= fp
    return True


def circuit(d, rounds, p, excl=(), scale=None, row_len=None):
    data, xm, zm = layout(d, d)
    RL = row_len or (2 * d + 1)
    idx = lambda c: c[0] + RL * (c[1] // 2)
    zset, xset = set(zm), set(xm)
    excl = list(excl)
    excl_data = [c for c in excl if c in set(data)]
    zdead = [c for c in excl if c in zset]
    assert len(excl_data) + len(zdead) == len(excl), 'only data qubits and Z ancillas can be excluded'
    assert compatible(excl, d), 'overlapping exclusions'
    for c in excl_data:
        assert c in set(bulk_data(d)), 'bulk data qubits only'
    for c in zdead:
        assert c in set(bulk_zanc(d)), 'bulk Z ancillas only'
    data_e = [c for c in data if c not in set(excl_data)]
    dset = set(data_e)
    zgroups, xgroups = [], []
    for q in excl_data:
        nb = [(q[0] + dx, q[1] + dy) for dx, dy in DIAG]
        zgroups.append(sorted(c for c in nb if c in zset)); xgroups.append(sorted(c for c in nb if c in xset))
    zg = {c for g in zgroups for c in g}; xg = {c for g in xgroups for c in g}
    normal_z = sorted(c for c in zm if c not in zg and c not in set(zdead))
    normal_x = sorted(c for c in xm if c not in xg)
    sc = scale or {}
    s = lambda c: sc.get(c, 1.0)

    def act(r):
        Z = normal_z + (sorted(zg) if r % 2 == 0 else [])
        X = normal_x + (sorted(xg) if r % 2 == 1 else [])
        return Z, X

    def noise1(name, cs, pmax):
        if not cs:
            return []
        groups = {}
        for c in cs:
            groups.setdefault(min(p * s(c), pmax), []).append(idx(c))
        return [f'{name}({pr}) ' + ' '.join(map(str, sorted(v))) for pr, v in sorted(groups.items())]

    def noise2(pairs):
        groups = {}
        for a, b in pairs:
            groups.setdefault(min(p * max(s(a), s(b)), 0.9375), []).extend([idx(a), idx(b)])
        return [f'DEPOLARIZE2({pr}) ' + ' '.join(map(str, v)) for pr, v in sorted(groups.items())]

    allq = sorted(data_e + normal_z + normal_x + sorted(zg) + sorted(xg), key=idx)
    out = [f'QUBIT_COORDS({c[0]}, {c[1]}) {idx(c)}' for c in allq]
    meas_all = sorted(normal_z + normal_x + sorted(zg) + sorted(xg), key=idx)
    data_s = sorted(data_e, key=idx)
    out.append('R ' + ' '.join(str(idx(c)) for c in data_s)); out += noise1('X_ERROR', data_s, 0.5)
    out.append('R ' + ' '.join(str(idx(c)) for c in meas_all)); out += noise1('X_ERROR', meas_all, 0.5)
    out.append('TICK')
    ox = [(1, 1), (-1, 1), (1, -1), (-1, -1)]; oz = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    rec = {}; m = 0
    for r in range(rounds):
        Z, X = act(r)
        Xs = sorted(X, key=idx)
        if r > 0:
            out.append('TICK')
        out += noise1('DEPOLARIZE1', data_s, 0.75)
        if Xs:
            out.append('H ' + ' '.join(str(idx(c)) for c in Xs)); out += noise1('DEPOLARIZE1', Xs, 0.75)
        out.append('TICK')
        for k in range(4):
            pairs = []
            for c in sorted(X):
                dc = (c[0] + ox[k][0], c[1] + ox[k][1])
                if dc in dset:
                    pairs.append((c, dc))
            for c in sorted(Z):
                dc = (c[0] + oz[k][0], c[1] + oz[k][1])
                if dc in dset:
                    pairs.append((dc, c))
            out.append('CX ' + ' '.join(f'{idx(a)} {idx(b)}' for a, b in pairs)); out += noise2(pairs); out.append('TICK')
        if Xs:
            out.append('H ' + ' '.join(str(idx(c)) for c in Xs)); out += noise1('DEPOLARIZE1', Xs, 0.75)
        out.append('TICK')
        M = sorted(Z + X, key=idx)
        out += noise1('X_ERROR', M, 0.5); out.append('MR ' + ' '.join(str(idx(c)) for c in M)); out += noise1('X_ERROR', M, 0.5)
        for c in M:
            rec[(c, r)] = m; m += 1
        R = lambda key: f'rec[{rec[key] - m}]'
        if r == 0:
            for c in sorted(Z):
                out.append(f'DETECTOR({c[0]}, {c[1]}, 0) {R((c, 0))}')
        else:
            for c in sorted(normal_z + normal_x):
                out.append(f'DETECTOR({c[0]}, {c[1]}, {r}) {R((c, r))} {R((c, r - 1))}')
            if r % 2 == 0 and r >= 2:
                for g in zgroups:
                    out.append(f'DETECTOR({g[0][0]}, {g[0][1]}, {r}) ' + ' '.join(R((c, t)) for c in g for t in (r, r - 2)))
            if r % 2 == 1 and r >= 3:
                for g in xgroups:
                    out.append(f'DETECTOR({g[0][0]}, {g[0][1]}, {r}) ' + ' '.join(R((c, t)) for c in g for t in (r, r - 2)))
    out += noise1('X_ERROR', data_s, 0.5)
    out.append('M ' + ' '.join(str(idx(c)) for c in data_s))
    for c in data_s:
        rec[(c, 'd')] = m; m += 1
    R = lambda key: f'rec[{rec[key] - m}]'
    sup = lambda c: [(c[0] + dx, c[1] + dy) for dx, dy in DIAG if (c[0] + dx, c[1] + dy) in dset]
    T = rounds
    last_z = max(r for r in range(rounds) if r % 2 == 0)
    gauge_last_is_z = (rounds - 1) % 2 == 0
    for c in normal_z:
        out.append(f'DETECTOR({c[0]}, {c[1]}, {T}) ' + ' '.join(R((q, 'd')) for q in sup(c)) + f' {R((c, rounds - 1))}')
    for g in zgroups:
        if gauge_last_is_z:
            for c in g:
                out.append(f'DETECTOR({c[0]}, {c[1]}, {T}) ' + ' '.join(R((q, 'd')) for q in sup(c)) + f' {R((c, last_z))}')
        else:
            out.append(f'DETECTOR({g[0][0]}, {g[0][1]}, {T}) ' + ' '.join(R((q, 'd')) for c in g for q in sup(c))
                       + ' ' + ' '.join(R((c, last_z)) for c in g))
    for c in zdead:
        out.append(f'DETECTOR({c[0]}, {c[1]}, {T}) ' + ' '.join(R((q, 'd')) for q in sup(c)))
    out.append('OBSERVABLE_INCLUDE(0) ' + ' '.join(R((q, 'd')) for q in data_s if q[1] == 1))
    meta = dict(excl_data=excl_data, zdead=zdead, zg=sorted(zg), xg=sorted(xg), normal_z=normal_z, zgroups=zgroups)
    return '\n'.join(out) + '\n', meta
