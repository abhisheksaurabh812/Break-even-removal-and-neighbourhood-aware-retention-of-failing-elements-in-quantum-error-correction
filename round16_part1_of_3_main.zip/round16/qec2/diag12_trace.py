"""Post-hoc (not pre-registered): trace what each gate did in a time window of one round-12 run.
python3 diag12_trace.py <test> <seed> <round0> <round1> [arm ...]
Prints the failures active in the window (qubit, role, coordinates, factor, start, end), then for each arm its
switch-outs / returns / probes (policy log) and the learner's namings, watch returns and re-checks (sized log),
and the arm's logical failures in consecutive sub-windows."""
import sys, json
import numpy as np
import analyse8 as A

test, seed, r0, r1 = sys.argv[1], int(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
arms = sys.argv[5:] or ['sz_all', 'sz_field', 'sz_watch', 'sz_w12', 'sz_w12r']
r = A.load(f'out12/{test}_s{seed}.npz')
d = r['cfg']['d']; er = r['cfg']['bpe'] * d
R, EX = A.roles(d)
xy = A.circuit_model(d).qxy
C = lambda g: tuple(int(round(v)) for v in xy[int(g)])
e0, e1 = int(r0 // er), int(r1 // er)
print(f'window rounds {r0:.0f}-{r1:.0f} = epochs {e0}-{e1} ({er} rounds per epoch)')
print('failures active in the window:')
for t0, dur, q, fac in sorted(r['defects']):
    if t0 < r1 and t0 + dur > r0:
        print(f'  q{int(q)} {R.get(int(q))} {EX.get(int(q), "not switchable")} at {C(q)}: x{fac:.1f}, rounds {int(t0)}-{int(t0 + dur)}'
              f' (epochs {int(t0 // er)}-{int((t0 + dur) // er)})')
for arm in arms:
    inf = r['info'][arm]
    pl = [l for l in inf.get('policy_log', []) if e0 <= l[1] < e1]
    sl = [l for l in inf.get('sized', {}).get('log', []) if isinstance(l, list) and len(l) > 1 and isinstance(l[1], (int, float)) and e0 <= l[1] < e1]
    print(f'== {arm}: {len(pl)} policy entries, {len(sl)} learner entries')
    for l in pl:
        if l[0] == 'probe':
            continue
        print('   P', l[0], l[1], f'q{l[3]}' if len(l) > 3 and isinstance(l[3], int) else '', l[2] if len(l) > 2 else '', l[4:] if len(l) > 4 else '')
    nprobe = sum(1 for l in pl if l[0] == 'probe')
    if nprobe:
        print(f'   P ({nprobe} probe readings omitted)')
    agg = {}
    for l in sl:
        if l[0] in ('on', 'off', 'wret'):
            print('   L', l)
        else:
            agg[l[0]] = agg.get(l[0], 0) + 1
    if agg:
        print('   L counts of other learner entries:', agg)
    fa = A.per_epoch(r, arm)
    edges = np.linspace(e0, e1, 7).astype(int)
    print('   failures per sub-window:', [int(fa[a:b].sum()) for a, b in zip(edges[:-1], edges[1:])], 'edges (epochs)', edges.tolist())
