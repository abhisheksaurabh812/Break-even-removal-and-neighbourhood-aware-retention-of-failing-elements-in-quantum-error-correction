"""
Detect-name-exclude test.  Usage: python3 run3.py cfg.json out.npz key=json ...

Arms that never change the circuit decode the same samples (as run2.py).  Arms that switch a qubit
out of the code decode samples of the deformed circuit (deform.py) for the blocks where they do so;
deformed circuits are per-qubit tagged like the original, so they are driven by the same per-qubit
factor trajectories.  Comparisons are paired by epoch.

Arm kinds (in addition to run2's static / oracle / window / slow):
  oracle-excl : knows the true rates and the true defects; switches out every excludable qubit whose
                defect factor is past the measured crossover (data 13x, Z ancilla 7x), up to two at a time;
                exact weights for whatever circuit it runs.  Ideal bound for exclusion.
  excl        : wraps a localizer arm ('inner' spec).  When the localizer names an excludable qubit with
                estimated rate ratio >= r_ex, that qubit is switched out from the next epoch for t_rein
                rounds (then switched back in with its entries reset to calibration).  While a qubit is
                out, the learner keeps learning from every detector and edge whose error mechanisms are
                unchanged by the deformation; edges near the hole use the device-calibration projection.
Excludable: bulk data qubits and bulk Z ancillas (deform.py); at most two compatible exclusions.
"""
import sys, os, json, time, hashlib
from collections import OrderedDict
import numpy as np
from scipy.sparse import csr_matrix
from model import Model, circuit_model, unroll, analyze, parse_dem, filter_for_qubit, _qregion, P_REF, CACHE
from sampler import Sampler, build_matching, weights_from_p
from arms import prepare, Stats, estimate, WMIN
import deform, rectgen
from run2 import make_scenario, build_arms

THETA = {'data': 13.0, 'zanc': 7.0}       # crossover from ideal_excl.py (p = 0.003, d = 7)


# ------------------------------------------------------------------ models
def signatures(m):
    key = lambda k: (int(m.src_g[k]), int(round(m.p_ref[k] / P_REF * 1e6)))
    es = [[] for _ in range(m.E)]
    Cc = m.C.tocoo()
    for e, k in zip(Cc.row, Cc.col):
        es[e].append(key(k))
    ds = [[] for _ in range(m.nZ)]
    for k, u in zip(m.src_det_k, m.src_det_u):
        ds[u].append(key(k))
    m.esig = [tuple(sorted(x)) for x in es]; m.dsig = [tuple(sorted(x)) for x in ds]
    return m


def base_model(d):
    m = circuit_model(d); prepare(m); signatures(m)
    data, xm, zm = rectgen.layout(d, d)
    m.zanc = sorted(zm); m.anc_id = {c: i for i, c in enumerate(m.zanc)}
    m.qgroup = {(int(round(x)), int(round(y))): g for g, (x, y) in enumerate(m.qxy)}
    m.gcoord = {g: c for c, g in m.qgroup.items()}
    m.excludable = {}
    for c in deform.bulk_data(d):
        m.excludable[m.qgroup[c]] = ('data', c)
    for c in deform.bulk_zanc(d):
        m.excludable[m.qgroup[c]] = ('zanc', c)
    m.det_index = {(int(a), int(t)): i for i, (a, t) in enumerate(zip(m.danc, m.dt))}
    m.edge_index = {(int(u), int(v)): e for e, (u, v) in enumerate(zip(m.eu, m.ev))}
    m.name = 'base'
    return m


def deformed_model(base, excl):
    d = base.d; T = base.T
    excl = tuple(sorted(excl))
    tag = '_'.join(f'{x}-{y}' for x, y in excl)
    fn = os.path.join(CACHE, f'excl_d{d}_r{T}_{tag}.npz')
    m = Model(); m.kind = 'circuit'; m.d = d
    txt, meta = deform.circuit(d, T, P_REF, excl=list(excl))
    special = {tuple(c) for c in meta['zg']} | {tuple(c) for c in meta['zdead']}
    if os.path.exists(fn):
        z = np.load(fn, allow_pickle=True)
        for k in z.files:
            setattr(m, k, z[k])
        m.K = int(m.K); m.nZ = int(m.nZ); m.T = int(m.T); m.bad = int(m.bad)
    else:
        lines = txt.splitlines()
        coords = {}
        for l in lines:
            if l.startswith('QUBIT_COORDS'):
                c = tuple(int(float(x)) for x in l[l.index('(') + 1:l.index(')')].split(','))
                coords[int(l.split()[-1])] = c
        _, dets = parse_dem(analyze(lines))
        zdets = sorted(k for k, c in dets.items() if (int(c[0]), int(c[1])) in base.anc_id)
        zmap = {k: i for i, k in enumerate(zdets)}
        danc = np.array([base.anc_id[(int(dets[k][0]), int(dets[k][1]))] for k in zdets])
        dt = np.array([int(round(dets[k][2])) for k in zdets])
        src_p, src_g, src_obs, sdk, sdu, c_k, c_u, c_v, c_o = [], [], [], [], [], [], [], [], []
        K = 0; bad = 0
        for q in sorted(coords):
            gi = base.qgroup[coords[q]]
            errs, _ = parse_dem(analyze(filter_for_qubit(lines, q)))
            for p, comps in errs:
                zall = set(); obs = 0; zcomps = []
                for comp in comps:
                    zs = [zmap[int(t[1:])] for t in comp if t[0] == 'D' and int(t[1:]) in zmap]
                    lo = sum(1 for t in comp if t == 'L0') % 2
                    obs ^= lo
                    if zs:
                        zcomps.append((zs, lo))
                    for zz in zs:
                        zall ^= {zz}
                if not zall:
                    bad += int(obs); continue
                k = K; K += 1
                src_p.append(p); src_g.append(gi); src_obs.append(obs)
                for zz in zall:
                    sdk.append(k); sdu.append(zz)
                for zs, lo in zcomps:
                    if len(zs) > 2:
                        bad += 1; continue
                    zs = sorted(zs)
                    c_k.append(k); c_u.append(zs[0]); c_v.append(zs[1] if len(zs) == 2 else -1); c_o.append(lo)
        m.K, m.nZ, m.T = K, len(zdets), T
        m.p_ref = np.array(src_p); m.src_g = np.array(src_g); m.src_obs = np.array(src_obs, np.uint8)
        m.src_det_k = np.array(sdk); m.src_det_u = np.array(sdu)
        m.c_k, m.c_u, m.c_v, m.c_o = map(np.array, (c_k, c_u, c_v, c_o))
        m.danc, m.dt = danc, dt; m.bad = bad
        np.savez_compressed(fn, K=K, nZ=m.nZ, T=T, p_ref=m.p_ref, src_g=m.src_g, src_obs=m.src_obs, src_det_k=m.src_det_k,
                            src_det_u=m.src_det_u, c_k=m.c_k, c_u=m.c_u, c_v=m.c_v, c_o=m.c_o, danc=danc, dt=dt, bad=bad)
    m.dcls = np.where(m.dt == 0, 0, np.where(m.dt == m.T, 2, 1))
    m.dreg = np.array([_qregion(base.zanc[a], base.center) for a in m.danc])
    m.qxy = base.qxy; m.G = base.G; m.center = base.center; m.lattice = base.lattice
    m.finalize(); prepare(m); signatures(m)
    m.name = tag; m.excl = excl
    # ---- map to the base model
    spec = np.array([base.zanc[a] in special for a in m.danc])
    det_map = np.array([-1 if spec[j] else base.det_index.get((int(m.danc[j]), int(m.dt[j])), -1) for j in range(m.nZ)])
    det_ok = np.zeros(base.nZ, bool)
    for j in range(m.nZ):
        u = det_map[j]
        if u >= 0 and m.dsig[j] == base.dsig[u]:
            det_ok[u] = True
    cls_off = np.zeros(base.nclass, bool)
    np.logical_or.at(cls_off, base.dclass, ~det_ok)
    det_ok &= ~cls_off[base.dclass]
    emap = np.full(m.E, -1)
    for e in range(m.E):
        u = det_map[m.eu[e]]; v = det_map[m.ev[e]] if m.ev[e] >= 0 else -1
        if u < 0 or (m.ev[e] >= 0 and v < 0):
            continue
        key = (min(u, v), max(u, v)) if v >= 0 else (u, -1)
        b = base.edge_index.get(key)
        if b is not None and m.esig[e] == base.esig[b]:
            emap[e] = b
    edge_ok_full = np.zeros(base.E, bool); edge_ok_full[emap[emap >= 0]] = True
    edge_ok = edge_ok_full[base.nb_idx] & det_ok[base.U] & det_ok[base.V]
    anc_off = np.zeros(base.nA if hasattr(base, 'nA') else int(base.danc.max()) + 1, bool)
    ic = (base.class_cls == 1)
    anc_off[base.class_anc[ic & cls_off]] = True
    m.det_map = det_map; m.emap = emap
    m.mask = dict(edge_ok=edge_ok.astype(np.float32), det_ok=det_ok.astype(np.float32), cls_off=cls_off, anc_off=anc_off)
    m.to_base_cols = np.nonzero((det_map >= 0) & np.isin(det_map, np.nonzero(det_ok)[0]))[0]
    return m


def to_base(Xd, md, base):
    Xo = np.zeros((Xd.shape[0], base.nZ), np.uint8)
    cols = md.to_base_cols
    Xo[:, md.det_map[cols]] = Xd[:, cols]
    return Xo


# ------------------------------------------------------------------ arms
class OracleExcl:
    kind = 'oracle-excl'
    def __init__(self, name, base, events, er):
        self.name, self.base = name, base
        self.D = events['defects']; self.er = er; self.cur = (); self.log = []; self.nupd = 0
    def plan(self, e):
        t = (e + 0.5) * self.er
        act = sorted([d for d in self.D if d[0] <= t < d[0] + d[1]], key=lambda d: -d[3])
        chosen = []
        for d in act:
            g = d[2]
            if g in self.base.excludable:
                kind, c = self.base.excludable[g]
                if d[3] >= THETA[kind] and c not in chosen and len(chosen) < 2 and deform.compatible(chosen + [c], self.base.d):
                    chosen.append(c)
        new = tuple(sorted(chosen))
        if new != self.cur:
            self.log.append([e, list(map(list, new))])
        self.cur = new
        return new
    def info(self):
        return dict(changes=len(self.log), log=self.log[:2000])


class ExclArm:
    kind = 'excl'
    def __init__(self, name, base, inner, r_ex, t_rein, cal):
        self.name, self.base, self.inner = name, base, inner
        self.r_ex, self.t_rein = r_ex, t_rein
        self.cur = {}                       # coord -> dict(start_round, g, rhat, epoch)
        self.seen = 0; self.rounds = 0; self.log = []; self.cal = cal
        self.pending = []
    def config(self):
        return tuple(sorted(self.cur))
    def weights(self, md, true_pe):
        w_base = self.inner.weights(true_pe)
        if md is None:
            return w_base
        w = weights_from_p(md.edge_p(self.cal['f0']), WMIN)
        ok = md.emap >= 0
        w[ok] = w_base[md.emap[ok]]
        return w
    def update(self, X, crr, md, base_AggD, epoch, T):
        if md is None:
            self.inner.update(X, crr)
        else:
            Xo = to_base(X, md, self.base)
            crr_o = (Xo.astype(np.float32) @ base_AggD).reshape(-1, 4).astype(np.float64)
            self.inner.update(Xo, crr_o, md.mask)
        B = X.shape[0]; self.rounds += B * T
        # new namings this epoch
        L = self.inner.loclog
        for ent in L[self.seen:]:
            local, g, rhat = ent[2], ent[7], ent[9]
            if not local or g < 0 or rhat < self.r_ex or g not in self.base.excludable:
                continue
            kind, c = self.base.excludable[g]
            cs = list(self.cur)
            if c in self.cur or len(cs) >= 2 or not deform.compatible(cs + [c], self.base.d):
                continue
            self.cur[c] = dict(start=self.rounds, g=g, rhat=rhat, epoch=epoch)
            self.log.append(['out', epoch, list(c), g, round(rhat, 2)])
        self.seen = len(L)
        # switch back in after t_rein rounds (entries of that qubit reset to calibration)
        for c in list(self.cur):
            st = self.cur[c]
            if self.rounds - st['start'] >= self.t_rein:
                g = st['g']
                u = self.inner._shares(g)
                sel = u >= 0.5
                self.inner.p[sel] = self.cal['pe'][sel]
                for k in [k for k, o in self.inner.ovr.items() if o['q'] == g]:
                    del self.inner.ovr[k]
                del self.cur[c]
                self.log.append(['in', epoch, list(c), g])
    def info(self):
        d = self.inner.info(); d['excl_log'] = self.log[:5000]
        return d


# ------------------------------------------------------------------ run
def run(cfg, out):
    base = base_model(cfg['d'])
    rng_sc = np.random.default_rng(cfg['seed'])
    F, flags, events = make_scenario(base, cfg, rng_sc)
    n_ep, bpe, T = F.shape[0], cfg['bpe'], base.T
    er = bpe * T
    f_cal = F[0].astype(np.float64)
    pe = base.edge_p(f_cal); qd = base.det_rate(f_cal)
    qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f_cal)
    std_specs = [sp for sp in cfg['arms'] if sp['kind'] not in ('oracle-excl', 'excl')]
    if any(sp.get('base') == 'est' for sp in std_specs):
        cs = Sampler(base, np.random.default_rng(cfg['seed'] + 77777))
        st = Stats(base); nblk = cfg.get('cal_rounds', 1_000_000) // T
        for _ in range(0, nblk, 5000):
            Xc_, _ = cs.sample(np.tile(f_cal, (5000 // bpe, 1)), bpe); st.add(Xc_)
        pe_e, q_e, _, _ = estimate(base, st, pe, qcl, 10, 10)
        cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in base.int_classes])
    arms = []
    for sp in cfg['arms']:
        if sp['kind'] == 'oracle-excl':
            arms.append(OracleExcl(sp['name'], base, events, er))
        elif sp['kind'] == 'excl':
            inner = build_arms(base, cal, [sp['inner']])[0]
            arms.append(ExclArm(sp['name'], base, inner, sp['r_ex'], sp['t_rein'], cal))
        else:
            arms.append(build_arms(base, cal, [sp])[0])
    A = len(arms); names = [a.name for a in arms]
    sampler = Sampler(base, np.random.default_rng(cfg['seed'] + 99991))
    drng = np.random.default_rng(cfg['seed'] + 55555)
    dmodels = {}; dsamplers = {}

    def dm(key):
        if key not in dmodels:
            dmodels[key] = deformed_model(base, key)
            dsamplers[key] = Sampler(dmodels[key], drng)
        return dmodels[key]

    fails = np.zeros((A, n_ep, bpe), np.uint8); nexcl = np.zeros((A, n_ep), np.uint8)
    mcache = OrderedDict(); builds = 0; decodes = 0
    chunk = cfg.get('chunk', 250); t0 = time.time()
    for cs_ in range(0, n_ep, chunk):
        ce = min(n_ep, cs_ + chunk)
        Xc, oc = sampler.sample(F[cs_:ce].astype(np.float64), bpe)
        for e in range(cs_, ce):
            X0 = Xc[(e - cs_) * bpe:(e - cs_ + 1) * bpe]; o0 = oc[(e - cs_) * bpe:(e - cs_ + 1) * bpe]
            fe = F[e].astype(np.float64)
            true_pe = base.edge_p(fe)
            crr0 = (X0.astype(np.float32) @ base.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            keys = {}
            for i, a in enumerate(arms):
                if a.kind == 'oracle-excl':
                    keys[i] = a.plan(e)
                elif a.kind == 'excl':
                    keys[i] = a.config()
                else:
                    keys[i] = ()
            samples = {(): (X0, o0)}
            for k in set(keys.values()):
                if k and k not in samples:
                    md = dm(k)
                    samples[k] = dsamplers[k].sample(fe[None, :], bpe)
            preds = {}
            for i, a in enumerate(arms):
                k = keys[i]; md = dmodels[k] if k else None; mm = md if k else base
                X, o = samples[k]
                if a.kind == 'oracle-excl':
                    w = weights_from_p(mm.edge_p(fe), WMIN)
                elif a.kind == 'excl':
                    w = a.weights(md, true_pe)
                else:
                    w = a.weights(true_pe)
                w = np.round(w, 3)
                hk = (k, hashlib.md5(w.tobytes()).digest())
                pr = preds.get(hk)
                if pr is None:
                    mt = mcache.get(hk)
                    if mt is None:
                        mt = build_matching(mm, w); builds += 1; mcache[hk] = mt
                        if len(mcache) > 400:
                            mcache.popitem(last=False)
                    else:
                        mcache.move_to_end(hk)
                    pr = mt.decode_batch(X)[:, 0]; decodes += 1; preds[hk] = pr
                fails[i, e] = pr ^ o
                nexcl[i, e] = len(k)
            for i, a in enumerate(arms):
                if a.kind == 'oracle-excl':
                    continue
                if a.kind == 'excl':
                    k = keys[i]
                    a.update(samples[k][0], crr0 if not k else None, dmodels[k] if k else None, base.AggD, e, T)
                else:
                    a.update(X0, crr0)
        if cfg.get('verbose'):
            print(f'{ce}/{n_ep} {time.time() - t0:.0f}s builds={builds} dmodels={len(dmodels)}', file=sys.stderr, flush=True)
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, nexcl=nexcl, flags=flags, names=np.array(names), cfg=json.dumps(cfg),
                        events=json.dumps(events), info=json.dumps(info))
    tot = fails.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes,
                          deformed_configs=len(dmodels), totals=dict(zip(names, tot.tolist())),
                          excluded_epochs=dict(zip(names, (nexcl > 0).sum(1).tolist())),
                          n_defects=len(events['defects']), n_bursts=len(events['bursts']))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
