"""Independent recount for the exclusion test from the raw per-block failure arrays (own code)."""
import glob, math
import numpy as np

for scen in ('severe', 'moderate', 'none', 'realistic'):
    fs = sorted(glob.glob(f'out/testX_{scen}_s*.npz'))
    if not fs:
        continue
    per = {}
    for f in fs:
        z = np.load(f, allow_pickle=True)
        names = [str(n) for n in z['names']]
        fe = z['fails'].astype(np.int64).sum(axis=2)            # arms x epochs
        for i, n in enumerate(names):
            per.setdefault(n, []).append(fe[i])
    per = {n: np.concatenate(v) for n, v in per.items()}
    print(f'== {scen} ({len(fs)} seeds, {len(per["loc"])} epochs)')
    for a, b in (('excl', 'loc'), ('oracle-excl', 'oracle'), ('excl', 'oracle-excl'), ('loc', 'static-est')):
        d = (per[a] - per[b]).astype(float)
        z = d.mean() / (d.std(ddof=1) / math.sqrt(len(d)))
        print(f'   {a:>12} vs {b:<12} {per[a].sum():>7} vs {per[b].sum():<7} ({per[a].sum() / per[b].sum() - 1:+.4f})  z={z:+.1f}')
