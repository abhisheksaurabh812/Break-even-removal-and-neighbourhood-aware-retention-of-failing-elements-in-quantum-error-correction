"""Round 13 analysis (rules in PREREG_round13.md).   python3 analyse13.py > out13/res_13.json
A rule is evaluated only when every seed of its test has finished (done marker in out13/done/)."""
import json, os
import analyse8 as A

GATES = ('sz_w13',)
SEEDS = dict(d9_mixed=range(9101, 9111), d9_severe=range(9201, 9206), d9_moderate=range(9301, 9306),
             d9_realistic=range(9001, 9011), pairs_mixed=range(9401, 9411), long_severe=range(9501, 9507),
             long_mixed=range(9601, 9607), d9_hwlike=range(9701, 9711))
POOL = ('d9_mixed', 'd9_severe', 'd9_moderate', 'pairs_mixed')
LONG = ('long_severe', 'long_mixed')


def done(n):
    return os.path.exists(f'out13/done/{n}')


def runs(test):
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        out.append(A.load(f'out13/{n}.npz'))
    return out


PAIRS = [(g, ref) for g in GATES for ref in ('loc', 'sz', 'sz_all', 'sz_field', 'sz_w12r')]
PAIRS += [('sz_w12r', 'sz'), ('sz_w12r', 'sz_all'), ('sz_w12r', 'loc'), ('sz_w12r', 'sz_field'),
          ('sz_field', 'sz'), ('sz_field', 'sz_all'), ('sz_field', 'loc')]


def returns(rs, g):
    n = 0
    for r in rs:
        n += sum(1 for l in r['info'][g].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch')
    return n


def rules_for(g, res):
    c = lambda t, k: res[t][k]
    out = {}
    if 'd9_mixed' in res:
        out[f'R1_{g}_mixed_beats_sz_5pct'] = A.beats(c('d9_mixed', f'{g} vs sz'), 0.05)
        out[f'R1_{g}_mixed_beats_all_3pct'] = A.beats(c('d9_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_severe' in res:
        out[f'R2_{g}_severe_beats_sz_10pct'] = A.beats(c('d9_severe', f'{g} vs sz'), 0.10)
    if 'd9_moderate' in res:
        out[f'R3_{g}_moderate_vs_sz_within_1pct'] = bool(c('d9_moderate', f'{g} vs sz')['rel'] <= 0.01)
    if 'd9_realistic' in res:
        x = c('d9_realistic', f'{g} vs loc')
        out[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'pairs_mixed' in res:
        out[f'R5_{g}_pairs_vs_sz_within_1pct'] = bool(c('pairs_mixed', f'{g} vs sz')['rel'] <= 0.01)
    if 'long_severe' in res:
        out[f'R6_{g}_long_severe_beats_sz_10pct'] = A.beats(c('long_severe', f'{g} vs sz'), 0.10)
    if 'long_mixed' in res:
        out[f'R7_{g}_long_mixed_beats_sz_5pct'] = A.beats(c('long_mixed', f'{g} vs sz'), 0.05)
        out[f'R7_{g}_long_mixed_beats_all_3pct'] = A.beats(c('long_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_hwlike' in res:
        out[f'R8_{g}_hwlike_beats_sz_10pct'] = A.beats(c('d9_hwlike', f'{g} vs sz'), 0.10)
    return out


def main():
    res = {}; rules = {}
    for test in SEEDS:
        rs = runs(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        R['watch_returns'] = {g: returns(rs, g) for g in ('sz_w12r',) + GATES}
        for g in GATES + ('sz_w12r', 'sz_field'):
            pc = A.policy_checks(rs, g)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{g}'] = pc
        res[test] = R
    for g in GATES:
        rules.update(rules_for(g, res))
    if all(t in res for t in POOL):
        rs = sum((runs(t) for t in POOL), [])
        x = A.compare(rs, 'sz_w13', 'sz_w12r'); x['boot95'] = A.bootstrap(rs, 'sz_w13', 'sz_w12r')
        res['C1_pooled: sz_w13 vs sz_w12r'] = x
        rules['C1_sz_w13_fewer_failures_than_sz_w12r_pooled'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    if 'd9_hwlike' in res:
        x = res['d9_hwlike']['sz_w13 vs sz_w12r']
        rules['C2_sz_w13_hwlike_vs_sz_w12r_within_1pct'] = bool(x['rel'] <= 0.01)
    if all(t in res for t in LONG):
        rs = sum((runs(t) for t in LONG), [])
        x = A.compare(rs, 'sz_w13', 'sz_w12r'); x['boot95'] = A.bootstrap(rs, 'sz_w13', 'sz_w12r')
        res['C3_pooled: sz_w13 vs sz_w12r (long)'] = x
        rules['C3_sz_w13_fewer_failures_than_sz_w12r_long_pooled'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
