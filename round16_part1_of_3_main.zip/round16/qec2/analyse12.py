"""Round 12 analysis (rules in PREREG_round12.md).   python3 analyse12.py > out12/res_12.json
A rule is evaluated only when every seed of its test has finished (done marker in out12/done/)."""
import json, os
import analyse8 as A

GATES = ('sz_w12', 'sz_w12r')
SEEDS = dict(d9_mixed=range(8101, 8111), d9_severe=range(8201, 8206), d9_moderate=range(8301, 8306),
             d9_realistic=range(8001, 8011), pairs_mixed=range(8401, 8411), long_severe=range(8501, 8507),
             long_mixed=range(8601, 8607), d9_hwlike=range(8701, 8711))
POOL = ('d9_mixed', 'd9_severe', 'd9_moderate', 'pairs_mixed')


def done(n):
    return os.path.exists(f'out12/done/{n}')


def runs(test):
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        out.append(A.load(f'out12/{n}.npz'))
    return out


PAIRS = [(g, ref) for g in GATES for ref in ('loc', 'sz', 'sz_all', 'sz_field', 'sz_watch')]
PAIRS += [('sz_w12r', 'sz_w12'), ('sz_watch', 'sz'), ('sz_watch', 'sz_all'), ('sz_watch', 'loc'), ('sz_watch', 'sz_field'),
          ('sz_field', 'sz'), ('sz_field', 'sz_all'), ('sz_field', 'loc'), ('oracle_gated', 'oracle')]


def returns(rs, g):
    n = 0
    for r in rs:
        n += sum(1 for l in r['info'][g].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch')
    return n


def rules_for(g, res):
    c = lambda t, k: res[t][k]
    out = {}
    if 'd9_mixed' in res:
        out[f'R1_{g}_mixed_beats_sz_5pct'] = A.beats(c('d9_mixed', f'{g} vs sz'), 0.05)
        out[f'R1_{g}_mixed_beats_all_3pct'] = A.beats(c('d9_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_severe' in res:
        out[f'R2_{g}_severe_beats_sz_10pct'] = A.beats(c('d9_severe', f'{g} vs sz'), 0.10)
    if 'd9_moderate' in res:
        out[f'R3_{g}_moderate_vs_sz_within_1pct'] = bool(c('d9_moderate', f'{g} vs sz')['rel'] <= 0.01)
    if 'd9_realistic' in res:
        x = c('d9_realistic', f'{g} vs loc')
        out[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'pairs_mixed' in res:
        out[f'R5_{g}_pairs_vs_sz_within_1pct'] = bool(c('pairs_mixed', f'{g} vs sz')['rel'] <= 0.01)
    if 'long_severe' in res:
        out[f'R6_{g}_long_severe_beats_sz_10pct'] = A.beats(c('long_severe', f'{g} vs sz'), 0.10)
    if 'long_mixed' in res:
        out[f'R7_{g}_long_mixed_beats_sz_5pct'] = A.beats(c('long_mixed', f'{g} vs sz'), 0.05)
        out[f'R7_{g}_long_mixed_beats_all_3pct'] = A.beats(c('long_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_hwlike' in res:
        out[f'R8_{g}_hwlike_beats_sz_10pct'] = A.beats(c('d9_hwlike', f'{g} vs sz'), 0.10)
    return out


def main():
    res = {}; rules = {}
    for test in SEEDS:
        rs = runs(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        R['watch_returns'] = {g: returns(rs, g) for g in ('sz_watch',) + GATES}
        for g in GATES + ('sz_watch', 'sz_field'):
            pc = A.policy_checks(rs, g)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{g}'] = pc
        res[test] = R
    for g in GATES:
        rules.update(rules_for(g, res))
    if all(t in res for t in POOL):
        rs = sum((runs(t) for t in POOL), [])
        for key, a, b in (('C1', 'sz_w12', 'sz_watch'), ('C2', 'sz_w12r', 'sz_w12')):
            x = A.compare(rs, a, b); x['boot95'] = A.bootstrap(rs, a, b)
            res[f'{key}_pooled: {a} vs {b}'] = x
            rules[f'{key}_{a}_fewer_failures_than_{b}_pooled'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
