"""Post-hoc check (not pre-registered, no rule uses it): how cleanly do pair coincidences separate a
data-qubit fault from a Z-ancilla fault in this noise model?   python3 coinc_signature.py > out_extra/coinc_signature.json

Exact, no sampling: for every switchable qubit (bulk data qubit, bulk Z ancilla) at factor x nominal, with
every other qubit at nominal (p = 0.003), the change in every decoder-edge probability (what a pair
coincidence counter estimates) is split by edge type:
  time-like  same Z ancilla, consecutive rounds
  space-like two different Z ancillas, same round
  diagonal   two different Z ancillas, consecutive rounds
Only edges with both detectors in interior rounds are used (the steady state the twin monitors).
Reported per qubit kind: the time-like share of the excess, and how many qubits of each kind a single
threshold on that share would misclassify."""
import json
import numpy as np
from model import circuit_model, P_REF
import analyse8 as A

FACTORS = (3.0, 10.0, 33.6)
out = {}
for d in (7, 9):
    m = circuit_model(d)
    _, EX = A.roles(d)
    fn = 0.003 / P_REF
    f0 = np.full(m.G, fn)
    p0 = m.edge_p(f0)
    nb = m.ev >= 0
    v = np.maximum(m.ev, 0)
    interior = nb & (m.dcls[m.eu] == 1) & (m.dcls[v] == 1)
    same_anc = m.danc[m.eu] == m.danc[v]
    same_t = m.dt[m.eu] == m.dt[v]
    typ = {'time': interior & same_anc, 'space': interior & ~same_anc & same_t,
           'diag': interior & ~same_anc & ~same_t}
    q0 = m.det_rate(f0)
    res = {}
    for fac in FACTORS:
        share = {'data': [], 'zanc': []}
        detail = {'data': [], 'zanc': []}
        for g, kind in sorted(EX.items()):
            f = f0.copy(); f[g] = fn * fac
            dp = m.edge_p(f) - p0
            s = {k: float(dp[sel].sum()) for k, sel in typ.items()}
            tot = s['time'] + s['space'] + s['diag']
            sh = s['time'] / tot
            share[kind].append(sh)
            # single-detector view: excess detector rate on the most-raised Z ancilla vs the second
            dq = m.det_rate(f) - q0
            per_anc = np.bincount(m.danc[m.dcls == 1], dq[m.dcls == 1])
            top = np.sort(per_anc)[::-1]
            detail[kind].append(dict(q=int(g), time_share=round(sh, 3),
                                     excess=dict((k, round(x, 6)) for k, x in s.items()),
                                     det_top2_ratio=round(float(top[1] / top[0]), 3)))
        lo_z = min(share['zanc']); hi_d = max(share['data'])
        res[str(fac)] = dict(
            time_share_data=dict(min=round(min(share['data']), 3), median=round(float(np.median(share['data'])), 3),
                                 max=round(hi_d, 3), n=len(share['data'])),
            time_share_zanc=dict(min=round(lo_z, 3), median=round(float(np.median(share['zanc'])), 3),
                                 max=round(max(share['zanc']), 3), n=len(share['zanc'])),
            separated=bool(hi_d < lo_z),
            det_top2_ratio_data=dict(min=min(x['det_top2_ratio'] for x in detail['data']),
                                     max=max(x['det_top2_ratio'] for x in detail['data'])),
            det_top2_ratio_zanc=dict(min=min(x['det_top2_ratio'] for x in detail['zanc']),
                                     max=max(x['det_top2_ratio'] for x in detail['zanc'])),
            example_data=detail['data'][len(detail['data']) // 2],
            example_zanc=detail['zanc'][len(detail['zanc']) // 2])
    out[f'd{d}'] = res
print(json.dumps(out, indent=1))
