"""Round-9 job queue.   python3 queue8.py jobs8.txt <budget_minutes> <workers>
Job lines:  name  est_seconds  requires(comma list or -)  command ...
A job is skipped if out9/done/<name> exists.  It starts only when its requirements are done and it is
expected to finish inside the budget (elapsed + 1.3 x est < budget), so a batch never has to cut a job
short.  stdout/stderr -> out9/logs/<name>.{out,err}; exit status 0 -> done marker (holding the run time)."""
import sys, os, time, subprocess


def load(fn):
    jobs = []
    for line in open(fn):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        name, est, req, cmd = line.split(None, 3)
        jobs.append(dict(name=name, est=float(est), req=[] if req == '-' else req.split(','), cmd=cmd))
    return jobs


def done(n):
    return os.path.exists(f'out9/done/{n}')


def main():
    jobs = load(sys.argv[1]); budget = float(sys.argv[2]) * 60; W = int(sys.argv[3])
    t0 = time.time(); running = {}; failed = set()
    log = open('out9/queue.log', 'a')

    def L(msg):
        log.write(f'{time.strftime("%d %H:%M:%S")} {msg}\n'); log.flush()

    L(f'batch start, budget {budget / 60:.0f} min, {W} workers')
    while True:
        for n, (p, ts) in list(running.items()):
            rc = p.poll()
            if rc is not None:
                del running[n]
                if rc == 0:
                    open(f'out9/done/{n}', 'w').write(f'{time.time() - ts:.0f}\n'); L(f'done {n} {time.time() - ts:.0f}s')
                else:
                    failed.add(n); L(f'FAILED {n} rc={rc}')
        while len(running) < W:
            el = time.time() - t0
            cand = [j for j in jobs if not done(j['name']) and j['name'] not in running and j['name'] not in failed
                    and all(done(r) for r in j['req']) and el + 1.3 * j['est'] < budget]
            if not cand:
                break
            j = cand[0]
            out = open(f'out9/logs/{j["name"]}.out', 'w'); err = open(f'out9/logs/{j["name"]}.err', 'w')
            p = subprocess.Popen(j['cmd'], shell=True, stdout=out, stderr=err)
            running[j['name']] = (p, time.time()); L(f'start {j["name"]} (est {j["est"]:.0f}s)')
        if not running:
            break
        time.sleep(5)
    left = [j['name'] for j in jobs if not done(j['name'])]
    L(f'batch end; {len(left)} left: {" ".join(left)}')
    print(f'{len(left)} jobs left:', ' '.join(left), '| failed:', ' '.join(sorted(failed)) or 'none')


if __name__ == '__main__':
    main()
