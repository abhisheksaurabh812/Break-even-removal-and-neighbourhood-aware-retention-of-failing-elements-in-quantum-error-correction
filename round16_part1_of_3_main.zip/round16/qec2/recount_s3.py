"""Independent recount for the shared-rates re-test, straight from the raw arrays (own code)."""
import glob, math, json
import numpy as np

picks = json.load(open('out/res_s3_train.json'))['picks']
bs = picks.get('best_sep', 'sep-own')
for tag in ('int_k100', 'int_k500', 'fresh_k20'):
    fs = sorted(glob.glob(f'out/s3_test_{tag}_s*.npz'))
    if not fs:
        continue
    M = {}; U = {}
    for f in fs:
        z = np.load(f, allow_pickle=True); names = [str(n) for n in z['names']]
        for i, n in enumerate(names):
            M.setdefault(n, []).append(z['failM'][i][z['vM']].astype(np.int64))
            U.setdefault(n, []).append(z['failU'][i][z['vU']].astype(np.int64))
    M = {n: np.concatenate(v) for n, v in M.items()}; U = {n: np.concatenate(v) for n, v in U.items()}
    print(f'== {tag}: {len(fs)} seeds, merged blocks {len(M[bs])}, unmerged {len(U[bs])}')
    ref3 = 'static-shared' if tag.startswith('fresh') else bs
    for a, b in (('shared', ref3), ('shared-ratio', ref3), ('oracle', 'static-est'), ('oracle', bs)):
        x = int(((M[a] == 1) & (M[b] == 0)).sum()); y = int(((M[a] == 0) & (M[b] == 1)).sum())
        z = (abs(x - y) - 1) / math.sqrt(x + y) if x + y else 0
        print(f'   merged   {a:>13} vs {b:<13} {M[a].sum():>6} vs {M[b].sum():<6} ({M[a].sum() / M[b].sum() - 1:+.4f})  discordant {x}/{y}  z={z:.1f}')
    for a in ('shared', 'shared-ratio'):
        print(f'   unmerged {a:>13} vs {bs:<13} {U[a].sum():>7} vs {U[bs].sum():<7} ({U[a].sum() / U[bs].sum() - 1:+.4f})')
