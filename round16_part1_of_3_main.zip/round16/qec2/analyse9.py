"""Round 9 analysis (rules in PREREG_round9.md).   python3 analyse9.py > out9/res_9.json
A rule is evaluated only when every seed of its scenario has finished (done marker in out9/done/)."""
import json, os
import numpy as np
import analyse8 as A

SEEDS = dict(realistic=range(5001, 5011), mixed=range(5101, 5111), severe=range(5201, 5204),
             moderate=range(5301, 5306))


def done(n):
    return os.path.exists(f'out9/done/{n}')


def runs(scen):
    out = []
    for s in SEEDS[scen]:
        n = f'test_{scen}_s{s}'
        if not done(n):
            return None
        out.append(A.load(f'out9/{n}.npz'))
    return out


def split_by_switchout(rs, arm, ref):
    """Epochs labelled by what `arm` has switched out: none / only qubits with an active failure / at least
    one qubit without one; failures of arm minus ref in each class (as diag8_realistic.py)."""
    tot = {k: dict(epochs=0, diff=0, ref=0) for k in ('none', 'defect', 'no_defect')}
    for r in rs:
        er = r['cfg']['bpe'] * r['cfg']['d']; E = r['fails'].shape[1]
        a = A.per_epoch(r, arm); b = A.per_epoch(r, ref)
        out = [set() for _ in range(E)]
        for q, s0, s1, _ in A.out_intervals(r['info'][arm].get('policy_log', []), er):
            e0 = int(round(s0 / er)); e1 = E if s1 is None else int(round(s1 / er))
            for e in range(e0, min(e1, E)):
                out[e].add(q)
        for e in range(E):
            if not out[e]:
                k = 'none'
            else:
                t = (e + 0.5) * er
                k = 'defect' if all(any(dd[2] == q and dd[0] <= t < dd[0] + dd[1] for dd in r['defects'])
                                    for q in out[e]) else 'no_defect'
            tot[k]['epochs'] += 1; tot[k]['diff'] += int(a[e] - b[e]); tot[k]['ref'] += int(b[e])
    for k in tot:
        tot[k]['rel_within'] = round(tot[k]['diff'] / max(tot[k]['ref'], 1), 4)
    return tot


def field_decisions(rs):
    """Levels seen by the field gate at its switch-outs, and how many of the old gate's switch-outs it did not make."""
    Ls = []; old_only = 0; old_n = 0
    for r in rs:
        lf = r['info']['sz_field'].get('policy_log', []); lg = r['info']['sz_gated'].get('policy_log', [])
        Ls += [l[6] for l in lf if l[0] == 'out']
        fo = {(l[1], l[3]) for l in lf if l[0] == 'out'}
        for l in lg:
            if l[0] == 'out':
                old_n += 1
                old_only += not any(abs(e - l[1]) <= 64 and g == l[3] for e, g in fo)
    return dict(field_switch_outs=len(Ls), level_median=float(np.median(Ls)) if Ls else None,
                level_max=float(max(Ls)) if Ls else None, old_gate_switch_outs=old_n,
                old_gate_switch_outs_not_made_by_field_gate_within_64_epochs=old_only)


PAIRS = (('sz_field', 'loc'), ('sz_field', 'sz'), ('sz_field', 'sz_all'), ('sz_field', 'sz_gated'),
         ('sz_gated', 'loc'), ('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz', 'loc'), ('oracle_gated', 'oracle'))


def main():
    res = {}; rules = {}
    for scen in SEEDS:
        rs = runs(scen)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        for arm in ('sz_field', 'sz_gated'):
            pc = A.policy_checks(rs, arm)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{arm}'] = pc
            R[f'split_{arm}_vs_sz'] = split_by_switchout(rs, arm, 'sz')
        R['field_decisions'] = field_decisions(rs)
        res[scen] = R
    if 'realistic' in res:
        c = res['realistic']['sz_field vs loc']
        rules['G1_realistic_field_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(c['rel'] <= 0.01 and c['boot95']['hi'] <= 0.02)
    if 'mixed' in res:
        c = res['mixed']['sz_field vs sz']
        rules['G2_mixed_field_beats_sz_5pct_upper95_below_0'] = bool(c['rel'] <= -0.05 and c['boot95']['hi'] < 0)
        c = res['mixed']['sz_field vs sz_all']
        rules['G2_mixed_field_beats_all_3pct_upper95_below_0'] = bool(c['rel'] <= -0.03 and c['boot95']['hi'] < 0)
    if 'severe' in res:
        rules['G3_severe_field_beats_sz_10pct'] = A.beats(res['severe']['sz_field vs sz'], 0.10)
    if 'moderate' in res:
        rules['G4_moderate_field_vs_sz_within_1pct'] = bool(res['moderate']['sz_field vs sz']['rel'] <= 0.01)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
