"""Development tests for the round-13 naming (arms13.Sized7), learner only, d = 9, planted failures.
Every learner sees exactly the same detection events each epoch (paired).  Learners:
  s5   round-11/12 learner (Sized5), s6 = Sized5 + round-12 re-check (Sized6), s7 = new naming (defaults),
  s7off = Sized7 with every change off (must reproduce s5 exactly), plus optional ablations s7-<switch>.
Scenarios (failures: qubit, first epoch, last epoch, factor; hole: qubit switched out from epoch h0 to h1):
  single_data, single_zanc, two_at_once, second_near_known, hidden, hidden_then_open, background.
python3 test13.py <scenario|all> <seeds> [learners]      e.g.  python3 test13.py all 4 s5,s6,s7,s7off
Prints, per scenario and learner: for each planted failure the epochs to its first naming (- = never) and how many
other qubits were named (wrong names), summed over seeds."""
import sys, json, time
import numpy as np
from model import P_REF
from sampler import Sampler
from run3 import base_model, deformed_model, to_base
from run12 import make_sized
from arms13 import Sized7, OFF13

D9 = 9
CFG = json.load(open('cfg12/d9_mixed.json'))
INNER = [a for a in CFG['arms'] if a['name'] == 'sz_w12r'][0]['inner']
# qubits (d = 9): q23 data (11,3), q59 data (11,7), q79 Z ancilla (12,8), q61 data (13,7)
SCEN = dict(
    single_data=dict(n=500, fail=[(23, 50, 500, 44.0)]),
    single_zanc=dict(n=500, fail=[(79, 50, 500, 73.0)]),
    two_at_once=dict(n=500, fail=[(23, 50, 500, 44.0), (59, 50, 500, 75.0)]),
    second_near_known=dict(n=700, fail=[(59, 50, 700, 75.0), (23, 300, 700, 44.0)]),
    hidden=dict(n=500, fail=[(23, 50, 500, 44.0)], hole=(59, 0, 500)),
    hidden_then_open=dict(n=700, fail=[(23, 50, 700, 44.0)], hole=(59, 0, 350)),
    background=dict(n=1500, fail=[]),
    realistic_bg=dict(n=1500, fail=[], drift=(0.15, 3.0)),
    boundary_pair=dict(n=600, fail=[(85, 50, 600, 82.0), (103, 200, 600, 66.0)]),
    # bursts as run10.make_scenario: factor 1 + (peak - 1) exp(-(t - t0)/tau) exp(-dist^2 / (2 (2 x lattice)^2)), for 5 tau
    burst=dict(n=600, fail=[], burst=[(50, 80, 6.0, 59), (300, 120, 8.0, 23)]),
    burst_then_fail=dict(n=700, fail=[(23, 200, 700, 44.0)], burst=[(50, 100, 7.0, 59)]),
)


def learner(kind, base, cal):
    sp = json.loads(json.dumps(INNER)); sp['name'] = kind
    if kind == 's5':
        sp['kind'] = 'sized5'
    elif kind == 's6':
        sp['kind'] = 'sized6'
    else:
        sp['kind'] = 'sized5'
        n13 = {}
        if kind == 's7off':
            n13 = dict(OFF13)
        elif kind.startswith('s7-'):
            for sw in kind[3:].split('-'):
                n13[sw] = OFF13[sw]
        sp['sizer'] = dict(sp.get('sizer', {}), name13=n13)
        return Sized7(sp['name'], base, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                      sp.get('tmax'), sp.get('footprint'), sp['sizer'])
    return make_sized(base, cal, sp)


_BASE = {}


def run(scen, seed, kinds):
    sc = SCEN[scen]
    if D9 not in _BASE:
        _BASE[D9] = base_model(D9)
    base = _BASE[D9]
    rng = np.random.default_rng(seed)
    f0 = np.exp(CFG['het_sigma'] * rng.standard_normal(base.G)); f0 /= np.median(f0); f0 = np.clip(f0, 0.25, 4.0)
    f_cal = f0 * CFG['p_base'] / P_REF
    pe = base.edge_p(f_cal); qd = base.det_rate(f_cal)
    qcl = np.bincount(base.dclass, qd, base.nclass) / base.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in base.int_classes]), f0=f_cal)
    L = {k: learner(k, base, cal) for k in kinds}
    smp = Sampler(base, np.random.default_rng(seed + 1))
    hole = sc.get('hole')
    md = deformed_model(base, (base.gcoord[hole[0]],)) if hole else None
    smd = Sampler(md, np.random.default_rng(seed + 2)) if hole else None
    bpe = CFG['bpe']
    drift = sc.get('drift')
    dsel = np.zeros(base.G, bool); dfac = np.ones(base.G)
    if drift:
        dsel = rng.random(base.G) < drift[0]; dfac = rng.uniform(1.0, drift[1], base.G)
    for e in range(sc['n']):
        f = f_cal.copy()
        if drift:
            f[dsel] *= dfac[dsel] ** (e / sc['n'])
        for q, a, b, fac in sc['fail']:
            if a <= e < b:
                f[q] *= fac
        for e0, tau, peak, cq in sc.get('burst', []):
            if e0 <= e < e0 + 5 * tau:
                sp_ = np.exp(-((base.qxy - base.qxy[cq]) ** 2).sum(1) / (2 * (2.0 * base.lattice) ** 2))
                f = f * (1 + (peak - 1) * np.exp(-(e - e0) / tau) * sp_)
        if hole and hole[1] <= e < hole[2]:
            Xd, _ = smd.sample(f[None, :], bpe)
            X = to_base(Xd, md, base); mask = md.mask
        else:
            X, _ = smp.sample(f[None, :], bpe); mask = None
        crr = (X.astype(np.float32) @ base.AggD).reshape(-1, 4).astype(np.float64)
        for k, l in L.items():
            if mask is None:
                l.update(X, crr)
            else:
                l.update(X, crr, mask)
    out = {}
    bad = {q for q, _, _, _ in sc['fail']} | set(np.nonzero(dsel)[0].tolist())
    for k, l in L.items():
        on = [x for x in l.slog if x[0] == 'on']
        first = {}
        for q, a, b, fac in sc['fail']:
            t = [x[1] - a for x in on if x[2] == q and x[1] >= a]
            first[q] = t[0] if t else None
        wrong = sorted(set(int(x[2]) for x in on if x[2] not in bad))
        out[k] = dict(first=first, wrong=wrong, nwrong=sum(1 for x in on if x[2] not in bad),
                      slog=[x for x in l.slog if x[0] in ('on', 'off', 'reject', 'recheck')][:60],
                      c13=getattr(l, 'cnt13', None), log13=getattr(l, 'log13', [])[:30])
    return out


if __name__ == '__main__':
    which = sys.argv[1]; ns = int(sys.argv[2])
    kinds = sys.argv[3].split(',') if len(sys.argv) > 3 else ['s5', 's6', 's7', 's7off']
    scens = list(SCEN) if which == 'all' else which.split(',')
    res = {}
    for s in scens:
        t0 = time.time()
        res[s] = [run(s, 1000 + i, kinds) for i in range(ns)]
        print(f'== {s} ({time.time() - t0:.0f}s)', flush=True)
        for k in kinds:
            rows = [r[k] for r in res[s]]
            firsts = {q: [r['first'][q] for r in rows] for q in rows[0]['first']}
            print(f'  {k:8s} first naming (epochs after start) {firsts}  wrong names {sum(r["nwrong"] for r in rows)} '
                  f'{[r["wrong"] for r in rows]}  {rows[0]["c13"] or ""}', flush=True)
        if 's7off' in kinds and 's5' in kinds:
            same = all(r['s7off']['slog'] == r['s5']['slog'] for r in res[s])
            print('  s7off reproduces s5:', same, flush=True)
    json.dump(res, open(f'dev13/test13_{which.replace(",", "_")}_{ns}.json', 'w'), default=str)
