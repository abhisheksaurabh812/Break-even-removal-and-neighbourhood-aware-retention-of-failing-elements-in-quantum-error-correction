"""
Round-6 arms: delayed perfect knowledge, and the twin that adds analog readout monitoring to the
syndrome localizer (loc).

DelayedOracle(L): exact current rates, but L epochs late (an epoch is 20 blocks of 7 rounds = 140
    rounds).  With rollback of depth D, a reaction delay L behaves like a delay max(0, L - D).

Twin: the Test-L localizer (syndrome CUSUMs, footprint naming, targeted reweighting) plus, for every
    ancilla, two CUSUMs on its readout signal (|x| histogram per epoch): one for a loss of separation
    (snr0 / kS) and one for more decays during readout (decay rate x fD).  On an alarm the twin fits
    (snr, q) by maximum likelihood to the readouts since the CUSUM start; if the fit shows a change it
    names that ancilla (no localisation needed) and
      - sets the readout part of the ancilla's time-like edges to the fitted readout error (Z ancillas);
      - scales the ancilla's other error sources by the fitted decay-rate ratio f (mode 'full'), by
        1 + (f - 1) / 2 (mode 'half': the twin assumes T1 explains only half of those errors) or not
        at all (mode 'ro').
    The edges it touches are frozen at their values at the alarm (the slow estimator keeps learning
    underneath but is not used on them) and restored when the window fit returns to baseline.
    Syndrome-based overrides naming a qubit that the analog twin is handling are ignored.
"""
from collections import deque
import numpy as np
from arms import Static, Slow, WMIN, q_off
from sampler import weights_from_p
import ro

LSTEP = np.log(2) / 8


def qlog(x):
    return float(np.exp(np.round(np.log(max(x, 1e-9)) / LSTEP) * LSTEP))


class DelayedOracle(Static):
    kind = 'doracle'
    def __init__(self, name, m, cal, L):
        super().__init__(name, m, cal)
        self.L = int(L); self.hist = deque(maxlen=self.L + 1)
    def weights(self, true_pe):
        self.hist.append(true_pe)
        return weights_from_p(self.hist[0], WMIN)


class Twin(Slow):
    kind = 'twin'

    def __init__(self, name, m, cal, R, cusum, gating, reseed, tmax, footprint, analog):
        super().__init__(name, m, cal, R, 1, cusum, gating, reseed, tmax, footprint)
        self.an = analog
        rl = cal['roles']
        self.anc_q = rl['anc_q']; self.nZa = rl['nZa']; self.tl = rl['tl']
        b = cal['ro_base']
        self.snr0, self.q0, self.p0 = b['snr0'], b['q0'], b['p0']
        self.kap0 = -np.log1p(-np.minimum(self.q0, 0.999))
        nA = len(self.anc_q); self.nA = nA
        kS = analog.get('kS', 1.1); fD = analog.get('fD', 3.0)
        qD = -np.expm1(-self.kap0 * fD)
        lb = np.log(np.maximum(ro.bin_probs(self.snr0, self.q0, self.kap0), 1e-300))
        lS = np.log(np.maximum(ro.bin_probs(self.snr0 / kS, self.q0, self.kap0), 1e-300))
        lD = np.log(np.maximum(ro.bin_probs(self.snr0, qD, self.kap0 * fD), 1e-300))
        self.llrS = lS - lb; self.llrD = lD - lb                       # (nA, NB)
        self.ah = float(analog['h'])        # (not self.h: that is the regional CUSUM threshold of Slow)
        self.SS = np.zeros(nA); self.SD = np.zeros(nA)
        self.eS = np.zeros(nA, int); self.eD = np.zeros(nA, int)
        self.W = int(analog.get('W', 20)); self.Wmax = int(analog.get('Wmax', 400))
        self.ring = deque(maxlen=self.Wmax); self.ep_i = 0
        self.mode = analog.get('mode', 'full')
        self.on_p = analog.get('on_p', 1.2); self.on_f = analog.get('on_f', 1.3)
        self.off_p = analog.get('off_p', 1.12); self.off_f = analog.get('off_f', 1.15)
        self.active = {}
        self.frozen = np.zeros(m.E, bool); self.fval = np.zeros(m.E); self.fref = np.zeros(m.E, int)
        self.alog = []; self.n_false = 0; self.n_act = 0; self.act_epochs = 0
        self.grid = ro.grid()
        self.gidx = [self.grid.index(self.snr0[a], self.q0[a]) for a in range(nA)]
        self.tau = float(analog.get('tau', 4.0)); self.every = int(analog.get('every', 2))

    # ---------------------------------------------------------------- analog monitor
    def _sum_since(self, e0, a):
        n = max(1, min(self.ep_i - e0, len(self.ring)))
        r = self.ring
        return np.sum([r[-k][a] for k in range(1, n + 1)], axis=0)

    def _edges(self, a):
        g = int(self.anc_q[a])
        u = self._shares(g)
        sel = u >= 0.02
        if a < self.nZa:
            sel = sel.copy(); sel[self.tl[a]] = True
        return g, u, sel

    def _activate(self, a, e0, snr, q):
        g, u, sel = self._edges(a)
        idx = np.nonzero(sel)[0]
        new = idx[~self.frozen[idx]]
        self.fval[new] = self.p[new]; self.frozen[new] = True
        self.fref[idx] += 1
        self.active[a] = dict(g=g, u=u, idx=idx, e0=e0, start=self.ep_i)
        self._set(a, snr, q)
        self.n_act += 1

    def _set(self, a, snr, q):
        o = self.active[a]
        kap = -np.log1p(-min(q, 0.999))
        f = max(kap / max(self.kap0[a], 1e-9), 1.0)
        pr = float(ro.p_err_model(snr, q))
        o['f'] = qlog(f); o['pro'] = qlog(max(pr, self.p0[a])); o['snr'] = snr; o['q'] = q

    def _deactivate(self, a):
        o = self.active.pop(a)
        idx = o['idx']
        self.fref[idx] -= 1
        done = idx[self.fref[idx] == 0]
        self.p[done] = self.fval[done]; self.frozen[done] = False
        self.alog.append(['off', self.ep_i, int(a)])

    def _analog(self, H):
        self.ep_i += 1
        self.ring.append(H.astype(np.float64))
        lS = (H * self.llrS).sum(1); lD = (H * self.llrD).sum(1)
        nS = self.SS + lS; nD = self.SD + lD
        rS = nS <= 0; rD = nD <= 0
        self.SS = np.where(rS, 0.0, nS); self.SD = np.where(rD, 0.0, nD)
        self.eS[rS] = self.ep_i; self.eD[rD] = self.ep_i
        for a in range(self.nA):
            if a in self.active:
                o = self.active[a]
                if (self.ep_i - o['start']) % self.every:
                    continue
                e0 = max(o['e0'], self.ep_i - self.W)
                hs = self._sum_since(e0, a)
                snr, q, mdl = self.grid.fit_sel(hs, *self.gidx[a], self.tau)
                self._set(a, snr, q)
                kap = -np.log1p(-min(q, 0.999)); f = kap / max(self.kap0[a], 1e-9)
                pr = float(ro.p_err_model(snr, q))
                quiet = mdl == 0 or (f < self.off_f and (a >= self.nZa or pr < self.off_p * self.p0[a]))
                if quiet and self.ep_i - o['start'] >= 2:
                    self._deactivate(a)
                    self.SS[a] = 0; self.SD[a] = 0; self.eS[a] = self.ep_i; self.eD[a] = self.ep_i
                continue
            if self.SS[a] > self.ah or self.SD[a] > self.ah:
                cand = []
                if self.SS[a] > self.ah: cand.append(self.eS[a])
                if self.SD[a] > self.ah: cand.append(self.eD[a])
                e0 = int(min(cand))
                hs = self._sum_since(e0, a)
                snr, q, mdl = self.grid.fit_sel(hs, *self.gidx[a], self.tau)
                kap = -np.log1p(-min(q, 0.999)); f = kap / max(self.kap0[a], 1e-9)
                pr = float(ro.p_err_model(snr, q))
                changed = mdl > 0 and (f >= self.on_f or (a < self.nZa and pr >= self.on_p * self.p0[a]))
                if changed:
                    self._activate(a, e0, snr, q)
                    self.alog.append(['on', self.ep_i, int(a), int(self.anc_q[a]), e0, round(snr, 3),
                                      round(q, 5), round(pr, 5), round(f, 2)])
                else:
                    self.n_false += 1
                    self.alog.append(['false', self.ep_i, int(a), e0, round(snr, 3), round(q, 5)])
                    self.SS[a] = 0; self.SD[a] = 0; self.eS[a] = self.ep_i; self.eD[a] = self.ep_i
        if self.active:
            self.act_epochs += 1

    def update(self, X, crr, H=None, mask=None):
        super().update(X, crr, mask)
        if H is not None:
            self._analog(H)

    # ---------------------------------------------------------------- weights
    def weights(self, true_pe):
        m = self.m
        p = np.where(self.frozen, self.fval, self.p)
        handled = {o['g'] for o in self.active.values()}
        if self.fp and self.ovr:
            byq = {}
            for o in self.ovr.values():
                if o['q'] in handled:
                    continue
                if o['q'] not in byq or o['r'] > byq[o['q']]['r']:
                    byq[o['q']] = o
            fac = np.ones_like(p)
            for o in byq.values():
                fac *= 1 + o['u'] * (o['r'] - 1)
            p = p * fac
        if self.active:
            fac = np.ones_like(p)
            for a, o in self.active.items():
                f = o['f']
                if self.mode == 'half':
                    f = 1 + 0.5 * (f - 1)
                elif self.mode == 'ro':
                    f = 1.0
                fac[o['idx']] *= 1 + o['u'][o['idx']] * (f - 1)
            p = p * fac
            for a, o in self.active.items():
                if a < self.nZa:
                    e = self.tl[a]; p0 = self.p0[a]
                    # readout part replaced: remove the calibrated readout error, add the fitted one
                    other = np.clip((np.where(self.frozen[e], self.fval[e], self.p[e]) - p0) / (1 - 2 * p0), 1e-7, 0.45)
                    f = o['f'] if self.mode == 'full' else (1 + 0.5 * (o['f'] - 1) if self.mode == 'half' else 1.0)
                    other = other * (1 + o['u'][e] * (f - 1))
                    pr = o['pro']
                    p[e] = other + pr - 2 * other * pr
        p = np.clip(p, 1e-7, 0.45)
        w = weights_from_p(p, WMIN)
        if self.cusum:
            off = self.off
            if self.fp and self.nooff:
                off = np.where(self.fstate == 3, 0.0, off)
            w = np.maximum(w - off[m.ereg], WMIN)
        return w

    def info(self):
        d = super().info()
        d['analog'] = dict(activations=self.n_act, false_alarms=self.n_false, active_epochs=self.act_epochs,
                           log=self.alog)
        return d
