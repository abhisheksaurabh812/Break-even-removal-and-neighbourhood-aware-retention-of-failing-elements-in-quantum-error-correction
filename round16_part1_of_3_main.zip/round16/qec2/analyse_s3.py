"""Shared-rates re-test: training picks + headroom gate, paired comparisons, rules.  python3 analyse_s3.py"""
import glob, json
import numpy as np
from analyse2 import sign_test


def load(pat):
    fs = sorted(glob.glob(pat))
    if not fs:
        return None
    names = None; FM = []; FU = []
    for f in fs:
        z = np.load(f, allow_pickle=True); nm = list(z['names']); names = names or nm; assert nm == names
        FM.append(np.stack([z['failM'][i][z['vM']] for i in range(len(nm))]))
        FU.append(np.stack([z['failU'][i][z['vU']] for i in range(len(nm))]))
    return dict(files=len(fs), names=names, FM=np.concatenate(FM, 1), FU=np.concatenate(FU, 1))


def cmp(a, b):
    x = int(((a == 1) & (b == 0)).sum()); y = int(((a == 0) & (b == 1)).sum())
    fa, fb = int(a.sum()), int(b.sum())
    return dict(fails=fa, ref_fails=fb, rel=round(fa / fb - 1, 5), arm_only=x, ref_only=y, p=sign_test(x, y))


out = {}
tr = [load(f'out/s3_train_int_k{k}_s*.npz') for k in (100, 500)]
picks = {}
if all(tr):
    tot = {n: sum(int(d['FM'][d['names'].index(n)].sum()) for d in tr) for n in ('sep-own', 'sep-clock')}
    picks['best_sep'] = min(tot, key=tot.get); picks['train_merged'] = tot
    d = tr[0]; ix = d['names'].index
    g = cmp(d['FM'][ix('oracle')], d['FM'][ix('static-est')]); picks['G0_headroom'] = g
    picks['G0_pass'] = bool(g['rel'] <= -0.06)
out['picks'] = picks
bs = picks.get('best_sep', 'sep-own')
for gname, pat in (('interleaved_1pct', 'out/s3_test_int_k100_s*.npz'), ('interleaved_0.2pct', 'out/s3_test_int_k500_s*.npz'),
                   ('fresh_5pct', 'out/s3_test_fresh_k20_s*.npz')):
    d = load(pat)
    if d is None:
        continue
    ix = d['names'].index
    r = dict(files=d['files'], merged_blocks=int(d['FM'].shape[1]), unmerged_blocks=int(d['FU'].shape[1]),
             totals_merged={n: int(d['FM'][k].sum()) for k, n in enumerate(d['names'])},
             totals_unmerged={n: int(d['FU'][k].sum()) for k, n in enumerate(d['names'])}, merged={}, unmerged={})
    for a, b in (('shared', bs), ('shared-ratio', bs), ('shared', 'static-shared'), ('shared-ratio', 'static-shared'),
                 ('shared-ratio', 'shared'), ('oracle', 'static-est'), ('oracle', bs), (bs, 'static-est'),
                 ('static-shared', 'static-est'), ('sep-clock', 'sep-own')):
        r['merged'][f'{a} vs {b}'] = cmp(d['FM'][ix(a)], d['FM'][ix(b)])
        r['unmerged'][f'{a} vs {b}'] = cmp(d['FU'][ix(a)], d['FU'][ix(b)])
    fb, fo = int(d['FM'][ix(bs)].sum()), int(d['FM'][ix('oracle')].sum())
    r['room_captured'] = {a: round(float((fb - int(d['FM'][ix(a)].sum())) / (fb - fo)), 3) if fb != fo else None
                          for a in ('shared', 'shared-ratio', 'static-shared')}
    out[gname] = r
rules = {}
for arm in ('shared', 'shared-ratio'):
    for g, rule in (('interleaved_1pct', 'R1'), ('interleaved_0.2pct', 'R2')):
        if g in out:
            x = out[g]['merged'][f'{arm} vs {bs}']; rules[f'{arm}_{rule}_{g}'] = bool(x['rel'] <= -0.03 and x['p'] < 0.01)
    if 'fresh_5pct' in out:
        x = out['fresh_5pct']['merged'][f'{arm} vs static-shared']; rules[f'{arm}_R3_fresh'] = bool(x['rel'] <= -0.03 and x['p'] < 0.01)
    rules[f'{arm}_R4_unmerged'] = bool(all(out[g]['unmerged'][f'{arm} vs {bs}']['rel'] <= 0.005 for g in out if g != 'picks'))
out['rules'] = rules
print(json.dumps(out, indent=1))
