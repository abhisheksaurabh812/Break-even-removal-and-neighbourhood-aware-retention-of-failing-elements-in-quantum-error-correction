"""Ideal value of exclusion, independent of my per-qubit models: Stim sampling + PyMatching from Stim's own DEM.
For one bulk data qubit and one bulk Z ancilla, compare
  keep(f):  original circuit with every channel touching the qubit scaled by f, decoded with its exact DEM
  excl:     the qubit switched out (deformed circuit, nominal noise), decoded with its exact DEM
python3 ideal_excl.py <p> <shots>"""
import sys, os, subprocess, tempfile, json
import numpy as np
import pymatching
import deform

HERE = os.path.dirname(os.path.abspath(__file__))
STIM = os.path.join(os.path.dirname(HERE), 'bin', 'stim')
TMP = tempfile.mkdtemp(dir=os.path.join(os.path.dirname(HERE)))


def ler(circ, shots, chunk=200000):
    cf = os.path.join(TMP, 'c.stim'); df = os.path.join(TMP, 'c.dem'); of = os.path.join(TMP, 's.b8')
    open(cf, 'w').write(circ)
    subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
    m = pymatching.Matching.from_detector_error_model_file(df)
    nd = m.num_detectors
    fails = 0; done = 0; seed = 1
    while done < shots:
        n = min(chunk, shots - done)
        subprocess.run([STIM, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        nb = (nd + 1 + 7) // 8
        raw = np.fromfile(of, dtype=np.uint8).reshape(n, nb)
        bits = np.unpackbits(raw, axis=1, bitorder='little')[:, :nd + 1]
        pred = m.decode_batch(bits[:, :nd])[:, 0]
        fails += int((pred != bits[:, nd]).sum()); done += n; seed += 1
    return fails, shots


if __name__ == '__main__':
    p = float(sys.argv[1]); shots = int(sys.argv[2]); d = 7
    res = {}
    for name, c in (('data', (7, 7)), ('zanc', (6, 6))):
        txt, _ = deform.circuit(d, d, p, excl=[c])
        fe, n = ler(txt, shots)
        row = dict(excl=fe)
        for f in (1, 3, 10, 30, 100):
            txt, _ = deform.circuit(d, d, p, scale={c: f})
            fk, _ = ler(txt, shots)
            row[f'keep_f{f}'] = fk
        res[name] = row
        print(name, c, json.dumps(row), flush=True)
    res['shots'] = shots; res['p'] = p
    json.dump(res, open(os.path.join(HERE, 'out', f'ideal_excl_p{p}.json'), 'w'), indent=1)
