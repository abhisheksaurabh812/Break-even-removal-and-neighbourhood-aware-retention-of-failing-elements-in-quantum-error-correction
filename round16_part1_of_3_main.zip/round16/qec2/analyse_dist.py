"""
Equivalent-qubit saving from the distance runs (mixed scenario, d = 3, 5, 7).
For each arm: logical error per round at each distance, log-linear fit in d, then the
distance the static decoder would need to match the arm's error rate at d = 7,
converted to qubits (2d^2 - 1 for the rotated surface code).
"""
import glob, json
import numpy as np


def per_round(files, d):
    fails = None; blocks = 0; names = None
    for f in files:
        z = np.load(f, allow_pickle=True)
        names = list(z['names'])
        fz = z['fails'].reshape(len(names), -1)
        fails = fz.sum(1) if fails is None else fails + fz.sum(1)
        blocks += fz.shape[1]
    P = fails / blocks
    return names, 1 - (1 - P) ** (1.0 / d), fails, blocks


rows = {}
for d, pat in ((3, 'out/dist_d3_s*.npz'), (5, 'out/dist_d5_s*.npz'), (7, 'out/test_mixed_s*.npz')):
    fs = sorted(glob.glob(pat))
    if fs:
        rows[d] = per_round(fs, d)
ds = sorted(rows)
names = rows[ds[0]][0]
out = {'distances': ds, 'per_round': {}, 'fails': {}, 'fit': {}, 'equivalent': {}}
for k, n in enumerate(names):
    out['per_round'][n] = [float(rows[d][1][k]) for d in ds]
    out['fails'][n] = [int(rows[d][2][k]) for d in ds]
    a, b = np.polyfit(ds, np.log([rows[d][1][k] for d in ds]), 1)[::-1]   # ln p = a + b d
    out['fit'][n] = dict(intercept=float(a), slope=float(b), Lambda_per_2=float(np.exp(-2 * b)))
s = out['fit']['static']
for n in names:
    p7 = out['per_round'][n][ds.index(7)] if 7 in ds else None
    if p7 is None:
        continue
    dstar = (np.log(p7) - s['intercept']) / s['slope']
    out['equivalent'][n] = dict(static_distance_needed=float(dstar),
                               qubit_saving_vs_static=float(1 - (2 * 49 - 1) / (2 * dstar ** 2 - 1)))
print(json.dumps(out, indent=1))
