"""Round-13 development configurations (used seeds only).   python3 make_cfg13.py dev [name=json-of-name13 ...]
Each dev configuration is the round-12 test configuration of that test with ONLY the new arms: copies of round 12's
sz_w12r gate (watch 'once' + 'light') whose learner is arms13.Sized7 (the round-13 naming, settings sizer['name13']),
all in their own sample stream ("extra": "w3").  The main detection-event stream (every epoch with no qubit switched
out) and the failure process are fixed by the seed alone, so a dev run is compared, epoch by epoch, with the round-12
run of the same seed (out12/<test>_s<seed>.npz: sz_w12r, sz_w12, sz_watch, sz, sz_all, loc); only epochs with a
qubit switched out are sampled independently.  Dropping the round-12 arms makes a dev run several times cheaper."""
import json, copy, os, sys
from make_cfg9 import dump

TESTS = ('d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed', 'long_severe', 'long_mixed', 'd9_hwlike')


def watch13_arm(c, name, **name13):
    hole = name13.pop('_hole', None)               # dict -> the reshaped circuit's own estimates (PolicyArmFieldWatch3)
    w = [a for a in c['arms'] if a['name'] == 'sz_w12r'][0]
    a = copy.deepcopy(w)
    a['name'] = name; a['extra'] = 'w3'
    if hole is not None:
        a['kind'] = 'policy-field-watch3'; a['hole'] = dict(hole)
    a['inner']['kind'] = 'sized7'
    sz = dict(a['inner'].get('sizer', {})); sz.pop('recheck', None); sz['name13'] = dict(name13)
    a['inner']['sizer'] = sz
    return a


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'dev'
    variants = [('sz_w13', {})]
    for arg in sys.argv[2:]:
        n, v = arg.split('=', 1); variants.append((n, json.loads(v)))
    if what == 'dev':
        os.makedirs('dev13', exist_ok=True)
        for t in TESTS:
            c = json.load(open(f'cfg12/{t}.json'))
            c['arms'] = [watch13_arm(c, n, **kw) for n, kw in variants]
            dump(c, f'dev13/{t}.json')
        print('dev13 arms:', [(n, kw) for n, kw in variants])


# ---------------------------------------------------------------- round-13 test configurations (draft, not frozen)
# Round 12's configuration of each test with the reference arms the round-13 rules use (localizer, reweighting,
# switch-out-all, the round-10 gate sz_field, round 12's best gate sz_w12r) plus the new gate sz_w13 ("extra": "w3"):
# round 12's sz_w12r with the round-13 learner (arms13.Sized7) and the reshaped circuit's own estimates while a qubit is
# out (arms13.PolicyArmFieldWatch3).
# Dropped to save time (no rule uses them): oracle, oracle_gated, sz_watch, sz_w12.
TEST_ARMS = ('loc', 'sz', 'sz_all', 'sz_field', 'sz_w12r')


def write_tests():
    os.makedirs('cfg13', exist_ok=True)
    for t in TESTS:
        c = json.load(open(f'cfg12/{t}.json'))
        new = watch13_arm(c, 'sz_w13', _hole={})
        c['arms'] = [a for a in c['arms'] if a['name'] in TEST_ARMS] + [new]
        dump(c, f'cfg13/{t}.json')
    c = json.load(open('cfg13/d9_mixed.json'))
    print('cfg13 arms:', [(a['name'], a.get('extra', False)) for a in c['arms']])


# Lab-practice baselines (reported, no rule): what labs run during an experiment, on the same seeds after the main runs.
# fix_gen: fixed weights from one uniform error rate (the nominal rate) for every qubit; fix_cal: fixed weights from a
# calibration experiment at the start of the run (1,000,000 rounds at the starting rates); refit_1s: weights
# re-estimated from the last 1,000,000 rounds (about a second) and replaced every 1,000,000 rounds.
BASELINES = [dict(kind='static-generic', name='fix_gen'), dict(kind='static', name='fix_cal', base='est'),
             dict(kind='slow', name='refit_1s', R=1000000, s=0)]


def write_baselines():
    os.makedirs('cfg13', exist_ok=True)
    for t in TESTS:
        c = json.load(open(f'cfg12/{t}.json'))
        c['arms'] = [dict(a) for a in BASELINES]
        dump(c, f'cfg13/base_{t}.json')
    print('cfg13 baseline arms:', [a['name'] for a in BASELINES])


if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == 'test':
    write_tests()
    write_baselines()
