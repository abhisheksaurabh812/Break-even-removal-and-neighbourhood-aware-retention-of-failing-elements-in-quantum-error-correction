"""Round 14: compare analyse14.py's numbers (out14/res_14.json) with the independent recount (out14/recount14.json)
and re-derive every verdict from the recount alone.   python3 check14.py [res.json recount.json] > out14/check14.json"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out14/res_14.json'))
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out14/recount14.json'))
PRIOR = dict(cut=0.03, sieg=0.15, sieg_rw=0.15)          # as analyse14.py; PREREG_round14.md
C1_MAX = 0.0025
mism = []; n = 0
for key, c in C.items():
    if c is None:
        continue
    test, pair = key.split(': ')
    a = R[key] if test[:2] in ('C1', 'C2', 'P1', 'P2', 'P3') else R[test][pair]
    if a is None:
        mism.append(dict(key=key, field='missing in analyse14')); continue
    for name, x, y in (('fails', a['fails'], c['a']), ('ref_fails', a['ref_fails'], c['b']), ('rel', a['rel'], c['rel']),
                       ('z', a['z'], c['z']), ('per_seed', a['per_seed'], c['per_seed']),
                       ('boot_lo', a['boot95']['lo'], c['boot95'][0]), ('boot_hi', a['boot95']['hi'], c['boot95'][1])):
        n += 1
        if x != y:
            mism.append(dict(key=key, field=name, analyse=x, recount=y))


def beats(c, pct):
    return c['rel'] <= -pct and c['p'] < 0.01 and c['z'] < 0 and max(c['per_seed']) <= 0.01


g_ = lambda k: C.get(k)
v = {}
g = 'sz_w14'
k = lambda t, ref: g_(f'{t}: {g} vs {ref}')
if k('d9_mixed', 'sz') and k('d9_mixed', 'sz_all'):
    v[f'R1_{g}_mixed_beats_sz_5pct'] = beats(k('d9_mixed', 'sz'), 0.05)
    v[f'R1_{g}_mixed_beats_all_3pct'] = beats(k('d9_mixed', 'sz_all'), 0.03)
if k('d9_severe', 'sz'):
    v[f'R2_{g}_severe_beats_sz_10pct'] = beats(k('d9_severe', 'sz'), 0.10)
if k('d9_moderate', 'sz'):
    v[f'R3_{g}_moderate_vs_sz_within_1pct'] = k('d9_moderate', 'sz')['rel'] <= 0.01
if k('d9_realistic', 'loc'):
    x = k('d9_realistic', 'loc')
    v[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = x['rel'] <= 0.01 and x['boot95'][1] <= 0.02
if k('pairs_mixed', 'sz'):
    v[f'R5_{g}_pairs_vs_sz_within_1pct'] = k('pairs_mixed', 'sz')['rel'] <= 0.01
if k('long_severe', 'sz'):
    v[f'R6_{g}_long_severe_beats_sz_10pct'] = beats(k('long_severe', 'sz'), 0.10)
if k('long_mixed', 'sz') and k('long_mixed', 'sz_all'):
    v[f'R7_{g}_long_mixed_beats_sz_5pct'] = beats(k('long_mixed', 'sz'), 0.05)
    v[f'R7_{g}_long_mixed_beats_all_3pct'] = beats(k('long_mixed', 'sz_all'), 0.03)
if k('d9_hwlike', 'sz'):
    v[f'R8_{g}_hwlike_beats_sz_10pct'] = beats(k('d9_hwlike', 'sz'), 0.10)
c = g_('C1_pooled_all: sz_w14 vs sz_w13')
if c:
    v['C1_sz_w14_vs_sz_w13_all_within_0.25pct'] = c['rel'] <= C1_MAX
c = g_('C2_pooled_long: sz_w14 vs sz_w13')
if c:
    v['C2_sz_w14_fewer_failures_than_sz_w13_long_pooled'] = c['rel'] < 0 and c['z'] < 0 and c['p'] < 0.01
c = g_('P1_pooled_all: sz_w14 vs cut')
if c:
    v[f"P1_sz_w14_beats_cut_all_{round(100 * PRIOR['cut'])}pct"] = c['rel'] <= -PRIOR['cut'] and c['z'] < 0 and c['p'] < 0.01
for i, q in ((2, 'sieg'), (3, 'sieg_rw')):
    c = g_(f'P{i}_pooled_prior_subset: sz_w14 vs {q}')
    if c:
        v[f'P{i}_sz_w14_beats_{q}_subset_{round(100 * PRIOR[q])}pct'] = c['rel'] <= -PRIOR[q] and c['z'] < 0 and c['p'] < 0.01
ra = R.get('rules', {})
print(json.dumps(dict(values_compared=n, mismatches=mism, recount_verdicts=v, analyse_verdicts=ra,
                      verdicts_agree={k: v[k] == ra.get(k) for k in v}, all_agree=all(v[k] == ra.get(k) for k in v)
                      and set(v) == set(ra)), indent=1))
