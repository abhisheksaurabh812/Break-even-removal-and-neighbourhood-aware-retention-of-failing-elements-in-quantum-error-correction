"""Independent recount of round-9 decision numbers straight from the raw files (no code shared with
analyse9.py / analyse8.py): totals, relative differences, paired-epoch z, per-seed differences and the seed
bootstrap behind G1-G4, plus the old gate on the same seeds.    python3 recount9.py > out9/recount9.json"""
import json, os, math
import numpy as np


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z['fails'][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b):
    if not all(os.path.exists(p) for p in paths):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    n = len(paths)
    pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
    st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
    return dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
                p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()],
                boot95=[round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)])


P = lambda s, r: [f'out9/test_{s}_s{x}.npz' for x in r]
res = {}
for tag, paths, a, b in (
        ('G1 realistic', P('realistic', range(5001, 5011)), 'sz_field', 'loc'),
        ('G2 mixed', P('mixed', range(5101, 5111)), 'sz_field', 'sz'),
        ('G2 mixed', P('mixed', range(5101, 5111)), 'sz_field', 'sz_all'),
        ('G3 severe', P('severe', range(5201, 5204)), 'sz_field', 'sz'),
        ('G4 moderate', P('moderate', range(5301, 5306)), 'sz_field', 'sz'),
        ('old gate realistic', P('realistic', range(5001, 5011)), 'sz_gated', 'loc'),
        ('old gate mixed', P('mixed', range(5101, 5111)), 'sz_gated', 'sz'),
        ('old gate mixed', P('mixed', range(5101, 5111)), 'sz_gated', 'sz_all'),
        ('old gate severe', P('severe', range(5201, 5204)), 'sz_gated', 'sz'),
        ('old gate moderate', P('moderate', range(5301, 5306)), 'sz_gated', 'sz'),
        ('field vs old gate realistic', P('realistic', range(5001, 5011)), 'sz_field', 'sz_gated'),
        ('field vs old gate mixed', P('mixed', range(5101, 5111)), 'sz_field', 'sz_gated'),
        ('field vs old gate severe', P('severe', range(5201, 5204)), 'sz_field', 'sz_gated'),
        ('field vs old gate moderate', P('moderate', range(5301, 5306)), 'sz_field', 'sz_gated')):
    res[f'{tag}: {a} vs {b}'] = pair(paths, a, b)
print(json.dumps(res, indent=1))
