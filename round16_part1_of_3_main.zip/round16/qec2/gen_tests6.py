"""Fill the tuned analog threshold into the round-6 test configs and write two balanced job lists."""
import json, sys
pick = json.load(open('out6/res_tune.json'))['pick']
h = int(pick.split('_h')[1])
scen = ['t1m_severe', 'ro_short', 't1m', 'ro', 't1d', 't1d_severe', 'ro_severe']
for s in scen:
    c = json.load(open(f'cfg6/test_{s}.json'))
    for a in c['arms']:
        if a['kind'] == 'twin':
            a['analog']['h'] = h
    json.dump(c, open(f'cfg6/test_{s}.json', 'w'), indent=1)
jobs = [(s, sd) for s in scen for sd in (901, 902, 903)]
A = [j for i, j in enumerate(jobs) if i % 2 == 0]; B = [j for i, j in enumerate(jobs) if i % 2 == 1]
for nm, L in (('A', A), ('B', B)):
    open(f'jobs6_test{nm}.txt', 'w').write(''.join(f'cfg6/test_{s}.json out6/test_{s}_s{sd}.npz seed={sd}\n' for s, sd in L))
print('h =', h); print(open('jobs6_testA.txt').read()); print(open('jobs6_testB.txt').read())
