"""
Round 11: the field-aware gate of round 9 (arms9.PolicyArmField, unchanged) plus a watch on the hole.

Round 10 (d9_mixed, seed 6101) exposed a blind zone.  While a qubit is switched out, the twin stops using
every Z ancilla whose detectors change in the reshaped circuit (run3.deformed_model: for one bulk data qubit
at d = 9, 11 of the 40 Z ancillas), and the decoder gives every changed error mechanism its start-of-run
calibration probability.  A failure that starts in that zone is neither seen nor weighted until the hole
closes: in seed 6101 a Z ancilla failing at 65x went unseen for 273,000 rounds, while plain reweighting,
which never reshapes the circuit, handled it.

PolicyArmFieldWatch (with learner Sized5) changes three things, all only while a switch-out is active:
 1. Weights.  The changed mechanisms (those with no counterpart in the full circuit) get probabilities from
    the twin's current view of each qubit projected onto the reshaped circuit, md.edge_p(view), instead of
    the calibration.  view = calibration x the local level around the nearest hole relative to that
    level at calibration (the gate's ring estimate, on the learner's grid) x the learner's fitted factor for
    every qubit it is handling and has not switched out.  Mechanisms with a counterpart keep the learner's
    weights, as before.
 2. Watch.  Each epoch, every changed Z ancilla's interior detection count is compared with its expected
    count under `view` in the reshaped circuit, by a Poisson CUSUM (rho, h as the twin's per-ancilla
    monitor).  An alarm means something there has changed that the twin does not know about.  Two responses:
    mode 'return': the hole nearest that ancilla is probed and switched back in at once, and held in (its
       size pinned at the probed value, no switch-out) for `hold` epochs, so that the twin can see, name and
       size what happened; after that the gate decides afresh.  Logged as an 'in' entry ending in 'watch'.
    mode 'zone': the hole stays.  The twin sizes inside the reshaped circuit: among the qubits whose errors
       reach the alarmed ancilla (not a hole, not already handled), it takes the one whose factor, fitted by
       Poisson likelihood to the changed ancillas' counts over the last `win` epochs, gains most over factor 1
       (at least `gain` in log-likelihood, factor >= 1.25), and adds it to the view.  Every epoch it refits
       these factors (dropping one below 1.25 or with gain < 2) and, from the same counts, the size of every
       handled qubit whose evidence is hidden (see 3).  These zone factors enter the weights through 1; they
       are dropped when the hole that hides them closes, and the learner then names and sizes as usual.  The
       gate never acts on them.
 3. Keep what is hidden (learner Sized5 = Sized4 plus this).  A qubit the learner is handling whose evidence is
    mostly hidden by the reshaped circuit (at least half of its interior detection share on ignored ancillas)
    is not refitted or ended by the learner until its detectors are back; it keeps its last fitted size (mode
    'return') or is sized from the changed ancillas' counts (mode 'zone').  In Sized4 its sliding window
    filled with empty epochs, the fit fell to 1 and the qubit was ended as 'quiet' about one window after the
    hole opened (round 10, pairs test: 7 partners named before a hole opened were dropped this way while
    still failing).
Nothing else changes: gate, crossover table, probe, at most two compatible switch-outs.
"""
from collections import deque
import numpy as np
from arms9 import PolicyArmField
from arms7 import qround
from arms7b import Sized4
from arms import WMIN
from sampler import weights_from_p


class Sized5(Sized4):
    kind = 'sized5'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        W = self.m.fp_W
        self.Wn = W / np.maximum(W.sum(1, keepdims=True), 1e-30)
        self.n_kept = 0

    def update(self, X, crr, mask=None):
        hidden = {}
        if mask is not None:
            off = np.asarray(mask['anc_off'], bool)
            for g, o in self.sovr.items():
                if not o['susp'] and float(self.Wn[g][off].sum()) >= 0.5:
                    hidden[g] = o; o['susp'] = True          # hide from refit, hand-over and pin countdown
        super().update(X, crr, mask)
        for g, o in hidden.items():
            if self.sovr.get(g) is o:
                o['susp'] = False
        self.n_kept += len(hidden)

    def info(self):
        d = super().info(); d['sized']['kept_hidden_epochs'] = self.n_kept
        return d


class PolicyArmFieldWatch(PolicyArmField):
    kind = 'policy'

    def __init__(self, *a, watch=None, **k):
        super().__init__(*a, **k)
        w = dict(watch or {})
        self.w_weights = bool(w.get('weights', True))
        self.w_watch = bool(w.get('watch', True))
        self.w_level = bool(w.get('level', True))
        self.w_rho = float(w.get('rho', 2.0))
        self.w_h = float(w.get('h', 15.0))
        self.w_hold = int(w.get('hold', self.probe['period']))
        self.w_mode = w.get('mode', 'return')            # 'return': close the hole; 'zone': size inside it
        self.w_win = int(w.get('win', 20)); self.w_gain = float(w.get('gain', 10.0))
        m = self.base
        qc = m.det_rate(self.cal_f0)
        qn = np.array([qc[u].mean() if len(u) else np.nan for u in self.ints])
        self.ucal = -0.5 * np.log1p(-2 * np.clip(qn, 1e-9, 0.49))       # per Z ancilla, at calibration
        self.lcal = {}
        self.zones = {}
        self.S = None; self.zkey = None
        self._view = None
        self.n_watch = 0
        self.zov = {}; self.zwin = deque(maxlen=self.w_win); self.zlog = []
        Wf = m.fp_W
        self.Wn = Wf / np.maximum(Wf.sum(1, keepdims=True), 1e-30)

    # ------------------------------------------------------------ the twin's view of each qubit
    def level_cal(self, g):
        """Level around g at calibration, measured exactly as level() measures it now."""
        v = self.lcal.get(g)
        if v is None:
            r = self.ring(g)
            if len(r) < self.ring_min:
                foot = set(int(b) for b in self.inner._st(g)['anc'])
                r = np.array([b for b in range(self.base.nA) if b not in foot and np.isfinite(self.unom[b])], int)
            v = float(np.median(self.ucal[r] / self.unom[r])) if len(r) else 1.0
            self.lcal[g] = v
        return v

    def view(self, skip=None):
        m = self.base
        f = self.cal_f0.copy()
        if self.w_level and self.cur:
            gs = [st['g'] for st in self.cur.values()]
            rel = np.array([qround(max(self.level(g), 1e-3) / max(self.level_cal(g), 1e-3)) for g in gs])
            pos = m.qxy[gs]
            near = ((m.qxy[:, None, :] - pos[None, :, :]) ** 2).sum(-1).argmin(1)
            f = f * rel[near]
        for g, o in self.inner.sovr.items():
            if not o['susp'] and g != skip:
                f[g] *= o['r']
        for g, r in self.zov.items():
            if g != skip:
                f[g] *= r
        return f

    def weights(self, md, true_pe):
        if md is None or not self.w_weights:
            return super().weights(md, true_pe)
        w_base = self.inner.weights(true_pe)
        v = self._view if self._view is not None else self.view()
        w = weights_from_p(md.edge_p(v), WMIN)
        ok = md.emap >= 0
        w[ok] = w_base[md.emap[ok]]
        return w

    # ------------------------------------------------------------ watch on the changed region
    def zone(self, md):
        z = self.zones.get(md.name)
        if z is None:
            inb = np.zeros(md.nZ, bool); inb[md.to_base_cols] = True
            sel = np.nonzero((md.dcls == 1) & ~inb)[0]
            ancs = np.unique(md.danc[sel]).astype(int)
            gid = np.searchsorted(ancs, md.danc[sel])
            Gm = np.zeros((len(ancs), len(sel))); Gm[gid, np.arange(len(sel))] = 1.0
            Dzr = md.Dm[sel].tocsr()
            z = (ancs, [sel[gid == j] for j in range(len(ancs))], dict(sel=sel, gid=gid, Gm=Gm, Dz=Dzr.tocsc(), Dzr=Dzr))
            self.zones[md.name] = z
        return z

    def _zfit(self, md, z, g, nsum, nblk):
        """Factor of qubit g (on the learner's grid, over the view without g's own zone factor) that best explains
        the changed ancillas' counts nsum over nblk blocks (Poisson likelihood); returns (r, gain over r = 1)."""
        ex = z[2]; Dz = ex['Dz']
        fb = self.view(skip=g)
        ps = np.clip(md.p_ref * fb[md.src_g], 0, 0.45)
        Lz = Dz @ np.log1p(-2 * ps)
        ks = np.nonzero(md.src_g == g)[0]
        if not len(ks):
            return 1.0, 0.0
        sub = Dz[:, ks]
        if sub.nnz == 0:
            return 1.0, 0.0
        grid = self.inner.grid
        pk = ps[ks]
        M = np.log1p(-2 * np.minimum(0.45, pk[:, None] * grid[None, :])) - np.log1p(-2 * pk)[:, None]
        q = 0.5 * (1 - np.exp(Lz[:, None] + sub @ M))                 # zone dets x grid
        E = np.clip(ex['Gm'] @ q, 1e-12, None) * nblk                  # groups x grid
        ll = (nsum[:, None] * np.log(E) - E).sum(0)
        i = int(np.argmax(ll))
        return float(grid[i]), float(ll[i] - ll[0])

    def _zone_step(self, md, z, n, B, epoch, alarm_j):
        """Mode 'zone': keep sizing, inside the reshaped circuit, the qubits it has found there; on an alarm,
        find the qubit near the alarmed ancilla that best explains the excess and add it."""
        self.zwin.append(n)
        nsum = np.sum(self.zwin, 0); nblk = B * len(self.zwin)
        off = np.asarray(md.mask['anc_off'], bool)
        # qubits the learner is handling but cannot see (kept by Sized5): size them here instead
        for g, o in list(self.inner.sovr.items()):
            if o['susp'] or float(self.Wn[g][off].sum()) < 0.5:
                continue
            r, gain = self._zfit(md, z, g, nsum, nblk)
            r = max(r, 1.0)
            if abs(np.log(r) - np.log(o['r'])) >= 1.5 * np.log(2) / 8:
                self.zlog.append(['zsize', epoch, int(g), round(o['r'], 2), round(r, 2)])
                o['r'] = qround(r)
        handled = set(g for g, o in self.inner.sovr.items() if not o['susp'])
        for g in list(self.zov):
            r, gain = self._zfit(md, z, g, nsum, nblk)
            if r < 1.25 or gain < 2.0:
                del self.zov[g]; self.zlog.append(['zoff', epoch, int(g), round(r, 2)])
            elif abs(np.log(r) - np.log(self.zov[g])) >= 1.5 * np.log(2) / 8:
                self.zov[g] = qround(r)
        if alarm_j is None:
            return False
        rows = z[1][alarm_j]
        ex = z[2]
        pos = np.searchsorted(ex['sel'], rows)
        ks = np.unique(ex['Dzr'][pos].indices)
        cands = sorted(set(int(x) for x in md.src_g[ks]) - set(st['g'] for st in self.cur.values()) - handled)
        best = (0.0, None, 1.0)
        for g in cands:
            r, gain = self._zfit(md, z, g, nsum, nblk)
            if gain > best[0]:
                best = (gain, g, r)
        gain, g, r = best
        if g is not None and gain >= self.w_gain and r >= 1.25:
            self.zov[g] = qround(r)
            self.zlog.append(['zon', epoch, int(g), round(r, 2), round(gain, 1)])
        else:
            self.zlog.append(['znone', epoch, int(z[0][alarm_j]), round(gain, 1)])
        return True

    def _watch(self, X, md, epoch, ftrue):
        ancs, groups = self.zone(md)[:2]
        if not len(ancs):
            return
        if self.zkey != md.name or self.S is None:
            if self.zkey != md.name:
                self.zwin.clear()
                off = np.asarray(md.mask['anc_off'], bool)
                for g in list(self.zov):
                    if float(self.Wn[g][off].sum()) < 0.5:
                        del self.zov[g]; self.zlog.append(['zgone', epoch, int(g)])
            self.zkey = md.name; self.S = np.zeros(len(ancs))
        v = self.view()
        q = md.det_rate(v)
        xs = X.sum(0).astype(float); B = X.shape[0]
        n = np.array([xs[i].sum() for i in groups]); E = np.array([q[i].sum() for i in groups]) * B
        self.S = np.maximum(0.0, self.S + n * np.log(self.w_rho) - (self.w_rho - 1) * E)
        hit = np.nonzero(self.S >= self.w_h)[0]
        if self.w_mode == 'zone':
            j = int(hit[np.argmax(self.S[hit])]) if len(hit) else None
            if self._zone_step(md, self.zone(md), n, B, epoch, j):
                self.S = np.zeros(len(ancs))
            return
        if not len(hit):
            return
        j = int(hit[np.argmax(self.S[hit])]); b = int(ancs[j]); sj = float(self.S[j])
        pos = np.array(self.base.zanc[b], float)
        c = min(self.cur, key=lambda cc: float(((np.array(cc, float) - pos) ** 2).sum()))
        st = self.cur.pop(c); g = st['g']
        f_true = float(ftrue[g]) / self.fnom
        fp = f_true * float(np.exp(self.probe['sigma'] * self.rng.standard_normal()))
        inn = self.inner
        inn.reset_local(g)
        inn.resume(g, fp / self.fcal_abs[g])
        o = inn.sovr.get(g)
        if o is not None:
            o['cool'] = float(self.w_hold * B * self.base.T)
        self.n_watch += 1
        self.log.append(['in', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), b, round(sj, 1), 'watch'])
        self.S = None; self.zkey = None

    # ------------------------------------------------------------ policy
    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        if md is not None and self.w_watch and self.cur:
            self._watch(X, md, epoch, ftrue)
        elif md is None and self.zov:
            for g in list(self.zov):
                self.zlog.append(['zgone', epoch, int(g)])
            self.zov.clear(); self.zwin.clear(); self.zkey = None
        super().update(X, crr, md, base_AggD, epoch, T, ftrue, to_base)
        self._view = self.view() if self.cur else None

    def info(self):
        d = super().info(); d['watch_returns'] = self.n_watch; d['zone_log'] = self.zlog[:20000]
        return d
