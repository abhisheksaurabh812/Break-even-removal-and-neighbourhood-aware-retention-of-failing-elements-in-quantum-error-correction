# Pre-registration — round 15: the gate under correlated matching

Written 07 Nov 2026 05:34 IST, before any round-15 run. Round 14 (`RESULTS_round14.md`): fourteen of its fifteen checks passed: R1-R8,
C1, and the prior-art checks P1-P3 (7.0% fewer logical failures than a fixed cutoff, 35.1% fewer than detect-and-quarantine
as published, 26.8% fewer than that method tuned and given adaptive weights). C2 failed for want of cases: its rule changed
the result in 4 of the 20 long runs, all four for the better.

Every earlier round decoded with plain matching (PyMatching 2.4 on the Z-type detectors only). This round decodes
every arm with correlated matching as well: PyMatching 2.4 with `enable_correlations=True` on the X- and Z-type
detectors, so that a fault flipping both kinds of check (a Y error on a data qubit, or a two-qubit gate fault with an
X and a Z part) is weighed as one fault. Correlated matching is a stronger, widely used variant of matching; the
question is whether the gate's gains hold with it.

## The gate tested: `sz_w15`
Round 14's gate `sz_w14` with one change: **its keep/switch-out crossover tables are recomputed for correlated
matching.** The procedure is round 9's (`ideal_field9.py`), unchanged except for the decoder (`ideal_field15.py`):
a lone failing qubit in the bulk, its neighbours within Chebyshev distance 4 at L times the base rate, p = 0.003;
logical failures with the qubit switched out against kept at f times the base rate on the grid
L x (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30), capped at 300; the crossover is interpolated in log space. 2,000,000
shots at L = 1, 1.5 and 2, 1,000,000 at L = 3, 4, 6 and 8; Stim's samples and detector error model, the same seeds
as round 9.

Crossovers (failure size f*, in units of the base rate, above which switching the qubit out beats keeping it
with exact rates), plain matching (round 9-10 tables, used by `sz_w14`) -> correlated matching (used by
`sz_w15`):

| L | d = 9 data qubit: plain -> correlated | d = 9 Z ancilla: plain -> correlated | d = 7 data qubit: plain -> correlated | d = 7 Z ancilla: plain -> correlated |
|---|---|---|---|---|
| 1 | 13.25 -> **15.74** | 8.53 -> **8.61** | 13.77 -> **12.94** | 6.44 -> **6.12** |
| 1.5 | 15.07 -> **15.82** | 10.74 -> **10.16** | 14.04 -> **13.53** | 8.28 -> **8.52** |
| 2 | 14.92 -> **15.54** | 12.5 -> **11.51** | 15.34 -> **15.07** | 9.34 -> **9.78** |
| 3 | 16.34 -> **17.62** | 15.09 -> **15.35** | 15.81 -> **15.6** | 12 -> **11.39** |
| 4 | 16.54 -> **19.06** | 17.89 -> **18.24** | 14.23 -> **14.79** | 13.9 -> **13.49** |
| 6 | 14.94 -> **16.16** | 21.06 -> **21.14** | 12.75 -> **12.95** | 16.93 -> **16.91** |
| 8 | 12.57 -> **12.66** | 22.05 -> **20.04** | 11.72 -> **11.64** | 18.04 -> **17.58** |

Switched-out failures at L = 1 (2,000,000 shots), plain -> correlated: d = 9 data qubit 1,963 -> 735; d = 9 Z ancilla 2,019 -> 697; d = 7 data qubit 5,706 -> 2,760; d = 7 Z ancilla 4,761 -> 2,314.

Nothing else in the gate changes: twin, watch, hole rules and probe noise are round 14's, and `sz_w15` uses
`sz_w14`'s probe-noise stream, so the two take the same decisions wherever their tables agree.

## The decoder (`dev15/m15/`, development notes in `NOTES.md`)
- **Models.** Each circuit's detector error model is extended with its X-type detectors and with the errors that flip
  only X-type detectors. One Stim call per circuit, every noise channel tagged by qubit, so each error keeps the
  qubit it comes from (`model15.py`). The extension checks, error source by error source, that it reproduces round
  14's model (qubit, Z-type detectors, observable, probability) and stops otherwise.
- **Samples.** Z-type detection events and observable flips are drawn exactly as round 14 draws them (same
  generators, same calls); the X-type events come from separate generators (`corr15.Sampler15`). So the arms see
  what they saw in round 14 for the same seed and configuration.
- **Each arm's decoder.** An arm is known to the decoder only through its Z-edge weights, as in round 14. Its
  correlated decoder gets per-source probabilities: in units y = -log(1 - 2p), which add over the sources of an edge,
  every source with Z-type pieces is scaled by the ratio of the arm's edge value to the reference edge value (the
  geometric mean over its Z-type edges), and sources seen only by X-type checks keep the reference rate. Reference:
  the field the arm's decoder starts from (the calibration field; one uniform rate for `fix_gen`). This reproduces
  the arm's Z-edge probabilities exactly where an edge's sources have one Z-type piece (1,845 of 1,945 edges at
  d = 9) and to within 6e-5 elsewhere.
- **Arms learn from Z-type events only and decoder output is never fed back**, so every arm takes the decisions it
  would take under plain matching, and both decoders decode the same samples.

Verified before this round (`NOTES.md`, `eq/`):
- the extended models reproduce round 14's sources exactly (d = 5, 7, 9; reshaped circuits included);
- `run15.py` reproduces `run14.py` array for array (failures, switch-outs, flags, events, arm logs) on four
  configurations with switch-outs and early failures (400,000 rounds each, the prior-art arms included);
- with exact rates, correlated matching has 58-70% fewer failures than plain matching for one failing qubit at
  10-200x (d = 9, 200,000 shots per point);
- an arm's mapped weights lose against exact rates only for a qubit failing at 200x (about 3%), because an edge's
  increase is spread over all its sources; the rates of errors only X-type checks see are worth nothing measurable;
- the development check (`dev15/m15/devcheck/`; used seeds 900110-900357 picked for an early strong failure,
  400,000 rounds; the targeted configuration 1,600,000 rounds on seed 900679): all 25 round-15 configurations ran
  without error (25 runs, plus 5 with `run14.py`; the main and targeted ones from the final tables without the
  memory caps, the prior-art and baseline ones as frozen, caps included). Correlated matching had fewer failures
  than plain matching for every arm in every run. `sz_w15` and `sz_w14` took the same decisions in every short run
  except the targeted one (21 epochs apart): the early failures there were far above both tables' crossovers;
- against `run14.py` on round 14's configurations and the same seeds: `loc`, `sz` and `sz_all` identical, array for
  array, in the three main runs compared (d9_mixed, pairs_mixed, long_severe), and every arm identical in a prior-art
  run (d9_severe, memory caps included) and a baseline run (d9_hwlike). `sz_w14` and `cut` differ where expected:
  in round 14, `sz_w13`'s sample stream, drawn first, supplied the reshaped-circuit samples for configurations it
  shared with them; without `sz_w13` they come from `sz_w14`'s own stream (and `cut`'s probe noise follows its
  position in the list, which moved by one).

| One failing qubit, d = 9 (failures in 200,000 shots) | Plain, exact rates | Correlated, exact | Correlated, mapped | Correlated, nominal rates |
|---|---|---|---|---|
| data qubit 10x | 140 | 49 | 50 | 55 |
| data qubit 50x | 300 | 108 | 109 | 183 |
| data qubit 200x | 659 | 269 | 282 | 1,575 |
| Z ancilla 10x | 162 | 52 | 49 | 61 |
| Z ancilla 50x | 607 | 213 | 231 | 1,732 |
| Z ancilla 200x | 1,255 | 532 | 537 | 4,911 |

The plain-matching path of `run15.py` is round 14's decoder itself (`sampler.build_matching`), so `fails` repeats
round 14's numbers for the same seed and arms.

## Tests (fresh seeds; job list `jobs15.txt`: 70 main runs, 10 targeted runs, 32 prior-art runs, 70 baseline runs)
| Test | Configuration | Seeds | Prior-art runs |
|---|---|---|---|
| d9_mixed | round 14's | 11101-11110 | 11101-11104 |
| d9_severe | round 14's | 11201-11205 | 11201-11204 |
| d9_moderate | round 14's | 11301-11305 | 11301-11304 |
| d9_realistic | round 14's | 11001-11010 | 11001-11004 |
| pairs_mixed | round 14's | 11401-11410 | 11401-11404 |
| long_severe | round 14's | 11501-11510 | 11501-11504 |
| long_mixed | round 14's | 11601-11610 | 11601-11604 |
| d9_hwlike | round 14's | 11701-11710 | 11701-11704 |
| d7_holenbr (targeted) | round 14's pairs_mixed with follow-up failures (below) | 11801-11810 | - |

No seed from 11001 to 11810 was used by any earlier run (job lists and run outputs checked; the mock-test files
below only borrow the names). Jobs run in this order: the 70 main runs, the
10 targeted runs, the 32 prior-art runs, the 70 baseline runs (182 in all).

Main runs (`cfg15/<test>.json`, written by `dev15/m15/make_cfg15.py cfg15`):
- `loc`, `sz` (reweighting) and `sz_all` (switch-out-all), as in rounds 10-14.
- `sz_w14`: round 14's gate, unchanged ("extra": "w4").
- `cut`: round 14's fixed cutoff (13x data qubit, 7x Z ancilla; "extra": "w5").
- `sz_w15`: the gate under test ("extra": "w6"; `sz_w14`'s probe-noise stream).
- `cut15`: the fixed cutoff at the correlated-matching crossover of a lone failing qubit, the L = 1 row of the new
  tables for the test's distance (d = 9: 15.74x data qubit, 8.61x Z ancilla; d = 7: 12.94x data qubit, 6.12x Z ancilla; "extra": "w7").
Reshaped-circuit samples an arm needs that no earlier arm drew in that epoch come from its own stream.

Prior-art runs (`cfg15/prior_<test>.json`, first four seeds of each test): `sz`, `sieg` and `sieg_rw` as in round 14.
Lab-practice baselines (`cfg15/base_<test>.json`, all seeds; reported, no rule): `fix_gen`, `fix_cal`, `refit_1s`
as in round 14.

Dropped from the main runs: `sz_w13`.

**Targeted test of round 14's hole rule** (`cfg15/d7_holenbr.json`, seeds 11801-11810, 10 runs; added at 02:10
with the user's approval). Round 14's C2 failed for want of cases: the rule acts when a new failure appears next to a
qubit that has been switched out long enough for the reshaped circuit's own estimates to settle without it (round 13,
long severe seed 9502), which happened in 4 of the 20 long runs (all 4 improved: 25 fewer failures out of 152,500;
p = 0.065). This test makes the case common. Round 14's neighbouring-failure configuration (d = 7) for 20,000,000
rounds, without simultaneous pairs: failures of 20-100x (log-uniform) lasting 1-2 M rounds, one every 1.5 M rounds on
average, each followed 200,000-800,000 rounds after it starts by a failure of 5-100x lasting 300,000-1,000,000 rounds
on a qubit that shares a stabilizer with it (`dev15/m15/scenario15.py`; without the `follow` setting the scenario is
round 14's, draw for draw). Scenario generation alone gives 50 such cases on a switchable first qubit over the 10
seeds. Arms: the main runs' seven, plus round 13's gate `sz_w13` as in round 14 (its own sample stream "w3",
`sz_w14`'s probe-noise stream, so the two gates differ only by the rule).

Development (two short runs, development seeds and provisional tables):
- A first design (failures followed a fraction of their duration later, 2,000,000 rounds, seed 900501): the rule
  acted twice; the two gates differed in 7 epochs (+3 failures plain, 0 correlated). The second failure came before
  the reshaped circuit's estimates had settled, so they were not stale.
- The design above (4,000,000 rounds, seed 900679, four early cases): the rule acted 35 times (14 names frozen, 21
  hidden); `sz_w14` had 20 fewer failures than `sz_w13` with correlated matching (z −1.9) and 10 fewer with plain
  matching (z −1.1), in 75-102 epochs; switch-outs identical.

## Rules (for `sz_w15`, on correlated matching)
R1-R8 with round 14's bars:
- R1 d9_mixed: beats reweighting (sz) by >= 5% and switch-out-all (sz_all) by >= 3% pooled, both paired-epoch p < 0.01,
  and in no seed worse than either by more than 1%.
- R2 d9_severe: beats sz by >= 10%, p < 0.01, no seed worse by more than 1%.
- R3 d9_moderate: vs sz <= +1% pooled.
- R4 d9_realistic: vs the localizer <= +1% pooled, seed-bootstrap 95% upper bound <= +2%.
- R5 pairs: vs sz <= +1% pooled.
- R6 long_severe: beats sz by >= 10%, p < 0.01, no seed worse by more than 1%.
- R7 long_mixed: beats sz by >= 5% and sz_all by >= 3%, both p < 0.01, no seed worse than either by more than 1%.
- R8 d9_hwlike: beats sz by >= 10%, p < 0.01, no seed worse by more than 1%.

Against round 14's gate:
- C1: pooled over all 70 runs, `sz_w15` within +0.25% of `sz_w14`.

Round 14's hole rule, where it applies (the targeted test; not part of any pooled rule):
- C2b: pooled over the 10 targeted runs, `sz_w14` has fewer logical failures than `sz_w13`, paired-epoch z < 0,
  p < 0.01 (correlated matching; plain matching reported). Round 14's C2 stays a fail; this is a separate test.

Against prior art (paired-epoch z < 0 and p < 0.01 for each; round 14's margins):
- P1: pooled over all 70 runs, `sz_w15` beats `cut` by >= 3%.
- P1b: pooled over all 70 runs, `sz_w15` beats `cut15` by >= 3%.
- P2: pooled over the 32 prior-art seeds, `sz_w15` beats `sieg` by >= 15%.
- P3: pooled over the 32 prior-art seeds, `sz_w15` beats `sieg_rw` by >= 15%.

P2 and P3 pair each prior-art run with the main run of the same seed; the check that `sz` is identical in both files
is reported for both decoders.

No development run used correlated matching at test length: the bars are round 14's, unchanged.

Reported, not rules:
- every comparison above for both decoders, every arm against `sz`, `sz_all` and the localizer in every test, and
  `sz_w15` against `sz_w14`, `cut` and `cut15` per test;
- each arm's failures under correlated against plain matching, per test (the decoder's effect);
- on plain matching, R1-R8 and P1-P3 for `sz_w14` (round 14's gate and decoder on fresh seeds: a repeat of round 14);
- watch returns, switch-outs without a failure, crossover failures and how long they were switched out, for both
  gates and both cutoffs;
- lab-practice baselines for both decoders (`analyse15b.py`);
- the targeted test: every arm against `sz_w13`, `sz`, `sz_all`, the localizer and both cutoffs, for both decoders,
  and the rule's activity (names frozen and composed, hidden, restored, kept, released).

## Statistics (as rounds 8-14)
- Pooled relative difference of total logical failures.
- Paired per-epoch differences pooled over seeds (normal approximation) for p, and per-seed relative differences.
- Seed bootstrap with numpy default_rng(8), 10,000 resamples, 95% percentile interval.
- A rule is evaluated only when every seed of its tests has finished. A crashed run is re-run with the same seed; a code
  fix is logged here, with its time, before any re-run.
- `analyse15.py` computes the rules and every reported comparison for both decoders; `recount15.py` recounts the
  correlated-matching numbers independently from the raw arrays, and `verify15.py` compares the two and re-derives
  every verdict. All three, and `analyse15b.py`, were tested before the freeze on mock data built from round 14's
  runs (`dev15/m15/mock15.py`): 182 mock files from round 14's finished runs; 280 values compared,
  no mismatch; all 16 verdicts agree; the main-stream check passes for both decoders.
- `run15.py` keeps at most 40 reshaped-circuit models and 100 correlated decoders in memory (configuration keys
  `max_models` and `max_corr_decoders`; round 14 kept 200 models). With its X-type part a reshaped model at d = 9
  takes about 20 MB (13 MB in round 14), and in the development check a prior-art run was stopped for lack of memory
  with four runs side by side (the session allows 5.8 GB). Least recently used ones are dropped and rebuilt when
  needed; this changes no result: a 400,000-round prior-art run at d = 9 (74 reshaped circuits) with 3 models and 5 correlated
  decoders kept (1,066 model loads, 2,879 decoder builds) was identical, array for array, to the same run with 200
  and 150 kept.
- The queue (`queue15.py`) scales each job's estimate by the median run time / estimate of finished jobs of the same
  test and kind when deciding whether it fits in a batch; this changes only the order and timing of jobs. Estimates
  (`gen_jobs15.py`): round 14's mean run time per test times 2.4 (main and targeted runs; one arm more for the
  targeted ones), 3.5 (prior-art runs; 5.0 for the realistic and hardware-like ones, which visit about 1,100 reshaped
  circuits each) or 3.8 (baseline runs): 67.7 h of CPU, about 34 h on two workers if every estimate holds.

## Meaning
- R1-R8: whether the gate, tuned for the decoder, meets round 14's bars when the decoder is correlated matching.
- C1: whether retuning the tables for the decoder costs anything against the gate tuned for plain matching.
- C2b: whether round 14's hole rule helps where its case is common (round 14's C2 could not tell).
- P1-P3: the gate against fixed cutoffs (tuned for either decoder), the published detect-and-quarantine method, and
  that method tuned and given adaptive reweighting, all decoded with correlated matching.

## Known limits
As rounds 10-14, plus:
- Correlated matching only (PyMatching 2.4). No belief-propagation, tensor-network or neural decoder.
- The arms' correlated decoders know only what the arms learn: Z-edge weights. Their X-type rates are the
  reference rates; this costs nothing measurable for one failing qubit (`check15b.py`) but is not tested further.
- The bars are carried over from plain matching; the gaps between arms may change with the decoder.
- The tables, like round 9's, come from one qubit in a uniform region at p = 0.003, and each crossover carries
  sampling noise (roughly +-1-2x for the correlated data-qubit values at these shot counts, less for Z ancillas).
- The targeted test's scenario is built to produce the hole rule's case; how often the case arises in practice is
  not measured by it.

## Frozen
Every file the round-15 code reads, with sha256 in `out15/hashes_at_start.txt` (list in `dev15/m15/freeze15.py`;
modules found by importing the code in a fresh interpreter):
- Scripts (`dev15/m15/`): `run15.py`, `model15.py`, `corr15.py`, `scenario15.py`, `make_cfg15.py`, `gen_jobs15.py`, `queue15.py`,
  `analyse15.py`, `analyse15b.py`, `recount15.py`, `verify15.py`, `freeze15.py`, `ideal_field15.py`, `run_tables.sh`.
- Round 14's code that they import (`run14.py`, `arms14.py`, `model.py`, `sampler.py`, ...; unchanged since round 14).
- Tables (`dev15/m15/tables/field_table15_d{7,9}_{data,zanc}.json`), configurations (`cfg15/*.json`, and `cfg14/*.json`,
  read by `make_cfg15.py`), `jobs15.txt` and this file.
- The CUSUM kernel (`kernel.c`, `libkernel.so`) and the Stim command-line tool (`../bin/stim`).

Libraries (not hashed): Python 3.13.17, numpy 2.5.3, scipy 1.18.1, PyMatching 2.4.0.

## Edit log
(none)
