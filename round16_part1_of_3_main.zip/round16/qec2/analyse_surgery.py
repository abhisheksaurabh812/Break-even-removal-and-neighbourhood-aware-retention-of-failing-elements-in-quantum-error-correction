"""Paired comparisons for test B.  python3 analyse_surgery.py 'out/surgB_test_k5_s*.npz' ..."""
import sys, glob, json
import numpy as np
from analyse2 import sign_test


def cmp(a, b):
    x = int(((a == 1) & (b == 0)).sum()); y = int(((a == 0) & (b == 1)).sum())
    fa, fb = int(a.sum()), int(b.sum())
    return dict(fails=fa, ref_fails=fb, rel=round(fa / fb - 1, 5) if fb else None, arm_only=x, ref_only=y, p=sign_test(x, y))


out = {}
for pat in sys.argv[1:]:
    files = sorted(glob.glob(pat))
    if not files:
        continue
    names = None; FM = []; FU = []
    for f in files:
        z = np.load(f, allow_pickle=True)
        nm = list(z['names']); names = names or nm; assert nm == names
        FM.append(z['failM'].reshape(len(nm), -1)); FU.append(z['failU'].reshape(len(nm), -1))
    FM = np.concatenate(FM, 1); FU = np.concatenate(FU, 1)
    r = dict(files=len(files), merged_blocks=int(FM.shape[1]), unmerged_blocks=int(FU.shape[1]),
             totals_merged=dict(zip(names, FM.sum(1).tolist())), totals_unmerged=dict(zip(names, FU.sum(1).tolist())),
             merged={}, unmerged={})
    for a, b in (('shared', 'sep-own'), ('shared', 'sep-clock'), ('shared', 'static-est'), ('sep-own', 'static-est'),
                 ('sep-clock', 'static-est'), ('sep-clock', 'sep-own'), ('oracle', 'shared'), ('oracle', 'static-est')):
        if a in names and b in names:
            i, j = names.index(a), names.index(b)
            r['merged'][f'{a} vs {b}'] = cmp(FM[i], FM[j]); r['unmerged'][f'{a} vs {b}'] = cmp(FU[i], FU[j])
    out[pat] = r
print(json.dumps(out, indent=1))
