"""Post-hoc (not pre-registered): for one run, attribute the difference between two arms to the failures
active at the time.   python3 diag10_seed.py <test> <seed> <armA> <armB>
For each failure on any qubit: its true factor (x nominal) and kind, the fraction of it during which each gate
had the qubit switched out, and armA - armB logical failures over the epochs it spans; plus the difference
outside every failure window."""
import sys, json
import numpy as np
import analyse8 as A
from model import P_REF

test, seed, a, b = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
r = A.load(f'out10/{test}_s{seed}.npz')
cfg = r['cfg']; d = cfg['d']; er = cfg['bpe'] * d
_, EX = A.roles(d)
fa, fb = A.per_epoch(r, a), A.per_epoch(r, b)
tot = len(fa) * er
iv = {arm: A.out_intervals(r['info'][arm].get('policy_log', []), er) for arm in ('sz_field', 'sz_gated', 'sz_all')}


def cover(arm, q, t0, t1):
    c = 0.0
    for g, x, y, _ in iv[arm]:
        if g == q:
            y = tot if y is None else y
            c += max(0.0, min(y, t1) - max(x, t0))
    return round(c / max(t1 - t0, 1), 2)


used = np.zeros(len(fa), bool); rows = []
for t0, dur, q, fac in r['defects']:
    t1 = min(t0 + dur, tot); e0 = int(t0 // er); e1 = min(int(t1 // er), len(fa) - 1)
    used[e0:e1 + 1] = True
    rows.append(dict(q=int(q), kind=EX.get(q, 'not switchable'), factor=round(float(fac), 2), start=int(t0), rounds=int(t1 - t0),
                     new_out=cover('sz_field', q, t0, t1), old_out=cover('sz_gated', q, t0, t1), all_out=cover('sz_all', q, t0, t1),
                     diff=int(fa[e0:e1 + 1].sum() - fb[e0:e1 + 1].sum())))
rows.sort(key=lambda x: -abs(x['diff']))
print(json.dumps(dict(test=test, seed=seed, a=a, b=b, total_a=int(fa.sum()), total_b=int(fb.sum()),
                      outside_failures=int(fa[~used].sum() - fb[~used].sum()), top=rows[:8]), indent=1))
