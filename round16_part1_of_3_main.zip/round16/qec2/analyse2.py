"""
Analysis for the decisive test.
  python3 analyse2.py tune out/tune_s*.npz            -> best variant per arm family (training seeds only)
  python3 analyse2.py test  out/test_X_s*.npz          -> paired comparisons by phase
"""
import sys, json, math, glob
import numpy as np

FAMILIES = [('regional', 'regional_'), ('twobuffer', 'twobuf_'), ('slow+off', 'slowoff_c'),
            ('slow+off+rs', 'slowoffrs_'), ('gated', 'gated_')]
PHASES = [('burst', 1), ('post_burst', 2), ('defect', 4), ('step_transition', 8), ('after_step', 16)]


def sign_test(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    # exact two-sided binomial; use normal approximation for very large n
    if n > 4000:
        z = (abs(b - c) - 1) / math.sqrt(n)
        return math.erfc(z / math.sqrt(2))
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)


def load(files):
    F, W, FL, names = [], [], [], None
    for f in files:
        z = np.load(f, allow_pickle=True)
        nm = list(z['names'])
        if names is None:
            names = nm
        assert nm == names
        A = len(nm)
        F.append(z['fails'].reshape(A, -1)); W.append(z['werr'])
        FL.append(np.repeat(z['flags'], z['fails'].shape[2]))
    return names, F, W, FL


def tune(files):
    names, F, W, FL = load(files)
    tot = sum(f.sum(1) for f in F)
    res = {n: int(t) for n, t in zip(names, tot)}
    best = {}
    for fam, pre in FAMILIES:
        cands = [(res[n], n) for n in names if n.startswith(pre)]
        cands.sort()
        best[fam] = dict(choice=cands[0][1], fails=cands[0][0], all=dict((n, v) for v, n in cands))
    out = dict(seeds=len(files), totals_reference={k: res[k] for k in ('static', 'oracle', 'slow')}, best=best)
    print(json.dumps(out, indent=1))


def compare(names, F, i, j, mask=None):
    b = c = fi = fj = 0
    for f, msk in zip(F, mask if mask is not None else [None] * len(F)):
        a = f[i] if msk is None else f[i][msk]
        g = f[j] if msk is None else f[j][msk]
        b += int(((a == 1) & (g == 0)).sum()); c += int(((a == 0) & (g == 1)).sum())
        fi += int(a.sum()); fj += int(g.sum())
    return dict(fails=fi, ref_fails=fj, rel=(fi / fj - 1) if fj else float('nan'),
                arm_only=b, ref_only=c, p=sign_test(b, c))


def test(files):
    names, F, W, FL = load(files)
    gi = names.index('gated')
    nblocks = sum(f.shape[1] for f in F)
    out = dict(seeds=len(files), blocks=nblocks, rounds_per_block=None, names=names)
    tot = {n: int(sum(f[k].sum() for f in F)) for k, n in enumerate(names)}
    out['totals'] = tot
    # every arm against the full gated design, overall and by phase
    out['vs_gated'] = {}
    for k, n in enumerate(names):
        if n == 'gated':
            continue
        row = {'all': compare(names, F, k, gi)}
        for ph, bit in PHASES:
            msk = [(fl & bit) > 0 for fl in FL]
            if sum(m.sum() for m in msk) == 0:
                continue
            row[ph] = compare(names, F, k, gi, msk)
        quiet = [fl == 0 for fl in FL]
        row['quiet'] = compare(names, F, k, gi, quiet)
        out['vs_gated'][n] = row
    # key ablations
    pairs = [('slow+off@g', 'gated-nors'), ('gated-nors', 'gated'), ('slow+off@g', 'gated'),
             ('slow+off', 'slow+off+rs'), ('slow+off+rs', 'gated'), ('slow+off', 'gated'), ('slow', 'slow+off'),
             ('regional', 'slow+off'), ('twobuffer', 'slow+off'), ('static', 'regional'), ('static', 'slow'),
             ('static-est', 'slow'), ('static-est', 'regional-est'), ('static-est', 'twobuffer-est'),
             ('regional-est', 'gated'), ('twobuffer-est', 'gated'), ('static-est', 'gated'), ('static', 'static-est')]
    out['ablations'] = {}
    for a, b in pairs:
        if a in names and b in names:
            out['ablations'][f'{a} vs {b}'] = compare(names, F, names.index(a), names.index(b))
    # weight error by phase (mean |ln p_eff - ln p_true| over edges, averaged over epochs)
    we = {}
    for k, n in enumerate(names):
        allw = np.concatenate([w[k] for w in W])
        flags_ep = np.concatenate([fl[::f.shape[1] // w.shape[1]] for fl, f, w in zip(FL, F, W)])
        we[n] = dict(all=round(float(allw.mean()), 4), quiet=round(float(allw[flags_ep == 0].mean()), 4) if (flags_ep == 0).any() else None)
    out['weight_error'] = we
    # phase sizes
    out['phase_blocks'] = {ph: int(sum(((fl & bit) > 0).sum() for fl in FL)) for ph, bit in PHASES}
    out['phase_blocks']['quiet'] = int(sum((fl == 0).sum() for fl in FL))
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    mode = sys.argv[1]
    files = sorted(sum((glob.glob(a) for a in sys.argv[2:]), []))
    {'tune': tune, 'test': test}[mode](files)
