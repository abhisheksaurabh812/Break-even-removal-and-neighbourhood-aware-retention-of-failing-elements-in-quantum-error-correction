"""
Exploratory fix (after round 7 tests): Sized2 sizes a named qubit relative to the slow estimator's
CURRENT detector rates rather than the t = 0 calibration, and hands over to the slow estimator when it
ends (no restore of pre-naming values).  Motivation: in the round-7 'realistic' runs, persistent regional
steps made Sized attribute the whole regional rise to whichever qubit was named, with overrides that
never ended.
"""
import numpy as np
from arms import Slow
from arms7 import Sized, CAP, QS, qround


class Sized2(Sized):
    kind = 'sized2'

    def fit(self, g, n, N):
        s = self._st(g)
        if not len(s['dets']):
            return 1.0
        m = self.m
        qcur = np.clip(self.q[m.anc_int_class], 1e-6, 0.49)          # current per-detector rate per ancilla
        anc_of_det = s['anc'][s['didx']]
        lg0 = np.array([np.log1p(-2 * p).sum() if len(p) else 0.0 for p in s['pk']])   # g's calibrated part
        lother = np.log1p(-2 * qcur[anc_of_det]) - lg0                  # log(1 - 2 other_u)
        L = lother[:, None] + s['Rg']
        q = 0.5 * (1 - np.exp(L))
        nb = len(s['anc'])
        qb = np.zeros((nb, len(self.grid)))
        np.add.at(qb, s['didx'], q)
        cnt = np.bincount(s['didx'], minlength=nb).astype(float)
        qb /= np.maximum(cnt, 1)[:, None]
        qb = np.clip(qb, 1e-12, 1 - 1e-12)
        nn = n[s['anc']]; NN = N[s['anc']]
        ok = NN > 0
        if not ok.any():
            return 1.0
        ll = (nn[ok, None] * np.log(qb[ok]) + (NN[ok] - nn[ok])[:, None] * np.log1p(-qb[ok])).sum(0)
        return float(self.grid[int(np.argmax(ll))])

    def _unfreeze(self, g):
        e = self._st(g)['edges']
        self.fref[e] -= 1
        done = e[self.fref[e] == 0]
        self.frozen[done] = False          # hand over: keep what the slow estimator has learned


class Sized3(Sized):
    """Consistent version of the fix.  At naming, the twin snapshots the slow estimator's current view
    (per-ancilla detector rates, and the qubit's edges, which it freezes).  The qubit's size is fitted
    and its edges recomposed relative to that snapshot; when the window fit returns below r_off the
    snapshot values are restored (clean end).  After H rounds of activity the fit is repeated against
    the slow estimator's CURRENT rates; if those already explain the excess (fit < r_off), the qubit is
    handed over to the slow estimator (edges released with what it has learned, no restore).  This
    ends overrides that were misattributed to a qubit during a broad, persistent change."""
    kind = 'sized3'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.H = float(self.sz.get('H', 100000))
        self.n_handover = 0

    def _lg0(self, s):
        if 'lg0' not in s:
            s['lg0'] = np.array([np.log1p(-2 * p).sum() if len(p) else 0.0 for p in s['pk']])
        return s['lg0']

    def fit_base(self, g, n, N, qbase):
        s = self._st(g)
        if not len(s['dets']):
            return 1.0
        qb_ = np.clip(np.asarray(qbase, float), 1e-6, 0.49)
        anc_of_det = s['anc'][s['didx']]
        lother = np.log1p(-2 * qb_[anc_of_det]) - self._lg0(s) + self._others(g, s)
        L = lother[:, None] + s['Rg']
        q = 0.5 * (1 - np.exp(L))
        nb = len(s['anc'])
        qb = np.zeros((nb, len(self.grid)))
        np.add.at(qb, s['didx'], q)
        cnt = np.bincount(s['didx'], minlength=nb).astype(float)
        qb /= np.maximum(cnt, 1)[:, None]
        qb = np.clip(qb, 1e-12, 1 - 1e-12)
        nn = n[s['anc']]; NN = N[s['anc']]
        ok = NN > 0
        if not ok.any():
            return 1.0
        ll = (nn[ok, None] * np.log(qb[ok]) + (NN[ok] - nn[ok])[:, None] * np.log1p(-qb[ok])).sum(0)
        return float(self.grid[int(np.argmax(ll))])

    def fit(self, g, n, N):
        return self.fit_base(g, n, N, self.q[self.m.anc_int_class])

    def _activate(self, g, r, n0, N0, how):
        super()._activate(g, r, n0, N0, how)
        o = self.sovr[g]
        o['qsnap'] = self.q[self.m.anc_int_class].copy(); o['act'] = 0.0

    def resume(self, g, r):
        super().resume(g, r)
        if g in self.sovr:
            self.sovr[g]['act'] = 0.0

    def handover(self, g):
        o = self.sovr.pop(g, None)
        if o is None:
            return
        e = self._st(g)['edges']
        self.fref[e] -= 1
        done = e[self.fref[e] == 0]
        self.frozen[done] = False                     # keep what the slow estimator has learned
        self.n_handover += 1
        self.slog.append(['handover', self.ep_i, int(g), round(o['r'], 2)])

    def update(self, X, crr, mask=None):
        Slow.update(self, X, crr, mask)
        self.ep_i += 1
        self._convert()
        if not self.sovr:
            return
        m = self.m
        n = (X.astype(np.float32) @ m.A_int).sum(0).astype(float)
        N = X.shape[0] * self.nint
        if mask is not None:
            off = mask['anc_off']
            n = np.where(off, 0.0, n); N = np.where(off, 0.0, N)
        qcur = self.q[m.anc_int_class]
        rounds = X.shape[0] * m.T
        for g in list(self.sovr):
            o = self.sovr[g]
            if o['susp']:
                continue
            o['win'].append((n, N)); o['act'] += rounds
            nn = np.sum([w[0] for w in o['win']], 0); NN = np.sum([w[1] for w in o['win']], 0)
            if len(o['win']) < self.Wmin and o['init'] is not None:
                nn = nn + o['init'][0]; NN = NN + o['init'][1]
            r = self.fit_base(g, nn, NN, o['qsnap'])
            if len(o['win']) >= self.Wmin and r < self.r_off:
                self.deactivate(g, 'quiet')
                continue
            if o['act'] >= self.H and self.ep_i % 10 == 0:
                if self.fit_base(g, nn, NN, qcur) < self.r_off:
                    self.handover(g)
                    continue
            if abs(np.log(max(r, 1e-9)) - np.log(o['r'])) >= 1.5 * QS:
                o['r'] = qround(r)

    def info(self):
        d = super().info(); d['sized']['handovers'] = self.n_handover
        return d


class Sized4(Sized3):
    """Sized3 plus use of the probe result.  When a switched-out qubit is put back because a direct
    probe found it below the crossover, the twin pins that qubit's size to the probed value and holds it
    (no syndrome refits, no new switch-out) for a cooling-off period of C active rounds; then it runs the
    hand-over check against the slow estimator's current rates.  This stops the remove / put back /
    remove cycle when the syndrome fit is misattributing a broad change to one qubit."""
    kind = 'sized4'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.C = float(self.sz.get('C', 100000))
        self.n_pinned = 0

    def resume(self, g, r):
        super().resume(g, r)
        o = self.sovr.get(g)
        if o is not None:
            o['cool'] = self.C; self.n_pinned += 1
            self.slog.append(['pin', self.ep_i, int(g), round(r, 2)])

    def update(self, X, crr, mask=None):
        rounds = X.shape[0] * self.m.T
        held = {}
        for g, o in self.sovr.items():
            if not o['susp'] and o.get('cool', 0) > 0:
                held[g] = o
                o['susp'] = True                      # hide from the refit loop below
        super().update(X, crr, mask)
        qcur = self.q[self.m.anc_int_class]
        for g, o in held.items():
            if g not in self.sovr:
                continue
            o['susp'] = False
            o['cool'] -= rounds
            if o['cool'] <= 0:
                o['cool'] = 0
                # re-baseline on the slow estimator's current view: release the old frozen edges (keeping
                # what it has learned), freeze them again at their current values, and size the residual
                # from fresh data; a residual below r_off ends the override after Wmin epochs
                e = self._st(g)['edges']
                self.fref[e] -= 1
                done = e[self.fref[e] == 0]
                self.frozen[done] = False
                self._freeze(g)
                o['win'].clear(); o['init'] = None; o['qsnap'] = qcur.copy(); o['act'] = 0.0
                o['r'] = 1.0; o['start'] = self.ep_i
                self.slog.append(['unpin', self.ep_i, int(g)])

    def info(self):
        d = super().info(); d['sized']['pinned'] = self.n_pinned
        return d
