"""Merge main and supplementary runs of the same scenario and seed (identical detection events)."""
import sys, glob, os
import numpy as np

scen = sys.argv[1]
for f in sorted(glob.glob(f'out/test_{scen}_s*.npz')):
    seed = f.split('_s')[-1].split('.')[0]
    g = f'out/supp_{scen}_s{seed}.npz'
    if not os.path.exists(g):
        print('missing', g); continue
    a = np.load(f, allow_pickle=True); b = np.load(g, allow_pickle=True)
    na, nb = list(a['names']), list(b['names'])
    # check the shared arm is identical (same samples, deterministic arms)
    assert np.array_equal(a['fails'][na.index('gated')], b['fails'][nb.index('gated')]), 'runs differ'
    extra = [i for i, n in enumerate(nb) if n not in na]
    np.savez_compressed(f'out/merged_{scen}_s{seed}.npz',
                        fails=np.concatenate([a['fails'], b['fails'][extra]]),
                        werr=np.concatenate([a['werr'], b['werr'][extra]]),
                        flags=a['flags'], names=np.array(na + [nb[i] for i in extra]),
                        cfg=a['cfg'], events=a['events'], info=a['info'])
    print('merged', scen, seed, na + [nb[i] for i in extra])
