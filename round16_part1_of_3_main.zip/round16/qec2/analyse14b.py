"""Round 14, lab-practice baselines (reported, no rule; PREREG_round14.md).   python3 analyse14b.py > out14/res_14b.json
The baseline runs (out14/base_<test>_s<seed>.npz: fix_gen, fix_cal, refit_1s) decode the same main-stream detection
events as the main runs of the same seed (out14/<test>_s<seed>.npz), which depend on the seed alone; per seed, the two
files' arms are combined and compared epoch by epoch, as analyse13.py compares arms within one run.  A test is
reported only when every seed has both files."""
import json, os
import numpy as np
import analyse8 as A
from analyse14 import SEEDS, OUT

GATES = ('sz_w14', 'sz_w13', 'sz', 'loc', 'cut')
BASES = ('fix_gen', 'fix_cal', 'refit_1s')


def merged(test):
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not (os.path.exists(f'{OUT}/done/{n}') and os.path.exists(f'{OUT}/done/base_{n}')):
            return None
        r = A.load(f'{OUT}/{n}.npz'); b = A.load(f'{OUT}/base_{n}.npz')
        assert r['fails'].shape[1:] == b['fails'].shape[1:], n
        # only the arm names and per-epoch failure counts are kept (memory; A.per_epoch and A.totals give the same
        # values from these)
        F = np.concatenate([r['fails'].sum(2, keepdims=True), b['fails'].sum(2, keepdims=True)])
        out.append(dict(names=r['names'] + b['names'], fails=F))
        del r, b
    return out


def main():
    res = {}
    pool = []
    for test in SEEDS:
        rs = merged(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for g in GATES + ('fix_cal', 'refit_1s'):
            for b in BASES:
                if g == b or (g in BASES and BASES.index(g) <= BASES.index(b)):
                    continue
                x = A.compare(rs, g, b); x['boot95'] = A.bootstrap(rs, g, b)
                R[f'{g} vs {b}'] = x
        res[test] = R
        pool += rs
    if len(res) == len(SEEDS):
        P = dict(seeds=len(pool), totals=A.totals(pool))
        for g in GATES:
            for b in BASES:
                x = A.compare(pool, g, b); x['boot95'] = A.bootstrap(pool, g, b)
                P[f'{g} vs {b}'] = x
        res['all_tests_pooled'] = P
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
