# Round 16, part I, items 3b and 10 — rules (written before computing; added 9 Nov 2026 after an outside review)

No new simulation. Both items are descriptive (no bar).

## 3b — an absolute-target boundary, as in Palmer and Smith, beside the break-even threshold

Palmer and Smith (arXiv:2510.22001) judge a defective lattice against an absolute target logical error rate. Applied
to one failing qubit, that rule keeps the qubit while its logical failure rate stays at or below a fixed target and
acts once it exceeds it. `analyse16_I3b.py` uses the same tables as `analyse16_I.py` (distances 7 and 9 from rounds
9, 10 and 15; distances 5, 11 and 13 from round 16, part B; both roles, both decoders) and its interpolation `lnK`.

- Target: P_max = c × K(1; L = 1), the failures of the defect-free patch with every qubit nominal, for
  c = 1.25, 2, 5, 10 (fixed here).
- Boundary at level L: the smallest factor f ≥ L (dense log grid from L to 300) with K(f; L) ≥ P_max. If the patch
  already exceeds the target with the qubit at the regional level (K(L; L) ≥ P_max), the boundary is reported as
  "≤ L" (every qubit at or above the regional level fails the target); if the target is not reached by f = 300,
  "none".
- Reported for L = 1, 2, 4, 8 beside the break-even threshold f*(L), with the direction each moves from L = 1 to 4.

## 10 — a role-based crossover cutoff against reweighting alone, same naming and sizing (round 15 data)

From the round-15 run files (`../out15/*.npz`, the 70 runs of the pooled tests; per-run failures summed over epochs
and shots, as `analyse15.py` does). Arms: `cut15` (fixed cutoff at the correlated-matching thresholds for nominal
neighbours), `cut` (rounded plain-matching thresholds), `sz` (reweighting alone), `sz_all` (switch out every named
qubit), `loc` (localizer); all used the same earlier naming and sizing ([0120] of the filed specification).
Pooled relative difference (Σa − Σb)/Σb and a 95% seed-bootstrap interval (10,000 resamples, numpy seed 8, as
round 15), for each decoder, pooled and by test; the gate's rows against `sz` and `cut15` are recomputed as a check
against Table 3 (−18.9% and −8.7%). This item was first computed informally on 9 Nov 2026 while checking the review;
the script reproduces that computation and is reported as post hoc.
