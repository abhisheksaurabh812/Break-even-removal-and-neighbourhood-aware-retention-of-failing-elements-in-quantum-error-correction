"""Development (spent seeds): BP-OSD settings against matching on the same d=5 samples."""
import sys, os, subprocess, tempfile, time, numpy as np
S = sys.argv[1]; sys.path.insert(0, S + '/tools/PyMatching/src')
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import deform16, bposd16, pymatching
STIM = S + '/bin/stim'; d = 5; shots = int(sys.argv[2]); p = 0.003
T = tempfile.mkdtemp(dir=HERE)
txt, _ = deform16.circuit(d, d, p); cf = os.path.join(T, 'c.stim'); open(cf, 'w').write(txt)
subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', os.path.join(T, 'dec.dem')], check=True)
subprocess.run([STIM, 'analyze_errors', '--in', cf, '--out', os.path.join(T, 'raw.dem')], check=True)
of = os.path.join(T, 's.b8')
subprocess.run([STIM, 'detect', '--shots', str(shots), '--out_format', 'b8', '--append_observables', '--seed', '2', '--in', cf, '--out', of], check=True)
H, pr, L = bposd16.dem_to_matrices(open(os.path.join(T, 'raw.dem')).read()); nd = H.shape[0]
bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(shots, (nd + 1 + 7) // 8), axis=1, bitorder='little')[:, :nd + 1]
obs = bits[:, nd]
m = pymatching.Matching.from_detector_error_model_file(os.path.join(T, 'dec.dem'))
print('matching', int((m.decode_batch(bits[:, :nd])[:, 0] != obs).sum()))
for sc, it, od in [(0.625, 30, 8), (1.0, 30, 8), (0.75, 60, 8), (0.75, 30, 20)]:
    dec = bposd16.BPOSD(H, pr, max_iter=it, ms_scale=sc, osd_order=od); t = time.time()
    est = np.concatenate([dec.decode_batch(bits[i:i + 1000, :nd]) for i in range(0, shots, 1000)])
    print(f'scale {sc} iters {it} order {od}: fails {int(((est @ L.T % 2)[:, 0] != obs).sum())}  {time.time() - t:.0f}s', flush=True)
for f in os.listdir(T): os.remove(os.path.join(T, f))
os.rmdir(T)
