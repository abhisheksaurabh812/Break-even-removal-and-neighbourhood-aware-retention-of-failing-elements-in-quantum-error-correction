"""Round 16, part I, items 12 and 13: computed AFTER the pre-registered tests, from existing counts only (no new
simulation, no bar). Both use part I's cost function (analyse16_I.cost: failure sizes log-uniform on [2, 100]; extra
logical failures of a decision against the best decision, mean and worst over the sizes).
 (12) deciding with a matching decoder's threshold when the code is decoded by BP-OSD (distance 5, part J rows and
      part B thresholds; both roles, L = 1 and 4, plain and correlated: 8 cases);
 (13) a threshold scaled in proportion to the neighbourhood level, f*(L = 1) x L, against the measured break-even
      threshold f*(L) and against a threshold that ignores the level, f*(L = 1), for every table of part I
      (distances 5 to 13, both roles, both matching decoders), at L = 2, 4, 8.
python3 analyse16_I12_13.py   (writes out16/I/I12_results.json and out16/I/I13_results.json)"""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from analyse16_I import load, cost, fstar, FS          # noqa: E402

O = os.path.join(HERE, 'out16')


def item12():
    J = {r: {x['L']: x for x in json.load(open(f'{O}/J/d5_{r}_bposd.json'))['rows']} for r in ('zanc', 'data')}
    B = {(r, d): {x['L']: x for x in json.load(open(f'{O}/B/d5_{r}_{d}.json'))['rows']} for r in ('zanc', 'data')
         for d in ('plain', 'corr')}
    cases = []
    for r in ('zanc', 'data'):
        for L in (1.0, 4.0):
            for d in ('plain', 'corr'):
                fo = B[(r, d)][L]['crossover']; m, wst = cost(J[r][L], FS > fo)
                cases.append(dict(role=r, L=L, matching=d, fstar_bposd=J[r][L]['crossover'], fstar_matching=fo,
                                  mean_extra_pct=m, worst_pct=wst))
    res = dict(cases=cases, mean_pct=round(float(np.mean([c['mean_extra_pct'] for c in cases])), 2),
               max_pct=round(max(c['mean_extra_pct'] for c in cases), 2))
    json.dump(res, open(f'{O}/I/I12_results.json', 'w'), indent=1); return res


def item13():
    T = load(); per = []; agg = {}
    for k in sorted(T):
        d, role, dec = k
        if 1.0 not in T[k]:
            continue
        f1 = fstar(T[k][1.0])
        for L in (2.0, 4.0, 8.0):
            if L not in T[k]:
                continue
            cp = cost(T[k][L], FS > f1 * L); cb = cost(T[k][L], FS > f1)
            per.append(dict(d=d, role=role, decoder=dec, L=L, breakeven=fstar(T[k][L]), proportional=f1 * L,
                            prop_mean_pct=cp[0], prop_worst_pct=cp[1], blind_mean_pct=cb[0], blind_worst_pct=cb[1]))
    for role in ('zanc', 'data'):
        for L in (2.0, 4.0, 8.0):
            x = [p for p in per if p['role'] == role and p['L'] == L]
            agg[f'{role}|L{L:g}'] = dict(tables=len(x), prop_mean_pct=round(float(np.mean([p['prop_mean_pct'] for p in x])), 2),
                                         prop_max_pct=round(max(p['prop_mean_pct'] for p in x), 2),
                                         blind_mean_pct=round(float(np.mean([p['blind_mean_pct'] for p in x])), 2),
                                         blind_max_pct=round(max(p['blind_mean_pct'] for p in x), 2))
    res = dict(per_table=per, by_role_level=agg)
    json.dump(res, open(f'{O}/I/I13_results.json', 'w'), indent=1); return res


if __name__ == '__main__':
    a = item12(); print('(12) BP-OSD with matching thresholds: mean', a['mean_pct'], '% max', a['max_pct'], '%')
    b = item13()
    for k, v in b['by_role_level'].items():
        print('(13)', k, v)
