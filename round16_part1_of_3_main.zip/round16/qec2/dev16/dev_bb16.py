"""Development (spent seeds 1..): [[72,12,6]] code checks and baseline failure rates for choosing p."""
import sys, time, numpy as np
import bb16, bposd16
HX, HZ = bb16.bb_code(); LZ = bb16.z_logicals(HX, HZ)
print('n', HX.shape[1], 'rank HX', bb16.rank_gf2(HX), 'rank HZ', bb16.rank_gf2(HZ), 'k', HX.shape[1] - bb16.rank_gf2(HX) - bb16.rank_gf2(HZ), 'LZ', LZ.shape)
w = min(int(v.sum()) for v in LZ); print('min weight among the 12 Z-logical representatives found', w)
T = 6; H = bb16.spacetime(HZ, T); n = 72; m = 36
Lst = np.concatenate([np.tile(LZ, (1, T)), np.zeros((12, m * T), dtype=np.uint8)], axis=1)
for p in (0.015,):
    dec = bposd16.BPOSD(H, np.full(H.shape[1], p)); rng = np.random.default_rng(1); k = 1000
    e = (rng.random((k, H.shape[1])) < p).astype(np.uint8)
    s = (e.astype(np.int32) @ H.T.astype(np.int32)) % 2; lo = (e.astype(np.int32) @ Lst.T.astype(np.int32)) % 2
    t = time.time(); est = dec.decode_batch(s.astype(np.uint8))
    fl = int((((est.astype(np.int32) @ Lst.T.astype(np.int32)) % 2) != lo).any(axis=1).sum())
    ok = bool((((est.astype(np.int32) @ H.T.astype(np.int32)) % 2) == s).all())
    print(f'p={p}: {fl} failures of {k}  syndromes matched {ok}  {time.time() - t:.1f}s', flush=True)
