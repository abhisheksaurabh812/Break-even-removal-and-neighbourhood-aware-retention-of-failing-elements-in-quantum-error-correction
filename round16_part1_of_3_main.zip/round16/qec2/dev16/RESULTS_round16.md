# Round 16 — results (9–10 November 2026; corrected and extended 13 November 2026)

Surface-code memories, circuit-level depolarizing noise p = 0.003 unless stated, blocks of d rounds; a qubit kept at
factors L × (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30) until its failures reach those with it removed by deformation;
crossover interpolated in (ln f, ln failures). Rules for every part were written and hashed before its first run
(`PREREG_16*.md`). Every threshold was recomputed by a second program (`verify16.py`, `verify16_M.py`).

## Pre-registered checks: 34 of 36 passed

| Check | What | Result |
|---|---|---|
| B1 | Z-type measure qubit, L 1 to 3, distances 5 and 11, both decoders: rise of at least 1.15 times | 4 of 4 |
| B2 | Same, L 1 to 4, distance 13 | 2 of 2 |
| A1 | Unchanged weights lower the threshold by at least 1.15 times (d 7, 9; both roles, both decoders) | 8 of 8 |
| C1 | Rise with L under SI1000 (d 7, 9) and X-biased noise (d 7) | 6 of 6 |
| D1 | X-type measure qubit (X basis) within 15% of Z-type (Z basis) | 4 of 4 |
| E1 | Couplers: a finite threshold at L = 1 that rises by 1.15 times at L = 4 | **0 of 2** |
| F1 | Calibration maps: aware below keep, fixed 10×, fixed 20× (intervals below zero) | 6 of 6 |
| F2 | Targeted maps: aware below nominal thresholds | 2 of 2 |
| M1, M1p | Online, only the decision changed: gate below blind cutoff | 2 of 2 |

## Main numbers

- **Distance (B):** Z-type measure qubit, plain matching, L = 1: 4.3, 6.4, 8.5, 9.3, 10.4 at d = 5, 7, 9, 11, 13;
  at d = 13 it rises to 24.6 (plain) and 23.4 (correlated) at L = 4.
- **Ways of keeping (A):** d = 9, correlated, data qubit at L = 1: 15.4 with weights from the size, 8.9 unchanged,
  6.5 with no weights.
- **Couplers (E):** keeping beat removal up to 30× with nominal neighbours in every case; at L = 4 removal paid from
  55 to 113 (not up to 120 for the X-type coupler with plain matching).
- **Boundaries (H):** boundary data qubits 18.7–27.8 at d = 7 (bulk about 13–14), corner above 30; boundary
  measure qubit rises like the bulk (about 5 to 21 at d = 7).
- **Erasure only (K):** pays above 30× never with nominal neighbours; at L = 4 from 39 to 66.
- **BP-OSD (J), d = 5:** measure qubit 4.7 → 9.2 (L 1 → 4), within about 11% of matching; data qubit 8.5 (L = 1)
  and 8.1 (L = 4), 60–66% of matching's 12.3–14.2.
- **qLDPC [[72,12,6]] (G), BP-OSD, erase vs keep:** unchanged weights: erasing pays at every factor (≤ 1) at L 1,
  2, 4; tracked weights: 1.3 at L = 2, 8.1 at L = 4.
- **Approximate thresholds (I):** ±25% costs 0.24–0.39% on average; a factor of 2 costs 2.2–2.5%; the other
  matching decoder's thresholds cost 0.03%.
- **Fixed-target comparator (I3b):** at L = 4 every table's healthy code already misses targets up to 10× the
  healthy rate, so such a rule removes every qubit; break-even there is 10–25×.
- **Calibration maps (F):** aware vs keep −21.6% / −24.2%; vs fixed 10× −1.3% / −1.6%; vs fixed 20× −3.1% / −2.6%;
  targeted maps vs nominal −9.9% / −9.9% (plain / correlated).
- **Online (M), 30 runs:** gate vs blind cutoff −3.9% [−6.2, −1.7] (correlated), −3.2% [−5.0, −1.4] (plain);
  realistic −4.1% [−7.6, −0.5], hardware-like −4.6% [−8.3, −1.5], neighbouring failures +0.3% [−0.6, +1.0]. The
  gate had 6.2% fewer failures than re-fit with a fixed threshold [−10.6, −2.2]; re-fit against the blind cutoff was
  +2.5%, an interval [−0.4, +6.1] that includes zero. Under realistic noise the blind cutoff against never switching
  out was +2.7%, interval [−1.4, +7.1], also including zero, while the gate was −1.5% [−2.6, −0.6].
- **Earlier tests, like for like (I10):** cutoff (C) vs reweighting alone −11.2% [−15.8, −6.7]; under realistic
  noise +2.1% [+1.1, +3.0].
- **Role check (I11):** with 200 blocks, wrong namings were caught in 99.7–100% of cases at 10×; at 33.6× every data
  qubit named as a measure qubit was caught, but only 83–86% of measure qubits named as data qubits, the rest reading
  as undecided (detection saturates; an undecided check does not withhold). With 1,000 blocks every wrong naming at
  10× and 33.6× was caught. Correct namings were withheld in at most 0.6% of cases at 10× and 33.6×, and in 6–19% at
  3× with 200 blocks; at 3× the check needs 1,000 blocks (then 97.5–100% caught).

## Computed after the pre-registered tests (13 November 2026; no pass bar)

`analyse16_I12_13.py`, from the stored tables only; outputs `out16/I/I12_results.json` and `I13_results.json`.

- **Item 12 — matching thresholds used with BP-OSD (d = 5):** mean extra logical failures 0.47%, largest 1.51% (data
  qubit, L = 1, plain-matching thresholds), over the failure sizes of item 1.
- **Item 13 — a threshold in proportion to the level, f\*(1) × L, against the break-even threshold f\*(L)**
  (mean extra failures over the measured tables, distances 5–13, both matching decoders):

  | Role | L | Tables | Proportional, mean | Proportional, largest | Level ignored, mean | Level ignored, largest |
  |---|---|---|---|---|---|---|
  | Z-type measure | 2 | 8 | 0.56% | 1.3% | 1.19% | 2.2% |
  | Z-type measure | 4 | 10 | 1.90% | 3.2% | 2.93% | 4.8% |
  | Z-type measure | 8 | 8 | 1.43% | 2.0% | 0.93% | 1.2% |
  | data | 2 | 8 | 2.40% | 3.8% | 0.04% | 0.1% |
  | data | 4 | 8 | 5.57% | 7.1% | 0.05% | 0.1% |
  | data | 8 | 8 | 4.13% | 5.2% | 0.04% | 0.1% |

## Verification

- 313 thresholds in 122 files recomputed independently: no mismatch. Part M recomputed with round 15's own
  functions: no mismatch.
- Hashes unchanged: 227 of 227 (round 16), 178 of 178 (part M), 89 of 89 (round 15's frozen files).

## Deviations from the plan, all recorded before the affected runs or in the logs

- Part M was added on 9 November at the user's request after an outside review, with its own rules and hashes,
  and moved ahead of the remaining parts at the user's request before any part-M run (`jobs16_all5.txt`).
- One erasure job hit the 2-hour limit on background commands and was rerun from scratch; batches then used a
  95-minute start window.
- A container restart on 10 November stopped one BP-OSD job; the three remaining BP-OSD levels were run point by
  point (`j16pt.py`, checked to reproduce two counts of `j16.py` exactly), with points already printed by the
  interrupted run taken from its log.

## Changes to this write-up

- 13 November 2026: the online comparisons of re-fit against the blind cutoff and of the blind cutoff against never
  switching out (realistic noise) now give their intervals, both of which include zero (the earlier wording stated
  them as differences); the BP-OSD ratios are given exactly; the role-check summary now gives the 33.6× case with
  200 blocks separately (83–86% caught, the rest undecided), which the earlier line folded into "99.7–100%";
  items 12 and 13 added. No result file changed.
