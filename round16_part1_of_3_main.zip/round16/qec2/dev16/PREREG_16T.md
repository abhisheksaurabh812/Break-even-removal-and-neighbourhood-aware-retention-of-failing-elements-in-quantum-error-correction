# Round 16, parts A, C, D, E and K — rules (fixed before the first run)

Same builder, generator, crossover rule, shots (2,000,000 per point for L ≤ 2, 1,000,000 above) and region
(Chebyshev distance 4 raised to L) as part B (`PREREG_16B.md`), unless stated. Job list `jobs16T.txt`.
A threshold beyond the grid (factor 300) counts as above any finite value; "none at L = 1" means removal never paid.

## A — ways of keeping (Stim seeds from 1610001)
Distances 7 and 9; data qubit and Z-type measure qubit; plain and correlated matching. The kept qubit is decoded
with: exact rates (L = 1, 4); unchanged calibrated rates (L = 1, 4); tracked rates, i.e. the region's level but not
the qubit's size (L = 4; at L = 1 it equals unchanged); no weights (L = 1, 4). The removed configuration is decoded
with the same knowledge of the region.
- **A1.** At L = 1, the threshold with unchanged rates is at most the exact threshold divided by 1.15, for every
  distance, role and decoder (8 checks).
- Everything else in A is descriptive.

## C — other noise (Stim seeds from 1620001)
SI1000-like noise at p = 0.002 (distances 7 and 9) and X-biased noise, bias 10, at p = 0.002 (distance 7);
data and Z-type measure qubits; both decoders; L = 1, 3, 6. (p chosen on spent seeds so that the baseline failure
rate is close to that of depolarizing noise at 0.003: 317, 260 and, for X-bias at 0.003, 1,801 failures in 200,000
blocks at distance 7. Z-biased noise was dropped: the Z-basis memory had 1 failure in 200,000 blocks, so it cannot
inform a threshold.)
- **C1.** For the Z-type measure qubit, the threshold at L = 3 is at least 1.15 times that at L = 1, for each noise
  model, distance and decoder (6 checks).

## D — X-type measure qubits (Stim seeds from 1630001)
Distance 7, both decoders, L = 1 and 4: the X-type measure qubit nearest the centre in an X-basis memory, and the
Z-type measure qubit (6, 6) in the Z-basis memory, each with the same seeds.
- **D1.** In all four comparisons the two thresholds differ by at most 15% (two independent measurements, each with
  about 7% repeat precision). Under symmetric noise the two cases are mirror images.

## E — failing couplers (Stim seeds from 1640001)
One two-qubit gate's noise multiplied by f (absolute, relative to nominal); its two qubits' other channels nominal;
the region around its data qubit at L. Keeping it (decoder knows the gate's rate) is compared with removing its data
qubit or its Z-type measure qubit. Couplers of the central Z-type measure qubit in schedule steps 0–3 at distance 7
and steps 0 and 3 at distance 9; one coupler of the central X-type measure qubit (step 0, removing its data qubit);
both decoders; L = 1 and 4.
- **E1.** For at least one coupler and response, at distance 7, for both decoders: a finite threshold exists at
  L = 1, and the threshold at L = 4 is at least 1.15 times that at L = 1.

## K — decoder-only erasure (Stim seeds from 1660001)
The qubit stays in the circuit; the decoder either keeps it (unchanged rates; or tracked rates at L = 4) or treats
all its error mechanisms as erasures (probability capped). Distances 7 and 9; data and Z-type measure qubits; both
decoders; L = 1 and 4 (tracked: L = 4). Both decoders decode the same samples. Exploratory: no bar.

Verification by a second script as in part B. Hashes of this file, `jobs16T.txt` and the code in
`out16/T_hashes_at_start.txt` before the first run.
