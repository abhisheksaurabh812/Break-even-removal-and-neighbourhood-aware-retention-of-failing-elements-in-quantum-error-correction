"""Round 16, part H (and a cross-check of every removal used in round 16): circuit distance of the deformed codes.
For each distance, removed qubit and memory basis, the length of the shortest graphlike logical error of the circuit's
detector error model (Stim, decompose_errors). target() is copied from ideal16.py (which parses arguments on import).
python3 hdist16.py > out16/H/distances.txt"""
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(HERE)), 'tools', 'stimpy'))
import stim                                       # noqa: E402
import deform16                                   # noqa: E402
from rectgen import layout                       # noqa: E402


def target(d, kind, basis):
    data, xm, zm = layout(d, d)
    ch = deform16.checks(d)
    near = lambda xs, c0: min(xs, key=lambda c: (abs(c[0] - c0[0]) + abs(c[1] - c0[1]), c))
    mid = (d, d)
    if kind == 'data':
        return (d, d), None
    if kind == 'zanc':
        return (d - 1, d - 1), None
    if kind == 'xanc':
        return near([a for a, (t, s) in ch.items() if t == 'X' and len(s) == 4], mid), None
    if kind == 'edge-data-x':
        return near([c for c in data if c[1] == 1 and 1 < c[0] < 2 * d - 1], (d, 1)), None
    if kind == 'edge-data-z':
        return near([c for c in data if c[0] == 1 and 1 < c[1] < 2 * d - 1], (1, d)), None
    if kind == 'corner-data':
        return (1, 1), None
    if kind == 'edge-zanc':
        return near([a for a, (t, s) in ch.items() if t == 'Z' and len(s) == 2 and a[0] == 0], (0, d)), None
    m = re.fullmatch(r'([xz])coupler([0-3])', kind)
    if m:
        k = int(m.group(2))
        if m.group(1) == 'z':
            a = (d - 1, d - 1); o = [(1, 1), (1, -1), (-1, 1), (-1, -1)][k]
        else:
            a = near([c for c, (t, s) in ch.items() if t == 'X' and len(s) == 4], mid); o = [(1, 1), (-1, 1), (1, -1), (-1, -1)][k]
        return (a[0] + o[0], a[1] + o[1]), a
    raise ValueError(kind)


def dist(d, excl, basis):
    txt = deform16.circuit(d, d, 0.001, excl=excl, basis=basis)[0]
    dem = stim.Circuit(txt).detector_error_model(decompose_errors=True)
    return len(dem.shortest_graphlike_error()), dem.num_detectors


if __name__ == '__main__':
    kinds = ['data', 'zanc', 'xanc', 'edge-data-x', 'edge-data-z', 'corner-data', 'edge-zanc'] + \
            [f'zcoupler{k}' for k in range(4)] + ['xcoupler0']
    print('d kind removed basis distance detectors')
    for d in (5, 7, 9):
        for b in ('z', 'x'):
            print(d, 'none', '-', b, *dist(d, (), b), flush=True)
        for kind in kinds:
            q, anc = target(d, kind, 'z')
            for name, rm in ([('data', q), ('anc', anc)] if anc else [('qubit', q)]):
                for b in ('z', 'x'):
                    try:
                        print(d, kind, f'{name}{rm}', b, *dist(d, [rm], b), flush=True)
                    except AssertionError:           # a measure qubit can be removed only in its own memory basis
                        print(d, kind, f'{name}{rm}', b, 'n/a', '-', flush=True)
