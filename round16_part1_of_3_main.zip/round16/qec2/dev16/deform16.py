"""Round 16: rotated surface-code memory with qubits switched out, generalising ../deform.py (which is frozen).

New over deform.py:
  * any data qubit can be excluded, including edge and corner qubits; the gauge structure is worked out from the
    deformed checks (anticommuting checks are gauges, same-type products that commute with every gauge of the
    other type are super-stabilizers), instead of being hard-coded for the bulk;
  * the logical observable is moved to the nearest row (Z basis) or column (X basis) that avoids the deformation;
  * memory in the X basis (basis='x'): X-type checks play the part of the Z-type checks of the Z-basis memory, and
    X-type measure qubits can be excluded;
  * noise models: 'dep' (as deform.py), 'si1000' (SI1000-like weights on this CX/H circuit) and biased Pauli noise
    ('xbias<eta>' or 'zbias<eta>');
  * pair_scale: multiplies the two-qubit noise of one coupler (a pair of qubits), for failing-coupler tests.

For the bulk, 'dep' noise and the Z basis, the circuit text is identical to deform.py's (checked by check16.py).
Memory-type gauges are measured in even rounds and the other type in odd rounds, as in deform.py.
"""
import re
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rectgen import layout          # noqa: E402

DIAG = ((-1, -1), (-1, 1), (1, -1), (1, 1))
CAP1, CAP2, CAPX = 0.75, 0.9375, 0.5


def checks(d):
    """dict ancilla -> (type, support tuple), support = existing data qubits on the diagonals."""
    data, xm, zm = layout(d, d)
    ds = set(data)
    out = {}
    for typ, ms in (('X', xm), ('Z', zm)):
        for c in ms:
            out[c] = (typ, tuple(sorted((c[0] + dx, c[1] + dy) for dx, dy in DIAG if (c[0] + dx, c[1] + dy) in ds)))
    return out


def footprint(c, d):
    """Checks (ancilla coordinates) whose support an exclusion changes, or the ancilla itself."""
    ch = checks(d)
    if c in ch:
        return {c}
    return {a for a, (t, s) in ch.items() if c in s}


def compatible(cs, d):
    seen = set()
    for c in cs:
        fp = footprint(c, d) | {c}
        if fp & seen:
            return False
        seen |= fp
    return True


def _nullspace_gf2(rows, ncols):
    """Basis of {x in GF(2)^ncols : A x = 0} for A given as a list of row bitmasks."""
    piv = []           # (pivot column, row mask)
    A = [r for r in rows if r]
    red = []
    for r in A:
        for pc, pr in red:
            if (r >> pc) & 1:
                r ^= pr
        if r:
            pc = (r & -r).bit_length() - 1
            red = [(c0, (r0 ^ r) if (r0 >> pc) & 1 else r0) for c0, r0 in red]
            red.append((pc, r))
    pivots = {pc for pc, _ in red}
    basis = []
    for free in range(ncols):
        if free in pivots:
            continue
        x = 1 << free
        for pc, pr in red:
            if (pr >> free) & 1:
                x |= 1 << pc
        basis.append(x)
    return basis


def _parse_noise(noise):
    m = dict(idle=1.0, h=1.0, cx=1.0, meas=1.0, reset=1.0, data_meas_idle=0.0, bias=None)
    if noise == 'dep':
        return m
    if noise == 'si1000':
        m.update(idle=0.1, h=0.1, cx=1.0, meas=5.0, reset=2.0, data_meas_idle=2.0)
        return m
    mm = re.fullmatch(r'([xz])bias(\d+(?:\.\d+)?)', noise)
    if mm:
        m['bias'] = (mm.group(1), float(mm.group(2)))
        return m
    raise ValueError(noise)


def circuit(d, rounds, p, excl=(), scale=None, row_len=None, noise='dep', basis='z', pair_scale=None):
    data, xm, zm = layout(d, d)
    RL = row_len or (2 * d + 1)
    idx = lambda c: c[0] + RL * (c[1] // 2)
    ch = checks(d)
    MT = 'Z' if basis == 'z' else 'X'                       # memory type
    OT = 'X' if MT == 'Z' else 'Z'
    nz = _parse_noise(noise)
    excl = list(excl)
    excl_data = [c for c in excl if c in set(data)]
    dead = [c for c in excl if c in ch]
    assert len(excl_data) + len(dead) == len(excl), 'unknown qubit'
    assert all(ch[c][0] == MT for c in dead), 'only memory-type measure qubits can be excluded'
    assert compatible(excl, d), 'overlapping exclusions'
    xd = set(excl_data)
    data_e = [c for c in data if c not in xd]
    dset = set(data_e)
    # deformed checks
    defo = {}
    for a, (t, s) in ch.items():
        if a in dead:
            continue
        s2 = tuple(q for q in s if q not in xd)
        if s2:
            defo[a] = (t, s2)
    changed = {a for a in defo if len(defo[a][1]) != len(ch[a][1])}
    anti = {a: set() for a in defo}
    for a in changed:
        for b in defo:
            if defo[b][0] != defo[a][0] and len(set(defo[a][1]) & set(defo[b][1])) % 2:
                anti[a].add(b); anti[b].add(a)
    gauges = {a for a in defo if anti[a]}
    normal = {a for a in defo if not anti[a]}
    # clusters of anticommuting gauges, and their super-stabilizers per type
    clusters, seen = [], set()
    for a in sorted(gauges, key=idx):
        if a in seen:
            continue
        comp, stack = [], [a]
        seen.add(a)
        while stack:
            u = stack.pop(); comp.append(u)
            for v in anti[u]:
                if v not in seen:
                    seen.add(v); stack.append(v)
        clusters.append(sorted(comp))
    supers = {'Z': [], 'X': []}           # lists of gauge-coordinate lists (each a super-stabilizer)
    for comp in clusters:
        for T in ('Z', 'X'):
            gs = [a for a in comp if defo[a][0] == T]
            os_ = [a for a in comp if defo[a][0] != T]
            if not gs:
                continue
            rows = [sum(1 << i for i, g in enumerate(gs) if len(set(defo[g][1]) & set(defo[o][1])) % 2) for o in os_]
            for x in _nullspace_gf2(rows, len(gs)):
                supers[T].append(sorted(g for i, g in enumerate(gs) if (x >> i) & 1))
    normal_m = sorted(a for a in normal if defo[a][0] == MT)
    normal_o = sorted(a for a in normal if defo[a][0] == OT)
    g_m = sorted(a for a in gauges if defo[a][0] == MT)
    g_o = sorted(a for a in gauges if defo[a][0] == OT)
    sc = scale or {}
    s = lambda c: sc.get(c, 1.0)
    ps = pair_scale or {}
    pscale = lambda a, b: ps.get((a, b), ps.get((b, a), 1.0))

    def fmt(x):
        return repr(x) if isinstance(x, float) else str(x)

    def ch1(kind, cs, mult, pmax=CAP1, pauli='dep'):
        """kind 'D' = DEPOLARIZE1 (or biased channel), 'X'/'Z' = flip channel."""
        if not cs or mult == 0:
            return []
        groups = {}
        for c in cs:
            groups.setdefault(min(p * mult * s(c), pmax), []).append(idx(c))
        out = []
        for pr, v in sorted(groups.items()):
            q = ' '.join(map(str, sorted(v)))
            if kind == 'X':
                out.append(f'X_ERROR({fmt(pr)}) {q}')
            elif kind == 'Z':
                out.append(f'Z_ERROR({fmt(pr)}) {q}')
            elif nz['bias'] is None:
                out.append(f'DEPOLARIZE1({fmt(pr)}) {q}')
            else:
                out.append(_biased(pr, q))
        return out

    def _biased(t, q):
        axis, eta = nz['bias']
        big, small = t * eta / (eta + 1), t / (2 * (eta + 1))
        px, py, pz = (big, small, small) if axis == 'x' else (small, small, big)
        return f'PAULI_CHANNEL_1({px!r}, {py!r}, {pz!r}) {q}'

    def ch2(pairs):
        groups = {}
        for a, b in pairs:
            groups.setdefault(min(p * nz['cx'] * max(s(a), s(b)) * pscale(a, b), CAP2), []).extend([idx(a), idx(b)])
        out = []
        for pr, v in sorted(groups.items()):
            if nz['bias'] is None:
                out.append(f'DEPOLARIZE2({fmt(pr)}) ' + ' '.join(map(str, v)))
            else:                                        # independent biased channels, same marginal as DEPOLARIZE2
                out.append(_biased(min(0.8 * pr, CAP1), ' '.join(map(str, v))))
        return out

    allm = sorted(normal_m + normal_o + g_m + g_o, key=idx)
    allq = sorted(data_e + allm, key=idx)
    out = [f'QUBIT_COORDS({c[0]}, {c[1]}) {idx(c)}' for c in allq]
    data_s = sorted(data_e, key=idx)
    prep = 'R' if MT == 'Z' else 'RX'
    flip = 'X' if MT == 'Z' else 'Z'
    out.append(prep + ' ' + ' '.join(str(idx(c)) for c in data_s)); out += ch1(flip, data_s, nz['reset'], CAPX)
    out.append('R ' + ' '.join(str(idx(c)) for c in allm)); out += ch1('X', allm, nz['reset'], CAPX)
    out.append('TICK')
    ox = [(1, 1), (-1, 1), (1, -1), (-1, -1)]; oz = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    rec = {}; m = 0

    def act(r):
        Ms = normal_m + (g_m if r % 2 == 0 else [])
        Os = normal_o + (g_o if r % 2 == 1 else [])
        return Ms, Os

    for r in range(rounds):
        Ms, Os = act(r)
        Z = Ms if MT == 'Z' else Os
        X = Os if MT == 'Z' else Ms
        Xs = sorted(X, key=idx)
        if r > 0:
            out.append('TICK')
        out += ch1('D', data_s, nz['idle'])
        if Xs:
            out.append('H ' + ' '.join(str(idx(c)) for c in Xs)); out += ch1('D', Xs, nz['h'])
        out.append('TICK')
        for k in range(4):
            pairs = []
            for c in sorted(X):
                dc = (c[0] + ox[k][0], c[1] + ox[k][1])
                if dc in dset and dc in defo[c][1]:
                    pairs.append((c, dc))
            for c in sorted(Z):
                dc = (c[0] + oz[k][0], c[1] + oz[k][1])
                if dc in dset and dc in defo[c][1]:
                    pairs.append((dc, c))
            out.append('CX ' + ' '.join(f'{idx(a)} {idx(b)}' for a, b in pairs)); out += ch2(pairs); out.append('TICK')
        if Xs:
            out.append('H ' + ' '.join(str(idx(c)) for c in Xs)); out += ch1('D', Xs, nz['h'])
        out.append('TICK')
        M = sorted(Z + X, key=idx)
        out += ch1('X', M, nz['meas'], CAPX)
        if nz['data_meas_idle']:
            out += ch1('D', data_s, nz['data_meas_idle'])
        out.append('MR ' + ' '.join(str(idx(c)) for c in M)); out += ch1('X', M, nz['reset'], CAPX)
        for c in M:
            rec[(c, r)] = m; m += 1
        R = lambda key: f'rec[{rec[key] - m}]'
        if r == 0:
            for c in sorted(Ms):
                out.append(f'DETECTOR({c[0]}, {c[1]}, 0) {R((c, 0))}')
        else:
            for c in sorted(normal_m + normal_o):
                out.append(f'DETECTOR({c[0]}, {c[1]}, {r}) {R((c, r))} {R((c, r - 1))}')
            for T, par in ((MT, 0), (OT, 1)):
                if r % 2 == par and r >= 2 + par:
                    for g in supers[T]:
                        out.append(f'DETECTOR({g[0][0]}, {g[0][1]}, {r}) ' + ' '.join(R((c, t)) for c in g for t in (r, r - 2)))
    out += ch1(flip, data_s, nz['meas'], CAPX)
    out.append(('M ' if MT == 'Z' else 'MX ') + ' '.join(str(idx(c)) for c in data_s))
    for c in data_s:
        rec[(c, 'd')] = m; m += 1
    R = lambda key: f'rec[{rec[key] - m}]'
    sup = lambda a: [q for q in defo[a][1] if q in dset] if a in defo else [q for q in ch[a][1] if q in dset]
    T_ = rounds
    last_m = max(r for r in range(rounds) if r % 2 == 0)
    gauge_last_is_m = (rounds - 1) % 2 == 0
    for c in normal_m:
        out.append(f'DETECTOR({c[0]}, {c[1]}, {T_}) ' + ' '.join(R((q, 'd')) for q in sup(c)) + f' {R((c, rounds - 1))}')
    if gauge_last_is_m:
        for c in g_m:
            out.append(f'DETECTOR({c[0]}, {c[1]}, {T_}) ' + ' '.join(R((q, 'd')) for q in sup(c)) + f' {R((c, last_m))}')
    else:
        for g in supers[MT]:
            out.append(f'DETECTOR({g[0][0]}, {g[0][1]}, {T_}) ' + ' '.join(R((q, 'd')) for c in g for q in sup(c))
                       + ' ' + ' '.join(R((c, last_m)) for c in g))
    for c in dead:
        out.append(f'DETECTOR({c[0]}, {c[1]}, {T_}) ' + ' '.join(R((q, 'd')) for q in ch[c][1] if q in dset))
    obs = _observable(d, data_e, defo, OT, basis)
    out.append('OBSERVABLE_INCLUDE(0) ' + ' '.join(R((q, 'd')) for q in obs))
    meta = dict(excl_data=excl_data, dead=dead, gauges=sorted(gauges), supers=supers, obs=obs,
                normal_m=normal_m, normal_o=normal_o)
    return '\n'.join(out) + '\n', meta


def _observable(d, data_e, defo, OT, basis):
    """Nearest row (Z basis) / column (X basis) to the default one that avoids the deformation and commutes with
    every deformed check of the other type."""
    dset = set(data_e)
    lines = range(1, 2 * d, 2)
    for v in lines:
        line = [q for q in sorted(dset) if (q[1] if basis == 'z' else q[0]) == v]
        if len(line) != d:
            continue
        L = set(line)
        if all(len(L & set(sv)) % 2 == 0 for a, (t, sv) in defo.items() if t == OT):
            return sorted(line, key=lambda q: (q[1], q[0]))
    raise ValueError('no logical line avoids the deformation')
