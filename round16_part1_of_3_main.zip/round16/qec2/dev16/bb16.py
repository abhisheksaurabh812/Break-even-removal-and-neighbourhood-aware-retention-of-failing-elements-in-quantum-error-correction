"""Round 16, part G: keep versus decoder-only erasure for a failing qubit of the bivariate bicycle code [[72,12,6]].

Code: l = m = 6, A = x^3 + y + y^2, B = y^3 + x + x^2 (Bravyi et al. 2024); H_X = [A|B], H_Z = [B^T|A^T].
Noise: phenomenological X errors on the data qubits (probability p per qubit per round, times the qubit's factor)
and measurement errors (probability p) on the Z checks, over T noisy rounds and a final perfect round; decoded with
the space-time parity-check matrix by BP-OSD (bposd16.py). A failure is any of the 12 logical operators flipped.
The failing data qubit j0 (index 0) has factor f; its Tanner-graph neighbours (data qubits sharing a Z check with it)
are at level L. The decoder keeps it with priors that do not know f (retain = unchanged: every qubit nominal;
tracked: neighbours at L), or treats it as erased (its data-error columns at prior 0.5, other priors the same).
Both decoders decode the same samples; the crossover is the first f at which keeping fails at least as often.
The factors are absolute, f = 1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30 at every level (so a crossover below L can be seen),
the qubit's per-round probability capped at 0.5; crossing interpolated in (ln f, ln keep - ln erase).
python3 bb16.py --levels 1,2,4 --shots 100000 --seed0 S --p P --retain unchanged --out X.json [--T 6]"""
import sys, os, json, time, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import bposd16                                    # noqa: E402

REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30)


def shift(n):
    return np.roll(np.eye(n, dtype=np.uint8), 1, axis=1)


def bb_code(l=6, m=6):
    x = np.kron(shift(l), np.eye(m, dtype=np.uint8)); y = np.kron(np.eye(l, dtype=np.uint8), shift(m))
    mp = lambda M, k: np.linalg.matrix_power(M.astype(np.int64), k) % 2
    A = (mp(x, 3) + mp(y, 1) + mp(y, 2)) % 2
    B = (mp(y, 3) + mp(x, 1) + mp(x, 2)) % 2
    HX = np.concatenate([A, B], axis=1).astype(np.uint8)
    HZ = np.concatenate([B.T, A.T], axis=1).astype(np.uint8)
    assert not ((HX.astype(int) @ HZ.T.astype(int)) % 2).any()
    return HX, HZ


def rank_gf2(M):
    M = M.copy() % 2; r = 0
    for c in range(M.shape[1]):
        nz = np.nonzero(M[r:, c])[0]
        if nz.size == 0:
            continue
        p_ = r + nz[0]; M[[r, p_]] = M[[p_, r]]
        others = np.nonzero(M[:, c])[0]; others = others[others != r]
        M[others] ^= M[r]; r += 1
        if r == M.shape[0]:
            break
    return r


def kernel_gf2(M):
    M = M.copy() % 2; m, n = M.shape; piv = []; r = 0
    for c in range(n):
        nz = np.nonzero(M[r:, c])[0] if r < m else []
        if len(nz) == 0:
            continue
        p_ = r + nz[0]; M[[r, p_]] = M[[p_, r]]
        others = np.nonzero(M[:, c])[0]; others = others[others != r]
        M[others] ^= M[r]; piv.append(c); r += 1
        if r == m:
            break
    free = [c for c in range(n) if c not in piv]
    K = []
    for f in free:
        v = np.zeros(n, dtype=np.uint8); v[f] = 1
        for i, c in enumerate(piv):
            if M[i, f]:
                v[c] = 1
        K.append(v)
    return np.array(K, dtype=np.uint8)


def z_logicals(HX, HZ):
    K = kernel_gf2(HX)
    rows = HZ.copy(); r0 = rank_gf2(rows); out = []
    for v in K:
        t = np.vstack([rows, v])
        if rank_gf2(t) > r0:
            rows = t; r0 += 1; out.append(v)
    return np.array(out, dtype=np.uint8)


def spacetime(HZ, T):
    m, n = HZ.shape
    H = np.zeros((m * (T + 1), n * T + m * T), dtype=np.uint8)
    for t in range(T):
        H[m * t:m * (t + 1), n * t:n * (t + 1)] = HZ                       # data errors in round t
        H[m * t:m * (t + 1), n * T + m * t:n * T + m * (t + 1)] = np.eye(m, dtype=np.uint8)   # measurement error t
        H[m * (t + 1):m * (t + 2), n * T + m * t:n * T + m * (t + 1)] = np.eye(m, dtype=np.uint8)
    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--levels', required=True); ap.add_argument('--shots', type=int, required=True)
    ap.add_argument('--seed0', type=int, required=True); ap.add_argument('--p', type=float, required=True)
    ap.add_argument('--retain', default='unchanged'); ap.add_argument('--out', required=True)
    ap.add_argument('--T', type=int, default=6); ap.add_argument('--batch', type=int, default=2000)
    a = ap.parse_args()
    HX, HZ = bb_code(); LZ = z_logicals(HX, HZ)
    n = HX.shape[1]; m = HZ.shape[0]; T = a.T
    assert LZ.shape[0] == 12, LZ.shape
    H = spacetime(HZ, T)
    Lst = np.concatenate([np.tile(LZ, (1, T)), np.zeros((LZ.shape[0], m * T), dtype=np.uint8)], axis=1)
    j0 = 0
    nb = sorted(int(x) for x in set(np.nonzero(HZ[np.nonzero(HZ[:, j0])[0]].any(axis=0))[0]) - {j0})
    cols = lambda j: [j + n * t for t in range(T)]
    res = dict(code='[[72,12,6]]', T=T, p=a.p, retain=a.retain, seed0=a.seed0, qubit=j0, neighbours=nb, rows=[])
    if os.path.exists(a.out):
        prev = json.load(open(a.out))
        if all(prev.get(k) == res[k] for k in ('T', 'p', 'retain', 'seed0')):
            res['rows'] = prev['rows']
    have = {r['L'] for r in res['rows']}; t0 = time.time()
    for L in [float(x) for x in a.levels.split(',')]:
        if L in have:
            continue
        grid = list(REL)
        keep, erase = [], []
        for f in grid:
            pr = np.full(H.shape[1], a.p)
            for j in nb:
                pr[cols(j)] = min(0.5, a.p * L)
            pr[cols(j0)] = min(0.5, a.p * f)
            prior = np.full(H.shape[1], a.p)
            if a.retain == 'tracked':
                for j in nb:
                    prior[cols(j)] = min(0.5, a.p * L)
            pe = prior.copy(); pe[cols(j0)] = 0.5
            dk, de = bposd16.BPOSD(H, prior), bposd16.BPOSD(H, pe)
            fk = fe = 0; done = 0; seed = a.seed0
            while done < a.shots:
                k = min(a.batch, a.shots - done)
                rng = np.random.default_rng(seed)
                e = (rng.random((k, H.shape[1])) < pr).astype(np.uint8)
                s = (e.astype(np.int32) @ H.T.astype(np.int32)) % 2
                lo = (e.astype(np.int32) @ Lst.T.astype(np.int32)) % 2
                for dec, tag in ((dk, 'k'), (de, 'e')):
                    est = dec.decode_batch(s.astype(np.uint8))
                    fl = (((est.astype(np.int32) @ Lst.T.astype(np.int32)) % 2) != lo).any(axis=1).sum()
                    if tag == 'k':
                        fk += int(fl)
                    else:
                        fe += int(fl)
                done += k; seed += 1
            keep.append(fk); erase.append(fe)
            print('L', L, 'f', f, 'keep', fk, 'erase', fe, round(time.time() - t0), flush=True)
            if fk >= fe:
                break
        cross = None
        for i, (f, k_, e_) in enumerate(zip(grid, keep, erase)):
            if k_ >= e_:
                if i == 0:
                    cross = float(f)
                else:
                    g0 = np.log(max(keep[i - 1], 1)) - np.log(max(erase[i - 1], 1)); g1 = np.log(max(k_, 1)) - np.log(max(e_, 1))
                    tt = g0 / (g0 - g1) if g1 != g0 else 1.0
                    cross = round(float(np.exp(np.log(grid[i - 1]) + tt * (np.log(f) - np.log(grid[i - 1])))), 2)
                break
        res['rows'].append(dict(L=L, shots=a.shots, grid=grid[:len(keep)], keep=keep, erase=erase, crossover=cross))
        res['rows'].sort(key=lambda r: r['L'])
        json.dump(res, open(a.out, 'w'), indent=1)
    res['elapsed'] = round(res.get('elapsed', 0) + time.time() - t0, 1)
    json.dump(res, open(a.out, 'w'), indent=1)


if __name__ == '__main__':
    main()
