# Round 16, parts G and J — rules (fixed before the first run)

Both parts use `bposd16.py`, a BP-OSD decoder written for this round because the `ldpc` package cannot be installed
here: normalised min-sum belief propagation (scale 0.625, at most 30 iterations, messages capped at 50), then
ordered-statistics decoding on shots whose hard decision does not reproduce the syndrome (columns ranked by posterior,
OSD-0 plus a combination sweep over single flips and pairs among the first 20 non-pivot columns, lowest prior cost).

**Decoder checks done before this file (spent seeds).** Surface code, circuit-level noise: distance 3, 167 failures
in 20,000 shots against 158 for matching; distance 5, 24 in 8,000 against 28 for matching. Bivariate bicycle code
[[72,12,6]], perfect syndrome: every one of the 2,628 X errors of weight 1 and 2 is corrected (distance 6 corrects
2). No published table for the noise model of part G was found to compare with.

## G — a qLDPC code: keeping a failing qubit versus treating it as erased (numpy seeds from 1680001)

`bb16.py`. Code [[72,12,6]] (l = m = 6, A = x³ + y + y², B = y³ + x + x², Bravyi et al. 2024). Phenomenological
noise for a Z-basis memory: X errors on the data qubits with probability p per qubit per round (times the qubit's
factor) and Z-check measurement errors with probability p, over 6 noisy rounds and a final perfect round; the
space-time parity-check matrix is decoded by BP-OSD; a failure is any of the 12 logical Z operators flipped.
p = 0.01 (chosen on spent seeds: about 0.8% failures per block with every qubit nominal; 0.015 gave 12% at L = 4).

The failing data qubit is qubit 0 (all data qubits are equivalent under the code's translations); its 15 Tanner-graph
neighbours (the data qubits sharing a Z check with it) are at level L. Kept: the decoder's priors are either
unchanged (every qubit at p) or tracked (the neighbours at p·L, the failing qubit at p). Erased: the same priors with
the failing qubit's columns at 0.5. Both decoders decode the same samples. Factors f = 1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30
at every level (absolute, so a crossover below L is seen), capped at probability 0.5, up to the first factor at which
keeping fails at least as often; crossing interpolated in (ln f, ln keep − ln erase). 100,000 shots per point,
numpy generator seeds 1680001, 1680002, … per batch of 2,000 shots, the same for every point.
Unchanged priors at L = 1, 2, 4; tracked priors at L = 2, 4 (at L = 1 they equal the unchanged ones).

Outcome: exploratory, no bar. Reported whatever the outcome: each threshold (or "below 1": erasing pays even at
f = 1; or "none within the grid"), how it moves with L, and the failures of the kept qubit under unchanged and
tracked priors at equal f. Expected from the dev points: a threshold near 1 at L = 1, below L at L = 4 with
unchanged priors, and above L with tracked priors.

## J — a third decoder on the surface code (Stim seeds from 1670001)

`j16.py`. The same circuits (`deform16.py`), region (Chebyshev distance 4 raised to L), factor grid
L × (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30), stopping and crossing rule as `ideal16.py` with exact rates, but decoded by
BP-OSD with each configuration's own detector error model, not decomposed (hyperedges kept; identical mechanisms
merged). Distance 5, p = 0.003, Z-basis memory; the Z-type measure qubit (4, 4) and the data qubit (5, 5); L = 1
and 4; 100,000 shots per point (about ±20% on a threshold); Stim seeds 1670001, 1670002, … per chunk of 20,000
shots, the same for every configuration.

Outcome: exploratory, no bar. Reported: the four thresholds beside those of plain and correlated matching for the
same qubits from part B (`out16/B/d5_*`), and whether each moves between L = 1 and 4 in the same direction as for
matching.

Verification by a second script as in the other parts. Hashes of this file, `jobs16GJ.txt`, `bb16.py`, `j16.py`,
`bposd16.py` and `deform16.py` in `out16/GJ_hashes_at_start.txt` before the first run.
