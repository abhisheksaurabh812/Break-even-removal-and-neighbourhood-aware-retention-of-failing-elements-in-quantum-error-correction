"""Round 16, part M: runs round 15's runner (../dev15/m15/run15.py, unchanged and imported as is) with model caches
private to part M, so that nothing is written into round 15's folders.

    python3 run16m.py cfg.json out.npz [key=json ...]

Only these things differ from `PYTHONPATH=<scratchpad>/pylib python3 ../dev15/m15/run15.py cfg.json out.npz`:
 - the library folder that round 15 used (<scratchpad>/pylib, PyMatching 2.4.0) is put on the path here, not in the
   environment, so the queue's other jobs keep theirs;
 - model.py and run3.py cache into cacheM/c14 (run15.py's own CACHE14 switch, set before it is imported);
 - model15.base15 and model15.deformed15, whose cache folder is a default argument, are called by run15.run with
   cache=cacheM/c15.
Both folders start as hard links of round 15's caches (cache14, cache15); the cache code only reads a file that exists
and writes new files only when one is missing, so round 15's files are never written. The arms, the sampling, the
decoding and the output are run15.run's own."""
import os, sys, json, functools
HERE = os.path.dirname(os.path.abspath(__file__))
os.environ['CACHE14'] = os.path.join(HERE, 'cacheM', 'c14')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(HERE)), 'pylib'))
sys.path.insert(1, os.path.join(os.path.dirname(HERE), 'dev15', 'm15'))
import run15                                                          # noqa: E402
C15 = os.path.join(HERE, 'cacheM', 'c15')
run15.base15 = functools.partial(run15.base15, cache=C15)
run15.deformed15 = functools.partial(run15.deformed15, cache=C15)

if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run15.run(cfg, sys.argv[2])
