"""Round 16, part I, item 10 (rules: PREREG_16I3b.md): round 15's role-based crossover cutoffs against reweighting
alone and the other methods that used the same (earlier) naming and sizing; pooled and by test, both decoders.
python3 analyse16_I10.py   (writes out16/I/I10_results.txt and .json)"""
import os, glob, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); OUT15 = os.path.join(os.path.dirname(HERE), 'out15')
TESTS = ['d9_mixed', 'd9_severe', 'd9_moderate', 'd9_realistic', 'pairs_mixed', 'long_severe', 'long_mixed', 'd9_hwlike']
PAIRS = [('sz_w15', 'sz'), ('sz_w15', 'cut15'),                    # checks against Table 3 of the filed specification
         ('cut15', 'sz'), ('cut', 'sz'), ('cut15', 'loc'), ('cut15', 'sz_all'), ('cut', 'sz_all')]


def main():
    per = {'corr': [], 'plain': []}; test_of = []
    for t in TESTS:
        fs = sorted(glob.glob(os.path.join(OUT15, f'{t}_s*.npz')))
        for f in fs:
            z = np.load(f, allow_pickle=True); names = [str(x) for x in z['names']]; test_of.append(t)
            for dec, key in (('corr', 'fails_c'), ('plain', 'fails')):
                per[dec].append(dict(zip(names, z[key].astype(np.int64).sum(axis=(1, 2)).tolist())))
    assert len(test_of) == 70, len(test_of)

    def comp(dec, a, b, sub=None):
        rs = [r for r, t in zip(per[dec], test_of) if sub is None or t == sub]
        A = np.array([r[a] for r in rs], float); B = np.array([r[b] for r in rs], float)
        idx = np.random.default_rng(8).integers(0, len(A), size=(10000, len(A)))
        bs = (A[idx].sum(1) - B[idx].sum(1)) / B[idx].sum(1)
        return dict(rel_pct=round(100 * (A.sum() - B.sum()) / B.sum(), 2), lo_pct=round(100 * float(np.percentile(bs, 2.5)), 2),
                    hi_pct=round(100 * float(np.percentile(bs, 97.5)), 2), runs_better=int((A < B).sum()), runs=len(rs))
    R = {}; lines = []
    for dec in ('corr', 'plain'):
        for a, b in PAIRS:
            R[f'{dec}|{a} vs {b}|all'] = comp(dec, a, b)
            for t in TESTS:
                if (a, b) in (('cut15', 'sz'), ('sz_w15', 'sz'), ('sz_w15', 'cut15')):
                    R[f'{dec}|{a} vs {b}|{t}'] = comp(dec, a, b, t)
    for k, v in R.items():
        lines.append(f'{k:40s} {v["rel_pct"]:+7.2f}%  [{v["lo_pct"]:+.2f}, {v["hi_pct"]:+.2f}]  better in {v["runs_better"]}/{v["runs"]}')
    os.makedirs(os.path.join(HERE, 'out16', 'I'), exist_ok=True)
    json.dump(R, open(os.path.join(HERE, 'out16', 'I', 'I10_results.json'), 'w'), indent=1)
    open(os.path.join(HERE, 'out16', 'I', 'I10_results.txt'), 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
