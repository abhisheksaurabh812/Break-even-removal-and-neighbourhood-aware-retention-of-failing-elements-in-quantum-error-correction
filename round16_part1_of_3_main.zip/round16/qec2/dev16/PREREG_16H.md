# Round 16, part H — boundary and corner qubits: rules (fixed before the first run)

**Question.** Do qubits on the boundary and at the corner of the patch have finite switch-out (break-even)
thresholds, how do they compare with the bulk qubits of the same type, and do they move with the neighbourhood
level?

**Method.** `ideal16.py` with `deform16.py` (the same builder, crossover rule and decoders as part B; the decoder
knows the true rates, "exact"). Four qubits, chosen by `target()` in `ideal16.py`:
- `edge-data-x`: the data qubit on the boundary row y = 1 nearest the middle of that side;
- `edge-data-z`: the data qubit on the boundary column x = 1 nearest the middle of that side (the other boundary type);
- `corner-data`: the corner data qubit (1, 1);
- `edge-zanc`: the weight-two Z-type measure qubit on the boundary column x = 0 nearest the middle of that side.
The qubits within Chebyshev distance 4 of the qubit and inside the patch are raised to the level L (so the region
is smaller than in the bulk; its size is recorded). Distances 7 and 9; plain and correlated matching;
L = 1, 2, 4, 8; 2,000,000 shots per point for L ≤ 2 and 1,000,000 above; circuit-level depolarizing noise
p = 0.003; Z-basis memory; blocks of d rounds. Stim seeds 1650001, 1650002, … per chunk of 200,000 shots.

**Distance check (done before this file was written; `hdist16.py`, output `out16/H/distances.txt`).** With Stim's
shortest graphlike logical error: removing each of the three data qubits leaves distance d − 1 in both memory bases
(as for a bulk data qubit); removing the edge Z-type measure qubit leaves distance d in the Z basis (as for a bulk
Z-type measure qubit). Same check for every bulk and coupler removal used in round 16 at distances 5, 7 and 9.

**Outcome.** Exploratory: no pass bar ("removal never pays" is a possible result and would be reported as such).
For every qubit, distance, decoder and level, reported whatever the outcome:
1. the threshold, or "none within the grid" (factor 300);
2. the ratio of the threshold at L = 2, 4 and 8 to that at L = 1;
3. the ratio to the bulk qubit of the same type at the same distance, decoder and level (Table 1 / round 15 tables
   for distance 9 and 7; seeds differ, so each ratio carries both runs' precision, about 10%).

**Verification.** A second script recomputes every threshold from the stored counts with its own implementation.

**Job list.** `jobs16H.txt` (64 jobs, one per level, chained so that a table is written by one job at a time), run
by `queue16.py` together with the other parts. Hashes of this file, the job list and the code are recorded in
`out16/H/hashes_at_start.txt` before the first run and re-checked after.
