"""Round 16, part I: analyses of existing break-even tables (no new simulation).
python3 analyse16_I.py > out16/I/I_results.txt   (also writes out16/I/I_results.json)

Tables: distance 7 and 9, data qubit and Z-type measure qubit, plain matching (rounds 9 and 10) and correlated
matching (round 15), plus any finished round-16 part-B tables (distances 5, 11, 13). For a qubit of factor f at level
L, K(f) is the failure count kept (interpolated linearly in (ln f, ln K); flat below the grid; extrapolated from the
last two points above it) and E the count removed; the best decision costs min(K, E).
Failure sizes: log-uniform on [2, 100] (round 15's mixed scenario), evaluated on 400 log-spaced points.
 (1) misplaced thresholds: decide with mu * f*(L), mu in 0.5, 0.75, 1.25, 1.5, 2;
 (2) each decoder's thresholds used with the other decoder (same distance);
 (3) target boundaries in the manner of Palmer and Smith: act once K(f) >= (1 + eps) K(L), eps = 0.1, 0.25, 0.5, 1;
 (5) a fitted formula ln f* = a + b ln L + c (ln L)^2 per role and decoder (distances pooled, with a distance term);
 (6) a logistic classifier on (ln f, ln L, ln^2 L) trained on one distance's labels, tested on the other's;
 (7) one threshold for both roles at each level;
 (8) a worked cost-aware switching example;
 (9) the decision time per period of the gate's rule at distance 9, and the memory of the tables.
Cost = mean over the failure sizes of (failures of the decision - best) / best, in percent; also the worst case."""
import sys, os, json, glob, time
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); QEC2 = os.path.dirname(HERE)
sys.path.insert(0, QEC2); sys.path.insert(0, HERE)

SRC = {(7, 'data', 'plain'): 'out9/field_table_data.json', (7, 'zanc', 'plain'): 'out9/field_table_zanc.json',
       (9, 'data', 'plain'): 'out10/field_table_d9_data.json', (9, 'zanc', 'plain'): 'out10/field_table_d9_zanc.json',
       (7, 'data', 'corr'): 'dev15/m15/tables/field_table15_d7_data.json',
       (7, 'zanc', 'corr'): 'dev15/m15/tables/field_table15_d7_zanc.json',
       (9, 'data', 'corr'): 'dev15/m15/tables/field_table15_d9_data.json',
       (9, 'zanc', 'corr'): 'dev15/m15/tables/field_table15_d9_zanc.json'}
FS = np.exp(np.linspace(np.log(2), np.log(100), 400))
MUS = (0.5, 0.75, 1.25, 1.5, 2.0); EPS = (0.1, 0.25, 0.5, 1.0); LV = (1.0, 2.0, 4.0, 8.0)


def load():
    T = {}
    for k, f in SRC.items():
        T[k] = {r['L']: r for r in json.load(open(os.path.join(QEC2, f)))['rows']}
    for f in sorted(glob.glob(os.path.join(HERE, 'out16', 'B', 'd*_*_*.json'))):
        r = json.load(open(f)); dec = 'corr' if r['decoder'] == 'correlated' else 'plain'
        if r['rows']:
            T[(r['d'], r['kind'], dec)] = {x['L']: x for x in r['rows']}
    return T


def lnK(row, f):
    g = np.log(row['grid']); k = np.log(np.maximum(row['keep'], 1)); x = np.log(np.atleast_1d(f))
    if len(g) == 1:
        return np.full_like(x, k[0])
    out = np.interp(x, g, k)
    hi = x > g[-1]
    out[hi] = k[-1] + (x[hi] - g[-1]) * (k[-1] - k[-2]) / (g[-1] - g[-2])
    return out


def cost(row, remove):
    """remove: boolean array over FS. Returns (mean excess %, worst excess %)."""
    K = np.exp(lnK(row, FS)); E = max(row['excl'], 1)
    got = np.where(remove, E, K); best = np.minimum(K, E)
    ex = (got - best) / best * 100
    return round(float(ex.mean()), 2), round(float(ex.max()), 1)


def fstar(row):
    return row['crossover'] if row['crossover'] is not None else np.inf


def main():
    T = load(); R = {}
    keys = sorted(T)
    # (1) misplaced thresholds
    R['1_misplaced'] = {}
    for k in keys:
        for L in LV:
            if L not in T[k]:
                continue
            row = T[k][L]; fs = fstar(row)
            R['1_misplaced'][f'{k}|L{L:g}'] = {f'mu{m:g}': cost(row, FS > m * fs) for m in MUS}
    # (2) cross-decoder
    R['2_cross_decoder'] = {}
    for (d, role, dec) in keys:
        other = 'corr' if dec == 'plain' else 'plain'
        if (d, role, other) not in T:
            continue
        for L in LV:
            if L in T[(d, role, dec)] and L in T[(d, role, other)]:
                row = T[(d, role, dec)][L]; fo = fstar(T[(d, role, other)][L])
                R['2_cross_decoder'][f'{(d, role, dec)}|L{L:g}'] = dict(own=fstar(row), used=fo, cost=cost(row, FS > fo))
    # (3) target boundaries
    R['3_target_boundary'] = {}
    for k in keys:
        for L in LV:
            if L not in T[k]:
                continue
            row = T[k][L]; KL = np.exp(lnK(row, L))[0]
            out = {}
            for e in EPS:
                dense = np.exp(np.linspace(np.log(L), np.log(300), 2000))
                above = dense[np.exp(lnK(row, dense)) >= (1 + e) * KL]
                fb = float(above[0]) if above.size else np.inf
                out[f'eps{e:g}'] = dict(boundary=round(fb, 2), ratio_to_breakeven=round(fb / fstar(row), 2), cost=cost(row, FS > fb))
            R['3_target_boundary'][f'{k}|L{L:g}'] = dict(breakeven=fstar(row), **out)
    # (5) fitted formula
    R['5_fit'] = {}
    for role in ('data', 'zanc'):
        for dec in ('plain', 'corr'):
            X, y = [], []
            for (d, r_, de), rows in T.items():
                if r_ != role or de != dec:
                    continue
                for L, row in rows.items():
                    if row['crossover'] is not None:
                        lL = np.log(L); X.append([1, lL, lL * lL, d]); y.append(np.log(row['crossover']))
            X, y = np.array(X), np.array(y)
            coef, *_ = np.linalg.lstsq(X, y, rcond=None)
            res = y - X @ coef
            R['5_fit'][f'{role}|{dec}'] = dict(a=round(coef[0], 4), b=round(coef[1], 4), c=round(coef[2], 4), e_per_d=round(coef[3], 4),
                                               n=len(y), max_abs_residual_pct=round(float(np.max(np.abs(np.expm1(res)))) * 100, 1),
                                               rms_residual_pct=round(float(np.sqrt(np.mean(np.expm1(res) ** 2))) * 100, 1))
    # (6) classifier: train on distance a, test on distance b
    R['6_classifier'] = {}
    for dec in ('plain', 'corr'):
        for role in ('data', 'zanc'):
            for a, b in ((7, 9), (9, 7)):
                if (a, role, dec) not in T or (b, role, dec) not in T:
                    continue
                Xa, ya = [], []
                for L, row in T[(a, role, dec)].items():
                    lab = np.exp(lnK(row, FS)) > row['excl']
                    for f, l_ in zip(FS[::8], lab[::8]):
                        Xa.append([1, np.log(f), np.log(L), np.log(L) ** 2]); ya.append(float(l_))
                Xa, ya = np.array(Xa), np.array(ya); w = np.zeros(4)
                for _ in range(100):                       # Newton's method with a small ridge
                    p_ = 1 / (1 + np.exp(-np.clip(Xa @ w, -30, 30)))
                    H = (Xa * (p_ * (1 - p_))[:, None]).T @ Xa + 1e-3 * np.eye(4)
                    w -= np.linalg.solve(H, Xa.T @ (p_ - ya) + 1e-3 * w)
                out = {}
                for L, row in sorted(T[(b, role, dec)].items()):
                    if L not in LV:
                        continue
                    z = w[0] + w[1] * np.log(FS) + w[2] * np.log(L) + w[3] * np.log(L) ** 2
                    rem = z > 0
                    lab = np.exp(lnK(row, FS)) > row['excl']
                    out[f'L{L:g}'] = dict(accuracy=round(float((rem == lab).mean()), 3), cost=cost(row, rem),
                                          boundary=round(float(np.exp(-(w[0] + w[2] * np.log(L) + w[3] * np.log(L) ** 2) / w[1])), 2),
                                          breakeven=fstar(row))
                R['6_classifier'][f'{role}|{dec}|train d{a} test d{b}'] = dict(weights=[round(x, 3) for x in w], **out)
    # (7) one threshold for both roles at each level
    R['7_one_threshold'] = {}
    for d in (7, 9):
        for dec in ('plain', 'corr'):
            for L in LV:
                rows = [T[(d, r, dec)].get(L) for r in ('data', 'zanc')]
                if None in rows:
                    continue
                best = None
                for tau in np.exp(np.linspace(np.log(2), np.log(60), 300)):
                    c = [cost(r, FS > tau) for r in rows]; s = c[0][0] + c[1][0]
                    if best is None or s < best[0]:
                        best = (s, tau, c)
                R['7_one_threshold'][f'd{d}|{dec}|L{L:g}'] = dict(tau=round(best[1], 2), own=[fstar(r) for r in rows],
                                                                   cost_data=best[2][0], cost_zanc=best[2][1])
    # (8) worked cost-aware switching example (distance 9, correlated matching, Z-type measure qubit, L = 3)
    row = T[(9, 'zanc', 'corr')][3.0]; f = 30.0
    K = float(np.exp(lnK(row, f))[0]); E = row['excl']; shots = row['shots']
    gain_per_block = (K - E) / shots
    R['8_switching_example'] = dict(table='d9 zanc corr L=3', f=f, K=round(K), E=E, shots=shots,
                                    gain_per_block=gain_per_block,
                                    note='a switch (removal and return) costing c blocks of logical failure pays when the failure lasts '
                                         'more than c / gain_per_block blocks')
    for c in (0.001, 0.01):
        R['8_switching_example'][f'min_blocks_for_switch_cost_{c:g}'] = round(c / gain_per_block) if gain_per_block > 0 else None
    # (9) decision time and table memory (distance 9)
    import deform16
    from rectgen import layout
    d = 9; data, xm, zm = layout(d, d); allq = sorted(data + xm + zm)
    fp = {c: deform16.footprint(c, d) for c in allq}
    ring = {g: [allq.index(c) for c in zm if c not in fp[g] and c != g and max(abs(c[0] - g[0]), abs(c[1] - g[1])) <= 4]
            for g in sorted(data + zm)}
    tabs = {r: (np.log([1, 1.5, 2, 3, 4, 6, 8]), np.log([T[(9, r, 'corr')][L]['crossover'] for L in (1, 1.5, 2, 3, 4, 6, 8)]))
            for r in ('data', 'zanc')}
    role = {c: ('data' if c in data else 'zanc') for c in ring}
    rng = np.random.default_rng(5); u = np.exp(0.35 * rng.standard_normal(len(allq))); fac = np.exp(0.35 * rng.standard_normal(len(allq)))
    t0 = time.perf_counter(); n = 200
    for _ in range(n):
        dec_ = []
        for g, idx in ring.items():
            L = float(np.median(u[idx])); lx, ly = tabs[role[g]]
            fsg = float(np.exp(np.interp(np.log(max(L, 1.0)), lx, ly)))
            dec_.append(fac[allq.index(g)] > fsg)
    dt = (time.perf_counter() - t0) / n
    R['9_cost'] = dict(qubits_decided=len(ring), python_ms_per_period=round(dt * 1e3, 2),
                       table_bytes_per_decoder=2 * 7 * 2 * 8, note='pure-Python loop; a compiled version would be ~100x faster')
    json.dump(R, open(os.path.join(HERE, 'out16', 'I', 'I_results.json'), 'w'), indent=1, default=float)
    for sec, v in R.items():
        print('==', sec)
        for k, x in v.items() if isinstance(v, dict) else []:
            print(' ', k, x)


if __name__ == '__main__':
    main()
