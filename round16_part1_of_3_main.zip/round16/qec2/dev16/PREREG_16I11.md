# Round 16, part I, item 11 — the role check of claim 10 on sampled data: rules (fixed before computing)

Added 9 November 2026 after an outside review. No bar; reported whatever the outcome.

**Question.** Paragraph [0063] and claim 10 confirm a named qubit's role by the time-like share of the coincidence
excess around it; the shares quoted there (10–13% for a failing data qubit, 67–80% for a failing Z-type measure
qubit) were computed from the noise model without sampling. With the amount of data the gate has when it decides,
how often does the check (i) leave a correctly named qubit alone and (ii) catch a qubit named in the wrong role?

**Method** (`analyse16_I11.py`). Round 15's circuit model (`../model.py`, `circuit_model(d)`) and sampler
(`../sampler.py`), Z-type detection events, distance 7 and 9, p = 0.003, every other qubit nominal. Named qubit g:
its edge set E_g is the interior decoder edges whose probability a failure of g at 10× raises (exact model); on E_g
the estimated excess of an edge is p̂ − p₀, p̂ from the two-detector coincidence formula
p̂ = ½ − ½·sqrt(1 − 4(⟨uv⟩ − ⟨u⟩⟨v⟩)/(1 − 2⟨u⟩ − 2⟨v⟩ + 4⟨uv⟩)), p₀ the nominal value; the time-like share is the
summed excess of edges joining the same measure qubit in consecutive rounds over the summed excess of all of E_g.
**Rule: share ≥ 0.40 reads as a measure qubit, below 0.40 as a data qubit**; a contradiction with the named role
withholds the response. If the summed excess is not positive, the check reads "undecided" and does not withhold.
- Cases: (a) a bulk data qubit or bulk Z-type measure qubit fails and is named correctly; (b) a bulk data qubit fails
  and one of its Z-type measure qubits is named (the error of [0063]); (c) a bulk Z-type measure qubit fails and
  one of its data qubits is named.
- Factors 3, 10 and 33.6; windows of 200 and 1,000 blocks of d rounds (10 and 50 of the gate's epochs: the sizer's
  minimum and full window). Failing qubits: 12 data and 12 Z-type measure qubits per distance, drawn with numpy seed
  1700001 from the bulk ones; 30 samples of 1,000 blocks per failing qubit and factor (the 200-block window is the
  first 200 blocks), sampler seeds 1700101 + running index.
- Reported per distance, factor and window: the fraction of correct namings the check would withhold (a), the
  fraction of wrong namings it catches (b, c), the fraction undecided, the median sampled share, and the exact
  share on the same edge set.

Hashes of this file and `analyse16_I11.py` in `out16/I/I11_hashes_at_start.txt` before the run.
