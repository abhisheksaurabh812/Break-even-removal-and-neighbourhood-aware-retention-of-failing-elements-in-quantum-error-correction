"""Round 16, part I, item 3b (rules: PREREG_16I3b.md): an absolute-target boundary in the manner of Palmer and Smith
beside the break-even threshold, for every table analysed in part I.
python3 analyse16_I3b.py   (writes out16/I/I3b_results.txt and .json)"""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from analyse16_I import load, lnK, fstar          # noqa: E402  (read-only use of part I's loader and interpolation)

CS = (1.25, 2.0, 5.0, 10.0); LV = (1.0, 2.0, 4.0, 8.0)


def boundary(row, L, pmax):
    dense = np.exp(np.linspace(np.log(L), np.log(300), 4000))
    K = np.exp(lnK(row, dense))
    if K[0] >= pmax:
        return '<=L'
    hit = np.nonzero(K >= pmax)[0]
    return round(float(dense[hit[0]]), 2) if hit.size else 'none'


def main():
    T = load(); out = {}; lines = []
    for k in sorted(T):
        rows = T[k]
        if 1.0 not in rows:
            continue
        base = float(np.exp(lnK(rows[1.0], 1.0))[0])
        rec = {}
        for L in LV:
            if L not in rows:
                continue
            fs = fstar(rows[L])
            rec[f'L{L:g}'] = dict(breakeven=None if not np.isfinite(fs) else round(float(fs), 2),
                                  **{f'c{c:g}': boundary(rows[L], L, c * base) for c in CS})
        out[str(k)] = dict(base_failures=round(base), shots=rows[1.0].get('shots'), levels=rec)
        lines.append(f'{k}  base K(1;1) = {round(base)}')
        for L, r in rec.items():
            lines.append(f'   {L:4s} break-even {r["breakeven"]!s:>7}   target boundary c=1.25: {r["c1.25"]!s:>7}  c=2: '
                         f'{r["c2"]!s:>7}  c=5: {r["c5"]!s:>7}  c=10: {r["c10"]!s:>7}')
    os.makedirs(os.path.join(HERE, 'out16', 'I'), exist_ok=True)
    json.dump(out, open(os.path.join(HERE, 'out16', 'I', 'I3b_results.json'), 'w'), indent=1)
    open(os.path.join(HERE, 'out16', 'I', 'I3b_results.txt'), 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
