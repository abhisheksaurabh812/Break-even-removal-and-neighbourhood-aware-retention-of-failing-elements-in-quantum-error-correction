"""Round 16, part J: keep-versus-remove break-even points decoded by BP-OSD (bposd16.py) instead of matching.
Same circuits (deform16), region, grid and crossover rule as ideal16.py with --retain exact; the decoder is given
each circuit's own detector error model without decomposition (hyperedges kept).
python3 j16.py --d 5 --kind zanc --levels 1,4 --shots 100000 --seed0 S --out X.json --stim STIM"""
import sys, os, json, time, subprocess, tempfile, argparse, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
import deform16, bposd16                          # noqa: E402
from rectgen import layout                       # noqa: E402

REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30)
ap = argparse.ArgumentParser()
ap.add_argument('--d', type=int, required=True); ap.add_argument('--kind', required=True)
ap.add_argument('--levels', required=True); ap.add_argument('--shots', type=int, required=True)
ap.add_argument('--seed0', type=int, required=True); ap.add_argument('--out', required=True)
ap.add_argument('--stim', required=True); ap.add_argument('--p', type=float, default=0.003)
A = ap.parse_args()
TMP = tempfile.mkdtemp(prefix='j16_', dir=HERE)


def failures(txt, shots, chunk=20000):
    cf = os.path.join(TMP, 'c.stim'); df = os.path.join(TMP, 'c.dem'); of = os.path.join(TMP, 's.b8')
    open(cf, 'w').write(txt)
    subprocess.run([A.stim, 'analyze_errors', '--in', cf, '--out', df], check=True)
    H, pr, L = bposd16.dem_to_matrices(open(df).read())
    dec = bposd16.BPOSD(H, pr); nd = H.shape[0]
    fails = done = 0; seed = A.seed0
    while done < shots:
        n = min(chunk, shots - done)
        subprocess.run([A.stim, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(n, (nd + 1 + 7) // 8), axis=1, bitorder='little')[:, :nd + 1]
        est = np.concatenate([dec.decode_batch(bits[i:i + 2000, :nd]) for i in range(0, n, 2000)])
        fails += int((((est.astype(np.int32) @ L.T.astype(np.int32)) % 2)[:, 0] != bits[:, nd]).sum())
        done += n; seed += 1
    return fails


def crossover(grid, keep, ex):
    prev = None
    for f, k in zip(grid, keep):
        if k >= ex:
            if prev is None:
                return float(f)
            f0, k0 = prev
            t = (np.log(ex) - np.log(k0)) / (np.log(k) - np.log(k0))
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 2)
        prev = (f, max(k, 1))
    return None


if __name__ == '__main__':
    d = A.d
    q = (d, d) if A.kind == 'data' else (d - 1, d - 1)
    data, xm, zm = layout(d, d)
    region = [x for x in list(data) + list(xm) + list(zm) if x != q and max(abs(x[0] - q[0]), abs(x[1] - q[1])) <= 4]
    res = dict(d=d, kind=A.kind, qubit=list(q), p=A.p, decoder='bposd', seed0=A.seed0, rows=[])
    if os.path.exists(A.out):
        prev = json.load(open(A.out))
        if all(prev.get(k) == res[k] for k in ('d', 'kind', 'p', 'seed0')):
            res['rows'] = prev['rows']
    have = {r['L'] for r in res['rows']}; t0 = time.time()
    for L in [float(x) for x in A.levels.split(',')]:
        if L in have:
            continue
        sc = {x: L for x in region}
        ex = failures(deform16.circuit(d, d, A.p, excl=[q], scale=sc)[0], A.shots)
        grid = sorted(set(round(L * r, 3) for r in REL)); keep = []
        for f in grid:
            k = failures(deform16.circuit(d, d, A.p, scale={**sc, q: f})[0], A.shots); keep.append(k)
            print(A.kind, L, f, k, 'excl', ex, round(time.time() - t0), flush=True)
            if k >= ex:
                break
        res['rows'].append(dict(L=L, shots=A.shots, excl=ex, grid=grid[:len(keep)], keep=keep, crossover=crossover(grid, keep, ex)))
        res['rows'].sort(key=lambda r: r['L']); json.dump(res, open(A.out, 'w'), indent=1)
    res['elapsed'] = round(time.time() - t0, 1); json.dump(res, open(A.out, 'w'), indent=1)
    for f in os.listdir(TMP):
        os.remove(os.path.join(TMP, f))
    os.rmdir(TMP)
