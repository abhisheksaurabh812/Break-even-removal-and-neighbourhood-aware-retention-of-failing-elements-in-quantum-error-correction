"""Round 16, part M: writes the run configurations (cfgM/) and the job list (jobs16_M.txt).  python3 gen_cfg16M.py

Each test's scenario parameters are copied from round 15's stored configuration of that test (its first seed);
only 'seed' and 'arms' change. The four arms are copies of round 15's gate ('sz_w15': policy-field-watch4 with the
sized7 naming and sizing, the watch, the probes and the correlated-matching tables of the test's distance), differing
only in the threshold table and in 'resize' (re-fitting the qubit's factor against its neighbourhood level):
  gate     the round-15 gate unchanged: f*(role, L) from the table, re-fit on
  lookup1  the table flattened at its L = 1 values (switch-out and return thresholds no longer depend on L), re-fit on
  blind    the table flattened at its L = 1 values, re-fit off: round 15's cutoff (C) with the gate's naming, sizing
           and watch; nothing in the decision depends on the neighbourhood level
  rw       threshold 1e9 (never switches out): reweighting alone with the gate's naming and sizing
All four take probe noise from the same stream (seed_i 0) and each has its own sampling group ('extra'); arms in the
same configuration share samples (run15.run draws one sample per configuration and epoch)."""
import os, json, copy
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); OUT15 = os.path.join(os.path.dirname(HERE), 'out15')
TESTS = [('realistic', 'd9_realistic', range(18001, 18011), 1900),
         ('pairs', 'pairs_mixed', range(18401, 18411), 700),
         ('hwlike', 'd9_hwlike', range(18701, 18711), 1600)]
DEV_SEED = 18999


def arms_from(gate):
    def flat(tab, v=None):
        return {k: [[1.0, float(v if v is not None else rows[0][1])], [8.0, float(v if v is not None else rows[0][1])]]
                for k, rows in tab.items()}
    out = []
    for name, extra, table, resize in (('gate', 'w6', gate['table'], True),
                                       ('lookup1', 'w5', flat(gate['table']), True),
                                       ('blind', 'w7', flat(gate['table']), False),
                                       ('rw', 'w4', flat(gate['table'], 1e9), True)):
        a = copy.deepcopy(gate)
        a.update(name=name, extra=extra, table=table, resize=resize, seed_i=0)
        out.append(a)
    return out


def main():
    os.makedirs(os.path.join(HERE, 'cfgM'), exist_ok=True)
    jobs = ['# Round 16 part M jobs: name est_seconds requires command']
    for short, test, seeds, est in TESTS:
        src = sorted(f for f in os.listdir(OUT15) if f.startswith(f'{test}_s') and f.endswith('.npz'))[0]
        cfg15 = json.loads(str(np.load(os.path.join(OUT15, src), allow_pickle=True)['cfg']))
        gate = [a for a in cfg15['arms'] if a['name'] == 'sz_w15'][0]
        for s in list(seeds) + ([DEV_SEED] if short == 'realistic' else []):
            cfg = {k: v for k, v in cfg15.items() if k != 'arms'}
            cfg.update(seed=s, arms=arms_from(gate))
            name = f'M_{short}_s{s}' if s != DEV_SEED else f'devM_{short}_s{s}'
            json.dump(cfg, open(os.path.join(HERE, 'cfgM', f'{name}.json'), 'w'), indent=1)
            if s != DEV_SEED:
                jobs.append(f'{name} {est} - python3 run16m.py cfgM/{name}.json out16/M/{name}.npz')
        print(test, 'from', src, '| d', cfg15['d'], '| table L=1:', {k: v[0][1] for k, v in gate['table'].items()})
    open(os.path.join(HERE, 'jobs16_M.txt'), 'w').write('\n'.join(jobs) + '\n')
    print(len(jobs) - 1, 'jobs written')


if __name__ == '__main__':
    main()
