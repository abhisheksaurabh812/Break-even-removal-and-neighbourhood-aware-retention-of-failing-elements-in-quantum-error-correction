# Round 16, part B — rules (fixed before the first run)

**Question.** Do the break-even (switch-out) thresholds keep rising with the neighbourhood level at distances 5, 11
and 13, as they do at 7 and 9 (Table 1 of the first provisional)?

**Method.** `ideal16.py` (generator `deform16.py`, which writes the same circuit text as round 15's `deform.py` for
the bulk; checked by `check16.py`, 36 of 36 identical). Same rule as Table 1: the qubit kept at factors
L × (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30), capped at 300, until its failures reach those with it removed; crossing
interpolated in (ln f, ln failures). Qubits within Chebyshev distance 4 raised to L. Circuit-level depolarizing
noise p = 0.003; blocks of d rounds; the decoder knows the true rates ("exact", as Table 1).

**Configurations.**
- Distance 5 and distance 11: data qubit (d, d) and Z-type measure qubit (d − 1, d − 1); plain and correlated
  matching; L = 1, 1.5, 2, 3, 4, 6, 8; 2,000,000 shots per point for L ≤ 2 and 1,000,000 above.
- Distance 13: Z-type measure qubit (12, 12); plain and correlated matching; L = 1 and 4; 1,000,000 shots per point.
- Stim seeds 1600001, 1600002, … per chunk of 200,000 shots (never used before; earlier tables used 1, 2, …).

**Pre-registered checks** (a threshold beyond the grid counts as above any finite value):
- B1. At distances 5 and 11, for both decoders, the Z-type measure qubit's threshold at L = 3 is at least 1.15 times
  its threshold at L = 1 (four checks). The margin 1.15 is twice the 7% repeat precision of a threshold.
- B2. At distance 13, for both decoders, the Z-type measure qubit's threshold at L = 4 is at least 1.15 times its
  threshold at L = 1 (two checks).
- The data-qubit tables are descriptive (no bar). Every value is reported whatever the outcome.

**Verification.** A second script recomputes every crossover from the stored counts with its own implementation.

**Job list.** `jobs16B.txt`, run by `queue16.py` (two at a time, resumable by level). Hashes of this file, the code
and the job list are recorded in `out16/B/hashes_at_start.txt` before the first run and re-checked after.
