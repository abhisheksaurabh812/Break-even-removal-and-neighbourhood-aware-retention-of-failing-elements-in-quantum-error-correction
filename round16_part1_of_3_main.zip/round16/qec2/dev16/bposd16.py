"""Round 16: a BP-OSD decoder in numpy (the `ldpc` package cannot be installed here).

BPOSD(H, priors, max_iter=30, ms_scale=0.625, osd_order=20)
  H        m x n parity-check matrix (0/1 numpy array; detectors x error mechanisms)
  priors   n prior error probabilities
decode_batch(S) -> n-bit estimates for a batch of syndromes S (shots x m).
Belief propagation is normalised min-sum, vectorised over shots, with early stopping per shot. Shots whose hard
decision does not reproduce the syndrome go to ordered-statistics decoding: columns ranked by posterior
log-likelihood (most likely in error first), Gaussian elimination over GF(2) picks an information set, OSD-0 solves
on it, and a combination sweep tries flipping each single non-pivot column and each pair among the first
`osd_order` non-pivot columns, keeping the lowest-cost solution (cost = sum of prior log-likelihood weights).
Also: dem_to_matrices(dem_text) for Stim detector error models (hyperedges kept whole; '^' separators ignored).
"""
import numpy as np


def dem_to_matrices(dem_text):
    """Detector error model text -> (H [detectors x mechanisms], priors, L [observables x mechanisms]).
    Handles 'error(p) D.. L..' lines, 'detector' and 'logical_observable' declarations and shift_detectors; no repeat
    blocks (the circuits here have none)."""
    cols, ps, maxd, maxl, shift = [], [], -1, -1, 0
    for line in dem_text.splitlines():
        t = line.strip()
        if t.startswith('error('):
            p = float(t[6:t.index(')')])
            ds, ls = [], []
            for tok in t[t.index(')') + 1:].split():
                if tok.startswith('D'):
                    ds.append(int(tok[1:]) + shift)
                elif tok.startswith('L'):
                    ls.append(int(tok[1:]))
            cols.append((tuple(sorted(set(x for x in ds if ds.count(x) % 2))), tuple(sorted(set(x for x in ls if ls.count(x) % 2)))))
            ps.append(p)
            maxd = max([maxd] + ds); maxl = max([maxl] + ls)
        elif t.startswith('detector'):
            i = t.rfind('D')
            maxd = max(maxd, int(t[i + 1:]) + shift)
        elif t.startswith('logical_observable'):
            maxl = max(maxl, int(t.split('L')[-1]))
        elif t.startswith('shift_detectors'):
            shift += int(t.split()[-1])
        elif t.startswith('repeat'):
            raise ValueError('repeat blocks not supported')
    # merge identical columns (independent mechanisms with the same effect)
    merged = {}
    for (ds, ls), p in zip(cols, ps):
        if not ds and not ls:
            continue
        q = merged.get((ds, ls), 0.0)
        merged[(ds, ls)] = q * (1 - p) + p * (1 - q)
    keys = sorted(merged)
    H = np.zeros((maxd + 1, len(keys)), dtype=np.uint8)
    L = np.zeros((max(maxl + 1, 1), len(keys)), dtype=np.uint8)
    for j, (ds, ls) in enumerate(keys):
        H[list(ds), j] = 1
        if ls:
            L[list(ls), j] = 1
    return H, np.array([merged[k] for k in keys]), L


class BPOSD:
    def __init__(self, H, priors, max_iter=30, ms_scale=0.625, osd_order=20):
        self.H = (np.asarray(H) % 2).astype(np.uint8)
        self.m, self.n = self.H.shape
        p = np.clip(np.asarray(priors, dtype=float), 1e-12, 1 - 1e-12)
        self.llr0 = np.log((1 - p) / p)
        self.w = np.maximum(self.llr0, 0.0)              # cost of a column in OSD
        self.max_iter, self.alpha, self.order = max_iter, ms_scale, osd_order
        ci, vj = np.nonzero(self.H)
        o = np.argsort(ci, kind='stable')
        self.ec, self.ev = ci[o], vj[o]                  # edges sorted by check
        self.E = len(self.ec)
        self.cstart = np.searchsorted(self.ec, np.arange(self.m + 1))
        ov = np.argsort(self.ev, kind='stable')
        self.vorder = ov
        self.vstart = np.searchsorted(self.ev[ov], np.arange(self.n + 1))
        from scipy.sparse import csr_matrix
        self.EV = csr_matrix((np.ones(self.E), (np.arange(self.E), self.ev)), shape=(self.E, self.n))

    def _check_update(self, mvc, s):
        """Normalised min-sum: for each edge, sign product and minimum magnitude over the other edges of its check."""
        mag = np.abs(mvc); sgn = np.where(mvc < 0, 1, 0).astype(np.int8)
        out = np.empty_like(mvc)
        for i in range(self.m):
            a, b = self.cstart[i], self.cstart[i + 1]
            if b == a:
                continue
            mg = mag[:, a:b]; sg = sgn[:, a:b]
            k = np.argmin(mg, axis=1)
            m1 = mg[np.arange(mg.shape[0]), k]
            mg2 = mg.copy(); mg2[np.arange(mg.shape[0]), k] = np.inf
            m2 = mg2.min(axis=1)
            tot = (sg.sum(axis=1) + s[:, i]) % 2
            mins = np.where(np.arange(b - a)[None, :] == k[:, None], m2[:, None], m1[:, None])
            par = (tot[:, None] + sg) % 2
            out[:, a:b] = self.alpha * np.minimum(mins, 50.0) * (1 - 2 * par)   # a degree-1 check fixes its variable
        return out

    def _bp(self, S):
        nb = S.shape[0]
        mvc = np.broadcast_to(self.llr0[self.ev], (nb, self.E)).copy()
        post = np.broadcast_to(self.llr0, (nb, self.n)).copy()
        done = np.zeros(nb, dtype=bool)
        est = np.zeros((nb, self.n), dtype=np.uint8)
        for _ in range(self.max_iter):
            act = ~done
            if not act.any():
                break
            mcv = self._check_update(mvc[act], S[act])
            tot = np.asarray(self.EV.T @ mcv.T).T              # sum of incoming check messages per variable
            pa = self.llr0[None, :] + tot
            post[act] = pa
            mvc[act] = pa[:, self.ev] - mcv
            hard = (pa < 0).astype(np.uint8)
            ok = ((hard @ self.H.T) % 2 == S[act]).all(axis=1)
            idx = np.nonzero(act)[0]
            est[idx] = hard
            done[idx[ok]] = True
        return est, post, done

    def _osd(self, s, post):
        order = np.argsort(post)                        # most likely in error first
        Hs = self.H[:, order].copy()
        syn = s.copy().astype(np.uint8)
        rows = np.arange(self.m)
        piv_cols, r = [], 0
        A = np.concatenate([Hs, syn[:, None]], axis=1)
        for c in range(self.n):
            if r == self.m:
                break
            nz = np.nonzero(A[r:, c])[0]
            if nz.size == 0:
                continue
            pr = r + nz[0]
            if pr != r:
                A[[r, pr]] = A[[pr, r]]
            others = np.nonzero(A[:, c])[0]
            others = others[others != r]
            A[others] ^= A[r]
            piv_cols.append(c); r += 1
        rank = r
        piv = np.array(piv_cols, dtype=int)
        nonpiv = np.setdiff1d(np.arange(self.n), piv)[: self.order]
        w = self.w[order]

        def solve(flips):
            x = np.zeros(self.n, dtype=np.uint8)
            rhs = A[:rank, -1].copy()
            for f in flips:
                x[f] = 1
                rhs ^= A[:rank, f]
            x[piv] = rhs
            return x, float(w[x.astype(bool)].sum())
        best, bc = solve(())
        cands = [(f,) for f in nonpiv] + [(a, b) for i, a in enumerate(nonpiv) for b in nonpiv[i + 1:]]
        for fl in cands:
            x, c = solve(fl)
            if c < bc:
                best, bc = x, c
        out = np.zeros(self.n, dtype=np.uint8); out[order] = best
        return out

    def decode_batch(self, S):
        S = (np.asarray(S) % 2).astype(np.uint8)
        est, post, done = self._bp(S)
        for i in np.nonzero(~done)[0]:
            est[i] = self._osd(S[i], post[i])
        return est
