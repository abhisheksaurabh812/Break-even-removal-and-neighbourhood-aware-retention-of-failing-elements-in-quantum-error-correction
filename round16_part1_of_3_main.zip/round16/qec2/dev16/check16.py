"""Round 16 checks of deform16.py.
(1) For the bulk, 'dep' noise and the Z basis, deform16's circuit text must equal the frozen deform.py's.
(2) Every new configuration must give a valid detector error model (Stim refuses non-deterministic detectors or
    observables), and, when the Stim Python module is available, its shortest graph-like logical error is reported.
python3 check16.py <stim binary> [<path to a Stim python build>]"""
import sys, os, subprocess, tempfile, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
import deform, deform16                       # noqa: E402
from rectgen import layout                    # noqa: E402
STIM = sys.argv[1]
stimpy = None
if len(sys.argv) > 2:
    sys.path.insert(0, sys.argv[2])
    try:
        import stim as stimpy
    except Exception as e:                      # noqa: BLE001
        print('no stim python:', e)
TMP = tempfile.mkdtemp(prefix='chk16_', dir=HERE)


def dem_ok(txt):
    cf = os.path.join(TMP, 'c.stim'); open(cf, 'w').write(txt)
    r = subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf], capture_output=True, text=True)
    return r.returncode == 0, (r.stderr.strip().splitlines() or [''])[-1][:160]


def dist(txt):
    if stimpy is None:
        return None
    c = stimpy.Circuit(txt)
    return len(c.shortest_graphlike_error(ignore_ungraphlike_errors=True))


res = {'identical': [], 'valid': []}
for d in (5, 7, 9):
    bd, bz = deform.bulk_data(d), deform.bulk_zanc(d)
    cases = [(), (bd[len(bd) // 2],), (bz[len(bz) // 2],), (bd[0],), (bz[-1],)]
    a, b = bd[0], bd[-1]
    if deform.compatible([a, b], d):
        cases.append((a, b))
    for ex in cases:
        for sc in (None, {q: 2.0 for q in bd[:6]}):
            t0, _ = deform.circuit(d, d, 0.003, excl=ex, scale=sc)
            t1, _ = deform16.circuit(d, d, 0.003, excl=ex, scale=sc)
            res['identical'].append(dict(d=d, excl=[list(x) for x in ex], scaled=sc is not None, same=t0 == t1))
for d in (5, 7, 9):
    data, xm, zm = layout(d, d)
    ch = deform16.checks(d)
    edge_x = [c for c in data if c[1] == 1 and 1 < c[0] < 2 * d - 1]            # bottom edge (X-type boundary)
    edge_z = [c for c in data if c[0] == 1 and 1 < c[1] < 2 * d - 1]            # left edge (Z-type boundary)
    corners = [c for c in data if c[0] in (1, 2 * d - 1) and c[1] in (1, 2 * d - 1)]
    edge_zanc = [a for a, (t, s) in ch.items() if t == 'Z' and len(s) == 2]
    edge_xanc = [a for a, (t, s) in ch.items() if t == 'X' and len(s) == 2]
    pick = lambda xs: xs[len(xs) // 2]
    cfgs = [('edge-data-x', 'z', [pick(edge_x)]), ('edge-data-z', 'z', [pick(edge_z)])]
    cfgs += [('corner-data-' + str(i), 'z', [c]) for i, c in enumerate(corners)]
    cfgs += [('edge-zanc', 'z', [pick(edge_zanc)]), ('none', 'x', []), ('bulk-xanc', 'x', [pick(deform16_x := [a for a, (t, s) in ch.items() if t == 'X' and len(s) == 4])]),
             ('edge-xanc', 'x', [pick(edge_xanc)]), ('bulk-data-x', 'x', [pick(deform.bulk_data(d))])]
    for noise in ('dep', 'si1000', 'xbias10', 'zbias10'):
        for name, basis, ex in cfgs:
            if noise != 'dep' and name not in ('none', 'edge-data-x'):
                continue
            try:
                txt, meta = deform16.circuit(d, d, 0.003, excl=ex, basis=basis, noise=noise)
                ok, msg = dem_ok(txt)
                res['valid'].append(dict(d=d, name=name, basis=basis, noise=noise, ok=ok, msg=msg if not ok else '',
                                         obs_line=meta['obs'][0], dist=dist(txt) if ok and noise == 'dep' else None))
            except Exception as e:                  # noqa: BLE001
                res['valid'].append(dict(d=d, name=name, basis=basis, noise=noise, ok=False, msg=repr(e)[:160]))
    # a failing coupler: pair scale on one data-Z coupler
    c = (d, d); a = (d - 1, d - 1)
    txt, _ = deform16.circuit(d, d, 0.003, pair_scale={(c, a): 10.0})
    ok, msg = dem_ok(txt)
    res['valid'].append(dict(d=d, name='coupler', basis='z', noise='dep', ok=ok, msg=msg if not ok else '',
                             changed='DEPOLARIZE2(0.03)' in txt))
for f in os.listdir(TMP):
    os.remove(os.path.join(TMP, f))
os.rmdir(TMP)
print('identical to deform.py:', sum(r['same'] for r in res['identical']), 'of', len(res['identical']))
for r in res['identical']:
    if not r['same']:
        print('  DIFFERS', r)
for r in res['valid']:
    print(('ok  ' if r['ok'] else 'FAIL'), r)
