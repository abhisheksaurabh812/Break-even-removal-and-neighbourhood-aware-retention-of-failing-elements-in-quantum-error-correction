"""Development (spent seeds 1..): baseline failures per 200k blocks for candidate noise settings at d = 7."""
import sys, os, subprocess, tempfile, numpy as np
S = sys.argv[1]; sys.path.insert(0, S + '/tools/PyMatching/src')
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import deform16, pymatching
STIM = S + '/bin/stim'; T = tempfile.mkdtemp(dir=HERE); d = 7; n = 200000
for noise, p in [('dep', 0.003), ('si1000', 0.002), ('si1000', 0.003), ('xbias10', 0.003), ('zbias10', 0.003)]:
    txt, _ = deform16.circuit(d, d, p, noise=noise); cf = os.path.join(T, 'c.stim'); open(cf, 'w').write(txt)
    df = os.path.join(T, 'c.dem'); of = os.path.join(T, 's.b8')
    subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
    subprocess.run([STIM, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables', '--seed', '1', '--in', cf, '--out', of], check=True)
    m = pymatching.Matching.from_detector_error_model_file(df); nd = m.num_detectors
    b = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(n, (nd + 8) // 8), axis=1, bitorder='little')[:, :nd + 1]
    print(noise, p, int((m.decode_batch(b[:, :nd])[:, 0] != b[:, nd]).sum()), 'failures of', n, flush=True)
for f in os.listdir(T): os.remove(os.path.join(T, f))
os.rmdir(T)
