"""Development check (spent seeds): BP-OSD (bposd16) against PyMatching on the same surface-code samples."""
import sys, os, subprocess, tempfile, time, numpy as np
S = sys.argv[1]; sys.path.insert(0, S + '/tools/PyMatching/src')
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import deform16, bposd16, pymatching
STIM = S + '/bin/stim'
d = int(sys.argv[2]); shots = int(sys.argv[3]); p = float(sys.argv[4])
T = tempfile.mkdtemp(dir=HERE)
txt, _ = deform16.circuit(d, d, p)
cf = os.path.join(T, 'c.stim'); open(cf, 'w').write(txt)
subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', os.path.join(T, 'dec.dem')], check=True)
subprocess.run([STIM, 'analyze_errors', '--in', cf, '--out', os.path.join(T, 'raw.dem')], check=True)
of = os.path.join(T, 's.b8')
subprocess.run([STIM, 'detect', '--shots', str(shots), '--out_format', 'b8', '--append_observables', '--seed', '1', '--in', cf, '--out', of], check=True)
H, pr, L = bposd16.dem_to_matrices(open(os.path.join(T, 'raw.dem')).read())
nd = H.shape[0]
bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(shots, (nd + 1 + 7) // 8), axis=1, bitorder='little')[:, :nd + 1]
m = pymatching.Matching.from_detector_error_model_file(os.path.join(T, 'dec.dem'))
t = time.time(); pm = m.decode_batch(bits[:, :nd])[:, 0]; tpm = time.time() - t
dec = bposd16.BPOSD(H, pr)
t = time.time(); est = np.concatenate([dec.decode_batch(bits[i:i + 2000, :nd]) for i in range(0, shots, 2000)]); tb = time.time() - t
bp = (est @ L.T % 2)[:, 0]
obs = bits[:, nd]
print(f'd={d} p={p} shots={shots} H={H.shape}  matching fails {int((pm != obs).sum())} ({tpm:.1f}s)  bposd fails {int((bp != obs).sum())} ({tb:.1f}s)  syndrome ok {bool(((est @ H.T) % 2 == bits[:, :nd]).all())}')
for f in os.listdir(T): os.remove(os.path.join(T, f))
os.rmdir(T)
