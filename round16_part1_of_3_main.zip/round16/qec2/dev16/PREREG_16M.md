# Round 16, part M — the online gate with only the switch-out rule changed: rules (fixed before the first run)

Added on 9 November 2026, after an outside review of the round-16 plan, with the user's approval; parts A–K are
unchanged.

**Question.** Paragraph [0120] of the filed specification states that the gate's online margins over the fixed
cutoffs (Table 3: −8.7% against the cutoff at the correlated-matching thresholds) include the effect of the newer
naming and sizing and of the watch, which the cutoffs did not have, as well as that of the decision. With the naming,
sizing, watch, probes and decoding held identical, how many logical failures does the neighbourhood term of the
switch-out rule save, and how much does switching out save at all?

**Runner.** Round 15's runner, `../dev15/m15/run15.py`, unchanged, called through `run16m.py`, which only puts
round 15's library folder on the path and points the model caches at `cacheM/` (hard links of round 15's caches;
new models are written there only). A reproduction run of a stored round-15 run through `run16m.py` must give
identical arrays before any part-M run (`out16/M/dev_repro*`).

**Arms** (`gen_cfg16M.py`; every arm is round 15's gate, `sz_w15`: policy-field-watch4, the sized7 naming and sizing,
the watch, probes every 50 epochs, the correlated-matching tables of the test's distance, at most two qubits out):
- `gate`: unchanged (threshold f*(role, L) from the table at the qubit's neighbourhood level; factor re-fitted with
  the other qubits at that level).
- `lookup1`: the table flattened at its L = 1 values, so the switch-out and return thresholds do not depend on L;
  re-fit on.
- `blind`: the table flattened at its L = 1 values and re-fit off: the cutoff at the correlated-matching thresholds
  for nominal neighbours (round 15's cutoff (C)), with the gate's naming, sizing and watch. Nothing in its decision
  depends on the neighbourhood level.
- `rw`: never switches out (threshold 10⁹): reweighting alone with the gate's naming and sizing.
All four use the same probe-noise stream (seed_i 0) and separate sampling groups; arms in the same configuration in
an epoch share that epoch's samples (run15.run). Every arm is decoded by plain and by correlated matching on the
same samples; the decisions use the correlated-matching tables, as the gate's did in round 15.

**Tests and seeds.** Round 15's scenario parameters, copied from its stored configuration of each test:
realistic (distance 9; drift, bursts, regional steps; seeds 18001–18010), neighbouring failures (round 15's
`pairs_mixed`, distance 7; seeds 18401–18410) and hardware-like noise (distance 9; seeds 18701–18710): the three
tests in which round 15's gate and cutoffs differed because of the neighbourhood or naming. 30 runs. Seed 18999
(realistic, shortened) is spent on the development check of the arms.

**Statistics.** As round 15 ([0121]): for each comparison and decoder, the pooled relative difference in total
logical failures (Σa − Σb)/Σb over the 30 runs, the paired z statistic on per-epoch differences pooled over runs,
and a 95% seed-bootstrap interval (10,000 resamples of the runs, numpy seed 8).

**Pre-registered checks.**
- **M1** (correlated matching) and **M1p** (plain matching): `gate` against `blind`, pooled over the 30 runs: the
  relative difference is negative and its 95% interval lies below zero.

**Descriptive (no bar)**, pooled and by test, both decoders: `gate` vs `lookup1` (the threshold's dependence on the
level, re-fit held on); `lookup1` vs `blind` (the re-fit, threshold held at L = 1); `gate`, `lookup1` and `blind`
vs `rw` (switching out at all, same naming); for each arm the number of switch-outs, of switch-outs whose qubit's
true factor was below 2 at its first probe, and of epochs with a qubit out. Round 15's numbers for the same tests
(gate against cutoff (C) and against reweighting alone, with the earlier naming) are shown beside them for context;
they are not paired with these runs.

**Scripts.** `analyse16_M.py` (results: `out16/M/M_results.txt` and `.json`) and, written separately,
`verify16_M.py`, which recomputes every pooled number, z statistic and interval with round 15's functions
(`../analyse8.py`: `compare`, `bootstrap`) and re-checks the hashes.

**Job list.** `jobs16_M.txt` (30 jobs), appended to round 16's list as `jobs16_all4.txt` so that part M runs after
parts A–K. Hashes of this file, `gen_cfg16M.py`, `run16m.py`, the 30 configurations, `jobs16_M.txt`,
`jobs16_all4.txt`, `analyse16_M.py`, `verify16_M.py` and round 15's runner files in `out16/M/hashes_at_start.txt`
before the first run.
