"""Round 16 keep-versus-respond break-even tables (generalises dev15/m15/ideal_field15.py, same crossover rule).

python3 ideal16.py --d 9 --kind data --decoder corr --levels 1,1.5,2 --shots 2e6,2e6,2e6 --seed0 1 --out t.json
  --kind      data | zanc | xanc (X basis) | edge-data-x | edge-data-z | corner-data | edge-zanc
              | zcoupler<k> | xcoupler<k>   (coupler of the central Z/X measure qubit in schedule step k = 0..3)
  --response  remove (default; for couplers remove-data or remove-anc) | erase (decoder-only erasure)
  --retain    exact (default) | tracked | unchanged | uniform : what the decoder knows when the qubit is kept
              exact     = the true rates of every qubit (as Table 1)
              tracked   = the region's level but not the failing qubit's size
              unchanged = calibrated nominal rates only
              uniform   = no weights (every error mechanism equally likely)
              The removed configuration is decoded with the same knowledge of the region.
  --noise     dep (default) | si1000 | xbias<eta> | zbias<eta> ;  --p ;  --basis z | x
Seeds: Stim seeds seed0, seed0+1, ... per chunk of 200,000 shots, the same for every configuration of a run.
With --seed0 1, the defaults and the Table 1 qubits it reproduces dev15/m15/ideal_field15.py exactly."""
import sys, os, json, time, subprocess, tempfile, argparse, hashlib, re
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(HERE)
sys.path.insert(0, QEC2); sys.path.insert(0, HERE)
import deform16                                  # noqa: E402
from rectgen import layout                       # noqa: E402

REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30)
FMAX = 300.0
ap = argparse.ArgumentParser()
ap.add_argument('--d', type=int, required=True); ap.add_argument('--kind', required=True)
ap.add_argument('--decoder', choices=('plain', 'corr'), required=True)
ap.add_argument('--levels', required=True); ap.add_argument('--shots', required=True)
ap.add_argument('--seed0', type=int, required=True); ap.add_argument('--out', required=True)
ap.add_argument('--response', default='remove'); ap.add_argument('--retain', default='exact')
ap.add_argument('--noise', default='dep'); ap.add_argument('--p', type=float, default=0.003)
ap.add_argument('--basis', default='z'); ap.add_argument('--stim', required=True)
ap.add_argument('--pymatching', required=True)
A = ap.parse_args()
sys.path.insert(0, A.pymatching)
import pymatching                                # noqa: E402
CORR = A.decoder == 'corr'
TMP = tempfile.mkdtemp(prefix='i16_', dir=HERE)
_dem_cache = {}


def crossover(grid, keep, arm):
    """First factor at which the kept failures reach the other arm's, interpolated in (ln f, ln failures).
    `arm` is a number (removal, same for every factor) or a list (erasure, one value per factor)."""
    arms = arm if isinstance(arm, list) else [arm] * len(grid)
    prev = None
    for f, k, e in zip(grid, keep, arms):
        if k >= e:
            if prev is None:
                return float(f)
            f0, k0, e0 = prev
            g0 = np.log(k0) - np.log(e0); g1 = np.log(k) - np.log(e)
            t = g0 / (g0 - g1) if g1 != g0 else 1.0
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 2)
        prev = (f, max(k, 1), max(e, 1))
    return None


def dem_path(txt, uniform=False):
    key = hashlib.sha1((txt + str(uniform)).encode()).hexdigest()
    if key in _dem_cache:
        return _dem_cache[key]
    cf = os.path.join(TMP, key + '.stim'); df = os.path.join(TMP, key + '.dem')
    open(cf, 'w').write(txt)
    subprocess.run([A.stim, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
    if uniform:
        s = re.sub(r'error\([^)]*\)', 'error(0.01)', open(df).read())
        open(df, 'w').write(s)
    _dem_cache[key] = df
    return df


def failures(sample_txt, decode_paths, shots, chunk=200000):
    """Sample `sample_txt` with the run's seeds and decode the same shots with each detector error model."""
    cf = os.path.join(TMP, 'sample.stim'); of = os.path.join(TMP, 's.b8')
    open(cf, 'w').write(sample_txt)
    ms = [pymatching.Matching.from_detector_error_model_file(p_, enable_correlations=CORR) for p_ in decode_paths]
    nd = ms[0].num_detectors
    assert all(m.num_detectors == nd for m in ms)
    fails = [0] * len(ms); done = 0; seed = A.seed0
    while done < shots:
        n = min(chunk, shots - done)
        subprocess.run([A.stim, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        nb = (nd + 1 + 7) // 8
        bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(n, nb), axis=1, bitorder='little')[:, :nd + 1]
        for i, m in enumerate(ms):
            pred = m.decode_batch(bits[:, :nd], enable_correlations=CORR)[:, 0]
            fails[i] += int((pred != bits[:, nd]).sum())
        done += n; seed += 1
    return fails


def target(d, kind, basis):
    data, xm, zm = layout(d, d)
    ch = deform16.checks(d)
    near = lambda xs, c0: min(xs, key=lambda c: (abs(c[0] - c0[0]) + abs(c[1] - c0[1]), c))
    mid = (d, d)
    if kind == 'data':
        return (d, d), None
    if kind == 'zanc':
        return (d - 1, d - 1), None
    if kind == 'xanc':
        return near([a for a, (t, s) in ch.items() if t == 'X' and len(s) == 4], mid), None
    if kind == 'edge-data-x':
        return near([c for c in data if c[1] == 1 and 1 < c[0] < 2 * d - 1], (d, 1)), None
    if kind == 'edge-data-z':
        return near([c for c in data if c[0] == 1 and 1 < c[1] < 2 * d - 1], (1, d)), None
    if kind == 'corner-data':
        return (1, 1), None
    if kind == 'edge-zanc':
        return near([a for a, (t, s) in ch.items() if t == 'Z' and len(s) == 2 and a[0] == 0], (0, d)), None
    m = re.fullmatch(r'([xz])coupler([0-3])', kind)
    if m:
        k = int(m.group(2))
        if m.group(1) == 'z':
            a = (d - 1, d - 1); o = [(1, 1), (1, -1), (-1, 1), (-1, -1)][k]
        else:
            a = near([c for c, (t, s) in ch.items() if t == 'X' and len(s) == 4], mid); o = [(1, 1), (-1, 1), (1, -1), (-1, -1)][k]
        return (a[0] + o[0], a[1] + o[1]), a              # (data qubit, measure qubit)
    raise ValueError(kind)


def circ(excl=(), scale=None, pair=None):
    return deform16.circuit(A.d, A.d, A.p, excl=excl, scale=scale, noise=A.noise, basis=A.basis, pair_scale=pair)[0]


if __name__ == '__main__':
    Ls = [float(x) for x in A.levels.split(',')]; shots = [int(float(x)) for x in A.shots.split(',')]
    q, anc = target(A.d, A.kind, A.basis)
    coupler = anc is not None
    data, xm, zm = layout(A.d, A.d)
    allq = list(data) + list(xm) + list(zm)
    region = [x for x in allq if x != q and max(abs(x[0] - q[0]), abs(x[1] - q[1])) <= 4]
    if coupler:
        region = [x for x in region if x != anc]
        rm = {'remove-data': q, 'remove-anc': anc}.get(A.response)
    else:
        rm = q if A.response == 'remove' else None
    res = dict(d=A.d, kind=A.kind, qubit=list(q), anc=list(anc) if anc else None, p=A.p, noise=A.noise,
               basis=A.basis, response=A.response, retain=A.retain, decoder='correlated' if CORR else 'plain',
               seed0=A.seed0, region_size=len(region), rounds_per_shot=A.d, rows=[])
    if os.path.exists(A.out):
        prev = json.load(open(A.out))
        if all(prev.get(k) == res[k] for k in ('d', 'kind', 'p', 'noise', 'basis', 'response', 'retain', 'decoder', 'seed0')):
            res['rows'] = prev['rows']
    prev_elapsed = json.load(open(A.out)).get('elapsed', 0) if res['rows'] else 0
    have = {r['L'] for r in res['rows']}
    t0 = time.time()
    for L, n in zip(Ls, shots):
        if L in have:
            continue
        sc = {x: L for x in region}
        know = {'exact': sc, 'tracked': sc, 'unchanged': {}, 'uniform': {}}[A.retain]
        uni = A.retain == 'uniform'
        grid = sorted(set(min(FMAX, round(L * r, 3)) for r in REL))
        keep, arm = [], ([] if A.response == 'erase' else None)
        if A.response != 'erase':
            removed = circ(excl=[rm], scale=sc)
            arm = failures(removed, [dem_path(circ(excl=[rm], scale=know), uni) if A.retain != 'exact' else dem_path(removed)], n)[0]
        for f in grid:
            if coupler:
                sample = circ(scale=sc, pair={(anc, q): f})
                kd = circ(scale=know, pair={(anc, q): f} if A.retain == 'exact' else None)
            else:
                sample = circ(scale={**sc, q: f})
                kd = circ(scale={**know, q: f} if A.retain == 'exact' else know)
            paths = [dem_path(kd, uni)]
            if A.response == 'erase':
                if coupler:                                # the gate's channel at its cap: erasure in the decoder
                    ed = circ(scale=know, pair={(anc, q): 1e9})
                else:                                      # the qubit's channels at their caps
                    ed = circ(scale={**know, q: 1e9})
                paths.append(dem_path(ed, uni))
            fl = failures(sample, paths, n)
            keep.append(fl[0])
            if A.response == 'erase':
                arm.append(fl[1])
            print(A.kind, L, f, fl, 'arm', arm if not isinstance(arm, list) else arm[-1], round(time.time() - t0), flush=True)
            if fl[0] >= (arm[-1] if isinstance(arm, list) else arm):
                break
        row = dict(L=L, shots=n, grid=grid[:len(keep)], keep=keep, crossover=crossover(grid[:len(keep)], keep, arm))
        row['excl' if not isinstance(arm, list) else 'erase'] = arm
        res['rows'].append(row); res['rows'].sort(key=lambda r: r['L'])
        print(json.dumps(row), flush=True)
        json.dump(res, open(A.out, 'w'), indent=1)
    res['elapsed'] = round(prev_elapsed + time.time() - t0, 1)
    json.dump(res, open(A.out, 'w'), indent=1)
    for f in os.listdir(TMP):
        os.remove(os.path.join(TMP, f))
    os.rmdir(TMP)
