"""Round 16, part M verification, written separately from analyse16_M.py: recompute every pooled number, z statistic and
interval with round 15's own functions (../analyse8.py: compare, bootstrap; per-epoch counts as ../dev15/m15/
analyse15.py loads them), evaluate M1 and M1p, compare with out16/M/M_results.json, and re-check the hashes.
python3 verify16_M.py > out16/M/verify16_M.txt"""
import os, sys, json, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); QEC2 = os.path.dirname(HERE)
sys.path.insert(0, QEC2)
import analyse8 as A                                   # noqa: E402  (round 15's comparison and bootstrap)
SEEDS = [('realistic', s) for s in range(18001, 18011)] + [('pairs', s) for s in range(18401, 18411)] + \
        [('hwlike', s) for s in range(18701, 18711)]
KEYS = dict(corr='fails_c', plain='fails')
PAIRS = [('gate', 'blind'), ('gate', 'lookup1'), ('lookup1', 'blind'), ('gate', 'rw'), ('lookup1', 'rw'), ('blind', 'rw')]


def main():
    runs = {d: [] for d in KEYS}; tests = []
    for t, s in SEEDS:
        f = os.path.join(HERE, 'out16', 'M', f'M_{t}_s{s}.npz')
        if not os.path.exists(f):
            continue
        z = np.load(f, allow_pickle=True); tests.append(t)
        for d, k in KEYS.items():
            runs[d].append(dict(names=[str(x) for x in z['names']], fails=z[k].sum(2, keepdims=True).astype(np.int64)))
    n = len(tests); print('runs found:', n)
    mine = json.load(open(os.path.join(HERE, 'out16', 'M', 'M_results.json'))) if n else {}
    bad = 0
    for sub in [None, 'realistic', 'pairs', 'hwlike']:
        for d in KEYS:
            rs = [r for r, t in zip(runs[d], tests) if sub is None or t == sub]
            if not rs:
                continue
            for a, b in PAIRS:
                c = A.compare(rs, a, b); bt = A.bootstrap(rs, a, b)
                k = f'{d}|{a} vs {b}'
                m = mine['pooled'][k] if sub is None else mine['per_test'][sub][k]
                ok = (abs(100 * c['rel'] - m['rel_pct']) < 0.002 and abs(c['z'] - m['z']) < 0.011 and
                      abs(100 * bt['lo'] - m['lo_pct']) < 0.002 and abs(100 * bt['hi'] - m['hi_pct']) < 0.002)
                bad += not ok
                print(f"{sub or 'pooled':9s} {k:24s} rel {100 * c['rel']:+.3f}%  z {c['z']:+.2f}  "
                      f"[{100 * bt['lo']:+.3f}, {100 * bt['hi']:+.3f}]  {'agrees' if ok else 'MISMATCH'}")
                if sub is None and (a, b) == ('gate', 'blind') and n == 30:
                    print(f"  check {'M1' if d == 'corr' else 'M1p'}: passed = {c['rel'] < 0 and bt['hi'] < 0}")
    print('mismatches:', bad)
    hf = os.path.join(HERE, 'out16', 'M', 'hashes_at_start.txt'); changed = 0; total = 0
    for line in open(hf):
        p = line.split()
        if len(p) == 2 and len(p[0]) == 64:
            total += 1; f = os.path.join(HERE, p[1])
            cur = hashlib.sha256(open(f, 'rb').read()).hexdigest() if os.path.exists(f) else 'missing'
            if cur != p[0]:
                changed += 1; print('  CHANGED', p[1])
    print(f'hashes: {total - changed} of {total} unchanged')


if __name__ == '__main__':
    main()
