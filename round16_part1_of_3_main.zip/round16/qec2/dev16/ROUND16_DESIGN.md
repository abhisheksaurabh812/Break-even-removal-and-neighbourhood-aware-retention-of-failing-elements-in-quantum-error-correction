# Round 16 — design (approved 8 Nov 2026, with the v2 additions below)

## v2 additions and corrections (8 Nov 2026, after checking the cognate checklist line by line)

- B also measures distance 13 for the Z-type measure qubit at L = 1 and 4, both decoders.
- A gains a fourth way of keeping: (d) no weights (every error mechanism weighted equally).
- New part K: the decoder-only erasure response on the surface code. With exact weights erasure can never beat
  keeping, so K compares erasure with keeping under tracked and unchanged weights (the decoder does not know the
  qubit's size), distances 7 and 9, both roles, four levels.
- G corrected in the same way: erasure is compared with keeping under the nominal prior (the decoder does not know
  the qubit's size), not with keeping under the true prior.
- New part J: BP-OSD (the decoder written for G) on the surface code at distance 5, Z-type measure qubit, L = 1
  and 4, as a third decoder.
- F gains a fifth policy: joint decisions, choosing the set of removals with the lowest predicted failures from
  the tables, with the algorithm stated in the rules file.
- I gains: (5) a fitted formula for the threshold; (6) a classifier trained on the break-even labels; (7) one
  threshold for all qubit types; (8) a worked cost-aware switching example; (9) the gate's decision time per
  period and table memory; and (4) is extended to decision flips with their measured cost (keeping and removing
  simulated in the rebuilt noise field, as in the [0124] case).
- Each part gets its own rules file, hashed with its code before its first run.

Not testable in this round (described in words in the filing): neural decoders, leakage, hardware data,
union-find, lattice-surgery tables, partial removal, relocation and local enlargement.

Purpose: data for the second (cognate) provisional. Each part says what it supports. Nothing here is
pre-registered yet; once approved, the parts with pass bars go into a rules file whose hash is recorded before
the first run, as in rounds 8–15.

## Common settings

- Rotated surface-code memory in the Z basis, circuit-level depolarizing noise p = 0.003 unless stated, sampled
  with Stim; decoded by plain matching and by correlated matching (PyMatching 2.4, as in rounds 14–15).
- Break-even (crossover) rule as in Table 1: the qubit kept at a grid of factors and removed, failures compared,
  crossing interpolated in (ln f, ln failures); qubits within Chebyshev distance 4 raised to the level L.
- Full tables use the seven levels of Table 1 (1, 1.5, 2, 3, 4, 6, 8) and the same shots (2 million for L ≤ 2,
  1 million above). Parts marked "four levels" use L = 1, 2, 4, 8.
- Fresh seeds for every reported number; a second script recomputes each number from the raw counts.

## Parts

| Part | What | Supports in the new filing | Prediction / bar | Coding | Computing |
|---|---|---|---|---|---|
| A | Keeping without reweighting: break-even points when the kept qubit is decoded (a) with its true rate, as now, (b) with tracked weights (the decoder knows the region's level but not the qubit's size), (c) with unchanged calibrated weights. Distances 7 and 9, data and Z-type measure qubits, both decoders, four levels | "Any way of keeping the qubit" | (b) and (c) lower than (a) for every role and distance at L = 1 | small | ~5 h |
| B | Distances 5 and 11: full tables, both roles, both decoders | Scaling statements; the "rises with the level" claim | The Z-type measure qubit's threshold rises from L = 1 to L = 3 at both distances | none | ~10 h |
| C | Other noise: SI1000-style circuit noise (distances 7 and 9) and X-biased noise, bias 10 (distance 7) | "Any noise model" | Thresholds exist, and the Z-type measure qubit's rises from L = 1 to L = 3, under both | small | ~8 h |
| D | X-type measure qubits. Under symmetric noise, an X-basis memory with an X-type measure qubit removed is the mirror image (transpose) of the Z case with the same schedule, so its thresholds equal the Z-type ones; checked directly at L = 1 and L = 4, distance 7. Under biased noise the two differ, and part C gives that case | Every qubit type | Mirror check within the 7% repeat precision | small | <1 h |
| E | Failing couplers: one two-qubit gate's error raised by a factor f, the region at L. Keeping it is compared with removing its data qubit and, for a Z-check coupler, its measure qubit. Couplers in each of the four schedule steps; distances 7 and 9; both decoders; four levels | Claim 37, where Drouet et al. exclude couplers | A break-even point exists for at least one coupler type and rises from L = 1 to L = 4 | small | ~5 h |
| F | Layout decided at calibration time (Drouet's setting). 40 fixed calibration maps at distance 9: the usual spread (σ = 0.35), 1–4 failing qubits at 3–30 times nominal, and in half the maps a regional rise (2–4 times over a Gaussian region). Policies: keep all with a calibrated decoder; fixed limits at 10× and 20× nominal (20× is roughly Drouet's 5% two-qubit-gate limit); break-even points for normal neighbours; neighbourhood-aware break-even points. Up to four compatible removals; 500,000 shots per map and policy; both decoders | The calibration-time claims, against the closest prior art | Neighbourhood-aware has fewer failures than each other policy, pooled, with a 95% map-bootstrap interval below zero against the break-even-for-normal-neighbours policy | moderate | ~3 h |
| G | Small qLDPC check: bivariate bicycle code [[72,12,6]] with simple noise (data and measurement errors over 6 rounds) and a BP-OSD decoder written here. A failing data qubit at factor f, its Tanner-graph neighbours (qubits sharing a check) at level L; keeping it is compared with the decoder treating it as erased. Levels 1, 2, 4; about 8 factors; 100,000 shots per point | Claims 22, 23 and 36 (one data point) | Exploratory, no bar: reports whether the break-even point moves with the Tanner-graph level | ~1 day | ~4 h |
| H | Boundary and corner qubits: new removal code for edge data qubits, corner data qubits and edge Z-type measure qubits (boundary moved inwards). Every changed circuit is checked for valid detectors and the expected distance (Stim's search for the shortest undetectable logical error) before use. Distances 7 and 9; both decoders; four levels | Every qubit position; the "keep when no threshold exists" rule | Exploratory, no bar: "never pays" is a possible result | 1–2 days | ~8 h |
| I | Analyses of existing data, no new runs: (1) the cost of a misplaced threshold (0.5, 0.75, 1.25, 1.5 and 2 times the break-even point) over the mixed scenario's spread of failure sizes; (2) each decoder's thresholds used with the other decoder; (3) where a Palmer & Smith target boundary and the break-even point disagree; (4) decision flips in round 15's realistic runs | Approximate thresholds; "any decoder"; inventive step | none | none | ~1 h |

Total computing about 45 hours, run two jobs at a time (about 2 days of wall-clock time). With coding, checks,
the rules file and the write-up, about 6–8 days.

## Toolchain note

The package index is not reachable from this workspace at the moment. PyMatching 2.4.0 is being rebuilt from its
GitHub source (the same version as rounds 14–15); Stim's command-line tool is already here. The `ldpc` package
cannot be installed, so part G uses a BP-OSD decoder written for this round and checked against published
results for the same code before use. If it proves too slow, part G falls back to noise on the data qubits only.

## Left for later rounds (described in words in the filing)

Circuit-level qLDPC with a removal rule, neural decoders, leakage, distance 13, hardware data, LUCI and Halma
circuits.
