# Round 16, part F — switch-out layout decided at calibration time: rules (fixed before the first run)

**Question.** When the set of qubits to switch out is decided once, from a calibration map (the setting of Drouet
et al., arXiv:2607.12118), do neighbourhood-aware break-even thresholds give fewer logical failures than keeping
every qubit and than fixed error-rate limits; and, where break-even thresholds with and without the neighbourhood
disagree, which decision is right?

**Method.** `f16.py` (its docstring is part of these rules: map generation, neighbourhood level, thresholds,
policies, the joint algorithm and the seeds). Distance 9, Z-basis memory, circuit-level depolarizing noise
p = 0.003 times each qubit's factor, blocks of 9 rounds, `deform16.py` circuits. Thresholds from the distance-9
tables already filed (plain matching: round 10, `out10/field_table_d9_*.json`; correlated matching: round 15,
`dev15/m15/tables/field_table15_d9_*.json`). Each distinct removal set of a map is simulated with 500,000 shots and
decoded by plain and by correlated matching with its own (exact) detector error model; each decoder's policies use
that decoder's thresholds. Maps: numpy seeds 1690001 + m; Stim seeds 1691000 + 10 m + chunk.

- **Random maps**: maps 0–39 (`--kind random --variant rand`): spread σ = 0.35; 1–4 failing data or Z-type
  measure qubits at 3–30 times nominal; in the odd-numbered maps a regional rise (peak 2–4, Gaussian, w = 4, centre
  uniform over the patch).
- **Targeted maps**: maps 100–139 (`--kind targeted`): one failing Z-type measure qubit inside a regional rise
  centred on it, its factor log-uniform between the correlated-matching thresholds at L = 1 and at its own level, so
  that the two break-even policies disagree about it.

Policies: keep; fixed limits 10× and 20× (20× is roughly Drouet's 5% two-qubit-gate limit:
5% / 0.3% ≈ 17); break-even for normal neighbours ("nominal", f*(role, 1)); neighbourhood-aware ("aware",
f*(role, L)); joint (best compatible set by the tables' predicted benefit). At most four compatible removals.

**Change from the approved design, made before any F simulation.** The design's bar compared aware with nominal on
the random maps. A decision-only dry run on 400 dev maps (seeds 7000000 + m, no simulation; `out16/F/power_dev.txt`)
showed that the two policies choose different sets in only 1.1 (correlated) and 2.4 (plain) of every 40 random
maps, with a predicted gain of about 4–7% in those maps, i.e. well under 1% pooled: too rare to test on 40 maps. The
comparison with nominal is therefore made on the targeted maps, where the two always disagree (200 of 200 dev maps
for correlated matching, 199 of 200 for plain), and the random maps test aware against keep and the fixed limits
(different sets in about 29, 8–11 and 15–18 of every 40 maps).

**Pre-registered checks.** Pooled failures = the sum over maps of the failures of the policy's set, for one decoder.
Relative difference = (pooled aware − pooled other) / pooled other. Interval: 95% percentile interval over 10,000
bootstrap resamples of the maps (numpy seed 1699999).
- **F1.** Random maps, each decoder, against each of keep, fixed 10× and fixed 20×: the relative difference is
  negative and its interval lies below zero (6 checks).
- **F2.** Targeted maps, each decoder, over the maps in which aware and nominal choose different sets: the relative
  difference against nominal is negative and its interval lies below zero (2 checks).
- Descriptive (no bar): aware against nominal on the random maps; joint against aware on both sets; how often each
  pair of policies differs; every map's sets and failures.

**Verification.** A second script recomputes every pooled number and interval from the stored per-map counts.

**Job list.** `jobs16F.txt` (eight jobs of ten maps, each writing its own file; resumable by map). Hashes of this
file, the job list, `f16.py`, `deform16.py`, `../rectgen.py`, the four table files and `out16/F/power_dev.txt` in
`out16/F/hashes_at_start.txt` before the first run.
