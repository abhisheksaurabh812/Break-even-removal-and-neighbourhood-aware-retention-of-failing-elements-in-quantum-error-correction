"""Round 16, part J: finishes the levels still missing (data L=1, zanc L=4, data L=4) point by point with j16pt.py,
two points at a time, in j16.py's order (removed configuration, then the kept qubit at each factor until its failures
reach the removed configuration's), and assembles each level's row exactly as j16.py writes it. Restartable: points
already in out16/J/pts are not recomputed. Points of data L=1 that the interrupted j16.py run (job J_d5_data_bposd_L1,
started 10 Nov 05:28:29, stopped by a container restart) printed to its log are taken from that log: same program,
same seeds, so the same counts (j16pt.py was checked against j16.py on two points before use).
python3 j16drive.py"""
import os, re, sys, json, time, subprocess
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
STIM = os.path.join(os.path.dirname(os.path.dirname(HERE)), 'bin', 'stim')
REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30); D = 5; SHOTS = 100000; SEED0 = 1670001
LEVELS = [('data', 1.0, 'J_d5_data_bposd_L1'), ('zanc', 4.0, 'J_d5_zanc_bposd_L4'), ('data', 4.0, 'J_d5_data_bposd_L4')]
PTS = 'out16/J/pts'; os.makedirs(PTS, exist_ok=True)


def pfile(kind, L, f):
    return f'{PTS}/{kind}_L{L:g}_{"ex" if f == "ex" else f"f{float(f):g}"}.json'


def crossover(grid, keep, ex):                                        # as j16.py
    prev = None
    for f, k in zip(grid, keep):
        if k >= ex:
            if prev is None:
                return float(f)
            f0, k0 = prev
            t = (np.log(ex) - np.log(k0)) / (np.log(k) - np.log(k0))
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 2)
        prev = (f, max(k, 1))
    return None


def seed_from_log():
    """Counts printed by the interrupted j16.py run of data L=1: lines 'data 1.0 <f> <k> excl <ex> <t>'."""
    log = 'out16/logs/J_d5_data_bposd_L1.out'
    if not os.path.exists(log):
        return
    for line in open(log):
        m = re.match(r'data 1\.0 (\S+) (\d+) excl (\d+) (\d+)', line)
        if not m:
            continue
        f, k, ex = float(m.group(1)), int(m.group(2)), int(m.group(3))
        for ff, kk in ((f, k), ('ex', ex)):
            fn = pfile('data', 1.0, ff)
            if not os.path.exists(fn):
                json.dump(dict(d=D, kind='data', L=1.0, f=ff if ff == 'ex' else str(ff), p=0.003, shots=SHOTS, seed0=SEED0,
                               fails=kk, source='log of the interrupted j16.py run J_d5_data_bposd_L1 (10 Nov 05:28)'),
                          open(fn, 'w'), indent=1)


def state(kind, L):
    """Returns (grid, ex, keep, finished)."""
    grid = sorted(set(round(L * r, 3) for r in REL))
    ex = json.load(open(pfile(kind, L, 'ex')))['fails'] if os.path.exists(pfile(kind, L, 'ex')) else None
    keep = []
    for f in grid:
        fn = pfile(kind, L, f)
        if not os.path.exists(fn):
            break
        keep.append(json.load(open(fn))['fails'])
        if ex is not None and keep[-1] >= ex:
            return grid, ex, keep, True
    return grid, ex, keep, (ex is not None and len(keep) == len(grid))


def next_points(kind, L, running):
    grid, ex, keep, fin = state(kind, L)
    if fin:
        return []
    order = ['ex'] + grid
    return [f for f in order if not os.path.exists(pfile(kind, L, f)) and (kind, L, f) not in running]


def main():
    seed_from_log(); running = {}; t0 = time.time()
    while True:
        for key, pr in list(running.items()):
            if pr.poll() is not None:
                print(time.strftime('%H:%M:%S'), 'done', key, 'rc', pr.returncode, flush=True)
                if pr.returncode != 0:
                    sys.exit(f'point {key} failed')
                del running[key]
        # first the next point of each level that has nothing running, then further points (speculative) of any level
        busy = {(k, L) for k, L, _ in running}
        first = [(k, L, next_points(k, L, running)[0]) for k, L, _ in LEVELS if (k, L) not in busy and next_points(k, L, running)]
        rest = [(k, L, f) for k, L, _ in LEVELS for f in next_points(k, L, running) if (k, L, f) not in first]
        pending = first + rest
        while len(running) < 2 and pending:
            k, L, f = pending.pop(0)
            if not next_points(k, L, running) or f not in next_points(k, L, running):
                continue
            cmd = ['python3', 'j16pt.py', '--d', str(D), '--kind', k, '--L', str(L), '--f', str(f), '--shots', str(SHOTS),
                   '--seed0', str(SEED0), '--stim', STIM, '--out', pfile(k, L, f)]
            running[(k, L, f)] = subprocess.Popen(cmd, stdout=open(f'{PTS}/run.log', 'a'), stderr=subprocess.STDOUT)
            print(time.strftime('%H:%M:%S'), 'start', (k, L, f), flush=True)
        if not running and all(state(k, L)[3] for k, L, _ in LEVELS):
            break
        time.sleep(5)
    # assemble the rows as j16.py does, and mark the queue's jobs done
    for kind in ('data', 'zanc'):
        out = f'out16/J/d{D}_{kind}_bposd.json'
        res = json.load(open(out)) if os.path.exists(out) else dict(d=D, kind=kind, qubit=[D, D] if kind == 'data' else [D - 1, D - 1],
                                                                     p=0.003, decoder='bposd', seed0=SEED0, rows=[])
        have = {r['L'] for r in res['rows']}
        for k, L, job in LEVELS:
            if k != kind or L in have:
                continue
            grid, ex, keep, fin = state(k, L); assert fin
            res['rows'].append(dict(L=L, shots=SHOTS, excl=ex, grid=grid[:len(keep)], keep=keep, crossover=crossover(grid, keep, ex)))
            secs = sum(json.load(open(pfile(k, L, f))).get('elapsed', 0) for f in ['ex'] + grid[:len(keep)])
            open(f'out16/done/{job}', 'w').write(f'{secs:.0f}')
            open('out16/queue.log', 'a').write(f"{time.strftime('%H:%M:%S')} end {job} rc=0 {secs:.0f}s "
                                               f"(computed point by point with j16pt.py, out16/J/pts; see j16drive.py)\n")
        res['rows'].sort(key=lambda r: r['L']); res['pointwise'] = 'rows for levels finished by j16drive.py; see out16/J/pts'
        json.dump(res, open(out, 'w'), indent=1)
        print(out, [(r['L'], r['crossover']) for r in res['rows']], flush=True)


if __name__ == '__main__':
    main()
