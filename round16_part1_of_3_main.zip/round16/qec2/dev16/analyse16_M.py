"""Round 16, part M analysis (rules: PREREG_16M.md).  python3 analyse16_M.py
Reads out16/M/M_<test>_s<seed>.npz (whatever has finished), writes out16/M/M_results.txt and .json."""
import os, json, glob
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); OUTM = os.path.join(HERE, 'out16', 'M')
TESTS = {'realistic': range(18001, 18011), 'pairs': range(18401, 18411), 'hwlike': range(18701, 18711)}
DEC = {'corr': 'fails_c', 'plain': 'fails'}
PAIRS = [('gate', 'blind'), ('gate', 'lookup1'), ('lookup1', 'blind'), ('gate', 'rw'), ('lookup1', 'rw'), ('blind', 'rw')]
R15 = {'realistic': 'd9_realistic', 'pairs': 'pairs_mixed', 'hwlike': 'd9_hwlike'}


def load():
    runs = []
    for t, seeds in TESTS.items():
        for s in seeds:
            f = os.path.join(OUTM, f'M_{t}_s{s}.npz')
            if not os.path.exists(f):
                continue
            z = np.load(f, allow_pickle=True)
            names = [str(x) for x in z['names']]
            r = dict(test=t, seed=s, names=names, nexcl=z['nexcl'], info=json.loads(str(z['info'])))
            for d, k in DEC.items():
                r[d] = z[k].astype(np.int64).sum(2)            # (arms, epochs): failures per epoch
            runs.append(r)
    return runs


def stats(runs, dec, a, b):
    x = [r[dec][r['names'].index(a)] for r in runs]; y = [r[dec][r['names'].index(b)] for r in runs]
    A = np.array([v.sum() for v in x], float); B = np.array([v.sum() for v in y], float)
    dd = np.concatenate([u - v for u, v in zip(x, y)]).astype(float)
    z = float(dd.sum() / np.sqrt((dd ** 2).sum())) if (dd ** 2).sum() > 0 else 0.0
    idx = np.random.default_rng(8).integers(0, len(runs), size=(10000, len(runs)))
    bs = (A[idx].sum(1) - B[idx].sum(1)) / B[idx].sum(1)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return dict(fails=int(A.sum()), ref_fails=int(B.sum()), rel_pct=round(100 * (A.sum() - B.sum()) / B.sum(), 3),
                z=round(z, 2), lo_pct=round(100 * float(lo), 3), hi_pct=round(100 * float(hi), 3),
                runs=len(runs), runs_better=int((A < B).sum()), runs_worse=int((A > B).sum()))


def counts(runs, arm):
    outs = healthy = 0; epochs_out = 0
    for r in runs:
        log = r['info'][arm]['policy_log']
        for i, l in enumerate(log):
            if l[0] != 'out':
                continue
            outs += 1
            nxt = next((m for m in log[i + 1:] if m[0] in ('probe', 'in') and m[3] == l[3]), None)
            if nxt is not None and nxt[5] < 2.0:
                healthy += 1
        epochs_out += int((r['nexcl'][r['names'].index(arm)] > 0).sum())
    return dict(switch_outs=outs, healthy_at_first_probe=healthy, epochs_with_qubit_out=epochs_out)


def main():
    runs = load(); res = dict(runs=len(runs), by_test={t: sum(r['test'] == t for r in runs) for t in TESTS})
    res['pooled'] = {f'{d}|{a} vs {b}': stats(runs, d, a, b) for d in DEC for a, b in PAIRS} if runs else {}
    res['per_test'] = {}
    for t in TESTS:
        rs = [r for r in runs if r['test'] == t]
        if rs:
            res['per_test'][t] = {f'{d}|{a} vs {b}': stats(rs, d, a, b) for d in DEC for a, b in PAIRS}
    res['counts'] = {t: {a: counts([r for r in runs if r['test'] == t], a) for a in ('gate', 'lookup1', 'blind', 'rw')}
                     for t in TESTS if any(r['test'] == t for r in runs)}
    checks = {}
    for key, d in (('M1', 'corr'), ('M1p', 'plain')):
        x = res['pooled'].get(f'{d}|gate vs blind')
        checks[key] = None if (x is None or len(runs) < 30) else bool(x['rel_pct'] < 0 and x['hi_pct'] < 0)
    res['checks'] = checks
    i10 = os.path.join(HERE, 'out16', 'I', 'I10_results.json')
    if os.path.exists(i10):
        J = json.load(open(i10))
        res['round15_context'] = {t: {k: J.get(f'{d}|{k}|{R15[t]}') for d in DEC for k in ('sz_w15 vs cut15', 'sz_w15 vs sz')}
                                  for t in TESTS}
    json.dump(res, open(os.path.join(OUTM, 'M_results.json'), 'w'), indent=1)
    L = [f"part M: {res['runs']} of 30 runs ({res['by_test']}); checks {checks}", '', 'pooled:']
    for k, v in res['pooled'].items():
        L.append(f"  {k:24s} {v['rel_pct']:+7.2f}%  [{v['lo_pct']:+.2f}, {v['hi_pct']:+.2f}]  z={v['z']:+.1f}  "
                 f"better/worse {v['runs_better']}/{v['runs_worse']} of {v['runs']}")
    for t, P in res['per_test'].items():
        L.append(f'{t}:')
        for k, v in P.items():
            L.append(f"  {k:24s} {v['rel_pct']:+7.2f}%  [{v['lo_pct']:+.2f}, {v['hi_pct']:+.2f}]  z={v['z']:+.1f}")
    L.append('counts (switch-outs, healthy at first probe, epochs with a qubit out):')
    for t, C in res['counts'].items():
        L.append(f'  {t}: ' + '; '.join(f"{a} {c['switch_outs']}, {c['healthy_at_first_probe']}, {c['epochs_with_qubit_out']}"
                                       for a, c in C.items()))
    open(os.path.join(OUTM, 'M_results.txt'), 'w').write('\n'.join(L) + '\n')
    print('\n'.join(L))


if __name__ == '__main__':
    main()
