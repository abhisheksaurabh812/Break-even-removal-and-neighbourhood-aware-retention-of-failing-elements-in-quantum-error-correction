"""Round 16 design probe (development only; nothing frozen is read for a result or written).

Does PyMatching 2.4's correlated matching keep its advantage over plain matching as the distance grows?  arXiv
2610.26785 (19 Oct 2026) reports that correlated decoders' standard reweighting can fail on (d-1)/2-fault
configurations and lose error suppression well below threshold.  Here: the memory circuit the rounds use
(deform.circuit, d rounds, uniform circuit noise p, no failing qubit), Stim's samples and detector error model, both
decoders on the same samples (as ideal_field15.py: plain = enable_correlations False, correlated = True).  Per
distance: failures of each decoder, both, run time of sampling and of each decoder per shot.  Sampling continues in
chunks until the correlated decoder has `target` failures, `max_shots` shots or `max_s` seconds.

python3 dev16/probe/dscale16.py <p> <d,d,...> <out.json> [target=200] [max_shots=2e7] [max_s=1800]   (from qec2/)"""
import json, os, subprocess, sys, tempfile, time
import numpy as np
import pymatching
HERE = os.path.dirname(os.path.abspath(__file__))
QEC2 = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, QEC2)
import deform                                   # noqa: E402
STIM = os.path.join(os.path.dirname(QEC2), 'bin', 'stim')

kw = dict(a.split('=') for a in sys.argv[4:])
p = float(sys.argv[1]); ds = [int(x) for x in sys.argv[2].split(',')]; out = sys.argv[3]
target = int(kw.get('target', 200)); max_shots = int(float(kw.get('max_shots', 2e7))); max_s = float(kw.get('max_s', 1800))
TMP = tempfile.mkdtemp(prefix='ds16_', dir=HERE)
res = json.load(open(out)) if os.path.exists(out) else dict(p=p, rows=[])
done_d = {r['d'] for r in res['rows']}

for d in ds:
    if d in done_d:
        continue
    txt, _ = deform.circuit(d, d, p)
    cf, df, of = (os.path.join(TMP, x) for x in ('c.stim', 'c.dem', 's.b8'))
    open(cf, 'w').write(txt)
    t = time.time()
    subprocess.run([STIM, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
    mp = pymatching.Matching.from_detector_error_model_file(df, enable_correlations=False)
    mc = pymatching.Matching.from_detector_error_model_file(df, enable_correlations=True)
    t_build = time.time() - t
    nd = mc.num_detectors; nb = (nd + 1 + 7) // 8
    fp = fc = both = shots = 0; seed = 1; ts = tp = tc = 0.0; t0 = time.time()
    chunk = 20000 if d >= 11 else 50000
    while fc < target and shots < max_shots and time.time() - t0 < max_s:
        n = min(chunk, max_shots - shots)
        t = time.time()
        subprocess.run([STIM, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        raw = np.fromfile(of, dtype=np.uint8).reshape(n, nb)
        bits = np.unpackbits(raw, axis=1, bitorder='little')[:, :nd + 1]
        ts += time.time() - t; t = time.time()
        a = mp.decode_batch(bits[:, :nd])[:, 0] != bits[:, nd]
        tp += time.time() - t; t = time.time()
        b = mc.decode_batch(bits[:, :nd], enable_correlations=True)[:, 0] != bits[:, nd]
        tc += time.time() - t
        fp += int(a.sum()); fc += int(b.sum()); both += int((a & b).sum()); shots += n; seed += 1
    row = dict(d=d, rounds=d, detectors=nd, shots=shots, plain=fp, corr=fc, both=both,
               ratio_corr_plain=round(fc / max(fp, 1), 4),
               per_shot_us=dict(sample=round(1e6 * ts / shots, 2), plain=round(1e6 * tp / shots, 2),
                                corr=round(1e6 * tc / shots, 2)), build_s=round(t_build, 1),
               elapsed_s=round(time.time() - t0, 1))
    res['rows'].append(row); res['rows'].sort(key=lambda r: r['d'])
    json.dump(res, open(out, 'w'), indent=1)
    print(json.dumps(row), flush=True)
for f in os.listdir(TMP):
    os.remove(os.path.join(TMP, f))
os.rmdir(TMP)
