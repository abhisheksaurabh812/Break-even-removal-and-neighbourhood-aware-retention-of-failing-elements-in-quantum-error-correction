"""Round 16, part F: which qubits to switch out when the layout is decided at calibration time (Drouet et al.'s
setting), by six policies, on fixed calibration maps of a distance-9 rotated surface code.

python3 f16.py --maps 0-9 --out out16/F/maps.jsonl --stim STIM --pymatching PM [--shots 500000] [--variant V]
python3 f16.py --power 400 --variant V        (dev only: decision statistics on dev maps, no simulation)

Map m (numpy generator seeded with MAP_SEED0 + m; draws in this order):
  1. spread: every qubit's factor exp(0.35 z), z ~ N(0, 1), qubits in sorted coordinate order;
  2. failing qubits: k ~ U{1, ..., 4}; positions uniform without replacement over the removable qubits (data and
     Z-type measure qubits) with both coordinates in [4, 2d - 4]; factors log-uniform in [3, 30], replacing the spread;
  3. in odd-numbered maps a regional rise: peak A ~ U(2, 4); centre per the variant; every qubit's factor (failing
     ones included) multiplied by 1 + (A - 1) exp(-r^2 / (2 w^2)), r its distance from the centre in lattice units
     (neighbouring data qubits are 2 units apart). Variant 'rand': centre uniform over [1, 2d - 1]^2, w = 4;
     'near': centre = a failing qubit chosen uniformly + an offset uniform in [-4, 4]^2, w = 4; 'wide': as 'rand'
     with w = 6. (Draws for the rise are made in every map, used only in odd ones, so maps differ only there.)
Targeted maps (--kind targeted; the decision-relevant case, where the two break-even policies must differ):
  spread as above; one failing Z-type measure qubit g, uniform over the bulk Z-type measure qubits; a regional rise
  in every map, A ~ U(2, 4), centred on g, w = 4; then L_g from the map, and g's factor log-uniform between
  f*(zanc, 1; corr) and f*(zanc, L_g; corr) (replacing its value). No other failing qubit.
The decoder knows the map (exact rates) in every policy.

Neighbourhood level of a qubit g: median of the factors of the qubits within Chebyshev distance 4 of g, excluding g
and its footprint (the checks whose support it changes). Thresholds f*(role, L; decoder) from the distance-9 tables
(plain: round 10, out10/; correlated: round 15, dev15/m15/tables/), interpolated linearly in (ln L, ln f*) and held
constant outside L = 1..8; the bulk tables are used for every position. Removable: data and Z-type measure qubits.

Policies (each decoder its own thresholds; at most 4 removals; a candidate is added only if compatible with those
already chosen, deform16.compatible):
  keep     no removal;
  fixed10  remove qubits with factor >= 10, largest first;     fixed20  the same with 20;
  nominal  remove qubits with factor > f*(role, 1), largest factor / f* first;
  aware    remove qubits with factor > f*(role, L_g), largest factor / f* first;
  joint    the compatible set of at most 4 removals with the largest predicted total benefit, where a qubit's
           predicted benefit b = ln K(f, L) - ln E(L) from the same tables (ln K interpolated linearly in ln f
           within a level, flat below the grid, extrapolated from the last two points above it; b interpolated
           linearly in ln L between levels); only qubits with b > 0, the 12 largest; ties go to fewer removals.
Simulation: every distinct removal set of a map is sampled once (Stim seeds STIM_SEED0 + 10 m + chunk, chunks of
200,000 shots, the same for every set of the map) and decoded by plain and by correlated matching with its own
detector error model."""
import sys, os, json, time, subprocess, tempfile, argparse, itertools
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); QEC2 = os.path.dirname(HERE)
sys.path.insert(0, QEC2); sys.path.insert(0, HERE)
import deform16                                  # noqa: E402
from rectgen import layout                       # noqa: E402

D, P = 9, 0.003
MAP_SEED0, STIM_SEED0, DEV_SEED0 = 1690001, 1691000, 7000000
TABLES = {('data', 'plain'): 'out10/field_table_d9_data.json', ('zanc', 'plain'): 'out10/field_table_d9_zanc.json',
          ('data', 'corr'): 'dev15/m15/tables/field_table15_d9_data.json',
          ('zanc', 'corr'): 'dev15/m15/tables/field_table15_d9_zanc.json'}
DATA, XM, ZM = layout(D, D)
ALLQ = sorted(DATA + XM + ZM)
CH = deform16.checks(D)
FP = {c: deform16.footprint(c, D) for c in ALLQ}
ROLE = {**{c: 'data' for c in DATA}, **{c: 'zanc' for c in ZM}, **{c: 'xanc' for c in XM}}
REMOVABLE = sorted(DATA + ZM)
BULK = [c for c in REMOVABLE if 4 <= c[0] <= 2 * D - 4 and 4 <= c[1] <= 2 * D - 4]


def load_tables():
    out = {}
    for k, f in TABLES.items():
        r = json.load(open(os.path.join(QEC2, f)))
        assert r['d'] == D and r['kind'] == k[0] and abs(r['p'] - P) < 1e-12
        out[k] = sorted(r['rows'], key=lambda x: x['L'])
    return out


def fstar(rows, L):
    Ls = np.log([r['L'] for r in rows]); fs = [r['crossover'] for r in rows]
    x = float(np.clip(np.log(max(L, 1e-9)), Ls[0], Ls[-1]))
    j = int(np.searchsorted(Ls, x, side='right')) - 1; j = min(max(j, 0), len(Ls) - 2)
    a, b = fs[j], fs[j + 1]
    if a is None or b is None:                     # an infinite threshold at either bracketing level
        return float('inf')
    t = (x - Ls[j]) / (Ls[j + 1] - Ls[j])
    return float(np.exp(np.log(a) + t * (np.log(b) - np.log(a))))


def _lnK(row, f):
    g = np.log(row['grid']); k = np.log(np.maximum(row['keep'], 1)); x = np.log(f)
    if len(g) == 1 or x <= g[0]:
        return float(k[0])
    if x >= g[-1]:
        return float(k[-1] + (x - g[-1]) * (k[-1] - k[-2]) / (g[-1] - g[-2]))
    return float(np.interp(x, g, k))


def benefit(rows, L, f):
    Ls = np.log([r['L'] for r in rows])
    x = float(np.clip(np.log(max(L, 1e-9)), Ls[0], Ls[-1]))
    j = int(np.searchsorted(Ls, x, side='right')) - 1; j = min(max(j, 0), len(Ls) - 2)
    b = [_lnK(rows[i], f) - np.log(max(rows[i]['excl'], 1)) for i in (j, j + 1)]
    t = (x - Ls[j]) / (Ls[j + 1] - Ls[j])
    return float(b[0] + t * (b[1] - b[0]))


def make_map(seed, variant, odd):
    rng = np.random.default_rng(seed)
    fac = {c: float(np.exp(0.35 * z)) for c, z in zip(ALLQ, rng.standard_normal(len(ALLQ)))}
    k = int(rng.integers(1, 5))
    pos = [BULK[i] for i in rng.choice(len(BULK), size=k, replace=False)]
    ff = np.exp(rng.uniform(np.log(3), np.log(30), size=k))
    for c, f in zip(pos, ff):
        fac[c] = float(f)
    A = float(rng.uniform(2, 4)); u = rng.uniform(1, 2 * D - 1, size=2); pick = int(rng.integers(0, k))
    off = rng.uniform(-4, 4, size=2)
    if variant == 'near':
        c0 = (pos[pick][0] + off[0], pos[pick][1] + off[1]); w = 4.0
    else:
        c0 = (u[0], u[1]); w = 6.0 if variant == 'wide' else 4.0
    rise = None
    if odd:
        rise = dict(A=A, centre=[float(c0[0]), float(c0[1])], w=w)
        for c in ALLQ:
            r2 = (c[0] - c0[0]) ** 2 + (c[1] - c0[1]) ** 2
            fac[c] = float(fac[c] * (1 + (A - 1) * np.exp(-r2 / (2 * w * w))))
    return fac, [(list(c), ROLE[c], round(float(fac[c]), 4)) for c in pos], rise


def make_targeted(seed, tabs):
    rng = np.random.default_rng(seed)
    fac = {c: float(np.exp(0.35 * z)) for c, z in zip(ALLQ, rng.standard_normal(len(ALLQ)))}
    zb = [c for c in BULK if ROLE[c] == 'zanc']
    g = zb[int(rng.integers(0, len(zb)))]
    A = float(rng.uniform(2, 4)); w = 4.0
    for c in ALLQ:
        r2 = (c[0] - g[0]) ** 2 + (c[1] - g[1]) ** 2
        fac[c] = float(fac[c] * (1 + (A - 1) * np.exp(-r2 / (2 * w * w))))
    L = level(g, fac)
    lo, hi = fstar(tabs[('zanc', 'corr')], 1.0), fstar(tabs[('zanc', 'corr')], L)
    fac[g] = float(np.exp(np.log(lo) + rng.uniform() * (np.log(hi) - np.log(lo))))
    return fac, [(list(g), 'zanc', round(fac[g], 4))], dict(A=A, centre=[float(g[0]), float(g[1])], w=w, L=round(L, 4))


def level(g, fac):
    ex = FP[g] | {g}
    vals = [fac[c] for c in ALLQ if c not in ex and max(abs(c[0] - g[0]), abs(c[1] - g[1])) <= 4]
    return float(np.median(vals))


def greedy(cands):
    chosen = []
    for c in cands:
        if len(chosen) == 4:
            break
        if deform16.compatible(chosen + [c], D):
            chosen.append(c)
    return tuple(sorted(chosen))


def policies(fac, tabs, dec):
    info = {}
    for c in REMOVABLE:
        r = ROLE[c]; L = level(c, fac)
        info[c] = dict(f=fac[c], L=L, f1=fstar(tabs[(r, dec)], 1.0), fL=fstar(tabs[(r, dec)], L))
    out = {'keep': ()}
    for lim in (10, 20):
        out[f'fixed{lim}'] = greedy(sorted([c for c in REMOVABLE if fac[c] >= lim], key=lambda c: (-fac[c], c)))
    out['nominal'] = greedy(sorted([c for c in REMOVABLE if fac[c] > info[c]['f1']], key=lambda c: (-fac[c] / info[c]['f1'], c)))
    out['aware'] = greedy(sorted([c for c in REMOVABLE if fac[c] > info[c]['fL']], key=lambda c: (-fac[c] / info[c]['fL'], c)))
    # joint: only qubits that some table could favour removing are scored (factor above 2, to save time)
    bs = {c: benefit(tabs[(ROLE[c], dec)], info[c]['L'], fac[c]) for c in REMOVABLE if fac[c] > 2}
    pos = sorted([c for c in bs if bs[c] > 0], key=lambda c: (-bs[c], c))[:12]
    best, bestv = (), 0.0
    for n in range(1, min(4, len(pos)) + 1):
        for S in itertools.combinations(pos, n):
            v = sum(bs[c] for c in S)
            if v > bestv + 1e-12 and deform16.compatible(list(S), D):
                best, bestv = tuple(sorted(S)), v
    out['joint'] = best
    for c in bs:
        info[c]['b'] = bs[c]
    return out, info


def sample_and_decode(sets, fac, m, shots, A, pymatching, tmp):
    res = {}
    for S in sets:
        txt = deform16.circuit(D, D, P, excl=list(S), scale=fac)[0]
        cf = os.path.join(tmp, 'c.stim'); df = os.path.join(tmp, 'c.dem'); of = os.path.join(tmp, 's.b8')
        open(cf, 'w').write(txt)
        subprocess.run([A.stim, 'analyze_errors', '--decompose_errors', '--in', cf, '--out', df], check=True)
        mp = pymatching.Matching.from_detector_error_model_file(df, enable_correlations=False)
        mc = pymatching.Matching.from_detector_error_model_file(df, enable_correlations=True)
        nd = mp.num_detectors; fails = [0, 0]; done = 0; k = 0
        while done < shots:
            n = min(200000, shots - done)
            subprocess.run([A.stim, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables', '--seed',
                            str(STIM_SEED0 + 10 * m + k), '--in', cf, '--out', of], check=True)
            bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(n, (nd + 1 + 7) // 8), axis=1, bitorder='little')[:, :nd + 1]
            fails[0] += int((mp.decode_batch(bits[:, :nd])[:, 0] != bits[:, nd]).sum())
            fails[1] += int((mc.decode_batch(bits[:, :nd], enable_correlations=True)[:, 0] != bits[:, nd]).sum())
            done += n; k += 1
        res[S] = dict(plain=fails[0], corr=fails[1])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--maps'); ap.add_argument('--out'); ap.add_argument('--stim'); ap.add_argument('--pymatching')
    ap.add_argument('--shots', type=int, default=500000); ap.add_argument('--variant', default='rand')
    ap.add_argument('--power', type=int, default=0); ap.add_argument('--kind', default='random')
    A = ap.parse_args()
    tabs = load_tables()
    if A.power:
        stats = {dec: dict(n_diff_nominal=0, n_diff_joint=0, n_diff_f10=0, n_diff_f20=0, n_diff_keep=0, flips=[]) for dec in ('plain', 'corr')}
        for m in range(A.power):
            fac, failing, rise = make_map(DEV_SEED0 + m, A.variant, m % 2 == 1)
            for dec in ('plain', 'corr'):
                pol, info = policies(fac, tabs, dec); s = stats[dec]
                s['n_diff_nominal'] += pol['aware'] != pol['nominal']; s['n_diff_joint'] += pol['aware'] != pol['joint']
                s['n_diff_f10'] += pol['aware'] != pol['fixed10']; s['n_diff_f20'] += pol['aware'] != pol['fixed20']
                s['n_diff_keep'] += pol['aware'] != pol['keep']
                if pol['aware'] != pol['nominal']:
                    gain = sum(info[c].get('b', 0) for c in pol['aware']) - sum(info[c].get('b', 0) for c in pol['nominal'])
                    s['flips'].append(round(gain, 3))
        for dec, s in stats.items():
            fl = s.pop('flips')
            print(A.variant, dec, {k: round(v / A.power * 40, 1) for k, v in s.items()}, 'per 40 maps;',
                  'predicted ln-gain per differing map: mean', round(float(np.mean(fl)), 3) if fl else None,
                  'min', min(fl) if fl else None)
        return
    sys.path.insert(0, A.pymatching)
    import pymatching
    a, b = [int(x) for x in A.maps.split('-')]
    have = set()
    if os.path.exists(A.out):
        have = {json.loads(l)['map'] for l in open(A.out) if l.strip()}
    tmp = tempfile.mkdtemp(prefix='f16_', dir=HERE)
    for m in range(a, b + 1):
        if m in have:
            continue
        t0 = time.time()
        if A.kind == 'targeted':
            fac, failing, rise = make_targeted(MAP_SEED0 + m, tabs)
        else:
            fac, failing, rise = make_map(MAP_SEED0 + m, A.variant, m % 2 == 1)
        pols, infos = {}, {}
        for dec in ('plain', 'corr'):
            pols[dec], infos[dec] = policies(fac, tabs, dec)
        sets = sorted(set(S for dec in pols for S in pols[dec].values()))
        res = sample_and_decode(sets, fac, m, A.shots, A, pymatching, tmp)
        rec = dict(map=m, kind=A.kind, variant=A.variant if A.kind == 'random' else None, seed=MAP_SEED0 + m, shots=A.shots, failing=failing, rise=rise,
                   policies={dec: {k: [list(c) for c in S] for k, S in pols[dec].items()} for dec in pols},
                   failures={dec: {k: res[S][dec] for k, S in pols[dec].items()} for dec in pols},
                   sets=[dict(removed=[list(c) for c in S], **res[S]) for S in sets],
                   candidates={dec: [dict(q=list(c), role=ROLE[c], **{k: (round(v, 4) if np.isfinite(v) else None) for k, v in i.items()})
                                     for c, i in infos[dec].items() if i['f'] > 2] for dec in infos},
                   elapsed=round(time.time() - t0, 1))
        open(A.out, 'a').write(json.dumps(rec) + '\n')
        print(m, len(sets), 'sets', {dec: rec['failures'][dec] for dec in rec['failures']}, rec['elapsed'], flush=True)
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    os.rmdir(tmp)


if __name__ == '__main__':
    main()
