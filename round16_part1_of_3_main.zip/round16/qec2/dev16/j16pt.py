"""Round 16, part J, one point at a time: computes one configuration of j16.py's level (the removed configuration
'ex', or the kept qubit at one factor) with exactly j16.py's circuit, decoder, shots and seeds, and writes its failure
count to a file. Used because a whole level of j16.py can take longer than the 2-hour limit on one background command;
j16pt.py's counts must equal j16.py's (checked before use on two points of level 1 already computed by j16.py).
`failures()` and the circuit construction are copied from j16.py unchanged.
python3 j16pt.py --d 5 --kind zanc --L 4 --f ex|<factor> --shots 100000 --seed0 1670001 --stim STIM --out FILE.json"""
import sys, os, json, time, subprocess, tempfile, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
import deform16, bposd16                          # noqa: E402
from rectgen import layout                       # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument('--d', type=int, required=True); ap.add_argument('--kind', required=True)
ap.add_argument('--L', type=float, required=True); ap.add_argument('--f', required=True)
ap.add_argument('--shots', type=int, required=True); ap.add_argument('--seed0', type=int, required=True)
ap.add_argument('--stim', required=True); ap.add_argument('--p', type=float, default=0.003)
ap.add_argument('--out', required=True)
A = ap.parse_args()
TMP = tempfile.mkdtemp(prefix='j16pt_', dir=HERE)


def failures(txt, shots, chunk=20000):                       # as j16.py
    cf = os.path.join(TMP, 'c.stim'); df = os.path.join(TMP, 'c.dem'); of = os.path.join(TMP, 's.b8')
    open(cf, 'w').write(txt)
    subprocess.run([A.stim, 'analyze_errors', '--in', cf, '--out', df], check=True)
    H, pr, L = bposd16.dem_to_matrices(open(df).read())
    dec = bposd16.BPOSD(H, pr); nd = H.shape[0]
    fails = done = 0; seed = A.seed0
    while done < shots:
        n = min(chunk, shots - done)
        subprocess.run([A.stim, 'detect', '--shots', str(n), '--out_format', 'b8', '--append_observables',
                        '--seed', str(seed), '--in', cf, '--out', of], check=True)
        bits = np.unpackbits(np.fromfile(of, dtype=np.uint8).reshape(n, (nd + 1 + 7) // 8), axis=1, bitorder='little')[:, :nd + 1]
        est = np.concatenate([dec.decode_batch(bits[i:i + 2000, :nd]) for i in range(0, n, 2000)])
        fails += int((((est.astype(np.int32) @ L.T.astype(np.int32)) % 2)[:, 0] != bits[:, nd]).sum())
        done += n; seed += 1
    return fails


if __name__ == '__main__':
    d = A.d; L = float(A.L); t0 = time.time()
    q = (d, d) if A.kind == 'data' else (d - 1, d - 1)                                   # as j16.py
    data, xm, zm = layout(d, d)
    region = [x for x in list(data) + list(xm) + list(zm) if x != q and max(abs(x[0] - q[0]), abs(x[1] - q[1])) <= 4]
    sc = {x: L for x in region}
    if A.f == 'ex':
        k = failures(deform16.circuit(d, d, A.p, excl=[q], scale=sc)[0], A.shots)
    else:
        k = failures(deform16.circuit(d, d, A.p, scale={**sc, q: float(A.f)})[0], A.shots)
    json.dump(dict(d=d, kind=A.kind, L=L, f=A.f, p=A.p, shots=A.shots, seed0=A.seed0, fails=k,
                   elapsed=round(time.time() - t0, 1), source='j16pt.py'), open(A.out, 'w'), indent=1)
    for f in os.listdir(TMP):
        os.remove(os.path.join(TMP, f))
    os.rmdir(TMP)
    print(A.kind, L, A.f, k, round(time.time() - t0), flush=True)
