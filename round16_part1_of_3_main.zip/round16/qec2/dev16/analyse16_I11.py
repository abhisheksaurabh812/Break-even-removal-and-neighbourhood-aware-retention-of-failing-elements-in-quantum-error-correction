"""Round 16, part I, item 11 (rules: PREREG_16I11.md): the role check of claim 10 on sampled detection events.
python3 analyse16_I11.py   (writes out16/I/I11_results.txt and .json)"""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); QEC2 = os.path.dirname(HERE)
sys.path.insert(0, QEC2)
from model import circuit_model, P_REF        # noqa: E402
from sampler import Sampler                   # noqa: E402
import analyse8 as A                          # noqa: E402

FACTORS = (3.0, 10.0, 33.6); WINDOWS = (200, 1000); NQ = 12; NS = 30; CUT = 0.40


def phat(X, eu, ev):
    x = X.astype(np.float64); n = x.shape[0]
    mu = x.mean(0); xu, xv = mu[eu], mu[ev]
    xuv = (x[:, eu] * x[:, ev]).sum(0) / n
    den = 1 - 2 * xu - 2 * xv + 4 * xuv
    arg = 1 - 4 * (xuv - xu * xv) / np.where(den > 1e-12, den, 1e-12)
    return 0.5 - 0.5 * np.sqrt(np.clip(arg, 0, None))


def main(pick_seed=1700001, sample_seed=1700101, nq=NQ, ns=NS, factors=FACTORS, dists=(7, 9), write=True):
    """The arguments exist only so that a development test can run on spare seeds and a smaller grid; the run of
    record uses the defaults (the rules' values)."""
    rng_pick = np.random.default_rng(pick_seed); seed = [sample_seed]; out = {}; lines = []
    NQ_, NS_, FACTORS_ = nq, ns, factors
    for d in dists:
        m = circuit_model(d); _, EX = A.roles(d)
        fn = 0.003 / P_REF; f0 = np.full(m.G, fn); p0 = m.edge_p(f0)
        v = np.maximum(m.ev, 0)
        inter = (m.ev >= 0) & (m.dcls[m.eu] == 1) & (m.dcls[v] == 1)
        same_anc = m.danc[m.eu] == m.danc[v]
        timelike = inter & same_anc

        def eset(g):
            f = f0.copy(); f[g] = fn * 10.0
            return np.nonzero(inter & (m.edge_p(f) - p0 > 1e-12))[0]
        E = {g: eset(g) for g in EX}
        pos = {g: np.round(m.qxy[g]).astype(int) for g in EX}
        near = {g: [h for h in EX if EX[h] != EX[g] and np.abs(pos[g] - pos[h]).max() == 1] for g in EX}
        data = sorted(g for g in EX if EX[g] == 'data'); zanc = sorted(g for g in EX if EX[g] == 'zanc')
        fail = list(rng_pick.choice(data, min(NQ_, len(data)), replace=False)) + \
            list(rng_pick.choice(zanc, min(NQ_, len(zanc)), replace=False))
        res = {}
        for fac in FACTORS_:
            for W in WINDOWS:
                res[f'f{fac:g}|W{W}'] = {c: dict(n=0, withheld=0, undecided=0, shares=[], exact=[]) for c in
                                         ('a_data', 'a_zanc', 'b_data_named_zanc', 'c_zanc_named_data')}
            for q in fail:
                q = int(q); f = f0.copy(); f[q] = fn * fac
                dpx = m.edge_p(f) - p0
                named = [(q, f'a_{EX[q]}')] + [(h, 'b_data_named_zanc' if EX[q] == 'data' else 'c_zanc_named_data')
                                                for h in near[q]]
                for s in range(NS_):
                    X, _ = Sampler(m, np.random.default_rng(seed[0])).sample(f[None, :], 1000); seed[0] += 1
                    for W in WINDOWS:
                        ph = phat(X[:W], m.eu, v)
                        for g, case in named:
                            e = E[g]; ex = ph[e] - p0[e]; tot = ex.sum()
                            r = res[f'f{fac:g}|W{W}'][case]; r['n'] += 1
                            if s == 0:
                                r['exact'].append(float(dpx[e][timelike[e]].sum() / dpx[e].sum()))
                            if tot <= 0:
                                r['undecided'] += 1; continue
                            sh = float(ex[timelike[e]].sum() / tot); r['shares'].append(sh)
                            reads_zanc = sh >= CUT
                            if reads_zanc != (EX[g] == 'zanc'):
                                r['withheld'] += 1
        for key, C in res.items():
            for case, r in C.items():
                r['median_share'] = round(float(np.median(r['shares'])), 3) if r['shares'] else None
                r['exact_share'] = (round(min(r['exact']), 3), round(max(r['exact']), 3)) if r['exact'] else None
                r['withheld_frac'] = round(r['withheld'] / r['n'], 4) if r['n'] else None
                r['undecided_frac'] = round(r['undecided'] / r['n'], 4) if r['n'] else None
                del r['shares'], r['exact']
                lines.append(f"d{d} {key:10s} {case:20s} n={r['n']:4d}  withheld {r['withheld_frac']}  undecided "
                             f"{r['undecided_frac']}  median share {r['median_share']}  exact {r['exact_share']}")
        out[f'd{d}'] = res
    if not write:
        print('\n'.join(lines)); return out
    os.makedirs(os.path.join(HERE, 'out16', 'I'), exist_ok=True)
    json.dump(out, open(os.path.join(HERE, 'out16', 'I', 'I11_results.json'), 'w'), indent=1)
    open(os.path.join(HERE, 'out16', 'I', 'I11_results.txt'), 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
