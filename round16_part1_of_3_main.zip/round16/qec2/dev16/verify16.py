"""Round 16 verification, written separately from the run scripts: recompute every threshold from the stored counts,
evaluate the pre-registered checks, recompute part F's pooled numbers and intervals, and re-check the hashes.
python3 verify16.py > out16/verify16.txt"""
import os, sys, json, glob, math, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
INF = float('inf')


def xover(grid, keep, arm):
    """Independent implementation: first grid point with keep >= arm; crossing linear in (ln f, ln keep - ln arm)."""
    arms = list(arm) if isinstance(arm, list) else [arm] * len(grid)
    for i in range(len(keep)):
        if keep[i] >= arms[i]:
            if i == 0:
                return float(grid[0])
            r0 = math.log(max(keep[i - 1], 1)) - math.log(max(arms[i - 1], 1))
            r1 = math.log(max(keep[i], 1)) - math.log(max(arms[i], 1))
            x0, x1 = math.log(grid[i - 1]), math.log(grid[i])
            if r1 == r0:
                return float(grid[i])
            return math.exp(x0 - r0 * (x1 - x0) / (r1 - r0))
    return None


def tables():
    out = {}
    bad = []
    for f in sorted(glob.glob('out16/[ABCDEHKJG]/*.json')):
        r = json.load(open(f)); rows = {}
        for x in r.get('rows', []):
            arm = x.get('excl', x.get('erase'))
            v = xover(x['grid'], x['keep'], arm)
            s = x['crossover']
            if (v is None) != (s is None) or (v is not None and abs(v - s) > 0.006 + 1e-9 * abs(s)):
                bad.append((f, x['L'], s, v))
            rows[x['L']] = INF if v is None else v
        out[f] = rows
    return out, bad


def ratio_ok(hi, lo, m=1.15):
    return hi >= m * lo


def checks(T):
    res = []

    def g(f, L):
        return T.get(f, {}).get(L)

    for d in (5, 11):
        for dec in ('plain', 'corr'):
            a, b = g(f'out16/B/d{d}_zanc_{dec}.json', 3.0), g(f'out16/B/d{d}_zanc_{dec}.json', 1.0)
            res.append(('B1', f'd{d} {dec}', b, a, None if a is None or b is None else ratio_ok(a, b)))
    for dec in ('plain', 'corr'):
        a, b = g(f'out16/B/d13_zanc_{dec}.json', 4.0), g(f'out16/B/d13_zanc_{dec}.json', 1.0)
        res.append(('B2', f'd13 {dec}', b, a, None if a is None or b is None else ratio_ok(a, b)))
    for d in (7, 9):
        for role in ('data', 'zanc'):
            for dec in ('plain', 'corr'):
                ex, un = g(f'out16/A/d{d}_{role}_exact_{dec}.json', 1.0), g(f'out16/A/d{d}_{role}_unchanged_{dec}.json', 1.0)
                res.append(('A1', f'd{d} {role} {dec}', ex, un, None if ex is None or un is None else un <= ex / 1.15))
    for d, nz in ((7, 'si1000'), (9, 'si1000'), (7, 'xbias10')):
        for dec in ('plain', 'corr'):
            f = f'out16/C/d{d}_{nz}_zanc_{dec}.json'; a, b = g(f, 3.0), g(f, 1.0)
            res.append(('C1', f'd{d} {nz} {dec}', b, a, None if a is None or b is None else ratio_ok(a, b)))
    for dec in ('plain', 'corr'):
        for L in (1.0, 4.0):
            x, z = g(f'out16/D/d7_xanc_x_{dec}.json', L), g(f'out16/D/d7_zanc_z_{dec}.json', L)
            ok = None if x is None or z is None else (max(x, z) <= 1.15 * min(x, z))
            res.append(('D1', f'{dec} L{L:g}', z, x, ok))
    for dec in ('plain', 'corr'):
        found, seen = False, False
        for f in sorted(glob.glob(f'out16/E/d7_*_{dec}.json')):
            a, b = g(f, 4.0), g(f, 1.0)
            if a is None or b is None:
                continue
            seen = True
            if b < INF and ratio_ok(a, b):
                found = True
        res.append(('E1', f'd7 {dec}', None, None, found if seen else None))
    return res


def boot(diff_num, den, n=10000, seed=1699999):
    rng = np.random.default_rng(seed); k = len(den)
    idx = rng.integers(0, k, size=(n, k))
    r = diff_num[idx].sum(axis=1) / den[idx].sum(axis=1)
    return float(np.percentile(r, 2.5)), float(np.percentile(r, 97.5))


def part_f():
    out = []
    for kind in ('random', 'targeted'):
        recs = [json.loads(l) for f in sorted(glob.glob(f'out16/F/{kind}_*.jsonl')) for l in open(f) if l.strip()]
        if not recs:
            continue
        for dec in ('plain', 'corr'):
            # recompute each policy's failures from the per-set table
            for r in recs:
                st = {tuple(map(tuple, s['removed'])): s[dec] for s in r['sets']}
                for pol, S in r['policies'][dec].items():
                    assert st[tuple(map(tuple, S))] == r['failures'][dec][pol], (r['map'], dec, pol)
            others = ('keep', 'fixed10', 'fixed20', 'nominal', 'joint')
            for o in others:
                use = recs if not (kind == 'targeted' and o == 'nominal') else \
                    [r for r in recs if r['policies'][dec]['aware'] != r['policies'][dec]['nominal']]
                if not use:
                    continue
                a = np.array([r['failures'][dec]['aware'] for r in use], float)
                b = np.array([r['failures'][dec][o] for r in use], float)
                rel = (a.sum() - b.sum()) / b.sum()
                lo, hi = boot(a - b, b)
                ndiff = sum(r['policies'][dec]['aware'] != r['policies'][dec][o] for r in use)
                bar = None
                if kind == 'random' and o in ('keep', 'fixed10', 'fixed20'):
                    bar = 'F1'
                if kind == 'targeted' and o == 'nominal':
                    bar = 'F2'
                out.append(dict(kind=kind, decoder=dec, vs=o, maps=len(use), maps_differing=ndiff,
                                rel_pct=round(100 * rel, 2), lo_pct=round(100 * lo, 2), hi_pct=round(100 * hi, 2),
                                bar=bar, passed=(rel < 0 and hi < 0) if bar else None))
    return out


def hashes():
    out = []
    for hf in sorted(glob.glob('out16/**/*hashes_at_start.txt', recursive=True)):
        for line in open(hf):
            p = line.split()
            if len(p) != 2 or len(p[0]) != 64:
                continue
            h, f = p
            cur = hashlib.sha256(open(f, 'rb').read()).hexdigest() if os.path.exists(f) else 'missing'
            out.append((hf, f, cur == h))
    return out


if __name__ == '__main__':
    T, bad = tables()
    print('thresholds recomputed:', sum(len(v) for v in T.values()), 'rows in', len(T), 'files; mismatches:', len(bad))
    for b in bad:
        print('  MISMATCH', b)
    print('\npre-registered checks (check, case, reference, compared, passed):')
    for c in checks(T):
        print(' ', c)
    print('\npart F:')
    for x in part_f():
        print(' ', x)
    hs = hashes()
    print('\nhashes:', sum(ok for *_, ok in hs), 'of', len(hs), 'unchanged')
    for hf, f, ok in hs:
        if not ok:
            print('  CHANGED', hf, f)
