# Round 16 working notes (state for continuing after a break)

Design: `ROUND16_DESIGN.md` (v2 additions at the top; user approved on 8 Nov 2026, 23:25 IST).
Purpose: data for the cognate (second) provisional; the first provisional is filed.

## Toolchain (package index unreachable from this workspace)
- Stim CLI: `$S/bin/stim` (S = scratchpad). Stim Python: building from GitHub v1.15.0 in `$S/tools/Stim`
  (`python3 setup.py build_ext --inplace`, PYTHONPATH=$S/tools/PyMatching/pybind11 for pybind11).
- PyMatching 2.4.0 built from GitHub source in `$S/tools/PyMatching`; import with sys.path `$S/tools/PyMatching/src`
  (pip install fails on Debian setuptools `install_layout`; build_ext --inplace works).
- No `ldpc`: own BP-OSD in `bposd16.py` (min-sum scale 0.625, 30 iterations, OSD combination sweep order 20).
  Dev check (spent seeds 1, 2): d3 circuit-level BP-OSD 167 vs matching 158 of 20k; d5 order 20: 24 vs matching 28
  of 8k; order 8: 33. About 300-400 shots/s at d5.

## Validation
- `check16.py`: deform16 text identical to frozen deform.py in 36/36 bulk cases; all new configurations (edges,
  corners, edge Z ancilla, X basis incl. bulk/edge X ancilla, si1000, x/z bias, coupler pair scale) give valid DEMs.
  Distances not yet checked (needs Stim Python).
- `repro/`: ideal16 + rebuilt PyMatching reproduce round 15's d9 data corr L=1 row exactly (excl 735; keep 407,
  401, 418, ... as in dev15/m15/tables/field_table15_d9_data.json) with seeds 1..

## Parts and seeds (Stim chunk seeds start at seed0)
- B 1600001 (`PREREG_16B.md`, `jobs16B.txt`; hashes out16/B/hashes_at_start.txt).
- A, C, D, E, K: `PREREG_16T.md`, `jobs16T.txt`; seeds A 1610001, C 1620001, D 1630001, E 1640001, K 1660001;
  hashes out16/T_hashes_at_start.txt.
- H 1650001: `PREREG_16H.md`, `jobs16H.txt`; distance checks `hdist16.py` -> out16/H/distances.txt (data removals
  d-1 in both bases, measure-qubit removals d, at d = 5, 7, 9); hashes out16/H/hashes_at_start.txt.
- G (numpy 1680001+, p = 0.01, absolute factor grid) and J (Stim 1670001+, BP-OSD d5 zanc and data):
  `PREREG_16GJ.md`, `jobs16GJ.txt`; hashes out16/GJ_hashes_at_start.txt.
- F (maps numpy 1690001 + m, Stim 1691000 + 10m + chunk; random maps 0-39, targeted 100-139): `PREREG_16F.md`,
  `jobs16F.txt`, `f16.py`; dry run out16/F/power_dev.txt; hashes out16/F/hashes_at_start.txt. Bar moved from
  aware-vs-nominal on random maps (too rare: 1-2 differing maps per 40) to targeted maps (F2); F1 = aware vs keep,
  fixed 10x, fixed 20x on random maps.
- Stim Python (polyfill build) importable from $S/tools/stimpy (the sse2 .so exported the wrong symbol).
- Repro: round 15 d9 data corr L=1 row reproduced exactly (all 9 points, crossover 15.74).

## Running
Full job list `jobs16_all3.txt` = B, F, T, H, GJ (297 jobs). From 9 Nov ~07:00 relaunch with `jobs16_all4.txt`
(= all3 unchanged + part M's 30 jobs at the end; hashed in out16/M/hashes_at_start.txt), from dev16:
`python3 queue16.py jobs16_all4.txt 110 2 >> out16/queue.log 2>&1` (run_in_background) until "0 jobs left".
From 9 Nov ~17:00 (user asked for part M first): use `jobs16_all5.txt` (same job lines, part M first, interleaved;
hash added to out16/M/hashes_at_start.txt before any M run). The all4 queue was stopped after
K_d9_data_tracked_corr_L4 finished; the K job(s) it had just started were killed and rerun later from all5.
From 9 Nov 22:46: the 20:45 batch hit the 2-hour background limit (K_d7_zanc_unchanged_corr_L4 killed, no output,
rerun). Relaunch command is now `python3 queue16.py jobs16_all5.txt 95 2 >> out16/queue.log 2>&1` (95-min window).
The first batch (B only) logs to out16/B/queue.log.

## Part I (analyses, no runs)
`analyse16_I.py` -> out16/I/I_results.{txt,json}: (1) misplaced thresholds, (2) cross-decoder, (3) target
boundaries a la Palmer & Smith, (5) fitted formula, (6) classifier d7<->d9, (7) one threshold for both roles,
(8) switching example, (9) decision time/memory. Re-run when all B tables are in (it picks them up).
(4) decision flips in round 15's realistic runs with measured cost: not started (needs round 15's episode logs in
out15/*.npz 'info' and the true field rebuilt); do after the main runs if time allows.
Added 9 Nov after an outside review (rules PREREG_16I3b.md, hashes out16/I/I3b_hashes_at_start.txt):
(3b) `analyse16_I3b.py` absolute-target boundary (P&S use an absolute target, 0.005/round) beside f*: it falls to
"<= L" at L >= 2 for c <= 5 in every table, while f* stays 11-23 (zanc rises); (10) `analyse16_I10.py` round 15's
cutoff (C) vs reweighting alone, same earlier naming: -11.15% [-15.84, -6.67] corr, but +2.13% [+1.09, +2.97] under
realistic noise; reproduces Table 3 (-18.85%, -8.67%). Proposed, cheap, not yet written: (11) sampled time-like
share test for claim 10 (the [0063] misnaming case is round 9 seed 5304, d7, older gate; detection events not stored).
Proposed, needs the user's decision: online decision-only ablation (new arm subclassing PolicyArmFieldWatch4 with
fstar(kind, 1) and no re-fit; maybe a role-confirmation arm), fresh seeds, realistic/pairs_mixed/hwlike, ~11 CPU-h.

(11) done 9 Nov: `analyse16_I11.py` (rules PREREG_16I11.md, hashes out16/I/I11_hashes_at_start.txt) -> out16/I/
I11_results.{txt,json}: sampled role check, cut 0.40. At 10x/33.6x: wrong namings caught 99.7-100% even with 200
blocks, correct ones withheld <= 0.6%; at 3x needs 1000 blocks (caught 97.5-99%, withheld <= 3%); at 33.6x the
pair formula saturates for a failing measure qubit (undecided 18-22% with 200 blocks).

## Part M (user approved 9 Nov 05:42): online gate with only the switch-out rule changed
Rules PREREG_16M.md. Arms (pure configuration of round 15's gate, gen_cfg16M.py): gate, lookup1 (flat table at
L=1, re-fit on), blind (flat table, re-fit off = cutoff (C) with the gate's naming/watch), rw (never out).
Tests realistic d9 18001-18010, pairs_mixed d7 18401-18410, hwlike d9 18701-18710; dev seed 18999 spent.
Runner: run16m.py = round 15's run15.run unchanged + pylib on path + caches in cacheM/ (hard links of round 15's).
Checks M1 (corr) / M1p (plain): gate vs blind pooled, rel < 0 and bootstrap hi < 0. analyse16_M.py, verify16_M.py
(uses round 15's analyse8.compare/bootstrap). Job list jobs16_M.txt appended to jobs16_all3 as jobs16_all4.txt:
RELAUNCH WITH jobs16_all4.txt once out16/M/hashes_at_start.txt exists. Online role-check arm not built (needs new
detection code in the gate); claim 10 is covered offline by item (11).

Part M DONE 10 Nov 01:45 (30/30, rc 0). M1 (corr) PASS: gate vs blind -3.93% [-6.21, -1.70], z -29.3, better/worse
17/12; M1p (plain) PASS: -3.15% [-5.05, -1.35], 21/8. By test (corr): realistic -4.15% [-7.59, -0.51]; hwlike -4.61%
[-8.31, -1.45]; pairs +0.31% (level). gate vs lookup1 -6.25% [-10.62, -2.20]; lookup1 vs blind +2.47% [-0.41, +6.10];
gate vs rw -10.95% (realistic -1.52%, pairs -27.48%, hwlike -13.74%); blind vs rw realistic +2.74% [-1.38, +7.13].
verify16_M.py: 0 mismatches, M1/M1p pass, 178/178 hashes unchanged (out16/M/verify16_M.txt); round 15's 89 hashes OK
(check from qec2/, paths are relative to it).

10 Nov ~06:25: container restart stopped the queue. G complete (bb_tracked L4 done 05:28); J zanc L1 done 06:03
(crossover 4.73, ratio 1.57 to its estimate). J_d5_data_bposd_L1 (started 05:28:29) was killed after printing points
f <= 5 (ex 570). Remaining J levels (data L1, zanc L4, data L4) are finished POINT BY POINT: j16pt.py (failures()
copied from j16.py, identical; hashes in out16/J/pointwise_hashes.txt) checked against j16.py on data L1 f=1 (271)
and zanc L1 ex (438) before use; j16drive.py runs points two at a time in j16.py's order, restartable, seeds data L1
f <= 5 from the interrupted run's log, assembles rows as j16.py does, writes done markers and queue.log lines.
Relaunch if stopped: `python3 j16drive.py >> out16/J/pts/drive.log 2>&1` (run_in_background). No queue needed.

## Verification
`verify16.py` (independent crossover code, all pre-registered checks B1 B2 A1 C1 D1 E1 F1 F2, part F pooled
numbers and bootstrap, hash re-check) -> out16/verify16.txt. Tested on the d5 tables: 0 mismatches; B1 d5 passes.

## To do
Relaunch batches; when done: verify16, analyse16_I re-run, RESULTS_round16.md, package, report; cognate draft.

## 13 Nov 2026
- Post hoc items 12 and 13 (`analyse16_I12_13.py` -> `out16/I/I12_results.json`, `I13_results.json`): matching
  thresholds used with BP-OSD cost 0.47% mean, 1.51% max; a threshold f*(1)*L costs 2.4-5.6% (data qubits, L 2-8) where
  ignoring the level costs about 0.05%, and 0.6-1.9% (Z-measure) against 0.9-2.9%.
- Cognate Draft 6 built and sent (`deliver_cognate/Cognate_Provisional_Draft6_13Nov2026.pdf`, LaTeX zip). Fixed: the
  6.2% re-fit ratio direction, intervals on the realistic and re-fit comparisons, d13 block count, BP-OSD "about 11%",
  Palmer and Smith description plus [E0007] clarification, coupler statements limited to the model, claims 21-22 define
  the threshold, 18.9% margin qualified by [0120]; Table 18 added.
- Reviewed the user's own compile of Draft 5 (not my file; same errors plus claims 18, 21-23 and blanks), the HAT
  "blueprint" analysis (quotes accurate, conclusions not; HAT is public prior art) and the 17-page paper draft
  (numbers match; wording, ten references and disclosures to fix; hold until the cognate is filed).
- Reproducibility archive built (`pkg16_build/build_pkg16.py`, `final_pkg.sh` -> `deliver_round16/`): round 16 with
  the round-15 code and the 70 round-15 runs it reads, the tool builds, README, ENVIRONMENT, MANIFEST and check
  scripts. Checked from a fresh copy (all hash lists, both verifications, every analysis identical bar item 9's
  timing) and five jobs re-run identically (H, C, G, F, M). RESULTS_round16.md: role-check line corrected (33.6x,
  200 blocks: 83-86% caught, rest undecided).
- Paper rewritten (`paper_rewrite/`): tables generated from the result files, references checked; no Table 18.
