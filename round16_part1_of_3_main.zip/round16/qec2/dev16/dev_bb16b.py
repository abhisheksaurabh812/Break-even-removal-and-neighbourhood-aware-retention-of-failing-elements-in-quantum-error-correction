"""Dev only (spent seeds 99+): choose part G's operating point, and check the decoder on the BB code.
1) exhaustive code-capacity check: every weight-1 and weight-2 X error on the 72 data qubits (perfect syndrome)
   must be corrected up to a stabilizer (distance 6 corrects 2);
2) keep/erase failures at a few (p, L, f, retain) points, 10,000 shots each."""
import sys, os, time, itertools
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
sys.argv = [sys.argv[0]] + sys.argv[1:]
import bposd16                                     # noqa: E402
import importlib.util
spec = importlib.util.spec_from_file_location('bb16', os.path.join(HERE, 'bb16.py')); bb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bb)

HX, HZ = bb.bb_code(); LZ = bb.z_logicals(HX, HZ); n = HX.shape[1]; m = HZ.shape[0]
print('logicals', LZ.shape, 'rank HZ', bb.rank_gf2(HZ), flush=True)
if 'cc' in sys.argv:
    dec = bposd16.BPOSD(HZ, np.full(n, 0.01))
    errs = [np.eye(n, dtype=np.uint8)[i] for i in range(n)]
    errs += [(np.eye(n, dtype=np.uint8)[i] ^ np.eye(n, dtype=np.uint8)[j]) for i, j in itertools.combinations(range(n), 2)]
    E = np.array(errs); S = (E.astype(int) @ HZ.T) % 2
    t0 = time.time(); est = np.concatenate([dec.decode_batch(S[i:i + 500]) for i in range(0, len(E), 500)])
    res = (est ^ E)
    syn_ok = ((est.astype(int) @ HZ.T) % 2 == S).all(axis=1)
    log_fail = ((res.astype(int) @ LZ.T) % 2).any(axis=1)
    print('code capacity: errors', len(E), 'syndrome reproduced', int(syn_ok.sum()), 'logical failures', int(log_fail.sum()),
          f'{time.time() - t0:.0f}s', flush=True)

if 'scan' in sys.argv:
    T = 6; H = bb.spacetime(HZ, T)
    Lst = np.concatenate([np.tile(LZ, (1, T)), np.zeros((LZ.shape[0], m * T), dtype=np.uint8)], axis=1)
    j0 = 0
    nb = sorted(int(x) for x in set(np.nonzero(HZ[np.nonzero(HZ[:, j0])[0]].any(axis=0))[0]) - {j0})
    print('neighbours', len(nb), flush=True)
    cols = lambda j: [j + n * t for t in range(T)]
    shots = 10000
    for p, L, f, ret in [(0.01, 1, 1, 'u'), (0.01, 1, 5, 'u'), (0.01, 1, 20, 'u'), (0.01, 4, 4, 'u'), (0.01, 4, 4, 't'),
                         (0.01, 4, 16, 't'), (0.0125, 1, 1, 'u'), (0.0125, 4, 4, 't')]:
        pr = np.full(H.shape[1], p)
        for j in nb:
            pr[cols(j)] = min(0.5, p * L)
        pr[cols(j0)] = min(0.5, p * f)
        prior = np.full(H.shape[1], p)
        if ret == 't':
            for j in nb:
                prior[cols(j)] = min(0.5, p * L)
        pe = prior.copy(); pe[cols(j0)] = 0.5
        dk, de = bposd16.BPOSD(H, prior), bposd16.BPOSD(H, pe)
        rng = np.random.default_rng(99)
        e = (rng.random((shots, H.shape[1])) < pr).astype(np.uint8)
        s = ((e.astype(np.int32) @ H.T.astype(np.int32)) % 2).astype(np.uint8)
        lo = (e.astype(np.int32) @ Lst.T.astype(np.int32)) % 2
        t0 = time.time(); out = []
        for dec in (dk, de):
            est = np.concatenate([dec.decode_batch(s[i:i + 2000]) for i in range(0, shots, 2000)])
            out.append(int((((est.astype(np.int32) @ Lst.T.astype(np.int32)) % 2) != lo).any(axis=1).sum()))
        print(f'p {p} L {L} f {f} retain {ret}: keep {out[0]} erase {out[1]} ({time.time() - t0:.0f}s)', flush=True)
