"""Round-16 job queue (after dev15/m15/queue15.py).   python3 queue16.py <jobs file> <budget_minutes> <workers>
Run from qec2/dev16/.  Job lines:  name  est_seconds  requires(comma list or -)  command ...
A job is skipped if out16/done/<name> exists.  It starts only when its requirements are done and it is expected to
finish inside the budget (elapsed + 1.3 x est x r < budget), so a batch never cuts a job short.  r is the median of
(run time / estimate) over finished jobs with the same prefix (name up to the last '_'), within [0.5, 4], once two
have finished (else 1).  stdout/stderr -> out16/logs/<name>.{out,err}; exit 0 -> done marker holding the run time."""
import sys, os, time, subprocess, statistics, shlex

OUT = 'out16'


def prefix(n):
    return n.rsplit('_', 1)[0]


def done(n):
    return os.path.exists(f'{OUT}/done/{n}')


def ratios(jobs):
    r = {}
    for k in sorted(set(prefix(j['name']) for j in jobs)):
        xs = [float(open(f'{OUT}/done/{j["name"]}').read()) / j['est'] for j in jobs if prefix(j['name']) == k and done(j['name'])]
        r[k] = min(4.0, max(0.5, statistics.median(xs))) if len(xs) >= 2 else 1.0
    return r


def main():
    jf, budget, workers = sys.argv[1], float(sys.argv[2]) * 60, int(sys.argv[3])
    os.makedirs(f'{OUT}/done', exist_ok=True); os.makedirs(f'{OUT}/logs', exist_ok=True)
    jobs = []
    for line in open(jf):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        name, est, req, cmd = line.split(None, 3)
        jobs.append(dict(name=name, est=float(est), req=[] if req == '-' else req.split(','), cmd=cmd))
    t0 = time.time(); running = {}
    while True:
        for n, (p, ts) in list(running.items()):
            if p.poll() is not None:
                if p.returncode == 0:
                    open(f'{OUT}/done/{n}', 'w').write(f'{time.time() - ts:.1f}')
                print(f'{time.strftime("%H:%M:%S")} end {n} rc={p.returncode} {time.time() - ts:.0f}s', flush=True)
                del running[n]
        r = ratios(jobs)
        pending = [j for j in jobs if not done(j['name']) and j['name'] not in running]
        started = False
        for j in pending:
            if len(running) >= workers:
                break
            if not all(done(q) for q in j['req']):
                continue
            if time.time() - t0 + 1.3 * j['est'] * r[prefix(j['name'])] > budget:
                continue
            out = open(f'{OUT}/logs/{j["name"]}.out', 'a'); err = open(f'{OUT}/logs/{j["name"]}.err', 'a')
            running[j['name']] = (subprocess.Popen(shlex.split(j['cmd']), stdout=out, stderr=err), time.time())
            print(f'{time.strftime("%H:%M:%S")} start {j["name"]} est {j["est"] * r[prefix(j["name"])]:.0f}s', flush=True)
            started = True
        if not running and not started:
            left = [j['name'] for j in jobs if not done(j['name'])]
            print(f'stop: {len(left)} jobs left', flush=True)
            return
        time.sleep(10)


if __name__ == '__main__':
    main()
