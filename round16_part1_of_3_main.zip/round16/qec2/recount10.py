"""Independent recount of round-10 decision numbers straight from the raw files (no code shared with
analyse10.py / analyse8.py): totals, relative differences, paired-epoch z, per-seed differences and the seed
bootstrap behind every rule, plus the old gate on the same seeds.    python3 recount10.py > out10/recount10.json"""
import json, os, math
import numpy as np


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z['fails'][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b):
    if not all(os.path.exists(p) for p in paths):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    n = len(paths)
    pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
    st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
    return dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
                p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()],
                boot95=[round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)])


P = lambda t, r: [f'out10/{t}_s{x}.npz' for x in r]
T = dict(d9_realistic=range(6001, 6011), d9_mixed=range(6101, 6106), d9_severe=range(6201, 6204),
         d9_moderate=range(6301, 6306), pairs_mixed=range(6401, 6411), long_severe=range(6501, 6507),
         long_mixed=range(6601, 6607))
LIST = [('d9_realistic', 'sz_field', 'loc'), ('d9_mixed', 'sz_field', 'sz'), ('d9_mixed', 'sz_field', 'sz_all'),
        ('d9_severe', 'sz_field', 'sz'), ('d9_moderate', 'sz_field', 'sz'), ('pairs_mixed', 'sz_field', 'sz'),
        ('long_severe', 'sz_field', 'sz'), ('long_mixed', 'sz_field', 'sz'), ('long_mixed', 'sz_field', 'sz_all')]
LIST += [(t, 'sz_field', 'sz_gated') for t in T]
LIST += [('d9_realistic', 'sz_gated', 'loc'), ('d9_mixed', 'sz_gated', 'sz'), ('d9_mixed', 'sz_gated', 'sz_all'),
         ('d9_severe', 'sz_gated', 'sz'), ('d9_moderate', 'sz_gated', 'sz'), ('pairs_mixed', 'sz_gated', 'sz'),
         ('pairs_mixed', 'sz_field', 'sz_all'), ('pairs_mixed', 'sz_field', 'loc'), ('long_severe', 'sz_gated', 'sz'),
         ('long_mixed', 'sz_gated', 'sz'), ('long_mixed', 'sz_gated', 'sz_all')]
res = {}
for t, a, b in LIST:
    res[f'{t}: {a} vs {b}'] = pair(P(t, T[t]), a, b)
print(json.dumps(res, indent=1))
