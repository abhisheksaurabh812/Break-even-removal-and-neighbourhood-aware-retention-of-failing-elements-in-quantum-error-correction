"""Round 8, test 2a: keep/switch-out crossover for one bulk qubit, at any distance.
Independent of my per-qubit models: Stim sampling + PyMatching decoding from Stim's own detector error model.
  keep(f): original circuit with every channel touching the qubit scaled by f, decoded with its exact DEM
  excl:    the qubit switched out (deformed circuit, nominal noise), decoded with its exact DEM
Each shot is a d-round Z-memory experiment at SD6 circuit noise p.

python3 ideal_excl8.py <d> <kind: data|zanc> <p> <shots> <out.json>
Qubit: the bulk data qubit at the patch centre (d, d), or the bulk Z ancilla next to it (d-1, d-1).
Crossover rule (pre-registered, round 8): the first grid f with keep(f) >= excl; interpolate linearly in
(ln f, ln failures) between that f and the previous grid point; round to one decimal. No crossing up to
f = 100 -> crossover reported as '>100' and set to 100."""
import sys, os, json, time
import numpy as np
from ideal_excl import ler
import deform

F_GRID = (1, 2, 3, 5, 7, 10, 13, 20, 30, 50, 100)


def crossover(row):
    ex = row['excl']
    prev = None
    for f in F_GRID:
        k = row[f'keep_f{f}']
        if k >= ex:
            if prev is None:
                return float(f)
            f0, k0 = prev
            t = (np.log(ex) - np.log(k0)) / (np.log(k) - np.log(k0))
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 1)
        prev = (f, k)
    return 100.0


if __name__ == '__main__':
    d = int(sys.argv[1]); kind = sys.argv[2]; p = float(sys.argv[3]); shots = int(sys.argv[4]); out = sys.argv[5]
    c = (d, d) if kind == 'data' else (d - 1, d - 1)
    assert c in (deform.bulk_data(d) if kind == 'data' else deform.bulk_zanc(d))
    t0 = time.time()
    txt, _ = deform.circuit(d, d, p, excl=[c])
    fe, _ = ler(txt, shots)
    row = dict(excl=fe)
    print('excl', fe, round(time.time() - t0), flush=True)
    for f in F_GRID:
        txt, _ = deform.circuit(d, d, p, scale={c: f})
        fk, _ = ler(txt, shots)
        row[f'keep_f{f}'] = fk
        print(f, fk, round(time.time() - t0), flush=True)
    res = dict(d=d, kind=kind, qubit=list(c), p=p, shots=shots, rounds_per_shot=d, row=row,
               crossover=crossover(row), elapsed=round(time.time() - t0, 1))
    json.dump(res, open(out, 'w'), indent=1)
    print(json.dumps(res))
