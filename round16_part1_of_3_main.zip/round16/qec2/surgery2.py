"""
Circuit-level lattice-surgery test (v2): shared rate index vs model-based projection.

Changes from surgery.py (phenomenological screen):
  * circuit-level noise (SD6-style, Stim-validated rectangular generator), patches side by side
  * every error source is tagged by (qubit, channel type): 0 reset/measure flips, 1 one-qubit
    depolarisation (idle + H), 2 two-qubit depolarisation (CX, split half per qubit)
  * the TRUE noise is deliberately not of the form the model-based learner assumes:
      - static per-channel-type heterogeneity per qubit (sigma_ch)
      - static per-source jitter keyed by the physical channel (sigma_src)
      - drift per (qubit, channel type); defects hit the whole qubit or a single channel type
  * learners that keep entries (model-free, per decoding-graph edge type):
      sep-own, sep-clock (separate tables per configuration), shared (entry-copy index)
    learners that fit a physical model and project it onto any configuration's error model:
      model-q  (one rate factor per qubit), model-qt (one factor per qubit and channel type)
    hybrid-*: shared entry where that entry has been learned, model projection elsewhere
  * merge schedules: 'interleaved' (the same merged configuration recurs every k-th block) or
    'fresh' (each merge is a configuration never run before: before every merged epoch each arm
    forgets everything specific to the merged configuration and keeps only what a new
    configuration could inherit: patch-qubit information)
  * learners carry over statistics for entries that have not yet reached their sample minimum
Usage: python3 surgery2.py cfg.json out.npz key=json ...
"""
import sys, os, json, time, hashlib
from collections import OrderedDict
from types import SimpleNamespace
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize import lsq_linear
from statistics import NormalDist
from model import Model, P_REF, unroll, analyze, parse_dem, _split
from sampler import Sampler, weights_from_p, build_matching
from arms import prepare, Stats, pair_p
import surgery as S1
import rectgen

WMIN = 0.05
CTYPES = 3


# ------------------------------------------------------------------ channel-tagged circuit models
def filter_qt(lines, q, t):
    out = []
    for l in lines:
        name, arg, tg = _split(l)
        if name in ('DEPOLARIZE1', 'X_ERROR', 'Z_ERROR', 'Y_ERROR', 'DEPOLARIZE2'):
            if t == 0 and name == 'X_ERROR' and str(q) in tg:
                out.append(f'X_ERROR({arg}) {q}')
            elif t == 1 and name == 'DEPOLARIZE1' and str(q) in tg:
                out.append(f'DEPOLARIZE1({arg}) {q}')
            elif t == 2 and name == 'DEPOLARIZE2':
                v = list(map(int, tg)); pairs = [(a, b) for a, b in zip(v[0::2], v[1::2]) if a == q or b == q]
                if pairs:
                    out.append(f'DEPOLARIZE2({float(arg) / 2}) ' + ' '.join(f'{a} {b}' for a, b in pairs))
        else:
            out.append(l)
    return out


def build_model2(geo, name, T):
    W, x0 = geo['specs'][name]
    cache = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache', f'surg2_{name}_d{geo["d"]}_r{T}.npz')
    m = Model(); m.kind = 'circuit'; m.d = geo['d']; m.T = T
    if os.path.exists(cache):
        z = np.load(cache, allow_pickle=True)
        for k in z.files:
            setattr(m, k, z[k])
        m.K = int(m.K); m.nZ = int(m.nZ); m.T = int(m.T)
        return finish2(m, geo, name)
    lines = unroll(rectgen.circuit(W, geo['d'], T, P_REF, x0, row_len=geo['RL']))
    coords = {}
    for l in lines:
        if l.startswith('QUBIT_COORDS'):
            c = tuple(int(float(x)) for x in l[l.index('(') + 1:l.index(')')].split(','))
            coords[int(l.split()[-1])] = c
    _, dets = parse_dem(analyze(lines))
    zxy = {(int(c[0]), int(c[1])) for k, c in dets.items() if c[2] == 0}
    zdets = sorted(k for k, c in dets.items() if (int(c[0]), int(c[1])) in zxy)
    zmap = {k: i for i, k in enumerate(zdets)}
    nZ = len(zdets)
    danc = np.array([geo['ganc'][(int(dets[k][0]), int(dets[k][1]))] for k in zdets])
    dt = np.array([int(round(dets[k][2])) for k in zdets]); Tm = int(dt.max())
    dcls = np.where(dt == 0, 0, np.where(dt == Tm, 2, 1))
    src_p, src_g, src_t, src_obs, sdk, sdu, c_k, c_u, c_v, c_o = [], [], [], [], [], [], [], [], [], []
    K = 0; bad = 0
    for q in sorted(coords):
        gi = geo['gq'][coords[q]]
        for t in range(CTYPES):
            fl = filter_qt(lines, q, t)
            if not any(l.startswith(('X_ERROR', 'DEPOLARIZE')) for l in fl):
                continue
            errs, _ = parse_dem(analyze(fl))
            for p, comps in errs:
                zall = set(); obs = 0; zcomps = []
                for comp in comps:
                    zs = [zmap[int(x[1:])] for x in comp if x[0] == 'D' and int(x[1:]) in zmap]
                    lo = sum(1 for x in comp if x == 'L0') % 2
                    obs ^= lo
                    if zs:
                        zcomps.append((zs, lo))
                    for z in zs:
                        zall ^= {z}
                if not zall:
                    bad += int(obs); continue
                k = K; K += 1
                src_p.append(p); src_g.append(gi); src_t.append(t); src_obs.append(obs)
                for z in zall:
                    sdk.append(k); sdu.append(z)
                for zs, lo in zcomps:
                    if len(zs) > 2:
                        bad += 1; continue
                    zs = sorted(zs)
                    c_k.append(k); c_u.append(zs[0]); c_v.append(zs[1] if len(zs) == 2 else -1); c_o.append(lo)
    m.K, m.nZ, m.T = K, nZ, Tm
    m.p_ref = np.array(src_p); m.src_g = np.array(src_g); m.src_t = np.array(src_t)
    m.src_obs = np.array(src_obs, np.uint8)
    m.src_det_k = np.array(sdk); m.src_det_u = np.array(sdu)
    m.c_k, m.c_u, m.c_v, m.c_o = map(np.array, (c_k, c_u, c_v, c_o))
    m.danc, m.dt, m.dcls = danc, dt, dcls
    m.bad = bad
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    np.savez_compressed(cache, K=K, nZ=nZ, T=Tm, p_ref=m.p_ref, src_g=m.src_g, src_t=m.src_t, src_obs=m.src_obs,
                        src_det_k=m.src_det_k, src_det_u=m.src_det_u, c_k=m.c_k, c_u=m.c_u, c_v=m.c_v, c_o=m.c_o,
                        danc=danc, dt=dt, dcls=dcls, bad=bad)
    return finish2(m, geo, name)


def finish2(m, geo, name):
    m.dreg = np.zeros(m.nZ, int)
    m.qxy = np.zeros((geo['G'], 2)); m.G = geo['G']; m.center = np.zeros(2); m.lattice = 2.0
    m.finalize(); prepare(m)
    m.name = name
    sig = lambda k: (int(m.src_g[k]), int(m.src_t[k]), int(round(m.p_ref[k] / P_REF * 1e4)))
    srcsets = [set() for _ in range(m.E)]
    Cc = m.C.tocoo()
    for e, k in zip(Cc.row, Cc.col):
        srcsets[e].add(sig(k))
    au, av = m.danc[m.eu], np.where(m.ev >= 0, m.danc[np.maximum(m.ev, 0)], -1)
    dtt = np.where(m.ev >= 0, m.dt[np.maximum(m.ev, 0)] - m.dt[m.eu], 0)
    cu = m.dcls[m.eu]; cv = np.where(m.ev >= 0, m.dcls[np.maximum(m.ev, 0)], -1)
    m.type_key = [None] * m.ntype
    for e in range(m.E):
        k = (int(au[e]), int(av[e]), int(dtt[e]), int(cu[e]), int(cv[e]), tuple(sorted(srcsets[e])))
        t = m.etype[e]
        if m.type_key[t] is None:
            m.type_key[t] = k
        elif m.type_key[t] != k:
            m.type_key[t] = k[:5] + (tuple(sorted(set(m.type_key[t][5]) | set(k[5]))),)
    flip = {}
    for k_, u_ in zip(m.src_det_k, m.src_det_u):
        flip.setdefault(int(m.danc[u_]), set()).add(sig(k_))
    m.class_key = [(int(m.class_anc[c]), int(m.class_cls[c]), tuple(sorted(flip[int(m.class_anc[c])])))
                   for c in range(m.nclass)]
    # global detector ids of each source (for physical-channel keys)
    Tg = int(m.T) + 2
    gd = m.danc * Tg + m.dt
    m.src_dets = [[] for _ in range(m.K)]
    for k_, u_ in zip(m.src_det_k, m.src_det_u):
        m.src_dets[k_].append(int(gd[u_]))
    return m


# ------------------------------------------------------------------ truth (misspecified relative to the model learners)
def make_truth(mods, cfg):
    nd = NormalDist()
    sig = cfg.get('src_sigma', 0.25); seed = cfg['seed']
    for m in mods.values():
        j = np.empty(m.K)
        for k in range(m.K):
            key = f'{seed}|{int(m.src_g[k])}|{int(m.src_t[k])}|{sorted(m.src_dets[k])}|{int(m.src_obs[k])}'
            u = int(hashlib.md5(key.encode()).hexdigest()[:12], 16) / float(16 ** 12)
            j[k] = np.exp(sig * nd.inv_cdf(min(max(u, 1e-9), 1 - 1e-9)))
        m.p_true = m.p_ref * np.clip(j, 0.5, 2.0)
        m.src_g2 = m.src_g * CTYPES + m.src_t
        m.truth = SimpleNamespace(K=m.K, S=m.S, p_ref=m.p_true, src_g=m.src_g2, src_obs=m.src_obs)


def true_edge_p(m, f2):
    p = np.clip(m.p_true * f2[m.src_g2], 0, 0.45)
    return np.clip(-0.5 * np.expm1(m.C @ np.log1p(-2 * p)), 1e-7, 0.45)


def scenario2(G, cfg, rng, n_ep, er):
    G2 = G * CTYPES; t = (np.arange(n_ep) + 0.5) * er; tot = n_ep * er
    fq = np.exp(cfg['het_sigma'] * rng.standard_normal(G)); fq /= np.median(fq); fq = np.clip(fq, 0.25, 4.0)
    ch = np.clip(np.exp(cfg.get('ch_sigma', 0.3) * rng.standard_normal(G2)), 0.5, 2.0)
    F = np.tile((np.repeat(fq, CTYPES) * ch * cfg['p_base'] / P_REF).astype(np.float32), (n_ep, 1))
    flags = np.zeros(n_ep, np.uint8); events = []
    if cfg.get('drift_frac', 0) > 0:
        sel = rng.random(G2) < cfg['drift_frac']; fac = rng.uniform(1.0, cfg['drift_fac'], G2)
        F[:, sel] *= (fac[sel][None, :] ** (t / tot)[:, None]).astype(np.float32)
    t0 = 0.0
    while cfg.get('defects', True):
        t0 += rng.exponential(cfg['defect_gap'])
        if t0 > tot:
            break
        q = int(rng.integers(G)); fac = rng.uniform(*cfg['defect_fac']); dur = rng.uniform(*cfg['defect_dur'])
        groups = [q * CTYPES + c for c in range(CTYPES)] if rng.random() < 0.5 else [q * CTYPES + int(rng.integers(CTYPES))]
        on = (t >= t0) & (t < t0 + dur)
        F[np.ix_(on, groups)] *= fac; flags[on] |= 4
        events.append([float(t0), float(dur), q, float(fac), groups])
    return F, flags, events


# ------------------------------------------------------------------ entry learner with carry-over and reset support
class EntryLearner(S1.Learner):
    def __init__(self, models, ns, R, minN=None, **kw):
        super().__init__(models, ns, R, **kw)
        if minN is not None:
            self.minN = minN
        self.seen = np.zeros(len(self.p), bool)
        self.ver = 0

    def _carry(self, okp, okq):
        for m in self.models:
            st = self.st[m.name]; g = self.tmap[m.name]; gc = self.cmap[m.name]
            keep_e = ~okp[g[m.etype[m.nb_idx]]]
            keep_d = ~okq[gc[m.dclass]]
            for arr in (st.sa, st.sb, st.sab, st.sn):
                arr[~keep_e] = 0
            st.dn[~keep_d] = 0; st.dN[~keep_d] = 0

    def refresh(self, minN=None):
        pw, qw, okp, okq = self.window(minN)
        a = self.alpha
        self.p[okp] += a * (pw[okp] - self.p[okp]); self.q[okq] += a * (qw[okq] - self.q[okq])
        self.p = np.clip(self.p, 1e-6, 0.45)
        self.seen |= okp
        self._carry(okp & self.nb_type, okq)
        self.ver += 1

    def reset_entries(self, tmask, cmask, ref):
        self.p[tmask] = ref.p[tmask]; self.q[cmask] = ref.q[cmask]; self.seen[tmask] = False
        self.ver += 1
        for m in self.models:
            st = self.st[m.name]; g = self.tmap[m.name]; gc = self.cmap[m.name]
            ze = tmask[g[m.etype[m.nb_idx]]]; zd = cmask[gc[m.dclass]]
            for arr in (st.sa, st.sb, st.sab, st.sn):
                arr[ze] = 0
            st.dn[zd] = 0; st.dN[zd] = 0


# ------------------------------------------------------------------ model-based learner (fit physical factors, project)
class ModelLearner:
    """Fits one rate factor per group (qubit, or qubit x channel type) to the pooled syndrome
    statistics of every configuration it is given, then builds any configuration's edge
    probabilities from that configuration's own error model (structure only, nominal p_ref)."""
    def __init__(self, models, G, R, per_type=False, alpha=0.5, minfrac=0.25, prior_rel=0.5):
        self.models = models; self.per_type = per_type
        self.ng = G * CTYPES if per_type else G
        self.R = R; self.T = models[0].T; self.minN = minfrac * R / self.T; self.alpha = alpha
        self.prior_rel = prior_rel
        self.st = {m.name: Stats(m) for m in models}
        self.f = np.ones(self.ng)
        self.ver = 0
        self.D = {}
        for m in models:
            grp = self.grp(m)
            P = csr_matrix((m.p_ref, (np.arange(m.K), grp)), shape=(m.K, self.ng))
            Aedge = (m.C @ P).tocsr()                             # E x ng, lambda-space contributions
            nbt = m.etype[m.nb_idx]
            cnt = np.bincount(nbt, minlength=m.ntype).astype(float)
            Tm = csr_matrix((1.0 / np.maximum(cnt[nbt], 1), (nbt, m.nb_idx)), shape=(m.ntype, m.E))
            Atype = (Tm @ Aedge).tocsr()
            Bdet = (m.Dm @ P).tocsr()                             # nZ x ng
            ccnt = np.bincount(m.dclass, minlength=m.nclass).astype(float)
            Cm = csr_matrix((1.0 / ccnt[m.dclass], (m.dclass, np.arange(m.nZ))), shape=(m.nclass, m.nZ))
            Bclass = (Cm @ Bdet).tocsr()
            self.D[m.name] = (Atype, Bclass, cnt > 0)

    def grp(self, m):
        return m.src_g * CTYPES + m.src_t if self.per_type else m.src_g

    def add(self, m, X):
        self.st[m.name].add(X)

    def groups_of(self, m):
        return np.unique(self.grp(m))

    def _fit(self, minN, f_prev, prior_rel):
        rows, ys = [], []
        used_e, used_d = {}, {}
        for m in self.models:
            st = self.st[m.name]; Atype, Bclass, isnb = self.D[m.name]
            t_nb = m.etype[m.nb_idx]
            Sa = np.bincount(t_nb, st.sa, m.ntype); Sb = np.bincount(t_nb, st.sb, m.ntype)
            Sab = np.bincount(t_nb, st.sab, m.ntype); Sn = np.bincount(t_nb, st.sn, m.ntype)
            Snn = np.maximum(Sn, 1)
            pt = np.clip(pair_p(Sa / Snn, Sb / Snn, Sab / Snn), 1e-6, 0.45)
            okt = isnb & (Sn >= minN)
            w = np.sqrt(Sn[okt] / np.maximum(pt[okt], 1e-4))
            rows.append(Atype[okt].multiply(w[:, None]).tocsr()); ys.append(w * (-0.5 * np.log1p(-2 * pt[okt])))
            Dn = np.bincount(m.dclass, st.dn, m.nclass); DN = np.bincount(m.dclass, st.dN, m.nclass)
            okc = DN >= minN
            qc = np.clip(Dn[okc] / np.maximum(DN[okc], 1), 1e-6, 0.45)
            wc = np.sqrt(DN[okc] / np.maximum(qc, 1e-4))
            rows.append(Bclass[okc].multiply(wc[:, None]).tocsr()); ys.append(wc * (-0.5 * np.log1p(-2 * qc)))
            used_e[m.name] = okt; used_d[m.name] = okc
        from scipy.sparse import vstack, identity
        A = vstack(rows).tocsc(); y = np.concatenate(ys)
        info = np.asarray(abs(A).sum(0)).ravel() > 0
        # weak prior toward the previous estimate (identifies combinations the data cannot separate)
        wp = 1.0 / (prior_rel * np.maximum(f_prev, 1e-3))
        Ap = identity(self.ng, format='csc').multiply(wp[:, None]).tocsc()
        A2 = vstack([A, Ap]).tocsc(); y2 = np.concatenate([y, wp * f_prev])
        sol = lsq_linear(A2, y2, bounds=(0.01, 500.0), method='trf', lsmr_tol='auto', max_iter=200)
        return sol.x, info, used_e, used_d

    def calibrate(self, f0):
        f, info, _, _ = self._fit(10, f0, 2.0)
        self.f = np.where(info, f, f0)
        for st in self.st.values():
            st.reset()

    def refresh(self, minN=None):
        minN = self.minN if minN is None else minN
        f, info, used_e, used_d = self._fit(minN, self.f, self.prior_rel)
        self.f[info] += self.alpha * (f[info] - self.f[info])
        self.ver += 1
        for m in self.models:            # carry over statistics that were not used
            st = self.st[m.name]; okt = used_e[m.name]; okc = used_d[m.name]
            ze = okt[m.etype[m.nb_idx]]; zd = okc[m.dclass]
            for arr in (st.sa, st.sb, st.sab, st.sn):
                arr[ze] = 0
            st.dn[zd] = 0; st.dN[zd] = 0

    def edge_p(self, m):
        p = np.clip(m.p_ref * self.f[self.grp(m)], 0, 0.45)
        return np.clip(-0.5 * np.expm1(m.C @ np.log1p(-2 * p)), 1e-6, 0.45)


# ------------------------------------------------------------------ run
def run(cfg, out):
    d, T, bpe, k = cfg['d'], cfg['d'], cfg['bpe'], cfg['merge_every']
    mode = cfg.get('schedule', 'interleaved')
    geo = S1.geometry_circuit(d)
    mods = {n: build_model2(geo, n, T) for n in 'ABM'}
    A, B, M = mods['A'], mods['B'], mods['M']
    make_truth(mods, cfg)
    G = geo['G']
    nm = bpe // k; nu = bpe - nm
    assert nm >= 1 and nm * k == bpe
    er = bpe * T; n_ep = cfg['total_rounds'] // er
    F2, flags, events = scenario2(G, cfg, np.random.default_rng(cfg['seed']), n_ep, er)
    R = cfg['R']
    names = cfg['arms']
    # ---- calibration run at t = 0 (separate stream); every learner starts from the same calibration
    rc = np.random.default_rng(cfg['seed'] + 77777)
    nb_cal = cfg.get('cal_rounds', 1_000_000) // T
    cal = {'U': EntryLearner([A, B], 'U', R), 'M': EntryLearner([M], 'M', R), 'S': EntryLearner([A, B, M], 'S', R)}
    calm = {'q': ModelLearner([A, B, M], G, R, False), 'qt': ModelLearner([A, B, M], G, R, True)}
    for m in (A, B, M):
        smp = Sampler(m.truth, rc)
        for _ in range(0, nb_cal, 5000):
            X, _ = smp.sample(F2[:1].astype(np.float64), 5000)
            for L in list(cal.values()) + list(calm.values()):
                if m in L.models:
                    L.add(m, X)
    for L in cal.values():
        L.calibrate()
    nominal = cfg['p_base'] / P_REF
    calm['q'].calibrate(np.full(G, nominal)); calm['qt'].calibrate(np.full(G * CTYPES, nominal))
    # ---- learners
    L = {}
    def get(kind):
        if kind in L:
            return L[kind]
        if kind in ('sep-own', 'sep-clock'):
            lu = EntryLearner([A, B], 'U', R); lu.init_from(cal['U'])
            lm = EntryLearner([M], 'M', R, minN=(cfg.get('clock_minN', 200) if kind == 'sep-clock' else None)); lm.init_from(cal['M'])
            L[kind] = (lu, lm)
        elif kind == 'shared':
            ls = EntryLearner([A, B, M], 'S', R); ls.init_from(cal['S']); ls.seen[:] = True; L[kind] = ls
        elif kind in ('model-q', 'model-qt'):
            pt = kind.endswith('qt'); ml = ModelLearner([A, B, M], G, R, pt); ml.f = calm['qt' if pt else 'q'].f.copy()
            L[kind] = ml
        return L[kind]
    for n in names:
        if n in ('sep-own', 'sep-clock', 'shared', 'model-q', 'model-qt'):
            get(n)
        elif n.startswith('hybrid-'):
            get('shared'); get('model-' + n.split('-')[1])
    # masks of what is specific to the merged configuration
    S = L.get('shared') or cal['S']
    tA = set(S.tmap['A'].tolist()) | set(S.tmap['B'].tolist()); cA = set(S.cmap['A'].tolist()) | set(S.cmap['B'].tolist())
    seam_t = np.array([i not in tA for i in range(len(S.p))]); seam_c = np.array([i not in cA for i in range(len(S.q))])
    gAB = set(A.src_g.tolist()) | set(B.src_g.tolist())
    seam_q = np.array(sorted(set(M.src_g.tolist()) - gAB))
    seam_qt = (seam_q[:, None] * CTYPES + np.arange(CTYPES)[None, :]).ravel()
    # device-calibration projection: what a configuration that has never run gets in standard practice
    # (per-qubit calibration at t = 0 pushed through that configuration's own error model)
    proj = calm[cfg.get('proj', 'qt')]

    def entries_from_projection(EL, ml):
        num = np.zeros(len(EL.p)); cnt = np.zeros(len(EL.p)); numc = np.zeros(len(EL.q)); cntc = np.zeros(len(EL.q))
        for m in EL.models:
            g = EL.tmap[m.name][m.etype]
            np.add.at(num, g, ml.edge_p(m)); np.add.at(cnt, g, 1)
            ps = np.clip(m.p_ref * ml.f[ml.grp(m)], 0, 0.45)
            qd = -0.5 * np.expm1(m.Dm @ np.log1p(-2 * ps))
            gc = EL.cmap[m.name][m.dclass]
            np.add.at(numc, gc, qd); np.add.at(cntc, gc, 1)
        return SimpleNamespace(p=num / np.maximum(cnt, 1), q=numc / np.maximum(cntc, 1))
    refS = entries_from_projection(S, proj)
    refM = entries_from_projection(cal['M'], proj)

    def forget_merged():
        for n, obj in L.items():
            if n in ('sep-own', 'sep-clock'):
                lm = obj[1]
                lm.p[:] = refM.p; lm.q[:] = refM.q; lm.ver += 1
                for st in lm.st.values():
                    st.reset()
            elif n == 'shared':
                obj.reset_entries(seam_t, seam_c, refS)
            elif n == 'model-q':
                if not np.array_equal(obj.f[seam_q], calm['q'].f[seam_q]):
                    obj.f[seam_q] = calm['q'].f[seam_q]; obj.ver += 1
            elif n == 'model-qt':
                if not np.array_equal(obj.f[seam_qt], calm['qt'].f[seam_qt]):
                    obj.f[seam_qt] = calm['qt'].f[seam_qt]; obj.ver += 1

    pcache = {}
    def vers(n):
        if n in ('sep-own', 'sep-clock'):
            return (L[n][0].ver, L[n][1].ver)
        if n.startswith('hybrid-'):
            return (L['shared'].ver, L['model-' + n.split('-')[1]].ver)
        if n in L:
            return (L[n].ver,)
        return (0,)

    def probs(n, m, f2):
        if n == 'oracle':
            return true_edge_p(m, f2)
        key = (n, m.name); v = vers(n)
        hit = pcache.get(key)
        if hit is not None and hit[0] == v:
            return hit[1]
        p = probs_(n, m, f2)
        pcache[key] = (v, p)
        return p

    def probs_(n, m, f2):
        if n == 'static-est':                     # empirical calibration; a never-run merge gets the projection
            if m.name == 'M' and mode == 'fresh':
                return proj.edge_p(m)
            return (cal['U'] if m.name in 'AB' else cal['M']).edge_p(m)
        if n == 'static-model':                   # device-calibration projection everywhere
            return proj.edge_p(m)
        if n == 'oracle':
            return true_edge_p(m, f2)
        if n in ('sep-own', 'sep-clock'):
            lu, lm = L[n]
            return (lu if m.name in 'AB' else lm).edge_p(m)
        if n == 'shared':
            return L['shared'].edge_p(m)
        if n in ('model-q', 'model-qt'):
            return L[n].edge_p(m)
        if n.startswith('hybrid-'):
            sh = L['shared']; ml = L['model-' + n.split('-')[1]]
            seen = sh.seen[sh.tmap[m.name][m.etype]]
            return np.where(seen, sh.edge_p(m), ml.edge_p(m))
        raise ValueError(n)

    smp = {n: Sampler(mods[n].truth, np.random.default_rng(cfg['seed'] + 99991 + 17 * i)) for i, n in enumerate('ABM')}
    failU = np.zeros((len(names), n_ep, nu), np.uint8); failM = np.zeros((len(names), n_ep, nm), np.uint8)
    werrM = np.zeros((len(names), n_ep), np.float32)
    cache = OrderedDict(); builds = 0; decodes = 0
    rounds_u = rounds_m = rounds_wall = 0
    chunk = cfg.get('chunk', 50)
    t_start = time.time()

    def decode(m, w, X, preds):
        nonlocal builds, decodes
        w = np.round(w, 3)
        key = (m.name, hashlib.md5(w.tobytes()).digest())
        if key in preds:
            return preds[key]
        mt = cache.get(key)
        if mt is None:
            mt = build_matching(m, w); builds += 1; cache[key] = mt
            if len(cache) > 400:
                cache.popitem(last=False)
        else:
            cache.move_to_end(key)
        pr = mt.decode_batch(X)[:, 0]; decodes += 1
        preds[key] = pr
        return pr

    for cs in range(0, n_ep, chunk):
        ce = min(n_ep, cs + chunk)
        Fc = F2[cs:ce].astype(np.float64)
        XA, oA = smp['A'].sample(Fc, nu); XB, oB = smp['B'].sample(Fc, nu); XM, oM = smp['M'].sample(Fc, nm)
        for e in range(cs, ce):
            i0 = e - cs
            xa, xb, xm = XA[i0 * nu:(i0 + 1) * nu], XB[i0 * nu:(i0 + 1) * nu], XM[i0 * nm:(i0 + 1) * nm]
            ya, yb, ym = oA[i0 * nu:(i0 + 1) * nu], oB[i0 * nu:(i0 + 1) * nu], oM[i0 * nm:(i0 + 1) * nm]
            f2 = F2[e].astype(np.float64)
            if mode == 'fresh':
                forget_merged()
            preds = {}
            ltM = np.log(true_edge_p(M, f2))
            for i, n in enumerate(names):
                pa, pb, pm = probs(n, A, f2), probs(n, B, f2), probs(n, M, f2)
                fa = decode(A, weights_from_p(pa, WMIN), xa, preds) ^ ya
                fb = decode(B, weights_from_p(pb, WMIN), xb, preds) ^ yb
                failU[i, e] = fa | fb
                failM[i, e] = decode(M, weights_from_p(pm, WMIN), xm, preds) ^ ym
                werrM[i, e] = np.mean(np.abs(np.log(np.clip(pm, 1e-7, 0.45)) - ltM))
            rounds_u += nu * T; rounds_m += nm * T; rounds_wall += bpe * T
            for n, obj in L.items():
                if isinstance(obj, tuple):
                    obj[0].add(A, xa); obj[0].add(B, xb); obj[1].add(M, xm)
                else:
                    obj.add(A, xa); obj.add(B, xb); obj.add(M, xm)
            if 'sep-own' in L:
                lu, lm = L['sep-own']
                if rounds_u >= R:
                    lu.refresh()
                if rounds_m >= R:
                    lm.refresh()
            if rounds_u >= R:
                rounds_u = 0
            if rounds_m >= R:
                rounds_m = 0
            if rounds_wall >= R:
                rounds_wall = 0
                if 'sep-clock' in L:
                    lu, lm = L['sep-clock']; lu.refresh(); lm.refresh()
                for n in ('shared', 'model-q', 'model-qt'):
                    if n in L:
                        L[n].refresh()
        if cfg.get('verbose'):
            print(f'{ce}/{n_ep} {time.time() - t_start:.0f}s builds={builds} decodes={decodes}', file=sys.stderr, flush=True)
    np.savez_compressed(out, failU=failU, failM=failM, werrM=werrM, flags=flags, names=np.array(names),
                        cfg=json.dumps(cfg), events=json.dumps(events))
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t_start, 1), builds=builds, decodes=decodes,
                          merged_blocks=int(n_ep * nm), unmerged_blocks=int(n_ep * nu),
                          failM=dict(zip(names, failM.reshape(len(names), -1).sum(1).tolist())),
                          failU=dict(zip(names, failU.reshape(len(names), -1).sum(1).tolist())),
                          werrM=dict(zip(names, np.round(werrM.mean(1), 4).tolist())),
                          n_defects=len(events), seam_entries=int(seam_t.sum()), seam_classes=int(seam_c.sum()),
                          seam_qubits=int(len(seam_q)))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
