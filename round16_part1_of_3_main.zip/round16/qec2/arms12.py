"""
Round 12: the watch on the hole (arms11.PolicyArmFieldWatch, mode 'return', learner Sized5), with two changes to its
returns.  Round 11 (d9_mixed and d9_severe, 15 runs) made 474 watch returns: in 77% the same qubit was switched out again
within two hold periods, and only 36% were followed by the learner naming any new qubit during the hold.  Each return
also wiped the twin's notes on the returned qubit (Sized4.resume clears its window and pins it; at the end of the pin
its size restarts at 1).

PolicyArmFieldWatch2 changes only what happens around a watch return:
 1. No second look at the same signal (watch['once']).  When a qubit that the watch brought back is switched out again
    and, during the time it was back, the learner named no new qubit with at least a quarter of its interior detection
    share on the ancillas whose alarm caused the return's zone, the return is counted as fruitless.  For the new hole the
    watch then first measures, for `learn` epochs, each changed ancilla's count against its expected count, and from
    then on expects max(1, measured ratio) times the model value: it alarms only when the zone gets worse than it was.
    The flag ends when that qubit is put back by its probe; a later return is judged afresh.
 2. A light return (watch['light']).  The returned qubit's size is set from the probe reading (as before) but its
    learner window, its evidence and the localizer's alarms around it are kept: no reset_local, no Sized4 pin, no
    restart of its size at 1.  It is held in for `hold` epochs by the policy (no switch-out of it), after which the gate
    decides on its current size as for any qubit.  A probe reading below the learner's r_off ends its override.
With both off, the arm behaves exactly as arms11.PolicyArmFieldWatch in mode 'return'.

Sized6 (learner option, tested as a separate gate): Sized5 plus a re-check of stuck alarms.  The twin's per-ancilla
monitor classifies an alarm once (footprint test, naming); if that does not end in a handled qubit (the excess looked
spread out, the naming fell short, or the size fit was rejected), the ancilla stays classified for as long as its alarm
lasts and nothing more happens.  Round 11, d9_mixed seed 7109: a Z ancilla failing at 63x was judged 'spread' and went
unnamed for about 130,000 rounds.  Sized6: an ancilla whose alarm is still up `recheck` epochs after its last
classification, that is not hidden by a reshaped circuit, and on which no handled qubit has its main footprint (share
>= 0.2), collects fresh evidence and is classified again.
"""
import numpy as np
import deform
from arms import Stats
from arms7 import qround
from arms11 import PolicyArmFieldWatch, Sized5


class Sized6(Sized5):
    kind = 'sized6'

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.K = int(self.sz.get('recheck', 50))
        self.s2 = {}                   # ancilla -> learner epoch of its last classification
        self.n_recheck = 0

    def update(self, X, crr, mask=None):
        prev = self.astate.copy() if getattr(self, 'ac', None) else None
        super().update(X, crr, mask)
        if prev is None:
            return
        m = self.m
        for a in np.nonzero((prev != 2) & (self.astate == 2))[0]:
            self.s2[int(a)] = self.ep_i
        for a in list(self.s2):
            if self.astate[a] != 2:
                del self.s2[a]; continue
            if self.ep_i - self.s2[a] < self.K or self.aal[a] == 0:
                continue
            if mask is not None and bool(mask['anc_off'][a]):
                continue
            if any(bool(m.fp_supp[g, a]) for g, o in self.sovr.items() if not o['susp']):
                continue
            self.astate[a] = 1; self.aacc[a] = 0; self.aE[a] = 0
            self.astats[int(a)] = Stats(m)
            del self.s2[a]; self.n_recheck += 1
            self.slog.append(['recheck', self.ep_i, int(a)])

    def info(self):
        d = super().info(); d['sized']['rechecks'] = self.n_recheck
        return d


class PolicyArmFieldWatch2(PolicyArmFieldWatch):
    kind = 'policy'

    def __init__(self, *a, watch=None, **k):
        super().__init__(*a, watch=watch, **k)
        w = dict(watch or {})
        assert self.w_mode == 'return'
        self.w_once = bool(w.get('once', True))
        self.w_light = bool(w.get('light', True))
        self.w_learn = int(w.get('learn', 20))
        self.wait = {}                 # qubit -> epoch before which the gate may not switch it out (light return)
        self.pend = {}                 # qubit -> what the zone looked like when the watch brought it back
        self.rebase = set()            # qubits whose current hole uses a learned zone level
        self.zb = None                 # learned zone level for the current configuration
        self.n_fruitless = 0; self.n_fruitful = 0; self.n_rebase = 0

    # ------------------------------------------------------------ watch
    def _watch(self, X, md, epoch, ftrue):
        ancs, groups = self.zone(md)[:2]
        if not len(ancs):
            return
        if self.zkey != md.name or self.S is None:
            self.zkey = md.name; self.S = np.zeros(len(ancs)); self.zb = None
        v = self.view()
        q = md.det_rate(v)
        xs = X.sum(0).astype(float); B = X.shape[0]
        n = np.array([xs[i].sum() for i in groups]); E = np.array([q[i].sum() for i in groups]) * B
        if self.w_once and any(st['g'] in self.rebase for st in self.cur.values()):
            if self.zb is None:
                self.zb = dict(n=np.zeros(len(ancs)), E=np.zeros(len(ancs)), k=0, ratio=None)
            zb = self.zb
            if zb['ratio'] is None:
                zb['n'] += n; zb['E'] += E; zb['k'] += 1
                if zb['k'] >= self.w_learn:
                    zb['ratio'] = np.maximum(1.0, zb['n'] / np.maximum(zb['E'], 1e-9))
                    self.n_rebase += 1
                    self.log.append(['zlevel', epoch, md.name, round(float(zb['ratio'].max()), 2)])
                self.S = np.zeros(len(ancs))
                return
            E = E * zb['ratio']
        self.S = np.maximum(0.0, self.S + n * np.log(self.w_rho) - (self.w_rho - 1) * E)
        hit = np.nonzero(self.S >= self.w_h)[0]
        if not len(hit):
            return
        j = int(hit[np.argmax(self.S[hit])]); b = int(ancs[j]); sj = float(self.S[j])
        pos = np.array(self.base.zanc[b], float)
        c = min(self.cur, key=lambda cc: float(((np.array(cc, float) - pos) ** 2).sum()))
        st = self.cur.pop(c); g = st['g']
        f_true = float(ftrue[g]) / self.fnom
        fp = f_true * float(np.exp(self.probe['sigma'] * self.rng.standard_normal()))
        inn = self.inner
        if self.w_light:
            o = inn.sovr.get(g)
            if o is not None:
                rp = fp / self.fcal_abs[g]
                if rp < inn.r_off:
                    inn.deactivate(g, 'probe_quiet')
                else:
                    o['susp'] = False; o['r'] = qround(rp)
                    inn.slog.append(['wret', inn.ep_i, int(g), round(rp, 2)])
            self.wait[g] = epoch + self.w_hold
        else:
            inn.reset_local(g)
            inn.resume(g, fp / self.fcal_abs[g])
            o = inn.sovr.get(g)
            if o is not None:
                o['cool'] = float(self.w_hold * B * self.base.T)
        self.pend[g] = dict(ep=inn.ep_i, ancs=np.array(ancs, int))
        self.rebase.discard(g)
        self.n_watch += 1
        self.log.append(['in', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), b, round(sj, 1), 'watch'])
        self.S = None; self.zkey = None; self.zb = None

    def _fruitful(self, p):
        """Did the learner name a new qubit with >= 1/4 of its interior detection share on the returned zone?"""
        for l in self.inner.slog:
            if l[0] == 'on' and l[1] >= p['ep'] and float(self.Wn[int(l[2])][p['ancs']].sum()) >= 0.25:
                return True
        return False

    # ------------------------------------------------------------ policy (arms9.PolicyArmField.update plus the wait check)
    def _policy(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        m = self.base; inn = self.inner
        if md is None:
            Xo = X; off = None
            inn.update(X, crr)
        else:
            Xo = to_base(X, md, m); off = md.mask['anc_off']
            crr_o = (Xo.astype(np.float32) @ base_AggD).reshape(-1, 4).astype(np.float64)
            inn.update(Xo, crr_o, md.mask)
        n = (Xo.astype(np.float32) @ m.A_int).sum(0).astype(float)
        N = Xo.shape[0] * inn.nint
        if off is not None:
            n = np.where(off, 0.0, n); N = np.where(off, 0.0, N)
        self.win.append((n, N))
        self.rounds += X.shape[0] * T
        for g, o in sorted(inn.sovr.items(), key=lambda kv: -kv[1]['r']):
            if o['susp'] or o.get('cool', 0) > 0 or g not in m.excludable:
                continue
            if self.wait.get(g, -1) > epoch:
                continue
            kind, c = m.excludable[g]
            if c in self.cur or len(self.cur) >= 2 or not deform.compatible(list(self.cur) + [c], m.d):
                continue
            L = self.level(g); thr = self.fstar(kind, L)
            r_use = o['r']
            if self.resize:
                r_use = self.size_local(g, o, L)
                if r_use is None:
                    continue
            fabs = r_use * self.fcal_abs[g]
            if fabs < thr:
                continue
            self.cur[c] = dict(g=g, kind=kind, start=self.rounds, next=epoch + self.probe['period'])
            inn.suspend(g)
            inn.reset_local(g)
            self.log.append(['out', epoch, list(c), int(g), round(o['r'], 2), round(fabs, 2), round(L, 2),
                             round(thr, 2), round(r_use, 2)])
        for c in list(self.cur):
            st = self.cur[c]; g = st['g']
            if epoch < st['next']:
                continue
            f_true = float(ftrue[g]) / self.fnom
            fp = f_true * float(np.exp(self.probe['sigma'] * self.rng.standard_normal()))
            L = self.level(g); thr_in = self.fstar(st['kind'], L) / 1.5
            if fp < thr_in:
                del self.cur[c]
                inn.reset_local(g)
                inn.resume(g, fp / self.fcal_abs[g])
                self.rebase.discard(g); self.pend.pop(g, None)
                self.log.append(['in', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), round(L, 2),
                                 round(thr_in, 2)])
            else:
                st['next'] = epoch + self.probe['period']
                self.log.append(['probe', epoch, list(c), int(g), round(fp, 2), round(f_true, 2), round(L, 2),
                                 round(thr_in, 2)])

    def update(self, X, crr, md, base_AggD, epoch, T, ftrue, to_base):
        if md is not None and self.w_watch and self.cur:
            self._watch(X, md, epoch, ftrue)
        before = set(self.cur)
        self._policy(X, crr, md, base_AggD, epoch, T, ftrue, to_base)
        for c in set(self.cur) - before:                       # switched out this epoch
            g = self.cur[c]['g']
            p = self.pend.pop(g, None)
            if p is not None and self.w_once:
                if self._fruitful(p):
                    self.n_fruitful += 1
                else:
                    self.n_fruitless += 1; self.rebase.add(g)
                    self.log.append(['fruitless', epoch, list(c), int(g)])
        self._view = self.view() if self.cur else None

    def info(self):
        d = super().info()
        d.update(fruitless_returns=self.n_fruitless, fruitful_returns=self.n_fruitful, zone_levels_learned=self.n_rebase)
        return d
