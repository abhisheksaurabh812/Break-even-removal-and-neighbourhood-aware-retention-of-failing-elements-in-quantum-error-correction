"""
Shared-rates re-test with real headroom (circuit level).  Usage: python3 surgery3.py cfg.json out.npz key=json ...

Differences from surgery2.py:
  * high-dynamics noise (whole-qubit drift and defects, defect gap 75k) so that perfect knowledge has room
  * the learning stream follows the merge schedule (a merged block every `merge_every` blocks), and every
    epoch also decodes `probes` extra merged blocks that NO learner sees: they measure "how well would a
    merge at this moment be decoded", which gives statistical power at rare merge rates
  * arms: static-est, static-shared (calibrated entries reused, no learning), oracle, sep-own, sep-clock,
    shared (entry-copy index keyed by mechanism signature), shared-ratio (shared + for merged entries whose
    mechanism mix differs from a same-position patch entry, the patch entry's learned drift ratio is carried
    over onto the merged entry's calibration value)
  * fresh schedule: before every epoch's merged blocks, configuration-specific knowledge is reset to the
    device-calibration projection (as in surgery2)
"""
import sys, os, json, time, hashlib
from collections import OrderedDict
from types import SimpleNamespace
import numpy as np
from model import P_REF
from sampler import Sampler, weights_from_p, build_matching
import surgery as S1
from surgery2 import build_model2, make_truth, true_edge_p, EntryLearner, ModelLearner, CTYPES
from surgery2x import scenario2

WMIN = 0.05


class RatioLearner(EntryLearner):
    """Entry-copy shared index + drift-ratio transfer onto merged entries whose mechanism set differs from
    a same-position patch entry (a few extra seam gates)."""
    def setup_ratio(self, A, B, M, base_t, base_c):
        posT, posC = {}, {}
        for m in (A, B):
            for t, k in enumerate(m.type_key):
                posT[k[:5]] = self.tmap[m.name][t]
            for c, k in enumerate(m.class_key):
                posC[k[:2]] = self.cmap[m.name][c]
        tAB = set(self.tmap['A'].tolist()) | set(self.tmap['B'].tolist())
        cAB = set(self.cmap['A'].tolist()) | set(self.cmap['B'].tolist())
        self.rT = {}; self.rC = {}
        for t, k in enumerate(M.type_key):
            g = self.tmap['M'][t]
            if g not in tAB and k[:5] in posT:
                self.rT[g] = posT[k[:5]]
        for c, k in enumerate(M.class_key):
            g = self.cmap['M'][c]
            if g not in cAB and k[:2] in posC:
                self.rC[g] = posC[k[:2]]
        self.ti = np.array(list(self.rT.keys()), int); self.tp = np.array(list(self.rT.values()), int)
        self.ci = np.array(list(self.rC.keys()), int); self.cp = np.array(list(self.rC.values()), int)
        self.p_cal = self.p.copy(); self.q_cal = self.q.copy()
        self.set_base(base_t, base_c)

    def set_base(self, base_t, base_c):
        self.bt = base_t[self.ti].copy(); self.bc = base_c[self.ci].copy()

    def transfer(self):
        if len(self.ti):
            r = np.clip(self.p[self.tp] / np.maximum(self.p_cal[self.tp], 1e-9), 0.25, 20.0)
            self.p[self.ti] = np.clip(self.bt * r, 1e-6, 0.45)
        if len(self.ci):
            r = np.clip(self.q[self.cp] / np.maximum(self.q_cal[self.cp], 1e-9), 0.25, 20.0)
            self.q[self.ci] = np.clip(self.bc * r, 1e-6, 0.5)
        self.ver += 1

    def refresh(self, minN=None):
        super().refresh(minN)
        self.transfer()


def run(cfg, out):
    d, T, bpe, k = cfg['d'], cfg['d'], cfg['bpe'], cfg['merge_every']
    P = cfg.get('probes', 4); mode = cfg.get('schedule', 'interleaved')
    geo = S1.geometry_circuit(d)
    mods = {n: build_model2(geo, n, T) for n in 'ABM'}
    A, B, M = mods['A'], mods['B'], mods['M']
    make_truth(mods, cfg)
    G = geo['G']
    er = bpe * T; n_ep = cfg['total_rounds'] // er
    F2, flags, events = scenario2(G, cfg, np.random.default_rng(cfg['seed']), n_ep, er)
    R = cfg['R']; names = cfg['arms']
    # ---- calibration at t = 0 (separate stream)
    rc = np.random.default_rng(cfg['seed'] + 77777)
    nb_cal = cfg.get('cal_rounds', 1_000_000) // T
    cal = {'U': EntryLearner([A, B], 'U', R), 'M': EntryLearner([M], 'M', R), 'S': EntryLearner([A, B, M], 'S', R)}
    calm = ModelLearner([A, B, M], G, R, True)
    for m in (A, B, M):
        smp = Sampler(m.truth, rc)
        for _ in range(0, nb_cal, 5000):
            X, _ = smp.sample(F2[:1].astype(np.float64), 5000)
            for L_ in list(cal.values()) + [calm]:
                if m in L_.models:
                    L_.add(m, X)
    for L_ in cal.values():
        L_.calibrate()
    calm.calibrate(np.full(G * CTYPES, cfg['p_base'] / P_REF))
    S = cal['S']
    tAB = set(S.tmap['A'].tolist()) | set(S.tmap['B'].tolist()); cAB = set(S.cmap['A'].tolist()) | set(S.cmap['B'].tolist())
    seam_t = np.array([i not in tAB for i in range(len(S.p))]); seam_c = np.array([i not in cAB for i in range(len(S.q))])

    def from_projection(EL):
        num = np.zeros(len(EL.p)); cnt = np.zeros(len(EL.p)); numc = np.zeros(len(EL.q)); cntc = np.zeros(len(EL.q))
        for m in EL.models:
            g = EL.tmap[m.name][m.etype]
            np.add.at(num, g, calm.edge_p(m)); np.add.at(cnt, g, 1)
            ps = np.clip(m.p_ref * calm.f[calm.grp(m)], 0, 0.45)
            qd = -0.5 * np.expm1(m.Dm @ np.log1p(-2 * ps))
            gc = EL.cmap[m.name][m.dclass]
            np.add.at(numc, gc, qd); np.add.at(cntc, gc, 1)
        return SimpleNamespace(p=num / np.maximum(cnt, 1), q=numc / np.maximum(cntc, 1))
    refS = from_projection(S); refM = from_projection(cal['M'])
    # ---- learners
    L = {}
    for n in names:
        if n in ('sep-own', 'sep-clock'):
            lu = EntryLearner([A, B], 'U', R); lu.init_from(cal['U'])
            lm = EntryLearner([M], 'M', R, minN=(cfg.get('clock_minN', 200) if n == 'sep-clock' else None)); lm.init_from(cal['M'])
            L[n] = (lu, lm)
        elif n == 'shared':
            ls = EntryLearner([A, B, M], 'S', R); ls.init_from(S); L[n] = ls
        elif n == 'shared-ratio':
            lr = RatioLearner([A, B, M], 'S', R); lr.init_from(S)
            base_t = S.p.copy(); base_c = S.q.copy()
            if mode == 'fresh':
                base_t[seam_t] = refS.p[seam_t]; base_c[seam_c] = refS.q[seam_c]
            lr.setup_ratio(A, B, M, base_t, base_c); L[n] = lr
    ss_p = S.p.copy(); ss_q = S.q.copy()                       # static-shared entries
    if mode == 'fresh':
        ss_p[seam_t] = refS.p[seam_t]; ss_q[seam_c] = refS.q[seam_c]

    def forget_merged():
        for n, obj in L.items():
            if n in ('sep-own', 'sep-clock'):
                lm = obj[1]; lm.p[:] = refM.p; lm.q[:] = refM.q; lm.ver += 1
                for st in lm.st.values():
                    st.reset()
            elif n == 'shared':
                obj.reset_entries(seam_t, seam_c, refS)
            elif n == 'shared-ratio':
                obj.reset_entries(seam_t, seam_c, refS); obj.transfer()

    pcache = {}
    def vers(n):
        if n in ('sep-own', 'sep-clock'):
            return (L[n][0].ver, L[n][1].ver)
        if n in L:
            return (L[n].ver,)
        return (0,)

    def probs(n, m, f2):
        if n == 'oracle':
            return true_edge_p(m, f2)
        key = (n, m.name); v = vers(n); hit = pcache.get(key)
        if hit is not None and hit[0] == v:
            return hit[1]
        if n == 'static-est':
            p = calm.edge_p(m) if (m.name == 'M' and mode == 'fresh') else (cal['U'] if m.name in 'AB' else cal['M']).edge_p(m)
        elif n == 'static-shared':
            p = np.clip(ss_p[S.tmap[m.name][m.etype]], 1e-6, 0.45)
        elif n in ('sep-own', 'sep-clock'):
            lu, lm = L[n]; p = (lu if m.name in 'AB' else lm).edge_p(m)
        else:
            p = L[n].edge_p(m)
        pcache[key] = (v, p)
        return p

    smp = {n: Sampler(mods[n].truth, np.random.default_rng(cfg['seed'] + 99991 + 17 * i)) for i, n in enumerate('ABM')}
    nm_max = P + -(-bpe // k)
    failU = np.zeros((len(names), n_ep, bpe), np.uint8); vU = np.zeros((n_ep, bpe), bool)
    failM = np.zeros((len(names), n_ep, nm_max), np.uint8); vM = np.zeros((n_ep, nm_max), bool); lM = np.zeros((n_ep, nm_max), bool)
    cache = OrderedDict(); builds = 0; decodes = 0
    rounds_u = rounds_m = rounds_wall = 0
    t_start = time.time()

    def decode(m, w, X, preds):
        nonlocal builds, decodes
        w = np.round(w, 3); key = (m.name, hashlib.md5(w.tobytes()).digest())
        if key in preds:
            return preds[key]
        mt = cache.get(key)
        if mt is None:
            mt = build_matching(m, w); builds += 1; cache[key] = mt
            if len(cache) > 400:
                cache.popitem(last=False)
        else:
            cache.move_to_end(key)
        pr = mt.decode_batch(X)[:, 0]; decodes += 1; preds[key] = pr
        return pr

    for e in range(n_ep):
        b0 = e * bpe
        nml = sum(1 for b in range(b0, b0 + bpe) if b % k == 0)        # merged blocks in the learning stream
        nu = bpe - nml
        f2 = F2[e].astype(np.float64)
        Fe = F2[e:e + 1].astype(np.float64)
        xa, ya = smp['A'].sample(Fe, nu); xb, yb = smp['B'].sample(Fe, nu)
        xm, ym = smp['M'].sample(Fe, nml + P)                          # first nml learnable, then probes
        if mode == 'fresh':
            forget_merged()
        preds = {}
        for i, n in enumerate(names):
            pa, pb, pm = probs(n, A, f2), probs(n, B, f2), probs(n, M, f2)
            fa = decode(A, weights_from_p(pa, WMIN), xa, preds) ^ ya
            fb = decode(B, weights_from_p(pb, WMIN), xb, preds) ^ yb
            failU[i, e, :nu] = fa | fb
            failM[i, e, :nml + P] = decode(M, weights_from_p(pm, WMIN), xm, preds) ^ ym
        vU[e, :nu] = True; vM[e, :nml + P] = True; lM[e, :nml] = True
        xml = xm[:nml]
        rounds_u += nu * T; rounds_m += nml * T; rounds_wall += bpe * T
        for n, obj in L.items():
            if isinstance(obj, tuple):
                obj[0].add(A, xa); obj[0].add(B, xb)
                if nml:
                    obj[1].add(M, xml)
            else:
                obj.add(A, xa); obj.add(B, xb)
                if nml:
                    obj.add(M, xml)
        if 'sep-own' in L:
            lu, lm = L['sep-own']
            if rounds_u >= R:
                lu.refresh()
            if rounds_m >= R:
                lm.refresh()
        if rounds_u >= R:
            rounds_u = 0
        if rounds_m >= R:
            rounds_m = 0
        if rounds_wall >= R:
            rounds_wall = 0
            if 'sep-clock' in L:
                lu, lm = L['sep-clock']; lu.refresh(); lm.refresh()
            for n in ('shared', 'shared-ratio'):
                if n in L:
                    L[n].refresh()
        if cfg.get('verbose') and e % 2000 == 0:
            print(f'{e}/{n_ep} {time.time() - t_start:.0f}s builds={builds}', file=sys.stderr, flush=True)
    np.savez_compressed(out, failU=failU, vU=vU, failM=failM, vM=vM, lM=lM, flags=flags, names=np.array(names),
                        cfg=json.dumps(cfg), events=json.dumps(events))
    tm = {n: int(failM[i][vM].sum()) for i, n in enumerate(names)}
    tu = {n: int(failU[i][vU].sum()) for i, n in enumerate(names)}
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t_start, 1), builds=builds, decodes=decodes,
                          merged_blocks=int(vM.sum()), merged_learn_blocks=int(lM.sum()), unmerged_blocks=int(vU.sum()),
                          failM=tm, failU=tu, n_defects=len(events),
                          ratio_entries=(len(L['shared-ratio'].ti), len(L['shared-ratio'].ci)) if 'shared-ratio' in L else None)))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        kk, v = a.split('=', 1); cfg[kk] = json.loads(v)
    run(cfg, sys.argv[2])
