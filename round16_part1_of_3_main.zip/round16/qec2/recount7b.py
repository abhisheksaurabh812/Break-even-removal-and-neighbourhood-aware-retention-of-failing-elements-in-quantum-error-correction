"""Independent recount for round 7b straight from the raw arrays (no code shared with analyse7b.py)."""
import json, os
import numpy as np
from math import erf, sqrt
out = {}
for scen, a, b in (('severe', 'sz_gated', 'sz'), ('mixed', 'sz_gated', 'sz'), ('mixed', 'sz_gated', 'sz_all'),
                   ('moderate', 'sz_gated', 'sz'), ('none', 'sz_gated', 'sz'), ('realistic', 'sz', 'loc'),
                   ('realistic', 'sz_gated', 'loc')):
    ta = tb = 0; dd = []; ps = []
    ok = True
    for sd in (2001, 2002, 2003):
        f = f'out7b/test_{scen}_s{sd}.npz'
        if not os.path.exists(f):
            ok = False; break
        z = np.load(f, allow_pickle=True); names = [str(x) for x in z['names']]
        A = z['fails'][names.index(a)].astype(np.int64).sum(1); B = z['fails'][names.index(b)].astype(np.int64).sum(1)
        ta += int(A.sum()); tb += int(B.sum()); dd.append(A - B); ps.append(round((int(A.sum()) - int(B.sum())) / int(B.sum()), 4))
    if not ok:
        continue
    d = np.concatenate(dd).astype(float); zz = d.sum() / np.sqrt((d ** 2).sum()) if (d ** 2).sum() else 0.0
    out[f'{scen}: {a} vs {b}'] = dict(a=ta, b=tb, rel=round((ta - tb) / tb, 5), z=round(float(zz), 2), p=1 - erf(abs(zz) / sqrt(2)), per_seed=ps)
print(json.dumps(out, indent=1))
