"""Round 13 freeze: list every file the round-13 code reads and write their sha256 to out13/hashes_at_start.txt.
python3 freeze13.py            (run from qec2/, after make_cfg13.py test and gen_jobs13.py)
Python modules: everything under qec2/ that run13.py, analyse13.py and make_cfg13.py import (found by importing them
in a fresh interpreter); plus the scripts run as programs, the CUSUM kernel, the Stim command-line tool, the
configurations, the job list and the pre-registration."""
import glob, hashlib, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
probe = ("import sys, os, json; sys.path.insert(0, %r); import run13, analyse13, make_cfg13; "
         "print(json.dumps(sorted(os.path.relpath(m.__file__, %r) for m in list(sys.modules.values()) "
         "if getattr(m, '__file__', None) and os.path.abspath(m.__file__).startswith(%r + os.sep))))") % (HERE, HERE, HERE)
mods = json.loads(subprocess.run([sys.executable, '-c', probe], capture_output=True, text=True, check=True,
                                 cwd=HERE).stdout)
files = set(mods)
files |= {'run13.py', 'analyse13.py', 'analyse13b.py', 'recount13.py', 'check13.py', 'queue13.py', 'gen_jobs13.py',
          'make_cfg13.py', 'freeze13.py', 'kernel.c', 'libkernel.so', 'jobs13.txt', 'PREREG_round13.md', '../bin/stim'}
files |= set(os.path.relpath(f, HERE) for f in glob.glob(os.path.join(HERE, 'cfg13', '*.json')))
missing = [f for f in files if not os.path.exists(os.path.join(HERE, f))]
assert not missing, missing
os.makedirs(os.path.join(HERE, 'out13'), exist_ok=True)
with open(os.path.join(HERE, 'out13', 'hashes_at_start.txt'), 'w') as out:
    for f in sorted(files):
        h = hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
        out.write(f'{h}  {f}\n')
print(len(files), 'files hashed:', ' '.join(sorted(files)))
