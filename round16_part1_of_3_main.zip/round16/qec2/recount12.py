"""Independent recount of round-12 decision numbers straight from the raw files (no code shared with
analyse12.py / analyse8.py).    python3 recount12.py > out12/recount12.json"""
import json, os, math
import numpy as np


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z['fails'][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b):
    if not all(os.path.exists(p) for p in paths):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    n = len(paths)
    pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
    st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
    return dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
                p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()],
                boot95=[round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)])


P = lambda t, r: [f'out12/{t}_s{x}.npz' for x in r]
T = dict(d9_mixed=range(8101, 8111), d9_severe=range(8201, 8206), d9_moderate=range(8301, 8306),
         d9_realistic=range(8001, 8011), pairs_mixed=range(8401, 8411), long_severe=range(8501, 8507),
         long_mixed=range(8601, 8607), d9_hwlike=range(8701, 8711))
LIST = []
for g in ('sz_w12', 'sz_w12r'):
    LIST += [('d9_mixed', g, 'sz'), ('d9_mixed', g, 'sz_all'), ('d9_severe', g, 'sz'), ('d9_moderate', g, 'sz'),
             ('d9_realistic', g, 'loc'), ('pairs_mixed', g, 'sz'), ('long_severe', g, 'sz'), ('long_mixed', g, 'sz'),
             ('long_mixed', g, 'sz_all'), ('d9_hwlike', g, 'sz')]
    LIST += [(t, g, 'sz_watch') for t in T] + [(t, g, 'sz_field') for t in T]
res = {}
for t, a, b in LIST:
    res[f'{t}: {a} vs {b}'] = pair(P(t, T[t]), a, b)
pool = sum((P(t, T[t]) for t in ('d9_mixed', 'd9_severe', 'd9_moderate', 'pairs_mixed')), [])
res['C1_pooled: sz_w12 vs sz_watch'] = pair(pool, 'sz_w12', 'sz_watch')
res['C2_pooled: sz_w12r vs sz_w12'] = pair(pool, 'sz_w12r', 'sz_w12')
print(json.dumps(res, indent=1))
