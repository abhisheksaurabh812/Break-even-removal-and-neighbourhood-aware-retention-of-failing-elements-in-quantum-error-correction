"""Writes jobs13.txt (round 13).  Estimated seconds per job: the upper range of round-12 run times on this machine
(nine arms), scaled to round 13's six arms with the new gate counted as about two (round 12 ran up to 2.1 times its
estimates; these are set so that a batch's budget check, elapsed + 1.3 x estimate < budget, keeps every batch inside
the 2-hour limit on background work)."""
est = dict(d9_hwlike=2000, d9_mixed=1000, d9_severe=1000, d9_moderate=1400, d9_realistic=1700, pairs_mixed=1000,
           long_severe=1700, long_mixed=1800)
seeds = dict(d9_mixed=range(9101, 9111), d9_severe=range(9201, 9206), d9_moderate=range(9301, 9306),
             d9_realistic=range(9001, 9011), pairs_mixed=range(9401, 9411), long_severe=range(9501, 9507),
             long_mixed=range(9601, 9607), d9_hwlike=range(9701, 9711))


def interleave(a, b):
    out = []
    for i in range(max(len(a), len(b))):
        out += ([a[i]] if i < len(a) else []) + ([b[i]] if i < len(b) else [])
    return out


order = interleave([('d9_mixed', s) for s in seeds['d9_mixed']], [('d9_severe', s) for s in seeds['d9_severe']])
order += interleave([('d9_realistic', s) for s in seeds['d9_realistic']], [('pairs_mixed', s) for s in seeds['pairs_mixed']])
order += interleave([('d9_hwlike', s) for s in seeds['d9_hwlike']], [('long_severe', s) for s in seeds['long_severe']] + [('long_mixed', s) for s in seeds['long_mixed']])
order += [('d9_moderate', s) for s in seeds['d9_moderate']]
with open('jobs13.txt', 'w') as f:
    for t, s in order:
        n = f'{t}_s{s}'
        f.write(f'{n} {est[t]} - python3 run13.py cfg13/{t}.json out13/{n}.npz seed={s} > out13/{n}.json\n')
    # lab-practice baselines after every main run (same seeds; reported, no rule)
    for t, s in order:
        n = f'base_{t}_s{s}'
        f.write(f'{n} {int(0.45 * est[t])} - python3 run13.py cfg13/base_{t}.json out13/{n}.npz seed={s} > out13/{n}.json\n')
print(2 * len(order), 'jobs; total estimate', round(1.45 * sum(est[t] for t, _ in order) / 3600, 2), 'h of CPU')
