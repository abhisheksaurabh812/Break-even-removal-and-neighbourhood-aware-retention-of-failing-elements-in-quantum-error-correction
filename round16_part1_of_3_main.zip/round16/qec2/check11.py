"""Round 11: compare analyse11.py's numbers (out11/res_11.json) with the independent recount
(out11/recount11.json) and re-derive every verdict from the recount alone.   python3 check11.py > out11/check11.json"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out11/res_11.json'))
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out11/recount11.json'))
mism = []; n = 0
for key, c in C.items():
    if c is None:
        continue
    test, pair = key.split(': ')
    a = R['W6_pooled_mixed_severe_pairs'] if test.startswith('pooled') else R[test][pair]
    for name, x, y in (('fails', a['fails'], c['a']), ('ref_fails', a['ref_fails'], c['b']), ('rel', a['rel'], c['rel']),
                       ('z', a['z'], c['z']), ('per_seed', a['per_seed'], c['per_seed']),
                       ('boot_lo', a['boot95']['lo'], c['boot95'][0]), ('boot_hi', a['boot95']['hi'], c['boot95'][1])):
        n += 1
        if x != y:
            mism.append(dict(key=key, field=name, analyse=x, recount=y))


def beats(c, pct):
    return c['rel'] <= -pct and c['p'] < 0.01 and c['z'] < 0 and max(c['per_seed']) <= 0.01


F = 'sz_watch'
g = lambda k: C.get(k)
v = {}
if g(f'd9_mixed: {F} vs sz') and g(f'd9_mixed: {F} vs sz_all'):
    v['W1_sz'] = beats(g(f'd9_mixed: {F} vs sz'), 0.05); v['W1_all'] = beats(g(f'd9_mixed: {F} vs sz_all'), 0.03)
if g(f'd9_severe: {F} vs sz'):
    v['W2'] = beats(g(f'd9_severe: {F} vs sz'), 0.10)
if g(f'd9_moderate: {F} vs sz'):
    v['W3'] = g(f'd9_moderate: {F} vs sz')['rel'] <= 0.01
if g(f'd9_realistic: {F} vs loc'):
    c = g(f'd9_realistic: {F} vs loc'); v['W4'] = c['rel'] <= 0.01 and c['boot95'][1] <= 0.02
if g(f'pairs_mixed: {F} vs sz'):
    v['W5'] = g(f'pairs_mixed: {F} vs sz')['rel'] <= 0.01
c = g(f'pooled mixed+severe+pairs: {F} vs sz_field')
if c:
    v['W6'] = c['rel'] < 0 and c['z'] < 0 and c['p'] < 0.01
names = dict(W1_sz='W1_mixed_fix_beats_sz_5pct', W1_all='W1_mixed_fix_beats_all_3pct', W2='W2_severe_fix_beats_sz_10pct',
             W3='W3_moderate_fix_vs_sz_within_1pct', W4='W4_realistic_fix_vs_loc_within_1pct_and_upper95_within_2pct',
             W5='W5_pairs_fix_vs_sz_within_1pct', W6='W6_fix_fewer_failures_than_field_gate_pooled')
ra = R.get('rules', {})
print(json.dumps(dict(values_compared=n, mismatches=mism, recount_verdicts=v, analyse_verdicts=ra,
                      verdicts_agree={k: v[k] == ra.get(names[k]) for k in v}), indent=1))
