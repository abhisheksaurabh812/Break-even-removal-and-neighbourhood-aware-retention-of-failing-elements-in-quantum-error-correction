"""Round 9 configurations.  The field-aware gate's crossover table comes only from ideal_field9.py's output
(out9/field_table_{data,zanc}.json): rows (L, crossover), crossover null = no crossing on the grid.
  python3 make_cfg9.py dev    fill the table into cfg9/dev_{realistic,mixed,severe}.json
  python3 make_cfg9.py test   write cfg9/test_{realistic,mixed,severe,moderate}.json: the round-7b
                              configuration with its 8 arms unchanged plus sz_field (marked 'extra', so the
                              8 arms see exactly the samples they would see without it)"""
import sys, json, copy, os


def table():
    t = {}
    for k in ('data', 'zanc'):
        j = json.load(open(f'out9/field_table_{k}.json'))
        t[k] = [[r['L'], r['crossover']] for r in j['rows']]
    return t


def field_arm(gated, tab):
    f = copy.deepcopy(gated)
    f.update(kind='policy-field', name='sz_field', extra=True, table=tab, resize=True, ring_min=2, fallback='patch',
             radius=4.0, WL=50)                                  # version 2 of the gate, stated explicitly
    f.pop('mode', None)
    return f


def dump(c, p):
    tmp = p + '.tmp'
    json.dump(c, open(tmp, 'w'), indent=1); os.replace(tmp, p)


if __name__ == '__main__':
    tab = table()
    if sys.argv[1] == 'dev':
        for s in ('realistic', 'mixed', 'severe'):
            p = f'cfg9/dev_{s}.json'; c = json.load(open(p))
            for a in c['arms']:
                if a['name'] == 'sz_field':
                    a['table'] = tab
            dump(c, p)
    elif sys.argv[1] == 'test':
        for s in ('realistic', 'mixed', 'severe', 'moderate'):
            c = json.load(open(f'cfg7b/test_{s}.json'))
            g = [a for a in c['arms'] if a['name'] == 'sz_gated'][0]
            c['arms'] = c['arms'] + [field_arm(g, tab)]
            dump(c, f'cfg9/test_{s}.json')
    print(json.dumps(tab))
