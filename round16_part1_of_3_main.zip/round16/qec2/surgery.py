"""
Test B: shared error-rate index across lattice-surgery decoding tables (phenomenological screen).

Two distance-d rotated patches A (data rows 0..d-1) and B (rows d+1..2d) are stacked vertically.
  unmerged blocks: A and B are separate memories (two graphs, two observables, seam row idle)
  merged blocks:   one (2d+1) x d rectangle; A's top and B's bottom Z checks expand onto the seam
                   row, the seam data qubits add new error mechanisms, one observable (column x=0)
Every mechanism is a physical qubit (data X flip) or an ancilla (measurement flip), so the same
physical mechanism appears in both decoding graphs.  Learners differ only in how rate entries are
indexed and refreshed:
  sep-own    separate tables per configuration, each refreshed after R rounds of its own data
  sep-clock  separate tables, both refreshed every R wall-clock rounds on whatever data they have
  shared     one table keyed by physical mechanism set; both configurations read and write it
  static-est calibration estimate per configuration, never updated;  oracle = true rates
Usage: python3 surgery.py cfg.json out.npz key=json ...
"""
import sys, os, json, time, hashlib
from collections import OrderedDict
import numpy as np
from model import Model, P_REF
from sampler import Sampler, weights_from_p, build_matching
from arms import prepare, Stats, pair_p
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'sim'))
from qec_drift_sim import in_rowspace

WMIN = 0.05


# ------------------------------------------------------------------ geometry
def checks_rect(w, h, oy=0):
    """Z and X checks of a w x h rotated patch whose data rows start at global row oy."""
    Z, X = [], []
    for i in range(-1, w):
        for j in range(-1, h):
            interior = 0 <= i <= w - 2 and 0 <= j <= h - 2
            ztype = (i + j) % 2 == 0
            sup = [(x, y + oy) for x in (i, i + 1) for y in (j, j + 1) if 0 <= x < w and 0 <= y < h]
            c = (i + 0.5, j + 0.5 + oy)
            if ztype and (interior or ((j == -1 or j == h - 1) and 0 <= i <= w - 2)):
                Z.append((c, sup))
            if (not ztype) and (interior or ((i == -1 or i == w - 1) and 0 <= j <= h - 2)):
                X.append((c, sup))
    return Z, X


def geometry(d):
    assert d % 2 == 1
    H = 2 * d + 1
    qid = lambda x, y: y * d + x
    NQ = d * H
    ZA, XA = checks_rect(d, d, 0); ZB, XB = checks_rect(d, d, d + 1); ZM, XM = checks_rect(d, H, 0)
    centres = sorted({c for c, _ in ZA} | {c for c, _ in ZB})
    assert centres == sorted(c for c, _ in ZM), 'merged Z checks must reuse the patch ancillas'
    aid = {c: k for k, c in enumerate(centres)}
    nA = len(centres)
    cfgs = {}
    for name, Z, Xc, rows in (('A', ZA, XA, range(0, d)), ('B', ZB, XB, range(d + 1, H)), ('M', ZM, XM, range(0, H))):
        qs = [qid(x, y) for y in rows for x in range(d)]
        anc = [aid[c] for c, _ in Z]
        sup = {aid[c]: [qid(x, y) for x, y in s] for c, s in Z}
        # logical Z: column x = 0 over the configuration's rows; check commutation with X checks
        L = np.zeros(NQ, np.uint8); L[[qid(0, y) for y in rows]] = 1
        HX = np.zeros((len(Xc), NQ), np.uint8)
        for r, (_, s) in enumerate(Xc):
            HX[r, [qid(x, y) for x, y in s]] = 1
        HZ = np.zeros((len(Z), NQ), np.uint8)
        for r, (c, s) in enumerate(Z):
            HZ[r, [qid(x, y) for x, y in s]] = 1
        assert not (HX @ L % 2).any()
        assert not in_rowspace(HZ[:, qs], L[qs])
        cfgs[name] = dict(qubits=qs, anc=anc, sup=sup, L=L)
    seam = [qid(x, d) for x in range(d)]
    return dict(d=d, NQ=NQ, nA=nA, centres=centres, cfgs=cfgs, seam=seam, G=NQ + nA)


def build_model(geo, name, T):
    c = geo['cfgs'][name]; NQ, nAg = geo['NQ'], geo['nA']
    anc = sorted(c['anc']); la = {a: k for k, a in enumerate(anc)}; nA = len(anc)
    det = lambda a, t: t * nA + la[a]
    q2a = {}
    for a, s in c['sup'].items():
        for q in s:
            q2a.setdefault(q, []).append(a)
    src_p, src_g, src_obs, sdk, sdu, c_k, c_u, c_v, c_o = [], [], [], [], [], [], [], [], []
    K = 0
    for t in range(T + 1):
        for q in c['qubits']:
            zs = sorted(det(a, t) for a in q2a.get(q, []))
            if not zs:
                continue
            o = int(c['L'][q])
            src_p.append(P_REF); src_g.append(q); src_obs.append(o)
            for z in zs: sdk.append(K); sdu.append(z)
            c_k.append(K); c_u.append(zs[0]); c_v.append(zs[1] if len(zs) == 2 else -1); c_o.append(o)
            K += 1
        if t < T:
            for a in anc:
                zs = [det(a, t), det(a, t + 1)]
                src_p.append(P_REF); src_g.append(NQ + a); src_obs.append(0)
                for z in zs: sdk.append(K); sdu.append(z)
                c_k.append(K); c_u.append(zs[0]); c_v.append(zs[1]); c_o.append(0)
                K += 1
    m = Model(); m.kind = 'phenom'; m.d = geo['d']
    m.K, m.nZ, m.T = K, nA * (T + 1), T
    m.p_ref = np.array(src_p); m.src_g = np.array(src_g); m.src_obs = np.array(src_obs, np.uint8)
    m.src_det_k = np.array(sdk); m.src_det_u = np.array(sdu)
    m.c_k, m.c_u, m.c_v, m.c_o = map(np.array, (c_k, c_u, c_v, c_o))
    m.danc = np.array([a for t in range(T + 1) for a in anc])          # GLOBAL ancilla ids
    m.dt = np.array([t for t in range(T + 1) for a in anc])
    m.dcls = np.where(m.dt == 0, 0, np.where(m.dt == T, 2, 1))
    m.dreg = np.zeros(m.nZ, int)
    m.qxy = np.zeros((geo['G'], 2)); m.G = geo['G']; m.center = np.zeros(2); m.lattice = 2.0; m.bad = 0
    m.finalize(); prepare(m)
    m.name = name
    # per-edge source set (physical mechanisms) and global keys for types and detector classes
    srcsets = [set() for _ in range(m.E)]
    Cc = m.C.tocoo()
    for e, k in zip(Cc.row, Cc.col):
        srcsets[e].add(int(m.src_g[k]))
    au, av = m.danc[m.eu], np.where(m.ev >= 0, m.danc[np.maximum(m.ev, 0)], -1)
    dtt = np.where(m.ev >= 0, m.dt[np.maximum(m.ev, 0)] - m.dt[m.eu], 0)
    cu = m.dcls[m.eu]; cv = np.where(m.ev >= 0, m.dcls[np.maximum(m.ev, 0)], -1)
    m.type_key = [None] * m.ntype
    for e in range(m.E):
        k = (int(au[e]), int(av[e]), int(dtt[e]), int(cu[e]), int(cv[e]), tuple(sorted(srcsets[e])))
        t = m.etype[e]
        if m.type_key[t] is None:
            m.type_key[t] = k
        else:
            assert m.type_key[t][:5] == k[:5]
            if m.type_key[t] != k:            # same position, different mechanisms across rounds: keep union
                m.type_key[t] = k[:5] + (tuple(sorted(set(m.type_key[t][5]) | set(k[5]))),)
    # detector class key: (anc, cls, mechanisms flipping that ancilla's detectors)
    flip = {}
    for k_, u_ in zip(m.src_det_k, m.src_det_u):
        flip.setdefault(int(m.danc[u_]), set()).add(int(m.src_g[k_]))
    m.class_key = [(int(m.class_anc[c]), int(m.class_cls[c]), tuple(sorted(flip[int(m.class_anc[c])])))
                   for c in range(m.nclass)]
    gdet = np.array([t * nAg + a for t in range(T + 1) for a in anc])
    m.gdet = gdet
    m.Fm = m.F
    return m


# ------------------------------------------------------------------ circuit-level configurations
def _finish(m, geo, name, T, nAg):
    """Shared post-processing: finalize, index keys (position + mechanism signature), global dets."""
    m.dreg = np.zeros(m.nZ, int)
    m.qxy = np.zeros((geo['G'], 2)); m.G = geo['G']; m.center = np.zeros(2); m.lattice = 2.0
    m.finalize(); prepare(m)
    m.name = name
    sig = (lambda k: (int(m.src_g[k]), int(round(m.p_ref[k] / P_REF * 1e4)))) if geo.get('circuit') else \
          (lambda k: int(m.src_g[k]))
    srcsets = [set() for _ in range(m.E)]
    Cc = m.C.tocoo()
    for e, k in zip(Cc.row, Cc.col):
        srcsets[e].add(sig(k))
    au, av = m.danc[m.eu], np.where(m.ev >= 0, m.danc[np.maximum(m.ev, 0)], -1)
    dtt = np.where(m.ev >= 0, m.dt[np.maximum(m.ev, 0)] - m.dt[m.eu], 0)
    cu = m.dcls[m.eu]; cv = np.where(m.ev >= 0, m.dcls[np.maximum(m.ev, 0)], -1)
    m.type_key = [None] * m.ntype
    for e in range(m.E):
        k = (int(au[e]), int(av[e]), int(dtt[e]), int(cu[e]), int(cv[e]), tuple(sorted(srcsets[e])))
        t = m.etype[e]
        if m.type_key[t] is None:
            m.type_key[t] = k
        elif m.type_key[t] != k:
            m.type_key[t] = k[:5] + (tuple(sorted(set(m.type_key[t][5]) | set(k[5]))),)
    flip = {}
    for k_, u_ in zip(m.src_det_k, m.src_det_u):
        flip.setdefault(int(m.danc[u_]), set()).add(sig(k_))
    m.class_key = [(int(m.class_anc[c]), int(m.class_cls[c]), tuple(sorted(flip[int(m.class_anc[c])])))
                   for c in range(m.nclass)]
    return m


def geometry_circuit(d):
    """Patches side by side (Stim orientation: Z boundaries left/right, observable = bottom row).
    A: columns 0..d-1, seam column d, B: columns d+1..2d; merged = (2d+1) x d rectangle."""
    import rectgen
    RL = 2 * (2 * d + 1) + 1
    specs = dict(A=(d, 0), B=(d, d + 1), M=(2 * d + 1, 0))
    allq = {}; zanc = set()
    for n, (W, x0) in specs.items():
        data, xm, zm = rectgen.layout(W, d, x0)
        for c in data + xm + zm:
            allq[c] = c[0] + RL * (c[1] // 2)
        if n in 'AB':
            zanc |= set(zm)
    zM = set(rectgen.layout(2 * d + 1, d, 0)[2])
    assert zM == zanc, 'merged Z checks must reuse the patch ancillas'
    qcoords = sorted(allq)
    gq = {c: k for k, c in enumerate(qcoords)}
    ganc = {c: k for k, c in enumerate(sorted(zanc))}
    return dict(d=d, RL=RL, specs=specs, gq=gq, ganc=ganc, G=len(qcoords), nA=len(ganc), circuit=True,
                seam=[gq[(2 * d + 1, 2 * b + 1)] for b in range(d)])


def build_circuit_model(geo, name, T):
    import rectgen
    from model import unroll, analyze, parse_dem, filter_for_qubit
    W, x0 = geo['specs'][name]
    cache = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache', f'surg_{name}_d{geo["d"]}_r{T}.npz')
    m = Model(); m.kind = 'circuit'; m.d = geo['d']; m.T = T
    if os.path.exists(cache):
        z = np.load(cache, allow_pickle=True)
        for k in z.files:
            setattr(m, k, z[k])
        m.K = int(m.K); m.nZ = int(m.nZ); m.T = int(m.T)
        return _finish(m, geo, name, m.T, geo['nA'])
    lines = unroll(rectgen.circuit(W, geo['d'], T, P_REF, x0, row_len=geo['RL']))
    coords = {}
    for l in lines:
        if l.startswith('QUBIT_COORDS'):
            c = tuple(int(float(x)) for x in l[l.index('(') + 1:l.index(')')].split(','))
            coords[int(l.split()[-1])] = c
    _, dets = parse_dem(analyze(lines))
    zxy = {(int(c[0]), int(c[1])) for k, c in dets.items() if c[2] == 0}
    zdets = sorted(k for k, c in dets.items() if (int(c[0]), int(c[1])) in zxy)
    zmap = {k: i for i, k in enumerate(zdets)}
    nZ = len(zdets)
    danc = np.array([geo['ganc'][(int(dets[k][0]), int(dets[k][1]))] for k in zdets])
    dt = np.array([int(round(dets[k][2])) for k in zdets]); Tm = int(dt.max())
    dcls = np.where(dt == 0, 0, np.where(dt == Tm, 2, 1))
    src_p, src_g, src_obs, sdk, sdu, c_k, c_u, c_v, c_o = [], [], [], [], [], [], [], [], []
    K = 0; bad = 0
    for q in sorted(coords):
        gi = geo['gq'][coords[q]]
        errs, _ = parse_dem(analyze(filter_for_qubit(lines, q)))
        for p, comps in errs:
            zall = set(); obs = 0; zcomps = []
            for comp in comps:
                zs = [zmap[int(t[1:])] for t in comp if t[0] == 'D' and int(t[1:]) in zmap]
                lo = sum(1 for t in comp if t == 'L0') % 2
                obs ^= lo
                if zs:
                    zcomps.append((zs, lo))
                for z in zs:
                    zall ^= {z}
            if not zall:
                bad += int(obs); continue
            k = K; K += 1
            src_p.append(p); src_g.append(gi); src_obs.append(obs)
            for z in zall:
                sdk.append(k); sdu.append(z)
            for zs, lo in zcomps:
                if len(zs) > 2:
                    bad += 1; continue
                zs = sorted(zs)
                c_k.append(k); c_u.append(zs[0]); c_v.append(zs[1] if len(zs) == 2 else -1); c_o.append(lo)
    m.K, m.nZ, m.T = K, nZ, Tm
    m.p_ref = np.array(src_p); m.src_g = np.array(src_g); m.src_obs = np.array(src_obs, np.uint8)
    m.src_det_k = np.array(sdk); m.src_det_u = np.array(sdu)
    m.c_k, m.c_u, m.c_v, m.c_o = map(np.array, (c_k, c_u, c_v, c_o))
    m.danc, m.dt, m.dcls = danc, dt, dcls
    m.bad = bad
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    np.savez_compressed(cache, K=K, nZ=nZ, T=Tm, p_ref=m.p_ref, src_g=m.src_g, src_obs=m.src_obs, src_det_k=m.src_det_k,
                        src_det_u=m.src_det_u, c_k=m.c_k, c_u=m.c_u, c_v=m.c_v, c_o=m.c_o, danc=danc, dt=dt, dcls=dcls,
                        bad=bad)
    return _finish(m, geo, name, Tm, geo['nA'])


# ------------------------------------------------------------------ learners
class Index:
    """Global rate table.  Entries are keyed by (position, mechanism set); `ns` namespaces the keys,
    so separate tables use different namespaces and the shared table uses one."""
    def __init__(self):
        self.tkeys = {}; self.ckeys = {}
    def tid(self, k):
        return self.tkeys.setdefault(k, len(self.tkeys))
    def cid(self, k):
        return self.ckeys.setdefault(k, len(self.ckeys))


class Learner:
    """Slow per-mechanism estimator over one or more decoding graphs that share an index."""
    def __init__(self, models, ns, R, minfrac=0.25, alpha=0.5):
        self.models = models
        self.ix = Index()
        self.tmap = {m.name: np.array([self.ix.tid((ns,) + k) for k in m.type_key]) for m in models}
        self.cmap = {m.name: np.array([self.ix.cid((ns,) + k) for k in m.class_key]) for m in models}
        self.p = np.full(len(self.ix.tkeys), 0.01); self.q = np.full(len(self.ix.ckeys), 0.02)
        self.st = {m.name: Stats(m) for m in models}
        self.R = R; self.T = models[0].T
        self.minN = minfrac * R / self.T; self.alpha = alpha
        self.nb_type = np.zeros(len(self.ix.tkeys), bool)
        for m in models:
            self.nb_type[self.tmap[m.name][m.etype[m.nb_idx]]] = True

    def init_from(self, other):
        self.p[:] = other.p; self.q[:] = other.q

    def edge_p(self, m):
        return np.clip(self.p[self.tmap[m.name][m.etype]], 1e-6, 0.45)

    def add(self, m, X):
        self.st[m.name].add(X)

    def window(self, minN=None, minNd=None):
        """Window estimates pooled over all graphs by index entry (non-boundary types and classes)."""
        minN = self.minN if minN is None else minN; minNd = minN if minNd is None else minNd
        nT, nC = len(self.p), len(self.q)
        num = np.zeros(nT); den = np.zeros(nT); Dn = np.zeros(nC); DN = np.zeros(nC)
        for m in self.models:
            st = self.st[m.name]
            t_nb = m.etype[m.nb_idx]
            Sa = np.bincount(t_nb, st.sa, m.ntype); Sb = np.bincount(t_nb, st.sb, m.ntype)
            Sab = np.bincount(t_nb, st.sab, m.ntype); Sn = np.bincount(t_nb, st.sn, m.ntype)
            Snn = np.maximum(Sn, 1)
            pt = pair_p(Sa / Snn, Sb / Snn, Sab / Snn)
            g = self.tmap[m.name]
            np.add.at(num, g, Sn * pt); np.add.at(den, g, Sn)
            gc = self.cmap[m.name]
            np.add.at(Dn, gc, np.bincount(m.dclass, st.dn, m.nclass)); np.add.at(DN, gc, np.bincount(m.dclass, st.dN, m.nclass))
        okp = self.nb_type & (den >= minN); okq = DN >= minNd
        pw = self.p.copy(); pw[okp] = num[okp] / den[okp]
        qw = self.q.copy(); qw[okq] = Dn[okq] / DN[okq]
        # boundary entries from detector-rate subtraction in each graph (window values where available)
        bnum = np.zeros(nT); bden = np.zeros(nT)
        for m in self.models:
            g = self.tmap[m.name]; gc = self.cmap[m.name]
            psig = pw[g[m.etype[m.nb_idx]]]
            lnb = m.Inc_nb @ np.log1p(-2 * np.clip(psig, -0.2, 0.45))
            qu = qw[gc[m.dclass]]
            pB = 0.5 * (1 - np.clip((1 - 2 * qu) / np.exp(lnb), 0, 1))
            bu = m.eu[m.b_idx]; bt = g[m.etype[m.b_idx]]
            ok = okq[gc[m.dclass[bu]]]
            np.add.at(bnum, bt[ok], pB[bu][ok]); np.add.at(bden, bt[ok], 1)
        okb = bden > 0
        pw[okb] = bnum[okb] / bden[okb]
        return pw, qw, okp | okb, okq

    def refresh(self, minN=None):
        pw, qw, okp, okq = self.window(minN)
        a = self.alpha
        self.p[okp] += a * (pw[okp] - self.p[okp]); self.q[okq] += a * (qw[okq] - self.q[okq])
        self.p = np.clip(self.p, 1e-6, 0.45)
        for st in self.st.values():
            st.reset()

    def calibrate(self):
        pw, qw, okp, okq = self.window(10, 10)
        self.p[okp] = pw[okp]; self.q[okq] = qw[okq]
        self.p = np.clip(self.p, 1e-6, 0.45)
        for st in self.st.values():
            st.reset()


# ------------------------------------------------------------------ scenario
def scenario(geo, cfg, rng, n_ep, er):
    G = geo['G']; t = (np.arange(n_ep) + 0.5) * er; tot = n_ep * er
    f0 = np.exp(cfg['het_sigma'] * rng.standard_normal(G)); f0 /= np.median(f0); f0 = np.clip(f0, 0.25, 4.0)
    F = np.tile((f0 * cfg['p_base'] / P_REF).astype(np.float32), (n_ep, 1))
    flags = np.zeros(n_ep, np.uint8); events = []
    if cfg.get('drift_frac', 0) > 0:
        sel = rng.random(G) < cfg['drift_frac']; fac = rng.uniform(1.0, cfg['drift_fac'], G)
        F[:, sel] *= (fac[sel][None, :] ** (t / tot)[:, None]).astype(np.float32)
    t0 = 0.0
    while cfg.get('defects', True):
        t0 += rng.exponential(cfg['defect_gap'])
        if t0 > tot:
            break
        q = int(rng.integers(G)); fac = rng.uniform(*cfg['defect_fac']); dur = rng.uniform(*cfg['defect_dur'])
        on = (t >= t0) & (t < t0 + dur)
        F[on, q] *= fac; flags[on] |= 4
        events.append([float(t0), float(dur), q, float(fac)])
    return F, flags, events


# ------------------------------------------------------------------ run
def run(cfg, out):
    d, T, bpe, k = cfg['d'], cfg['d'], cfg['bpe'], cfg['merge_every']
    if cfg.get('noise', 'phenom') == 'circuit':
        geo = geometry_circuit(d)
        mods = {n: build_circuit_model(geo, n, T) for n in 'ABM'}
    else:
        geo = geometry(d)
        mods = {n: build_model(geo, n, T) for n in 'ABM'}
    A, B, M = mods['A'], mods['B'], mods['M']
    nm = bpe // k; nu = bpe - nm                         # merged / unmerged blocks per epoch
    assert nm >= 1 and nm * k == bpe
    er = bpe * T
    n_ep = cfg['total_rounds'] // er
    F, flags, events = scenario(geo, cfg, np.random.default_rng(cfg['seed']), n_ep, er)
    R = cfg['R']
    # calibration (t = 0 rates), separate stream, same estimator for every learner
    cal = {}
    rc = np.random.default_rng(cfg['seed'] + 77777)
    nb_cal = cfg.get('cal_rounds', 1_000_000) // T
    for ns, ms in (('U', [A, B]), ('M', [M]), ('S', [A, B, M])):
        L = Learner(ms, ns, R)
        cal[ns] = L
    for m in (A, B, M):
        smp = Sampler(m, rc)
        for _ in range(0, nb_cal, 5000):
            X, _ = smp.sample(F[:1].astype(np.float64), 5000)
            for ns in ('U', 'M', 'S'):
                if m in cal[ns].models:
                    cal[ns].add(m, X)
    for L in cal.values():
        L.calibrate()
    arms = []
    def learner_pair(ns_u, ns_m):
        lu = Learner([A, B], ns_u, R); lu.init_from(cal['U'])
        lm = Learner([M], ns_m, R); lm.init_from(cal['M'])
        return lu, lm
    names = cfg.get('arms', ['static-est', 'oracle', 'sep-own', 'sep-clock', 'shared'])
    learners = {}
    for n in names:
        if n == 'sep-own' or n == 'sep-clock':
            learners[n] = learner_pair('U', 'M')
        elif n == 'shared':
            ls = Learner([A, B, M], 'S', R); ls.init_from(cal['S']); learners[n] = (ls, ls)
    smp = {n: Sampler(mods[n], np.random.default_rng(cfg['seed'] + 99991 + 17 * i)) for i, n in enumerate('ABM')}
    failU = np.zeros((len(names), n_ep, nu), np.uint8); failM = np.zeros((len(names), n_ep, nm), np.uint8)
    cache = OrderedDict(); builds = 0
    rounds_u = rounds_m = rounds_wall = 0
    chunk = cfg.get('chunk', 200)
    t_start = time.time()

    def decode(m, w, X):
        nonlocal builds
        w = np.round(w, 3)
        key = (m.name, hashlib.md5(w.tobytes()).digest())
        mt = cache.get(key)
        if mt is None:
            mt = build_matching(m, w); builds += 1; cache[key] = mt
            if len(cache) > 400:
                cache.popitem(last=False)
        else:
            cache.move_to_end(key)
        return mt.decode_batch(X)[:, 0]

    for cs in range(0, n_ep, chunk):
        ce = min(n_ep, cs + chunk)
        Fc = F[cs:ce].astype(np.float64)
        XA, oA = smp['A'].sample(Fc, nu); XB, oB = smp['B'].sample(Fc, nu); XM, oM = smp['M'].sample(Fc, nm)
        for e in range(cs, ce):
            i0 = e - cs
            xa, xb, xm = XA[i0 * nu:(i0 + 1) * nu], XB[i0 * nu:(i0 + 1) * nu], XM[i0 * nm:(i0 + 1) * nm]
            ya, yb, ym = oA[i0 * nu:(i0 + 1) * nu], oB[i0 * nu:(i0 + 1) * nu], oM[i0 * nm:(i0 + 1) * nm]
            fe = F[e].astype(np.float64)
            for i, n in enumerate(names):
                if n == 'static-est':
                    pa, pb, pm = cal['U'].edge_p(A), cal['U'].edge_p(B), cal['M'].edge_p(M)
                elif n == 'oracle':
                    pa, pb, pm = A.edge_p(fe), B.edge_p(fe), M.edge_p(fe)
                else:
                    lu, lm = learners[n]
                    pa, pb, pm = lu.edge_p(A), lu.edge_p(B), lm.edge_p(M)
                fa = decode(A, weights_from_p(pa, WMIN), xa) ^ ya
                fb = decode(B, weights_from_p(pb, WMIN), xb) ^ yb
                failU[i, e] = fa | fb
                failM[i, e] = decode(M, weights_from_p(pm, WMIN), xm) ^ ym
            # learners see this epoch's data after decoding it
            rounds_u += nu * T; rounds_m += nm * T; rounds_wall += bpe * T
            for n, (lu, lm) in learners.items():
                lu.add(A, xa); lu.add(B, xb); lm.add(M, xm)
            if 'sep-own' in learners:
                lu, lm = learners['sep-own']
                if rounds_u >= R:
                    lu.refresh()
                if rounds_m >= R:
                    lm.refresh()
            if rounds_u >= R:
                rounds_u = 0
            if rounds_m >= R:
                rounds_m = 0
            if rounds_wall >= R:
                rounds_wall = 0
                if 'sep-clock' in learners:
                    lu, lm = learners['sep-clock']
                    lu.refresh(); lm.refresh(minN=cfg.get('clock_minN', 200))
                if 'shared' in learners:
                    learners['shared'][0].refresh()
        if cfg.get('verbose'):
            print(f'{ce}/{n_ep} {time.time() - t_start:.0f}s builds={builds}', file=sys.stderr, flush=True)
    np.savez_compressed(out, failU=failU, failM=failM, flags=flags, names=np.array(names),
                        cfg=json.dumps(cfg), events=json.dumps(events))
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t_start, 1), builds=builds,
                          merged_blocks=int(n_ep * nm), unmerged_blocks=int(n_ep * nu),
                          failM=dict(zip(names, failM.reshape(len(names), -1).sum(1).tolist())),
                          failU=dict(zip(names, failU.reshape(len(names), -1).sum(1).tolist())),
                          n_defects=len(events))))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
