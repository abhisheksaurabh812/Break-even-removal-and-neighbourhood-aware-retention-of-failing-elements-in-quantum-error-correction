"""Round 8 analysis (rules in PREREG_round8.md).   python3 analyse8.py > out8/res_8.json
Evaluates a rule only when every seed of its test has finished (done marker in out8/done/)."""
import json, os
import numpy as np
from scipy.special import ndtr
from model import circuit_model
import rectgen, deform

THETA7 = {'data': 13.0, 'zanc': 7.0}
SEEDS = dict(long=range(3001, 3007), d9=range(4001, 4004), more_new=range(2004, 2011), b7=range(2001, 2004),
             sens=range(2001, 2003))
_roles = {}


def roles(d):
    if d not in _roles:
        m = circuit_model(d)
        data, xm, zm = rectgen.layout(d, d)
        qg = {(int(round(x)), int(round(y))): g for g, (x, y) in enumerate(m.qxy)}
        R = {}
        for c in data: R[qg[c]] = 'D'
        for c in xm: R[qg[c]] = 'X'
        for c in zm: R[qg[c]] = 'Z'
        ex = {qg[c]: 'data' for c in deform.bulk_data(d)}
        ex.update({qg[c]: 'zanc' for c in deform.bulk_zanc(d)})
        _roles[d] = (R, ex)
    return _roles[d]


def done(name):
    return os.path.exists(f'out8/done/{name}')


def load(f):
    z = np.load(f, allow_pickle=True)
    ev = json.loads(str(z['events']))
    return dict(file=f, names=[str(x) for x in z['names']], fails=z['fails'].astype(np.int64), nexcl=z['nexcl'],
                info=json.loads(str(z['info'])), cfg=json.loads(str(z['cfg'])), defects=ev['defects'])


def runs_for(prefix, scen, seeds, new=True):
    """Loads out8/<prefix>_<scen>_s<seed>.npz (new) or out7b/test_<scen>_s<seed>.npz; None if any missing."""
    out = []
    for s in seeds:
        if new:
            n = f'{prefix}_{scen}_s{s}'
            if not done(n):
                return None
            out.append(load(f'out8/{n}.npz'))
        else:
            out.append(load(f'out7b/test_{scen}_s{s}.npz'))
    return out


def per_epoch(r, arm):
    return r['fails'][r['names'].index(arm)].sum(1)


def compare(runs, a, b):
    d = []; fa = fb = 0; seed_rel = []
    for r in runs:
        x, y = per_epoch(r, a), per_epoch(r, b)
        d.append(x - y); fa += int(x.sum()); fb += int(y.sum())
        seed_rel.append(round((int(x.sum()) - int(y.sum())) / max(int(y.sum()), 1), 4))
    d = np.concatenate(d).astype(float)
    s = float(np.sqrt((d ** 2).sum()))
    z = float(d.sum() / s) if s > 0 else 0.0
    return dict(fails=fa, ref_fails=fb, rel=round((fa - fb) / max(fb, 1), 5), z=round(z, 2),
                p=float(2 * (1 - ndtr(abs(z)))), per_seed=seed_rel, worst_seed=max(seed_rel))


def bootstrap(runs, a, b, n=10000, seed=8):
    A = np.array([per_epoch(r, a).sum() for r in runs], float)
    B = np.array([per_epoch(r, b).sum() for r in runs], float)
    S = len(runs)
    idx = np.random.default_rng(seed).integers(0, S, size=(n, S))
    st = (A[idx].sum(1) - B[idx].sum(1)) / B[idx].sum(1)
    lo, hi = np.percentile(st, [2.5, 97.5])
    return dict(lo=round(float(lo), 5), hi=round(float(hi), 5))


def beats(c, pct):
    return bool(c['rel'] <= -pct and c['p'] < 0.01 and c['z'] < 0 and c['worst_seed'] <= 0.01)


def totals(runs):
    names = runs[0]['names']
    return {n: sum(int(r['fails'][k].sum()) for r in runs) for k, n in enumerate(names)}


def out_intervals(log, er):
    """(g, start_round, end_round or None) for each switch-out in a policy log."""
    iv = []; open_ = {}
    for l in log:
        if l[0] == 'out':
            open_[l[3]] = ((l[1] + 1) * er, (l[1] + 0.5) * er)  # effective from the next epoch; decided mid-epoch
        elif l[0] == 'in' and l[3] in open_:
            a, td = open_.pop(l[3]); iv.append((l[3], a, (l[1] + 1) * er, td))
    for g, (a, td) in open_.items():
        iv.append((g, a, None, td))
    return iv


def policy_checks(runs, arm, theta=None):
    outs = healthy = 0; cross = []; delays = []
    for r in runs:
        d = r['cfg']['d']; er = r['cfg']['bpe'] * d; tot = r['fails'].shape[1] * er
        R, ex = roles(d)
        th = theta or [a for a in r['cfg']['arms'] if a['name'] == arm][0].get('theta') or THETA7
        log = r['info'][arm].get('policy_log', [])
        iv = out_intervals(log, er)
        for g, _, _, t in iv:
            outs += 1
            if not any(dd[2] == g and dd[0] <= t < dd[0] + dd[1] for dd in r['defects']):
                healthy += 1
        for dd in r['defects']:
            t0, dur, g, fac = dd
            if g in ex and fac >= th[ex[g]]:
                t1 = min(t0 + dur, tot)
                cov = 0.0; first = None
                for gg, a, b, _ in iv:
                    if gg != g:
                        continue
                    b = tot if b is None else b
                    ov = max(0.0, min(b, t1) - max(a, t0))
                    if ov > 0:
                        cov += ov
                        first = a if first is None else min(first, a)
                cross.append(dict(g=int(g), kind=ex[g], fac=round(fac, 1), dur=int(t1 - t0),
                                  out_fraction=round(cov / max(t1 - t0, 1), 3),
                                  delay=None if first is None else int(max(first - t0, 0))))
                if first is not None:
                    delays.append(max(first - t0, 0))
    return dict(switch_outs=outs, switch_outs_without_failure=healthy, crossover_failures=len(cross),
                switched_out=sum(c['out_fraction'] > 0 for c in cross),
                median_out_fraction=float(np.median([c['out_fraction'] for c in cross])) if cross else None,
                median_delay_rounds=float(np.median(delays)) if delays else None, failures=cross)


PAIRS = (('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz_all', 'sz'), ('sz', 'loc'), ('sz_gated', 'loc'),
         ('oracle_gated', 'oracle'), ('oracle_all', 'oracle'), ('oracle_gated', 'oracle_all'),
         ('oracle_gated', 'sz_gated'))


def block(runs, pairs=PAIRS, boot=False, pol=True):
    R = dict(seeds=len(runs), totals=totals(runs))
    for a, b in pairs:
        R[f'{a} vs {b}'] = compare(runs, a, b)
        if boot:
            R[f'{a} vs {b}']['boot95'] = bootstrap(runs, a, b)
    if pol:
        # "past the crossover" uses the run's own crossover for both arms (d = 9: 2a's values; d = 7: 13 / 7).
        # Fixed 3 Nov 23:40 (reporting only; no rule uses it): sz_all was being judged against 13 / 7 at d = 9.
        th = [a for a in runs[0]['cfg']['arms'] if a['name'] == 'sz_gated'][0].get('theta')
        R['policy_sz_gated'] = policy_checks(runs, 'sz_gated', th)
        R['policy_sz_all'] = policy_checks(runs, 'sz_all', th)
        for k in ('policy_sz_gated', 'policy_sz_all'):
            R[k]['failures'] = R[k]['failures'][:60]
    return R


def main():
    res = {}; rules = {}
    # ---- test 2a: crossovers
    cr = {}
    for d in (7, 9):
        for k in ('data', 'zanc'):
            n = f'ideal_d{d}_{k}'
            if done(n):
                j = json.load(open(f'out8/{n}.json'))
                cr[n] = dict(crossover=j['crossover'], row=j['row'], shots=j['shots'])
    res['crossovers'] = cr
    # ---- test 1: long failures
    for scen in ('severe', 'mixed'):
        runs = runs_for('long', scen, SEEDS['long'])
        if runs:
            res[f'long_{scen}'] = block(runs)
    if 'long_severe' in res:
        rules['L1_long_severe_gated_beats_sz_10pct'] = beats(res['long_severe']['sz_gated vs sz'], 0.10)
    if 'long_mixed' in res:
        rules['L2_long_mixed_gated_beats_sz_5pct'] = beats(res['long_mixed']['sz_gated vs sz'], 0.05)
        rules['L2_long_mixed_gated_beats_all_3pct'] = beats(res['long_mixed']['sz_gated vs sz_all'], 0.03)
    # ---- test 2b: distance 9
    for scen in ('severe', 'mixed'):
        runs = runs_for('d9', scen, SEEDS['d9'])
        if runs:
            res[f'd9_{scen}'] = block(runs)
            res[f'd9_{scen}']['theta_used'] = [a for a in runs[0]['cfg']['arms'] if a['name'] == 'sz_gated'][0].get('theta')
    if 'd9_severe' in res:
        rules['D1_d9_severe_gated_beats_sz_10pct'] = beats(res['d9_severe']['sz_gated vs sz'], 0.10)
    if 'd9_mixed' in res:
        rules['D2_d9_mixed_gated_beats_sz_5pct'] = beats(res['d9_mixed']['sz_gated vs sz'], 0.05)
        rules['D2_d9_mixed_gated_beats_all_3pct'] = beats(res['d9_mixed']['sz_gated vs sz_all'], 0.03)
    # ---- test 3: more seeds
    for scen in ('mixed', 'moderate', 'realistic'):
        new = runs_for('more', scen, SEEDS['more_new'])
        if new:
            old = runs_for('test', scen, SEEDS['b7'], new=False)
            res[f'more_{scen}_10seeds'] = block(old + new, boot=True)
            res[f'more_{scen}_new7'] = block(new, pairs=(('sz_gated', 'sz'), ('sz_gated', 'sz_all'), ('sz', 'loc'),
                                                         ('sz_gated', 'loc')), boot=True, pol=False)
    if 'more_realistic_10seeds' in res:
        R = res['more_realistic_10seeds']
        for a in ('sz', 'sz_gated'):
            c = R[f'{a} vs loc']
            rules[f'E1_realistic_{a}_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(c['rel'] <= 0.01 and c['boot95']['hi'] <= 0.02)
    if 'more_mixed_10seeds' in res:
        R = res['more_mixed_10seeds']
        c = R['sz_gated vs sz']; rules['E2_mixed_gated_beats_sz_5pct_upper95_below_0'] = bool(c['rel'] <= -0.05 and c['boot95']['hi'] < 0)
        c = R['sz_gated vs sz_all']; rules['E2_mixed_gated_beats_all_3pct_upper95_below_0'] = bool(c['rel'] <= -0.03 and c['boot95']['hi'] < 0)
    if 'more_moderate_10seeds' in res:
        rules['E3_moderate_gated_vs_sz_within_1pct'] = bool(res['more_moderate_10seeds']['sz_gated vs sz']['rel'] <= 0.01)
    # ---- test 4: sensitivity
    for scen in ('severe', 'mixed'):
        runs = runs_for('sens', scen, SEEDS['sens'])
        if not runs:
            continue
        old = runs_for('test', scen, SEEDS['sens'], new=False)
        rep = {}
        for r, o in zip(runs, old):
            for k, n in enumerate(o['names']):
                rep[f"{n}_s{r['cfg']['seed']}"] = bool(np.array_equal(r['fails'][r['names'].index(n)], o['fails'][k]))
        R = dict(reproduces_7b_exactly=all(rep.values()), reproduce_detail=rep, totals=totals(runs))
        for v in ('g_th05', 'g_th2', 'g_p7', 'g_p640', 'g_s05', 'g_s30'):
            R[f'{v} vs sz_gated'] = compare(runs, v, 'sz_gated')
            R[f'{v} vs sz'] = compare(runs, v, 'sz')
        R['sz_gated vs sz'] = compare(runs, 'sz_gated', 'sz')
        res[f'sens_{scen}'] = R
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
