"""Round 14 freeze: list every file the round-14 code reads and write their sha256 to out14/hashes_at_start.txt.
python3 freeze14.py            (run from qec2/, after make_cfg14.py test and gen_jobs14.py)
Python modules: everything under qec2/ that run14.py, analyse14.py and make_cfg14.py import (found by importing them
in a fresh interpreter); plus the scripts run as programs, the CUSUM kernel, the Stim command-line tool, the
configurations, the job list and the pre-registration."""
import glob, hashlib, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
probe = ("import sys, os, json; sys.path.insert(0, %r); import run14, analyse14, make_cfg14; "
         "print(json.dumps(sorted(os.path.relpath(m.__file__, %r) for m in list(sys.modules.values()) "
         "if getattr(m, '__file__', None) and os.path.abspath(m.__file__).startswith(%r + os.sep))))") % (HERE, HERE, HERE)
mods = json.loads(subprocess.run([sys.executable, '-c', probe], capture_output=True, text=True, check=True,
                                 cwd=HERE).stdout)
files = set(mods)
files |= {'run14.py', 'analyse14.py', 'analyse14b.py', 'recount14.py', 'check14.py', 'queue14.py', 'gen_jobs14.py',
          'make_cfg14.py', 'freeze14.py', 'kernel.c', 'libkernel.so', 'jobs14.txt', 'PREREG_round14.md', '../bin/stim',
          'dev14/prior/tune_sieg.py'}
files |= set(os.path.relpath(f, HERE) for f in glob.glob(os.path.join(HERE, 'cfg14', '*.json')))
files |= set(os.path.relpath(f, HERE) for f in glob.glob(os.path.join(HERE, 'cfg13', '*.json')))   # read by make_cfg14.py
missing = [f for f in files if not os.path.exists(os.path.join(HERE, f))]
assert not missing, missing
os.makedirs(os.path.join(HERE, 'out14'), exist_ok=True)
with open(os.path.join(HERE, 'out14', 'hashes_at_start.txt'), 'w') as out:
    for f in sorted(files):
        h = hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
        out.write(f'{h}  {f}\n')
print(len(files), 'files hashed:', ' '.join(sorted(files)))
