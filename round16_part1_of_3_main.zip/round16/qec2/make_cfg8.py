"""Round-8 configurations, all derived mechanically from the round-7b test configurations (cfg7b/).
  python3 make_cfg8.py        -> cfg8/long_{severe,mixed}.json, cfg8/sens_{severe,mixed}.json
  python3 make_cfg8.py d9     -> cfg8/d9_{severe,mixed}.json (needs out8/ideal_d9_{data,zanc}.json)"""
import json, sys, copy, os

def load(s):
    return json.load(open(f'cfg7b/test_{s}.json'))

def dump(c, f):
    tmp = f'{f}.{os.getpid()}.tmp'          # atomic: two jobs may write the same (identical) file at once
    json.dump(c, open(tmp, 'w'), indent=1)
    os.replace(tmp, f)
    print('wrote', f)

if len(sys.argv) > 1 and sys.argv[1] == 'd9':
    th = {k: json.load(open(f'out8/ideal_d9_{k}.json'))['crossover'] for k in ('data', 'zanc')}
    for s in ('severe', 'mixed'):
        c = load(s); c['d'] = 9
        for a in c['arms']:
            if a['kind'] == 'policy':
                a['probe'] = dict(a['probe'], period=50)       # 50 epochs x 180 rounds = 9,000 rounds
            if a['name'] in ('sz_gated', 'oracle_gated'):
                a['theta'] = dict(th)
        dump(c, f'cfg8/d9_{s}.json')
else:
    # test 1: long-lived failures
    for s in ('severe', 'mixed'):
        c = load(s)
        c.update(total_rounds=20_000_000, defect_gap=5_000_000, defect_dur=[2_000_000, 6_000_000])
        dump(c, f'cfg8/long_{s}.json')
    # test 4: sensitivity -- the 7b arms unchanged and in the same order, plus six 'extra' gated arms
    for s in ('severe', 'mixed'):
        c = load(s)
        g = [a for a in c['arms'] if a['name'] == 'sz_gated'][0]
        var = [('g_th05', dict(theta={'data': 6.5, 'zanc': 3.5})),
               ('g_th2', dict(theta={'data': 26.0, 'zanc': 14.0})),
               ('g_p7', dict(probe={'period': 7, 'sigma': 0.15})),
               ('g_p640', dict(probe={'period': 640, 'sigma': 0.15})),
               ('g_s05', dict(probe={'period': 64, 'sigma': 0.05})),
               ('g_s30', dict(probe={'period': 64, 'sigma': 0.30}))]
        for name, ch in var:
            a = copy.deepcopy(g); a.update(ch); a['name'] = name; a['extra'] = True
            c['arms'].append(a)
        dump(c, f'cfg8/sens_{s}.json')
