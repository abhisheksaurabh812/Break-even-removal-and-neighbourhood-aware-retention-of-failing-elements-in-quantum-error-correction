"""Writes jobs11.txt (round 11).  Estimated seconds per job: round-10 timings plus the development runs' cost of the
extra arm.  Every job uses run11.py (identical to run9/run10 for every arm except the one marked "extra": "w")."""
est = dict(d9_realistic=1450, d9_mixed=950, d9_severe=900, d9_moderate=1000, pairs_mixed=650)
seeds = dict(d9_realistic=range(7001, 7011), d9_mixed=range(7101, 7111), d9_severe=range(7201, 7206),
             d9_moderate=range(7301, 7306), pairs_mixed=range(7401, 7411))
order = []
m, v = list(seeds['d9_mixed']), list(seeds['d9_severe'])
for i in range(10):                                       # the two tests the blind zone failed, first
    order.append(('d9_mixed', m[i]))
    if i < len(v):
        order.append(('d9_severe', v[i]))
r, p = list(seeds['d9_realistic']), list(seeds['pairs_mixed'])
for i in range(10):
    order += [('d9_realistic', r[i]), ('pairs_mixed', p[i])]
order += [('d9_moderate', s) for s in seeds['d9_moderate']]
with open('jobs11.txt', 'w') as f:
    for t, s in order:
        n = f'{t}_s{s}'
        f.write(f'{n} {est[t]} - python3 run11.py cfg11/{t}.json out11/{n}.npz seed={s} > out11/{n}.json\n')
print(len(order), 'jobs; total estimate', round(sum(est[t] for t, _ in order) / 3600, 2), 'h of CPU')
