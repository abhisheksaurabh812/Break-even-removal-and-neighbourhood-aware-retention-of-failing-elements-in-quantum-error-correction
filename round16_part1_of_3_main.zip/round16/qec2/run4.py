"""
Round-6 runner: analog readout layer, measurement-qubit failures, twin arms and delayed oracles.
Usage:  python3 run4.py config.json out.npz [key=json ...]

Scenario: static heterogeneity (per qubit, sigma het_sigma) times failures.  Each failure process in
cfg['failures'] is a Poisson stream (mean gap `gap` rounds) of events on a random qubit of a pool:
  kind 't1' : all of the qubit's error sources x fac, and (ancillas) its readout decay rate x fac
  kind 'ro' : a Z ancilla's readout separation divided by k (amplifier / resonator problem)
pools: 'data', 'meas' (Z and X ancillas), 'zanc', 'all'.  Durations uniform in `dur`.
"""
import sys, json, time, hashlib
from collections import OrderedDict
import numpy as np
from model import circuit_model, P_REF
from sampler import Sampler, build_matching
from arms import prepare, Static, Oracle, Slow, Stats, estimate
from arms4 import DelayedOracle, Twin
from arms7 import Sized
import ro

ROLES = None


def roles(m):
    z = np.load(__file__.replace('run4.py', 'roles_d7.npz'))
    zq, xanc, data, det_of, tl = z['zq'], z['xanc'], z['data'], z['det_of'], z['tl']
    anc_q = np.concatenate([zq, xanc])
    nZa = len(zq)
    T = m.T
    inc = np.zeros((nZa * T, m.nZ), np.int32)            # readout (a, r) -> detectors (a, r), (a, r + 1)
    for a in range(nZa):
        for r in range(T):
            inc[a * T + r, det_of[a, r]] = 1; inc[a * T + r, det_of[a, r + 1]] = 1
    # number of readouts of ancilla a that flip each detector (1 at the ends, 2 inside)
    dcount = np.zeros(m.nZ, int); danc_of = -np.ones(m.nZ, int)
    for a in range(nZa):
        for r in range(T + 1):
            u = det_of[a, r]; danc_of[u] = a; dcount[u] = 1 if r in (0, T) else 2
    return dict(zq=zq, xanc=xanc, data=data, anc_q=anc_q, nZa=nZa, tl=tl, inc=inc, dcount=dcount, danc_of=danc_of)


def comb(p, q):
    return p + q - 2 * p * q


def full_rates(m, rl, f, pro_z):
    """True edge probabilities and detector rates including the readout layer (pro_z: per Z ancilla)."""
    pe = m.edge_p(f).copy()
    e = rl['tl']
    pe[e] = comb(pe[e], pro_z[:, None])
    qd = m.det_rate(f).copy()
    a = rl['danc_of']; c = rl['dcount']
    pr = pro_z[a]
    q2 = np.where(c == 2, comb(pr, pr), pr)
    qd = comb(qd, q2)
    return pe, qd


def make_scenario(m, rl, cfg, rng):
    bpe = cfg['bpe']; T = m.T; er = bpe * T
    n_ep = cfg['total_rounds'] // er
    t = (np.arange(n_ep) + 0.5) * er
    tot = n_ep * er
    G = m.G
    f0 = np.exp(cfg['het_sigma'] * rng.standard_normal(G)); f0 /= np.median(f0)
    f0 = np.clip(f0, 0.25, 4.0)
    scale = cfg['p_base'] / P_REF
    F = np.tile((f0 * scale).astype(np.float64), (n_ep, 1))
    nA = len(rl['anc_q'])
    snr0 = ro.SNR0 * np.exp(ro.SNR_HET * rng.standard_normal(nA))
    kmul = np.ones((n_ep, nA))
    flags = np.zeros(n_ep, np.uint8)
    events = []
    pools = dict(data=rl['data'], meas=rl['anc_q'], zanc=rl['zq'], all=np.arange(G))
    pos_of = {int(g): i for i, g in enumerate(rl['anc_q'])}
    for proc in cfg.get('failures', []):
        t0 = 0.0
        pool = pools[proc['pool']]
        while True:
            t0 += rng.exponential(proc['gap'])
            if t0 > tot:
                break
            q = int(pool[rng.integers(len(pool))]); dur = rng.uniform(*proc['dur'])
            on = (t >= t0) & (t < t0 + dur)
            if proc['kind'] == 't1':
                fac = rng.uniform(*proc['fac'])
                F[on, q] *= fac
            else:
                fac = rng.uniform(*proc['k'])
                kmul[on, pos_of[q]] *= fac
            flags[on] |= 4
            events.append([float(t0), float(dur), q, float(fac), proc['kind'], pos_of.get(q, -1)])
    snr = snr0[None, :] / kmul
    kap = ro.KAP0 * F[:, rl['anc_q']] / scale
    return F, snr, kap, flags, events


def build_arms(m, cal, specs):
    arms = []
    for sp in specs:
        k = sp['kind']; nm = sp['name']
        est = sp.get('base') == 'est'
        c = dict(pe=cal['pe_est'], mu=cal['mu_est']) if est else cal
        if k == 'static':
            arms.append(Static(nm, m, c))
        elif k == 'oracle':
            arms.append(Oracle(nm, m, cal))
        elif k == 'doracle':
            arms.append(DelayedOracle(nm, m, cal, sp['L']))
        elif k == 'slow':
            arms.append(Slow(nm, m, cal, sp['R'], sp.get('s', 1), sp.get('cusum'), sp.get('gating', False),
                             sp.get('reseed', False), sp.get('tmax'), sp.get('footprint')))
        elif k == 'sized':
            arms.append(Sized(nm, m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                              sp.get('tmax'), sp.get('footprint'), sp.get('sizer', {})))
        elif k == 'twin':
            arms.append(Twin(nm, m, cal, sp['R'], sp.get('cusum'), sp.get('gating', False), sp.get('reseed', False),
                             sp.get('tmax'), sp.get('footprint'), sp['analog']))
        else:
            raise ValueError(k)
    return arms


def readout_flips(rl, flips):
    N = flips.shape[0]
    return ((flips.reshape(N, -1).astype(np.int32) @ rl['inc']) % 2).astype(np.uint8)


def run(cfg, out):
    m = circuit_model(cfg['d'])
    prepare(m)
    rl = roles(m)
    nZa, T, bpe = rl['nZa'], m.T, cfg['bpe']
    rng_sc = np.random.default_rng(cfg['seed'])
    F, SNR, KAP, flags, events = make_scenario(m, rl, cfg, rng_sc)
    n_ep = F.shape[0]
    pro_all = np.concatenate([ro.p_err(SNR[i:i + 2000], KAP[i:i + 2000]) for i in range(0, n_ep, 2000)])  # true readout errors
    f_cal = F[0]
    pe, qd = full_rates(m, rl, f_cal, pro_all[0, :nZa])
    qcl = np.bincount(m.dclass, qd, m.nclass) / m.class_count
    cal = dict(pe=pe, qclass=qcl, mu=np.array([qcl[c].sum() for c in m.int_classes]), f0=f_cal,
               roles=rl)
    pr0 = pro_all[0, :nZa][rl['danc_of']]                       # readout flips on each detector at t = 0
    cal['det_extra'] = np.where(rl['dcount'] == 2, comb(pr0, pr0), pr0)
    # calibration experiment at t = 0 rates (separate random streams): detector statistics for the
    # estimated static weights, readout histograms for the twin's analog baseline
    cs = Sampler(m, np.random.default_rng(cfg['seed'] + 77777)); crng = np.random.default_rng(cfg['seed'] + 55555)
    st = Stats(m); nep_c = cfg.get('cal_rounds', 1_000_000) // (bpe * T)
    Hc = np.zeros((len(rl['anc_q']), ro.NB))
    for s0 in range(0, nep_c, 250):
        ne = min(250, nep_c - s0)
        Xc_, _ = cs.sample(np.tile(f_cal, (ne, 1)), bpe)
        fl, h = ro.sample(crng, np.tile(SNR[0], (ne, 1)), np.tile(KAP[0], (ne, 1)), bpe, T, nZa)
        Xc_ ^= readout_flips(rl, fl)
        st.add(Xc_); Hc += h.sum(0)
    pe_e, q_e, _, _ = estimate(m, st, pe, qcl, 10, 10)
    cal['pe_est'] = pe_e; cal['mu_est'] = np.array([q_e[c].sum() for c in m.int_classes])
    g = ro.grid()
    fits = np.array([g.fit(Hc[a]) for a in range(len(rl['anc_q']))])
    cal['ro_base'] = dict(snr0=fits[:, 0], q0=fits[:, 1], p0=ro.p_err_model(fits[:, 0], fits[:, 1]))
    arms = build_arms(m, cal, cfg['arms'])
    A = len(arms)
    sampler = Sampler(m, np.random.default_rng(cfg['seed'] + 99991))
    rrng = np.random.default_rng(cfg['seed'] + 31337)
    fails = np.zeros((A, n_ep, bpe), np.uint8)
    mcache = OrderedDict(); builds = 0; decodes = 0
    chunk = cfg.get('chunk', 250)
    t0 = time.time()
    last_key = None; true_pe = None
    for c0 in range(0, n_ep, chunk):
        c1 = min(n_ep, c0 + chunk)
        Xc, oc = sampler.sample(F[c0:c1], bpe)
        fl, Hh = ro.sample(rrng, SNR[c0:c1], KAP[c0:c1], bpe, T, nZa)
        Xc ^= readout_flips(rl, fl)
        for e in range(c0, c1):
            X = Xc[(e - c0) * bpe:(e - c0 + 1) * bpe]; obs = oc[(e - c0) * bpe:(e - c0 + 1) * bpe]
            key = (F[e].tobytes(), pro_all[e, :nZa].tobytes())
            if key != last_key:
                true_pe, _ = full_rates(m, rl, F[e], pro_all[e, :nZa]); last_key = key
            crr = (X.astype(np.float32) @ m.AggD).reshape(bpe * (T - 1), 4).astype(np.float64)
            preds = {}
            for i, arm in enumerate(arms):
                w = np.round(arm.weights(true_pe), 3)
                k = hashlib.md5(w.tobytes()).digest()
                pr = preds.get(k)
                if pr is None:
                    mt = mcache.get(k)
                    if mt is None:
                        mt = build_matching(m, w); builds += 1
                        mcache[k] = mt
                        if len(mcache) > 400:
                            mcache.popitem(last=False)
                    else:
                        mcache.move_to_end(k)
                    pr = mt.decode_batch(X)[:, 0]; decodes += 1
                    preds[k] = pr
                fails[i, e] = pr ^ obs
            for arm in arms:
                if isinstance(arm, Twin):
                    arm.update(X, crr, Hh[e - c0])
                else:
                    arm.update(X, crr)
        if cfg.get('verbose'):
            print(f'{c1}/{n_ep} epochs {time.time() - t0:.0f}s builds={builds} decodes={decodes}', file=sys.stderr, flush=True)
    names = [a.name for a in arms]
    info = {a.name: a.info() for a in arms}
    np.savez_compressed(out, fails=fails, flags=flags, names=np.array(names), cfg=json.dumps(cfg),
                        events=json.dumps(events), info=json.dumps(info), pro=pro_all.astype(np.float32),
                        ro_base=json.dumps({k: v.tolist() for k, v in cal['ro_base'].items()}))
    tot = fails.reshape(A, -1).sum(1)
    print(json.dumps(dict(out=out, elapsed=round(time.time() - t0, 1), builds=builds, decodes=decodes,
                          totals=dict(zip(names, tot.tolist())), n_events=len(events),
                          analog={a.name: {k: v for k, v in a.info()['analog'].items() if k != 'log'}
                                  for a in arms if isinstance(a, Twin)})))


if __name__ == '__main__':
    cfg = json.load(open(sys.argv[1]))
    for a in sys.argv[3:]:
        k, v = a.split('=', 1); cfg[k] = json.loads(v)
    run(cfg, sys.argv[2])
