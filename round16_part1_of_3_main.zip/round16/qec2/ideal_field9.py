"""Round 9 (design input): keep/switch-out crossover for one bulk qubit when its neighbourhood is
noisier than nominal.  Stim sampling + PyMatching on Stim's own detector error model, as ideal_excl8.py.
  region:  every qubit within Chebyshev distance 4 (lattice coordinates) of the target, at factor L
           (relative to nominal p); all other qubits nominal
  keep(f): the target at absolute factor f, everything else as above, decoded with its exact DEM
  excl:    the target switched out, everything else as above, decoded with its exact DEM
Grid f = L x (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30), capped at 300.  Crossover rule as round 8: the first
grid f with keep(f) >= excl, interpolated in (ln f, ln failures) from the previous grid point; if the
first point already crosses, the crossover is that point; no crossing on the grid -> null (never switch out).
The grid stops at the first crossing (later points cannot change the rule's result).  An existing output
file is resumed: L values already in it are skipped.
python3 ideal_field9.py <d> <data|zanc> <p> <L,L,...> <shots,shots,...> <out.json>"""
import sys, os, json, time
import numpy as np
from ideal_excl import ler
import deform
from rectgen import layout

REL = (1, 1.5, 2, 3, 5, 7, 10, 13, 20, 30)
FMAX = 300.0


def crossover(grid, keep, excl):
    prev = None
    for f, k in zip(grid, keep):
        if k >= excl:
            if prev is None:
                return float(f)
            f0, k0 = prev
            t = (np.log(excl) - np.log(k0)) / (np.log(k) - np.log(k0))
            return round(float(np.exp(np.log(f0) + t * (np.log(f) - np.log(f0)))), 2)
        prev = (f, k)
    return None


if __name__ == '__main__':
    d = int(sys.argv[1]); kind = sys.argv[2]; p = float(sys.argv[3])
    Ls = [float(x) for x in sys.argv[4].split(',')]; shots = [int(float(x)) for x in sys.argv[5].split(',')]
    out = sys.argv[6]
    c = (d, d) if kind == 'data' else (d - 1, d - 1)
    assert c in (deform.bulk_data(d) if kind == 'data' else deform.bulk_zanc(d))
    data, xm, zm = layout(d, d)
    allq = list(data) + list(xm) + list(zm)
    region = [q for q in allq if q != c and max(abs(q[0] - c[0]), abs(q[1] - c[1])) <= 4]
    res = dict(d=d, kind=kind, qubit=list(c), p=p, region_size=len(region), rounds_per_shot=d, rows=[])
    if os.path.exists(out):
        prev = json.load(open(out))
        if prev.get('kind') == kind and prev.get('d') == d and prev.get('p') == p:
            res['rows'] = prev['rows']
    have = {r['L'] for r in res['rows']}
    t0 = time.time()
    for L, n in zip(Ls, shots):
        if L in have:
            continue
        sc = {q: L for q in region}
        txt, _ = deform.circuit(d, d, p, excl=[c], scale=sc)
        ex, _ = ler(txt, n)
        grid = [min(FMAX, round(L * r, 3)) for r in REL]
        grid = sorted(set(grid))
        keep = []
        for f in grid:
            txt, _ = deform.circuit(d, d, p, scale={**sc, c: f})
            k, _ = ler(txt, n)
            keep.append(k)
            print(kind, L, f, k, 'excl', ex, round(time.time() - t0), flush=True)
            if k >= ex:
                break
        row = dict(L=L, shots=n, excl=ex, grid=grid[:len(keep)], keep=keep, crossover=crossover(grid, keep, ex))
        res['rows'].append(row); res['rows'].sort(key=lambda r: r['L'])
        print(json.dumps(row), flush=True)
        json.dump(res, open(out, 'w'), indent=1)
    res['elapsed'] = round(time.time() - t0, 1)
    json.dump(res, open(out, 'w'), indent=1)
