"""Independent recount of round-14 decision numbers straight from the raw files (no code shared with
analyse14.py / analyse8.py).    python3 recount14.py > out14/recount14.json   (OUT=... for mock tests)"""
import json, os, math
import numpy as np

OUT = os.environ.get('OUT', 'out14')


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z['fails'][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b, paths_b=None):
    paths_b = paths if paths_b is None else paths_b
    if not all(os.path.exists(p) for p in paths + paths_b):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths_b]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    n = len(paths)
    pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
    st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
    return dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
                p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()],
                boot95=[round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)])


P = lambda t, r: [f'{OUT}/{t}_s{x}.npz' for x in r]
T = dict(d9_mixed=range(10101, 10111), d9_severe=range(10201, 10206), d9_moderate=range(10301, 10306),
         d9_realistic=range(10001, 10011), pairs_mixed=range(10401, 10411), long_severe=range(10501, 10511),
         long_mixed=range(10601, 10611), d9_hwlike=range(10701, 10711))
g = 'sz_w14'
LIST = [('d9_mixed', g, 'sz'), ('d9_mixed', g, 'sz_all'), ('d9_severe', g, 'sz'), ('d9_moderate', g, 'sz'),
        ('d9_realistic', g, 'loc'), ('pairs_mixed', g, 'sz'), ('long_severe', g, 'sz'), ('long_mixed', g, 'sz'),
        ('long_mixed', g, 'sz_all'), ('d9_hwlike', g, 'sz')]
LIST += [(t, g, ref) for t in T for ref in ('sz_w13', 'cut')]
res = {}
for t, a, b in LIST:
    res[f'{t}: {a} vs {b}'] = pair(P(t, T[t]), a, b)
allp = sum((P(t, T[t]) for t in T), [])
res['C1_pooled_all: sz_w14 vs sz_w13'] = pair(allp, g, 'sz_w13')
longp = sum((P(t, T[t]) for t in ('long_severe', 'long_mixed')), [])
res['C2_pooled_long: sz_w14 vs sz_w13'] = pair(longp, g, 'sz_w13')
res['P1_pooled_all: sz_w14 vs cut'] = pair(allp, g, 'cut')
sub = sum(([f'{OUT}/{t}_s{x}.npz' for x in list(T[t])[:4]] for t in T), [])
subp = sum(([f'{OUT}/prior_{t}_s{x}.npz' for x in list(T[t])[:4]] for t in T), [])
for t in T:
    a_ = [f'{OUT}/{t}_s{x}.npz' for x in list(T[t])[:4]]; b_ = [f'{OUT}/prior_{t}_s{x}.npz' for x in list(T[t])[:4]]
    for q in ('sieg', 'sieg_rw'):
        res[f'prior_{t}: {g} vs {q}'] = pair(a_, g, q, b_)
for i, q in ((2, 'sieg'), (3, 'sieg_rw')):
    res[f'P{i}_pooled_prior_subset: sz_w14 vs {q}'] = pair(sub, g, q, subp)
print(json.dumps(res, indent=1))
