"""Round 9: compare analyse9.py's numbers (out9/res_9.json) with the independent recount (out9/recount9.json)
and re-derive the G1-G4 verdicts from the recount alone.     python3 check9.py [res recount] > out9/check9.json"""
import json, sys

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'out9/res_9.json'))
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else 'out9/recount9.json'))
mism = []; n = 0
for key, c in C.items():
    if c is None:
        continue
    tag, pair = key.split(': ')
    scen = tag.split()[-1]
    a = R[scen][pair]
    checks = (('fails', a['fails'], c['a']), ('ref_fails', a['ref_fails'], c['b']), ('rel', a['rel'], c['rel']),
              ('z', a['z'], c['z']), ('per_seed', a['per_seed'], c['per_seed']),
              ('boot_lo', a['boot95']['lo'], c['boot95'][0]), ('boot_hi', a['boot95']['hi'], c['boot95'][1]))
    for name, x, y in checks:
        n += 1
        if x != y:
            mism.append(dict(key=key, field=name, analyse=x, recount=y))


def g(key):
    return C.get(key)


v = {}
c = g('G1 realistic: sz_field vs loc')
if c: v['G1'] = c['rel'] <= 0.01 and c['boot95'][1] <= 0.02
c1, c2 = g('G2 mixed: sz_field vs sz'), g('G2 mixed: sz_field vs sz_all')
if c1 and c2:
    v['G2_vs_sz'] = c1['rel'] <= -0.05 and c1['boot95'][1] < 0
    v['G2_vs_all'] = c2['rel'] <= -0.03 and c2['boot95'][1] < 0
c = g('G3 severe: sz_field vs sz')
if c: v['G3'] = c['rel'] <= -0.10 and c['p'] < 0.01 and c['z'] < 0 and max(c['per_seed']) <= 0.01
c = g('G4 moderate: sz_field vs sz')
if c: v['G4'] = c['rel'] <= 0.01
ra = R.get('rules', {})
names = {'G1': 'G1_realistic_field_vs_loc_within_1pct_and_upper95_within_2pct',
         'G2_vs_sz': 'G2_mixed_field_beats_sz_5pct_upper95_below_0',
         'G2_vs_all': 'G2_mixed_field_beats_all_3pct_upper95_below_0',
         'G3': 'G3_severe_field_beats_sz_10pct', 'G4': 'G4_moderate_field_vs_sz_within_1pct'}
agree = {k: (v[k] == ra.get(names[k])) for k in v}
print(json.dumps(dict(values_compared=n, mismatches=mism, recount_verdicts=v, analyse_verdicts=ra,
                      verdicts_agree=agree), indent=1))
