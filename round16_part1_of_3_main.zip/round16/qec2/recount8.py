"""Independent recount of round-8 decision numbers straight from the raw files (no code shared with
analyse8.py): crossovers from the raw failure counts, totals, relative differences, paired-epoch z,
per-seed differences and the seed bootstrap behind L1-L2, D1-D2, E1-E3, and the sensitivity
reproduction check.    python3 recount8.py > out8/recount8.json"""
import json, os, math
import numpy as np


def fails_by_epoch(path, arm):
    z = np.load(path, allow_pickle=True)
    names = list(map(str, z['names']))
    return z['fails'][names.index(arm)].astype(np.int64).sum(axis=1)


def pair(paths, a, b, boot=False):
    if not all(os.path.exists(p) for p in paths):
        return None
    xs = [fails_by_epoch(p, a) for p in paths]; ys = [fails_by_epoch(p, b) for p in paths]
    ta = np.array([x.sum() for x in xs], float); tb = np.array([y.sum() for y in ys], float)
    diff = np.concatenate([x - y for x, y in zip(xs, ys)]).astype(float)
    zz = diff.sum() / math.sqrt((diff ** 2).sum()) if (diff ** 2).sum() > 0 else 0.0
    out = dict(a=int(ta.sum()), b=int(tb.sum()), rel=round((ta.sum() - tb.sum()) / tb.sum(), 5), z=round(zz, 2),
               p=math.erfc(abs(zz) / math.sqrt(2)), per_seed=[round(v, 4) for v in ((ta - tb) / tb).tolist()])
    if boot:
        n = len(paths)
        pick = np.random.default_rng(8).integers(0, n, size=(10000, n))
        st = (ta[pick].sum(1) - tb[pick].sum(1)) / tb[pick].sum(1)
        out['boot95'] = [round(float(np.percentile(st, 2.5)), 5), round(float(np.percentile(st, 97.5)), 5)]
    return out


def cross(row):
    grid = [1, 2, 3, 5, 7, 10, 13, 20, 30, 50, 100]
    e = row['excl']
    for i, f in enumerate(grid):
        if row[f'keep_f{f}'] >= e:
            if i == 0:
                return float(f)
            fa, ka = grid[i - 1], row[f'keep_f{grid[i - 1]}']; kb = row[f'keep_f{f}']
            lf = math.log(fa) + (math.log(e) - math.log(ka)) / (math.log(kb) - math.log(ka)) * (math.log(f) - math.log(fa))
            return round(math.exp(lf), 1)
    return 100.0


res = {}
for d in (7, 9):
    for k in ('data', 'zanc'):
        f = f'out8/ideal_d{d}_{k}.json'
        if os.path.exists(f):
            j = json.load(open(f))
            res[f'crossover d{d} {k}'] = dict(recounted=cross(j['row']), stored=j['crossover'])
L = lambda s: [f'out8/long_{s}_s{x}.npz' for x in range(3001, 3007)]
D9 = lambda s: [f'out8/d9_{s}_s{x}.npz' for x in range(4001, 4004)]
M10 = lambda s: [f'out7b/test_{s}_s{x}.npz' for x in range(2001, 2004)] + [f'out8/more_{s}_s{x}.npz' for x in range(2004, 2011)]
for tag, paths, a, b, bt in (
        ('L1 long_severe', L('severe'), 'sz_gated', 'sz', False),
        ('L2 long_mixed', L('mixed'), 'sz_gated', 'sz', False),
        ('L2 long_mixed', L('mixed'), 'sz_gated', 'sz_all', False),
        ('long_severe', L('severe'), 'oracle_gated', 'oracle', False),
        ('D1 d9_severe', D9('severe'), 'sz_gated', 'sz', False),
        ('D2 d9_mixed', D9('mixed'), 'sz_gated', 'sz', False),
        ('D2 d9_mixed', D9('mixed'), 'sz_gated', 'sz_all', False),
        ('d9_severe', D9('severe'), 'oracle_gated', 'oracle', False),
        ('E1 realistic10', M10('realistic'), 'sz', 'loc', True),
        ('E1 realistic10', M10('realistic'), 'sz_gated', 'loc', True),
        ('E2 mixed10', M10('mixed'), 'sz_gated', 'sz', True),
        ('E2 mixed10', M10('mixed'), 'sz_gated', 'sz_all', True),
        ('E3 moderate10', M10('moderate'), 'sz_gated', 'sz', True)):
    res[f'{tag}: {a} vs {b}'] = pair(paths, a, b, bt)
for s in ('severe', 'mixed'):
    ok = []
    for x in (2001, 2002):
        p8, p7 = f'out8/sens_{s}_s{x}.npz', f'out7b/test_{s}_s{x}.npz'
        if not os.path.exists(p8):
            ok = None; break
        z8, z7 = np.load(p8, allow_pickle=True), np.load(p7, allow_pickle=True)
        n8 = list(map(str, z8['names'])); n7 = list(map(str, z7['names']))
        ok.append(all(np.array_equal(z8['fails'][n8.index(n)], z7['fails'][i]) for i, n in enumerate(n7)))
    res[f'sens_{s}: 7b arms reproduced exactly'] = None if ok is None else all(ok)
print(json.dumps(res, indent=1))
