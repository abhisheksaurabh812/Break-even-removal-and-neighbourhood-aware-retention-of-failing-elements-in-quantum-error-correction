"""Switch-outs of a dev arm (dev13/<test>_s<seed>.npz) and of a round-12 arm (out12/...) on the same seed:
each switch-out interval, whether a true failure of that qubit was active, its factor; totals of 'false' switch-outs
(no true failure active on that qubit) in count and epochs.   python3 diag13_outs.py <test> <seed> [dev_arm] [r12_arm]"""
import sys
import numpy as np
import analyse8 as A


def outs(run, arm, er):
    return [(int(g), float(x), None if y is None else float(y)) for g, x, y, _ in
            A.out_intervals(run['info'][arm].get('policy_log', []), er)]


def classify(iv, defects, T):
    rows = []
    for g, x, y in iv:
        y2 = T if y is None else y
        best = None
        for t0, dur, q, fac in defects:
            if int(q) == g and t0 < y2 and t0 + dur > x:
                best = max(best or 0, float(fac))
        rows.append((g, x, y2, best))
    return rows


if __name__ == '__main__':
    test, seed = sys.argv[1], int(sys.argv[2])
    da = sys.argv[3] if len(sys.argv) > 3 else 'sz_w13'
    ra = sys.argv[4] if len(sys.argv) > 4 else 'sz_w12r'
    d = A.load(f'dev13/{test}_s{seed}.npz'); r = A.load(f'out12/{test}_s{seed}.npz')
    er = r['cfg']['bpe'] * r['cfg']['d']
    T = float(len(A.per_epoch(r, ra)) * er)
    for name, run, arm in (('dev ' + da, d, da), ('r12 ' + ra, r, ra)):
        rows = classify(outs(run, arm, er), r['defects'], T)
        true = [x for x in rows if x[3] is not None]; false = [x for x in rows if x[3] is None]
        ep = lambda L: sum((y - x) / er for _, x, y, _ in L)
        print(f'{name}: {len(rows)} switch-outs, {len(true)} on a true failure ({ep(true):.0f} epochs), '
              f'{len(false)} false ({ep(false):.0f} epochs)')
        if false:
            qs = {}
            for g, x, y, _ in false:
                qs.setdefault(g, []).append(round((y - x) / er))
            print('   false by qubit (epochs each):', dict(sorted(qs.items(), key=lambda kv: -sum(kv[1]))[:12]))
