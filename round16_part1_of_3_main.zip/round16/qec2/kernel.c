/* Per-round regional CUSUM with floor and ceiling, alarm episodes with hold-off,
 * and an exponentially weighted burst-ratio counter (claims 8, 9, 10 of the draft).
 *
 * c       : nr x R per-round detection-event counts (row-major)
 * mu      : R expected counts per round (from the slow estimator)
 * state   : S[R], alarm[R], hold[R], alen[R], bratio[R] (updated in place)
 * act_out : nr x R, 1 while an alarm episode is active
 * new_out : nr x R, 1 at the round an episode starts
 */
void cusum_run(int nr, int R, const double *c, const double *mu,
               double lr, double rho, double h, double smax, int holdoff, double beta_tau,
               double *S, int *alarm, int *hold, double *alen, double *bratio,
               unsigned char *act_out, unsigned char *new_out)
{
    double a = beta_tau > 0 ? 1.0 / beta_tau : 0.0;
    for (int t = 0; t < nr; t++) {
        for (int g = 0; g < R; g++) {
            double x = c[t * R + g];
            double s = S[g] + x * lr - mu[g] * (rho - 1.0);
            if (s < 0) s = 0;
            if (s > smax) s = smax;
            S[g] = s;
            int above = s >= h;
            unsigned char nw = 0;
            if (!alarm[g] && above) {
                alarm[g] = 1; hold[g] = 0; alen[g] = 0; bratio[g] = rho; nw = 1;
            }
            if (alarm[g]) {
                if (above) hold[g] = 0; else hold[g]++;
                if (hold[g] >= holdoff) { alarm[g] = 0; hold[g] = 0; }
            }
            if (alarm[g]) {
                double m = mu[g] > 1e-9 ? mu[g] : 1e-9;
                alen[g] += 1.0;
                bratio[g] += a * (x / m - bratio[g]);
            }
            act_out[t * R + g] = (unsigned char)alarm[g];
            new_out[t * R + g] = nw;
        }
    }
}
