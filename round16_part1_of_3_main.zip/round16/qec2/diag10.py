"""Round 10 reported diagnostics (written before the runs; no rule uses them).   python3 diag10.py > out10/diag10.json
For every finished test:
  healthy_time   switch-outs of a qubit with no active failure, and the rounds they lasted (as extra9.py), per arm.
  disagreements  failures on a switchable qubit where the new and old gates' switched-out fractions differ by
                 more than 0.2, binned by the qubit's true factor relative to nominal over the clean-patch
                 crossover f*(kind, L = 1) of its distance (as diag9_disagree.py); new-minus-old failures.
  pairs          (pairs test only) for every paired failure: whether each gate switched out the first qubit,
                 its partner, both or neither (out for more than half the failure), whether a member was
                 switchable and past its crossover, and how many healthy qubits each gate switched out during it."""
import json
import numpy as np
import analyse8 as A
from analyse10 import SEEDS, runs
from run3 import base_model
from run10 import make_scenario
from model import P_REF

BINS = [(0, 0.75), (0.75, 1.0), (1.0, 1.25), (1.25, 1.5), (1.5, 1e9)]
XO = {7: {k: dict((r['L'], r['crossover']) for r in json.load(open(f'out9/field_table_{k}.json'))['rows'])[1.0]
          for k in ('data', 'zanc')},
      9: {k: dict((r['L'], r['crossover']) for r in json.load(open(f'out10/field_table_d9_{k}.json'))['rows'])[1.0]
          for k in ('data', 'zanc')}}


def cover(iv, q, t0, t1, tot):
    c = 0.0
    for g, a, b, _ in iv:
        if g == q:
            b = tot if b is None else b
            c += max(0.0, min(b, t1) - max(a, t0))
    return c / max(t1 - t0, 1)


def active(r, g, t):
    return any(dd[2] == g and dd[0] <= t < dd[0] + dd[1] for dd in r['defects'])


res = {}
for test in SEEDS:
    rs = runs(test)
    if not rs:
        continue
    d = rs[0]['cfg']['d']; _, EX = A.roles(d); base = base_model(d)
    R = dict(healthy_time={}, disagreements=dict(rows=[]), pairs=dict(rows=[]))
    for arm in ('sz_field', 'sz_gated', 'sz_all'):
        n = h = 0; rounds = 0.0; longest = 0.0
        for r in rs:
            er = r['cfg']['bpe'] * d; tot = r['fails'].shape[1] * er
            for g, a, b, t in A.out_intervals(r['info'][arm].get('policy_log', []), er):
                n += 1
                if active(r, g, t):
                    continue
                h += 1; dur = (tot if b is None else b) - a; rounds += dur; longest = max(longest, dur)
        R['healthy_time'][arm] = dict(switch_outs=n, without_failure=h, rounds_out_without_failure=int(rounds), longest=int(longest))
    for r in rs:
        cfg = r['cfg']; er = cfg['bpe'] * d
        F, _, ev = make_scenario(base, cfg, np.random.default_rng(cfg['seed']))
        assert ev['defects'] == r['defects']
        fn = cfg['p_base'] / P_REF; tot = r['fails'].shape[1] * er
        fa, fb = A.per_epoch(r, 'sz_field'), A.per_epoch(r, 'sz_gated')
        iv = {arm: A.out_intervals(r['info'][arm].get('policy_log', []), er) for arm in ('sz_field', 'sz_gated', 'sz_all')}
        for t0, dur, q, fac in r['defects']:
            if q not in EX:
                continue
            t1 = min(t0 + dur, tot); e0 = int(t0 // er); e1 = min(int(t1 // er), len(fa) - 1)
            cf, cg = cover(iv['sz_field'], q, t0, t1, tot), cover(iv['sz_gated'], q, t0, t1, tot)
            if abs(cf - cg) <= 0.2:
                continue
            fabs = float(F[min(e0 + 1, len(F) - 1), q] / fn)
            R['disagreements']['rows'].append(dict(seed=cfg['seed'], q=int(q), kind=EX[q], fabs=round(fabs, 2),
                                                   rel_to_crossover=round(fabs / XO[d][EX[q]], 3),
                                                   who_out='new' if cf > cg else 'old',
                                                   new_minus_old=int(fa[e0:e1 + 1].sum() - fb[e0:e1 + 1].sum())))
        for t0, q, q2 in ev.get('pairs', []):
            dur = [dd[1] for dd in r['defects'] if dd[0] == t0 and dd[2] == q][0]
            t1 = min(t0 + dur, tot); e0 = int(t0 // er); e1 = min(int(t1 // er), len(fa) - 1)
            row = dict(seed=cfg['seed'], q=int(q), q2=int(q2), rounds=int(t1 - t0), new_minus_old=int(fa[e0:e1 + 1].sum() - fb[e0:e1 + 1].sum()))
            past = []
            for g in (q, q2):
                fabs = float(F[min(e0 + 1, len(F) - 1), g] / fn)
                past.append(bool(g in EX and fabs >= XO[d][EX[g]]))
                row[f'q{"" if g == q else "2"}_kind'] = EX.get(g, 'not switchable'); row[f'q{"" if g == q else "2"}_fabs'] = round(fabs, 2)
            row['past_crossover'] = past
            for arm in ('sz_field', 'sz_gated', 'sz_all'):
                o = [cover(iv[arm], g, t0, t1, tot) > 0.5 for g in (q, q2)]
                row[arm] = 'both' if all(o) else 'first' if o[0] else 'partner' if o[1] else 'neither'
                row[arm + '_healthy_outs'] = sum(1 for g, a, b, t in iv[arm] if t0 <= t < t1 and not active(r, g, t))
            R['pairs']['rows'].append(row)
    rows = R['disagreements']['rows']
    R['disagreements']['summary'] = {f'{who} out, {lo}-{hi if hi < 1e8 else "inf"} x crossover': dict(
        failures=len(sel), new_minus_old=sum(x['new_minus_old'] for x in sel))
        for who in ('new', 'old') for lo, hi in BINS
        for sel in [[x for x in rows if x['who_out'] == who and lo <= x['rel_to_crossover'] < hi]] if sel}
    R['disagreements']['total_new_minus_old'] = sum(x['new_minus_old'] for x in rows)
    pr = R['pairs']['rows']
    if pr:
        R['pairs']['summary'] = dict(
            pairs=len(pr), with_a_member_past_crossover=sum(any(x['past_crossover']) for x in pr),
            **{f'{arm}_{k}': sum(x[arm] == k for x in pr) for arm in ('sz_field', 'sz_gated', 'sz_all')
               for k in ('both', 'first', 'partner', 'neither')},
            **{f'{arm}_healthy_outs_during_pairs': sum(x[arm + '_healthy_outs'] for x in pr) for arm in ('sz_field', 'sz_gated', 'sz_all')},
            new_minus_old_during_pairs=sum(x['new_minus_old'] for x in pr))
        R['pairs']['rows'] = pr[:80]
    res[test] = R
print(json.dumps(res, indent=1))
