"""
Decoder arms for the decisive test.  Every arm outputs edge weights for the same decoding
graph; they differ only in how the weights are formed.

  static      calibrated weights (true rates at t = 0), never updated
  oracle      true current rates (upper bound)
  slow        per-mechanism pair-correlation estimator, pooled across rounds (Spitz-style)
  regional    calibrated weights shifted by each region's windowed detector-event rate
  twobuffer   as regional, but a short window is used when it differs significantly from a long one
  slow+off    slow estimator + regional CUSUM burst offsets (no gating, no re-seed)
  slow+off+rs as slow+off, plus re-seeding after a persistent alarm (no gating)
  gated       slow + CUSUM offsets + gating of burst events + hold-off + re-seed (claims 1, 8-11)
"""
import ctypes, os
from collections import deque
import numpy as np
from scipy.sparse import csr_matrix
from sampler import weights_from_p

_lib = ctypes.CDLL(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'libkernel.so'))
_dp = ctypes.POINTER(ctypes.c_double); _ip = ctypes.POINTER(ctypes.c_int); _up = ctypes.POINTER(ctypes.c_ubyte)
_lib.cusum_run.argtypes = [ctypes.c_int, ctypes.c_int, _dp, _dp, ctypes.c_double, ctypes.c_double, ctypes.c_double,
                           ctypes.c_double, ctypes.c_int, ctypes.c_double, _dp, _ip, _ip, _dp, _dp, _up, _up]
QSTEP = np.log(2) / 8          # offsets quantised in steps of 2^(1/8) to limit graph rebuilds
WMIN = 0.05


def q_off(x):
    return np.round(x / QSTEP) * QSTEP


def pair_p(a, b, ab):
    """Pairwise edge probability; signed (can be slightly negative from noise) so that sums stay unbiased."""
    den = 1 - 2 * a - 2 * b + 4 * ab
    inside = 1 - 4 * (ab - a * b) / np.where(np.abs(den) < 1e-12, 1e-12, den)
    return 0.5 - 0.5 * np.sqrt(np.maximum(inside, 0))


def prepare(m):
    """Extra index structures used by the estimators."""
    nb = m.ev >= 0
    m.nb_idx = np.nonzero(nb)[0]; m.b_idx = np.nonzero(~nb)[0]
    m.U = m.eu[nb]; m.V = m.ev[nb]
    m.ereg_nb = m.ereg[nb]
    n = len(m.nb_idx)
    rows = np.concatenate([m.U, m.V]); cols = np.concatenate([np.arange(n), np.arange(n)])
    m.Inc_nb = csr_matrix((np.ones(2 * n), (rows, cols)), shape=(m.nZ, n))
    anc_reg = np.zeros(m.danc.max() + 1, int); anc_reg[m.danc] = m.dreg
    m.class_reg = anc_reg[m.class_anc]
    m.int_classes = [np.nonzero((m.class_cls == 1) & (m.class_reg == g))[0] for g in range(4)]
    m.class_count = np.bincount(m.dclass, minlength=m.nclass)
    m.AggD = m.Agg.toarray().astype(np.float32)
    return m


class Stats:
    def __init__(self, m):
        self.m = m
        n = len(m.nb_idx)
        self.sa = np.zeros(n); self.sb = np.zeros(n); self.sab = np.zeros(n); self.sn = np.zeros(n)
        self.dn = np.zeros(m.nZ); self.dN = np.zeros(m.nZ)

    def add(self, X, keep=None, mask=None):
        m = self.m
        if mask is not None:
            B = X.shape[0]
            k = np.ones((B, 4), bool) if keep is None else keep
            ke = k[:, m.ereg_nb].astype(np.float32) * mask['edge_ok'][None, :]
            kd = k[:, m.dreg].astype(np.float32) * mask['det_ok'][None, :]
            a = X[:, m.U].astype(np.float32); b = X[:, m.V].astype(np.float32)
            self.sa += (a * ke).sum(0); self.sb += (b * ke).sum(0); self.sab += (a * b * ke).sum(0); self.sn += ke.sum(0)
            self.dn += (X * kd).sum(0); self.dN += kd.sum(0)
            return
        a = X[:, m.U].astype(np.float32); b = X[:, m.V].astype(np.float32)
        if keep is None:
            self.sa += a.sum(0); self.sb += b.sum(0); self.sab += (a * b).sum(0); self.sn += X.shape[0]
            self.dn += X.sum(0); self.dN += X.shape[0]
        else:
            if not keep.any():
                return
            ke = keep[:, m.ereg_nb].astype(np.float32)
            self.sa += (a * ke).sum(0); self.sb += (b * ke).sum(0); self.sab += (a * b * ke).sum(0)
            self.sn += ke.sum(0)
            kd = keep[:, m.dreg].astype(np.float32)
            self.dn += (X * kd).sum(0); self.dN += kd.sum(0)

    def zero_region(self, g):
        m = self.m
        msk = m.ereg_nb == g
        for arr in (self.sa, self.sb, self.sab, self.sn):
            arr[msk] = 0
        dm = m.dreg == g
        self.dn[dm] = 0; self.dN[dm] = 0

    def reset(self):
        for arr in (self.sa, self.sb, self.sab, self.sn, self.dn, self.dN):
            arr[:] = 0


def estimate(m, st, p_prev, q_prev, minN, minNd):
    t_nb = m.etype[m.nb_idx]
    Sa = np.bincount(t_nb, st.sa, m.ntype); Sb = np.bincount(t_nb, st.sb, m.ntype)
    Sab = np.bincount(t_nb, st.sab, m.ntype); Sn = np.bincount(t_nb, st.sn, m.ntype)
    okt = Sn >= minN
    Snn = np.maximum(Sn, 1)
    pt = pair_p(Sa / Snn, Sb / Snn, Sab / Snn)
    p = p_prev.copy(); ok = np.zeros(m.E, bool)
    sel = okt[t_nb]
    p[m.nb_idx[sel]] = pt[t_nb[sel]]; ok[m.nb_idx[sel]] = True
    Dn = np.bincount(m.dclass, st.dn, m.nclass); DN = np.bincount(m.dclass, st.dN, m.nclass)
    okc = DN >= minNd
    q = q_prev.copy(); q[okc] = Dn[okc] / DN[okc]
    # boundary edges: detector rate minus the contributions of its other edges
    psig = p[m.nb_idx].copy(); psig[sel] = pt[t_nb[sel]]         # signed values for the subtraction
    lnb = m.Inc_nb @ np.log1p(-2 * np.clip(psig, -0.2, 0.45))
    qu = q[m.dclass]
    pB = 0.5 * (1 - np.clip((1 - 2 * qu) / np.exp(lnb), 0, 1))
    bu = m.eu[m.b_idx]; bt = m.etype[m.b_idx]
    cnt = np.bincount(bt, minlength=m.ntype)
    avg = np.bincount(bt, pB[bu], m.ntype) / np.maximum(cnt, 1)
    okb = okc[m.dclass[bu]]
    p[m.b_idx[okb]] = avg[bt[okb]]; ok[m.b_idx[okb]] = True
    return np.clip(p, 1e-6, 0.45), np.clip(q, 1e-6, 0.5), ok, okc


# ------------------------------------------------------------------ arms
class Static:
    kind = 'static'
    def __init__(self, name, m, cal):
        self.name, self.m = name, m
        self.w = weights_from_p(cal['pe'], WMIN)
    def weights(self, true_pe): return self.w
    def update(self, X, crr): pass
    def info(self): return {}


class Oracle(Static):
    kind = 'oracle'
    def weights(self, true_pe): return weights_from_p(true_pe, WMIN)


class Window:
    """Regional windowed reweighting of the calibrated model (one window or a short/long pair)."""
    kind = 'window'
    def __init__(self, name, m, cal, k, k_long=None, z=None):
        self.name, self.m = name, m
        self.w0 = weights_from_p(cal['pe'], WMIN)
        self.mu0 = cal['mu']
        self.k, self.kl, self.z = k, k_long, z
        self.hist = deque(maxlen=max(k, k_long or 0))
        self.lb = np.zeros(4); self.nr = None
    def weights(self, true_pe):
        return np.maximum(self.w0 - self.lb[self.m.ereg], WMIN)
    def _rate(self, k):
        h = list(self.hist)[-k:]
        return np.sum(h, 0) / (len(h) * self.nr)
    def update(self, X, crr):
        self.nr = crr.shape[0]
        self.hist.append(crr.sum(0))
        rs = self._rate(self.k)
        if self.kl is None:
            r = rs
        else:
            rl = self._rate(self.kl)
            sig = np.sqrt(np.maximum(rl, 1e-9) * 1.5 / (min(self.k, len(self.hist)) * self.nr))
            r = np.where(np.abs(rs - rl) > self.z * sig, rs, rl)
        beta = np.clip(r / self.mu0, 0.25, 20.0)
        self.lb = q_off(np.log(beta))
    def info(self): return {}


def footprint_prep(m, radius):
    """Detector footprint of every qubit (share of its error mass landing on each Z ancilla's
    interior detectors), ancilla positions, and neighbourhoods used by footprint-aware gating."""
    if getattr(m, 'fp_ready', None) == radius:
        return m
    nA = int(m.danc.max()) + 1
    inter = m.dcls == 1
    k, u = m.src_det_k, m.src_det_u
    sel = inter[u]
    W = np.zeros((m.G, nA))
    np.add.at(W, (m.src_g[k[sel]], m.danc[u[sel]]), m.p_ref[k[sel]])
    Wn = W / np.maximum(W.sum(1, keepdims=True), 1e-30)
    m.fp_W = W
    m.fp_supp = (Wn >= 0.2)                                   # G x nA: main footprint of each qubit
    pos = (W.T @ m.qxy) / np.maximum(W.sum(0)[:, None], 1e-30)
    D = np.sqrt(((pos[:, None, :] - pos[None, :, :]) ** 2).sum(-1))
    m.fp_nbr = D <= radius                                    # nA x nA neighbourhoods
    m.nA = nA
    A = np.zeros((m.nZ, nA), np.float32); A[np.nonzero(inter)[0], m.danc[inter]] = 1
    m.A_int = A
    ic = np.full(nA, -1); ic[m.class_anc[m.class_cls == 1]] = np.nonzero(m.class_cls == 1)[0]
    m.anc_int_class = ic; m.anc_nint = m.class_count[ic].astype(float)
    anc_reg = np.zeros(nA, int); anc_reg[m.danc] = m.dreg
    m.anc_reg = anc_reg
    AggA = np.zeros((m.nZ, (m.T - 1) * nA), np.float32)          # interior events per (round, ancilla)
    for u in np.nonzero(inter)[0]:
        AggA[u, (m.dt[u] - 1) * nA + m.danc[u]] = 1
    m.AggA = AggA
    m.fp_ready = radius
    return m


class Slow:
    """Per-mechanism slow estimator with optional CUSUM offsets, gating and re-seeding.
    footprint=dict(conc, emin, zs, radius): footprint-aware gating.  An alarm episode is gated
    provisionally; once the hot ancilla has `emin` expected interior events in the episode, the
    spatial pattern of excess events is compared with the detector footprints of single qubits.
    If one qubit's footprint explains >= conc of the significant excess in the neighbourhood,
    the episode is treated as a local (single-qubit) change: its buffered data are released to
    the slow estimator, gating stops and no re-seed is done.  Otherwise gating and re-seeding
    proceed as in the gated arm.
    footprint['localize']: for a local episode, name the qubit whose footprint fits best, estimate
    its rate ratio from the excess, and reweight only the edges that qubit contributes to (by its
    calibrated share of each edge) until the slow estimator has absorbed the change or the alarm
    ends; the regional offset is not applied to that region meanwhile.
    footprint['local_nooff']: ablation - local episodes get no regional offset and no reweighting."""
    kind = 'slow'
    def __init__(self, name, m, cal, R, s=1, cusum=None, gating=False, reseed=False, tmax=None, footprint=None):
        self.name, self.m = name, m
        self.fp = footprint
        self.rcap = float((footprint or {}).get('rcap', 30.0))     # cap on a named qubit's rate ratio (30 in rounds 3-5)
        if footprint:
            footprint_prep(m, footprint.get('radius', 6.0))
            self.fstate = np.zeros(4, np.int8)          # 0 none, 1 provisional, 2 spread (gated), 3 local (released)
            self.nacc = np.zeros((4, m.nA)); self.Eacc = np.zeros((4, m.nA))
            self.episodes = []; self.nupd = 0
            self.localize = bool(footprint.get('localize')); self.nooff = bool(footprint.get('local_nooff')) or self.localize
            self.ovr = {}; self.ucache = {}
            f0 = cal.get('f0')
            self.f0 = np.ones(m.G) if f0 is None else np.asarray(f0, float)
            self.n_ovr = 0; self.ovr_rounds = 0
            Wf = m.fp_W * self.f0[:, None]
            self.share_all = Wf / np.maximum(Wf.sum(0)[None, :], 1e-30)    # G x nA calibrated shares
            self.ac = footprint.get('anc')
            if self.ac:
                nA = m.nA; self.nooff = True
                self.aS = np.zeros(nA); self.aal = np.zeros(nA, np.int32); self.ahold = np.zeros(nA, np.int32)
                self.alen_a = np.zeros(nA); self.abr = np.full(nA, float(self.ac['rho']))
                self.astate = np.zeros(nA, np.int8); self.aacc = np.zeros((nA, nA)); self.aE = np.zeros((nA, nA))
                self.loclog = []; self.n_aalarm = 0
                self.astats = {}; self.Ut = None
        self.p = cal['pe'].copy(); self.q = cal['qclass'].copy()
        self.R, self.alpha = R, 2.0 ** (-s)
        self.st = Stats(m); self.rounds = 0
        self.minN = 0.25 * R / m.T; self.minNd = 0.25 * R / m.T
        self.cusum = cusum; self.gating = gating; self.reseed = reseed
        self.ep = Stats(m) if (reseed or gating) else None
        self.off = np.zeros(4)
        self.n_alarm = 0; self.n_reseed = 0; self.gated_blocks = 0
        if cusum:
            self.rho = cusum['rho']; self.h = cusum['h']; self.smax = cusum['h'] + cusum.get('margin', 3.0)
            self.holdoff = int(cusum['holdoff']); self.btau = cusum.get('beta_tau', 2000.0)
            self.tmax_int = (tmax or 1e18) * (m.T - 1) / m.T
            self.S = np.zeros(4); self.alarm = np.zeros(4, np.int32); self.hold = np.zeros(4, np.int32)
            self.alen = np.zeros(4); self.bratio = np.full(4, self.rho)

    def mu(self, mask=None):
        # expected detection events per interior round in each region = sum of the per-round
        # rates of that region's Z ancillas (one interior detector class per ancilla)
        if mask is not None:
            off = mask['cls_off']
            return np.array([self.q[c[~off[c]]].sum() for c in self.m.int_classes])
        return np.array([self.q[c].sum() for c in self.m.int_classes])

    def weights(self, true_pe):
        p = self.p
        if self.fp and self.ovr:
            byq = {}
            for o in self.ovr.values():
                if o['q'] not in byq or o['r'] > byq[o['q']]['r']:
                    byq[o['q']] = o
            fac = np.ones_like(p)
            for o in byq.values():
                fac *= 1 + o['u'] * (o['r'] - 1)
            p = np.clip(p * fac, 1e-7, 0.45)
        w = weights_from_p(p, WMIN)
        if self.cusum:
            off = self.off
            if self.fp and self.nooff:
                off = np.where(self.fstate == 3, 0.0, off)
            w = np.maximum(w - off[self.m.ereg], WMIN)
        return w

    def _shares(self, g):
        u = self.ucache.get(g)
        if u is None:
            m = self.m
            base = m.p_ref * self.f0[m.src_g]
            u = (m.C @ (base * (m.src_g == g))) / np.maximum(m.C @ base, 1e-30)
            self.ucache[g] = u
        return u

    def _ovr_refresh(self):
        for g in list(self.ovr):
            o = self.ovr[g]
            sel = o['u'] > 0.5
            if not sel.any():
                sel = o['u'] >= o['u'].max() * 0.8
            # edge-level ratio already absorbed by the slow estimator on the qubit's dominant edges;
            # keep only the remainder so the correction is not applied twice
            absorbed = float(np.median(self.p[sel] / np.maximum(o['p_dec'][sel], 1e-9)))
            uu = float(np.median(o['u'][sel]))
            r_res = 1 + ((1 + uu * (o['r'] - 1)) / max(absorbed, 1e-3) - 1) / max(uu, 1e-3)
            if r_res < 1.1:
                del self.ovr[g]
            else:
                o['r'] = r_res; o['p_dec'] = self.p.copy()

    def update(self, X, crr, mask=None):
        m = self.m; B = X.shape[0]; Tint = m.T - 1
        keep = None
        self.mask = mask
        if self.cusum:
            mu = self.mu(mask)
            nr = crr.shape[0]
            act = np.empty((nr, 4), np.uint8); new = np.empty((nr, 4), np.uint8)
            c = np.ascontiguousarray(crr, dtype=np.float64)
            _lib.cusum_run(nr, 4, c.ctypes.data_as(_dp), np.ascontiguousarray(mu).ctypes.data_as(_dp),
                           float(np.log(self.rho)), float(self.rho), float(self.h), float(self.smax),
                           self.holdoff, float(self.btau),
                           self.S.ctypes.data_as(_dp), self.alarm.ctypes.data_as(_ip), self.hold.ctypes.data_as(_ip),
                           self.alen.ctypes.data_as(_dp), self.bratio.ctypes.data_as(_dp),
                           act.ctypes.data_as(_up), new.ctypes.data_as(_up))
            bact = act.reshape(B, Tint, 4).any(1); bnew = new.reshape(B, Tint, 4).any(1)
            self.n_alarm += int(new.sum())
            if self.fp:
                keep = self._fp_pre(X, bact, bnew)
            elif self.gating:
                keep = ~bact
                self.gated_blocks += int(bact.sum())
            if self.ep is not None:
                emask = bact.copy()
                for g in np.nonzero(bnew.any(0))[0]:
                    self.ep.zero_region(g)
                    b0 = np.nonzero(bnew[:, g])[0][-1]
                    emask[:b0, g] = False
                self.ep.add(X, emask, mask)
            active = self.alarm.astype(bool)
            self.off = np.where(active, q_off(np.log(np.clip(self.bratio, 1.0, 20.0))), 0.0)
        self.st.add(X, keep, mask)
        if self.fp:
            self._fp_post()
            if self.ac:
                self._anc_monitor(X)
        if self.reseed and self.cusum:
            per = self.alarm.astype(bool) & (self.alen > self.tmax_int)
            if self.fp:
                per &= self.fstate == 2
            for g in np.nonzero(per)[0]:
                p_new, q_new, okp, okq = estimate(m, self.ep, self.p, self.q, 200, 200)
                ep_ = okp & (m.ereg == g); cq = okq & (m.class_reg == g)
                self.p[ep_] = p_new[ep_]; self.q[cq] = q_new[cq]
                self.S[g] = 0; self.alarm[g] = 0; self.hold[g] = 0; self.alen[g] = 0; self.bratio[g] = self.rho
                self.off[g] = 0.0
                if self.fp:
                    self.fstate[g] = 0
                self.st.zero_region(g); self.ep.zero_region(g)
                self.n_reseed += 1
        self.rounds += B * m.T
        if self.rounds >= self.R:
            p_new, q_new, okp, okq = estimate(m, self.st, self.p, self.q, self.minN, self.minNd)
            a = self.alpha
            self.p[okp] += a * (p_new[okp] - self.p[okp]); self.q[okq] += a * (q_new[okq] - self.q[okq])
            self.st.reset(); self.rounds = 0
            if self.fp and self.ovr:
                self._ovr_refresh()

    # ---------------- footprint-aware gating
    def _fp_pre(self, X, bact, bnew):
        m = self.m; B = X.shape[0]
        self.nupd += 1
        cnt = None
        start = np.zeros(4, int)
        for g in np.nonzero(bnew.any(0))[0]:
            if self.fstate[g] == 1:
                self._fp_decide(g, final=True)
            b0 = np.nonzero(bnew[:, g])[0][-1]
            start[g] = b0
            self.nacc[g] = 0; self.Eacc[g] = 0; self.fstate[g] = 1
        prov = np.nonzero(self.fstate == 1)[0]
        if len(prov):
            cnt = X.astype(np.float32) @ m.A_int                 # B x nA interior events per ancilla
            eb = self.q[m.anc_int_class] * m.anc_nint             # expected per block
            if getattr(self, 'mask', None) is not None:
                eb = eb * ~self.mask['anc_off']
            for g in prov:
                msk = bact[:, g].copy(); msk[:start[g]] = False
                nb = int(msk.sum())
                if nb:
                    self.nacc[g] += cnt[msk].sum(0); self.Eacc[g] += nb * eb
        gate = bact & np.isin(self.fstate, (1, 2))[None, :]
        self.gated_blocks += int(gate.sum())
        return ~gate

    def _classify(self, n, E, hot):
        """Footprint test around ancilla `hot`: local/spread decision (fraction of significant excess
        explained by one qubit's main footprint) and the best-fitting qubit with its rate ratio."""
        m, f = self.m, self.fp
        e = n - E; z = e / np.sqrt(np.maximum(E, 1e-9))
        nb = m.fp_nbr[hot]
        es = np.where(nb & (z > f.get('zs', 2.0)), np.maximum(e, 0), 0.0)
        tot = es.sum()
        gstar, top3, rhat = -1, [], 1.0
        if tot <= 0:
            return 1.0, True, gstar, top3, rhat, 0          # no significant excess: false alarm
        sc = m.fp_supp.astype(float) @ es
        frac = float(sc.max() / tot)
        local = frac >= f['conc']
        # name the qubit: weighted least-squares fit of the excess pattern over the whole
        # neighbourhood to each qubit's expected footprint (ancillas with no excess count
        # against a candidate, so a superset footprint does not win); slope -> rate ratio
        Xg = self.share_all[:, nb] * E[nb][None, :]
        ee = e[nb]; wv = 1.0 / np.maximum(E[nb], 1.0)
        num = (Xg * (ee * wv)[None, :]).sum(1); den = (Xg ** 2 * wv[None, :]).sum(1)
        lam = np.maximum(num / np.maximum(den, 1e-30), 0.0)
        resid = ((ee[None, :] - lam[:, None] * Xg) ** 2 * wv[None, :]).sum(1)
        order = np.argsort(np.where(den > 0, resid, np.inf))
        gstar = int(order[0]); top3 = [int(x) for x in order[:3]]
        # significance of the fitted excess for the named qubit (WLS slope / its standard error);
        # a qubit is only reweighted when the fit is significant (z >= zname)
        zfit = float(lam[gstar] * np.sqrt(den[gstar]))
        rhat = float(np.clip(1 + lam[gstar], 1.0, self.rcap)) if zfit >= f.get('zname', 3.0) else 1.0
        return frac, local, gstar, top3, rhat, int((es > 0).sum())

    def _fp_decide(self, g, final=False):
        m, f = self.m, self.fp
        n, E = self.nacc[g], self.Eacc[g]
        e = n - E; z = e / np.sqrt(np.maximum(E, 1e-9))
        inreg = m.anc_reg == g
        zr = np.where(inreg, z, -np.inf)
        hot = int(np.argmax(zr))
        if not final and E[hot] < f['emin']:
            return False
        frac, local, gstar, top3, rhat, nsig = self._classify(n, E, hot)
        if local:
            st, ep = self.st, self.ep
            msk = m.ereg_nb == g
            st.sa[msk] += ep.sa[msk]; st.sb[msk] += ep.sb[msk]; st.sab[msk] += ep.sab[msk]; st.sn[msk] += ep.sn[msk]
            dm = m.dreg == g
            st.dn[dm] += ep.dn[dm]; st.dN[dm] += ep.dN[dm]
            self.fstate[g] = 3
            if self.localize and gstar >= 0 and rhat >= 1.1 and not final:
                self.ovr[('reg', int(g))] = dict(q=gstar, r=rhat, u=self._shares(gstar), p_dec=self.p.copy())
                self.n_ovr += 1
        else:
            self.fstate[g] = 2
        self.episodes.append([self.nupd, int(g), int(local), round(frac, 3), nsig, int(final),
                              round(float(E[hot]), 1), gstar, top3, round(rhat, 2)])
        return True

    def _fp_post(self):
        for g in np.nonzero(self.fstate == 1)[0]:
            if self.alarm[g]:
                self._fp_decide(g)
            else:
                self._fp_decide(g, final=True)
        ended = (self.alarm == 0) & (self.fstate != 1)
        for g in np.nonzero(ended)[0]:
            self.ovr.pop(('reg', int(g)), None)
        self.fstate[ended] = 0
        if self.ovr:
            self.ovr_rounds += 1

    def _anc_monitor(self, X):
        """Per-ancilla CUSUM on interior detection events; on an alarm, collect evidence around that
        ancilla, then run the footprint test.  A local verdict names the qubit and starts a targeted
        reweighting of the edges it contributes to (no gating; the burst layer is untouched)."""
        m, ac = self.m, self.ac; B = X.shape[0]; Tint = m.T - 1; nA = m.nA
        cra = np.ascontiguousarray((X.astype(np.float32) @ m.AggA).reshape(B * Tint, nA), dtype=np.float64)
        mu_a = self.q[m.anc_int_class]
        if getattr(self, 'mask', None) is not None:
            mu_a = mu_a * ~self.mask['anc_off']
        mu_a = np.ascontiguousarray(mu_a, dtype=np.float64)
        nr = B * Tint
        act = np.empty((nr, nA), np.uint8); new = np.empty((nr, nA), np.uint8)
        rho = float(ac['rho']); h = float(ac['h'])
        _lib.cusum_run(nr, nA, cra.ctypes.data_as(_dp), mu_a.ctypes.data_as(_dp), float(np.log(rho)), rho, h, h + 3.0,
                       int(ac.get('holdoff', 1500)), float(ac.get('beta_tau', 2000.0)),
                       self.aS.ctypes.data_as(_dp), self.aal.ctypes.data_as(_ip), self.ahold.ctypes.data_as(_ip),
                       self.alen_a.ctypes.data_as(_dp), self.abr.ctypes.data_as(_dp),
                       act.ctypes.data_as(_up), new.ctypes.data_as(_up))
        bact = act.reshape(B, Tint, nA).any(1); bnew = new.reshape(B, Tint, nA).any(1)
        self.n_aalarm += int(new.sum())
        start = np.zeros(nA, int)
        for a in np.nonzero(bnew.any(0))[0]:
            start[a] = np.nonzero(bnew[:, a])[0][-1]
            self.aacc[a] = 0; self.aE[a] = 0; self.astate[a] = 1
            self.astats[int(a)] = Stats(m)
        col = np.nonzero(self.astate == 1)[0]
        if len(col):
            cnt = X.astype(np.float32) @ m.A_int
            eb = self.q[m.anc_int_class] * m.anc_nint
            if getattr(self, 'mask', None) is not None:
                eb = eb * ~self.mask['anc_off']
            for a in col:
                msk = bact[:, a].copy(); msk[:start[a]] = False
                nb = int(msk.sum())
                if nb:
                    self.aacc[a] += cnt[msk].sum(0); self.aE[a] += nb * eb
                    if ac.get('pairs', True):
                        self.astats[int(a)].add(X[msk])
                if self.aE[a, a] >= ac.get('emin', 60):
                    frac, local, gstar, top3, rhat, nsig = self._classify(self.aacc[a], self.aE[a], a)
                    if ac.get('pairs', True):
                        gstar, top3, rhat = self._name_pairs(self.astats[int(a)], self.aacc[a], self.aE[a], a)
                    self.astats.pop(int(a), None)
                    self.astate[a] = 2
                    if local and gstar >= 0 and rhat >= 1.1:
                        self.ovr[('anc', int(a))] = dict(q=gstar, r=rhat, u=self._shares(gstar), p_dec=self.p.copy())
                        self.n_ovr += 1
                    self.loclog.append([self.nupd, int(a), int(local), round(frac, 3), nsig, 0,
                                        round(float(self.aE[a, a]), 1), gstar, top3, round(rhat, 2)])
        for a in np.nonzero((self.aal == 0) & (self.astate > 0))[0]:
            self.ovr.pop(('anc', int(a)), None)
            self.astate[a] = 0; self.astats.pop(int(a), None)

    def _name_pairs(self, st, n, E, a):
        """Name the qubit from pair (coincidence) excess per edge type plus per-ancilla event excess
        in the neighbourhood of ancilla a; one common slope lambda = r - 1 per candidate qubit."""
        m, f = self.m, self.fp
        if self.Ut is None:                      # calibrated share of each qubit in each edge type
            cnt = np.bincount(m.etype, minlength=m.ntype).astype(float)
            U = np.zeros((m.G, m.ntype))
            for g in np.unique(m.src_g):
                U[g] = np.bincount(m.etype, self._shares(int(g)), m.ntype) / np.maximum(cnt, 1)
            self.Ut = U
            nb_t = np.zeros(m.ntype, bool); nb_t[m.etype[m.nb_idx]] = True
            self.t_anc = np.full((m.ntype, 2), -1)
            self.t_anc[m.etype, 0] = m.danc[m.eu]; self.t_anc[m.etype, 1] = np.where(m.ev >= 0, m.danc[np.maximum(m.ev, 0)], -1)
            self.nb_t = nb_t
            cntt = np.bincount(m.etype, minlength=m.ntype).astype(float)
            self.t_cnt = cntt
        nbr = m.fp_nbr[a]
        tsel = self.nb_t & (nbr[self.t_anc[:, 0]] | ((self.t_anc[:, 1] >= 0) & nbr[np.maximum(self.t_anc[:, 1], 0)]))
        t_nb = m.etype[m.nb_idx]
        Sa = np.bincount(t_nb, st.sa, m.ntype); Sb = np.bincount(t_nb, st.sb, m.ntype)
        Sab = np.bincount(t_nb, st.sab, m.ntype); Sn = np.bincount(t_nb, st.sn, m.ntype)
        Snn = np.maximum(Sn, 1)
        ph = pair_p(Sa / Snn, Sb / Snn, Sab / Snn)
        ps = np.bincount(m.etype, self.p, m.ntype) / np.maximum(self.t_cnt, 1)
        tsel &= Sn > 0
        dT = (ph - ps)[tsel]; sT = np.sqrt(np.maximum(np.maximum(ph, ps)[tsel], 1e-6) / Snn[tsel])
        XT = self.Ut[:, tsel] * ps[tsel][None, :]
        dA = (n - E)[nbr]; sA = np.sqrt(np.maximum(E[nbr], 1.0))
        XA = self.share_all[:, nbr] * E[nbr][None, :]
        Y = np.concatenate([dT / sT, dA / sA]); Xg = np.concatenate([XT / sT[None, :], XA / sA[None, :]], 1)
        num = Xg @ Y; den = (Xg ** 2).sum(1)
        lam = np.maximum(num / np.maximum(den, 1e-30), 0.0)
        resid = ((Y[None, :] - lam[:, None] * Xg) ** 2).sum(1)
        order = np.argsort(np.where(den > 0, resid, np.inf))
        g = int(order[0]); top3 = [int(x) for x in order[:3]]
        z = float(lam[g] * np.sqrt(den[g]))
        rhat = float(np.clip(1 + lam[g], 1.0, self.rcap)) if z >= f.get('zname', 3.0) else 1.0
        return g, top3, rhat

    def info(self):
        d = dict(alarms=self.n_alarm, reseeds=self.n_reseed, gated_blocks=self.gated_blocks)
        if self.fp:
            d['episodes'] = self.episodes
            d['overrides'] = self.n_ovr; d['override_epochs'] = self.ovr_rounds
            if self.ac:
                d['anc_alarms'] = self.n_aalarm; d['localizations'] = self.loclog
        return d
