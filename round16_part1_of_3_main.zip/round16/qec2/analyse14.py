"""Round 14 analysis (rules in PREREG_round14.md).   python3 analyse14.py > out14/res_14.json
A rule is evaluated only when every seed of the tests it uses has finished (done marker in out14/done/).
OUT may be changed (mock tests: OUT=mock14/out14 python3 analyse14.py)."""
import json, os
import numpy as np
import analyse8 as A

OUT = os.environ.get('OUT', 'out14')
GATE = 'sz_w14'
SEEDS = dict(d9_mixed=range(10101, 10111), d9_severe=range(10201, 10206), d9_moderate=range(10301, 10306),
             d9_realistic=range(10001, 10011), pairs_mixed=range(10401, 10411), long_severe=range(10501, 10511),
             long_mixed=range(10601, 10611), d9_hwlike=range(10701, 10711))
LONG = ('long_severe', 'long_mixed')
PRIOR_SEEDS = {t: list(r)[:4] for t, r in SEEDS.items()}        # prior_<test>_s<seed> runs (sieg, sieg_rw): 32
# prior-art arms and the margin by which the gate must beat each, pooled: cut over all 70 runs (P1), sieg and sieg_rw
# over the 32 runs that have them (P2, P3)
PRIOR = dict(cut=0.03, sieg=0.15, sieg_rw=0.15)
C1_MAX = 0.0025


def done(n):
    return os.path.exists(f'{OUT}/done/{n}')


def load(f):
    """analyse8.load with the failures summed over the shots of each epoch (every statistic here uses per-epoch
    counts only; this keeps 70 runs of eight arms in memory)."""
    z = np.load(f, allow_pickle=True)
    ev = json.loads(str(z['events']))
    return dict(file=f, names=[str(x) for x in z['names']], fails=z['fails'].sum(2, keepdims=True).astype(np.int64),
                nexcl=z['nexcl'], info=json.loads(str(z['info'])), cfg=json.loads(str(z['cfg'])), defects=ev['defects'])


_cache = {}


def runs(test):
    if test in _cache:
        return _cache[test]
    out = []
    for s in SEEDS[test]:
        n = f'{test}_s{s}'
        if not done(n):
            return None
        out.append(load(f'{OUT}/{n}.npz'))
    _cache[test] = out
    return out


REFS = ('loc', 'sz', 'sz_all')
PAIRS = [(g, r) for g in (GATE, 'sz_w13') for r in REFS] + [(GATE, 'sz_w13')]
PAIRS += [(GATE, 'cut'), ('sz_w13', 'cut')] + [('cut', r) for r in REFS]
QPAIRS = [(g, q) for g in (GATE, 'sz_w13', 'sz', 'sz_all', 'cut', 'loc') for q in ('sieg', 'sieg_rw')] + [('sieg_rw', 'sieg')]


def merged_prior(test):
    """Per seed of the prior subset: the main run's arms with the prior run's sieg and sieg_rw (its reweighting arm,
    which must equal the main run's epoch by epoch, is kept as 'sz_prior'); None until every seed has both."""
    out = []
    for s in PRIOR_SEEDS[test]:
        n = f'{test}_s{s}'
        if not (done(n) and done(f'prior_{n}')):
            return None
        r = [x for x in runs(test) if x['file'].endswith(f'/{n}.npz')][0] if runs(test) else load(f'{OUT}/{n}.npz')
        p = load(f'{OUT}/prior_{n}.npz')
        assert r['fails'].shape[1:] == p['fails'].shape[1:], n
        names = r['names'] + [x if x != 'sz' else 'sz_prior' for x in p['names']]
        info = dict(r['info']); info.update({k: v for k, v in p['info'].items() if k != 'sz'})
        out.append(dict(file=r['file'], names=names, fails=np.concatenate([r['fails'], p['fails']]), info=info,
                        cfg=dict(r['cfg'], arms=r['cfg']['arms'] + [a for a in p['cfg']['arms'] if a['name'] != 'sz']),
                        defects=r['defects'], nexcl=None))
    return out


def returns(rs, g):
    n = 0
    for r in rs:
        n += sum(1 for l in r['info'][g].get('policy_log', []) if l[0] == 'in' and l[-1] == 'watch')
    return n


def rules_for(g, res):
    c = lambda t, k: res[t][k]
    out = {}
    if 'd9_mixed' in res:
        out[f'R1_{g}_mixed_beats_sz_5pct'] = A.beats(c('d9_mixed', f'{g} vs sz'), 0.05)
        out[f'R1_{g}_mixed_beats_all_3pct'] = A.beats(c('d9_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_severe' in res:
        out[f'R2_{g}_severe_beats_sz_10pct'] = A.beats(c('d9_severe', f'{g} vs sz'), 0.10)
    if 'd9_moderate' in res:
        out[f'R3_{g}_moderate_vs_sz_within_1pct'] = bool(c('d9_moderate', f'{g} vs sz')['rel'] <= 0.01)
    if 'd9_realistic' in res:
        x = c('d9_realistic', f'{g} vs loc')
        out[f'R4_{g}_realistic_vs_loc_within_1pct_and_upper95_within_2pct'] = bool(x['rel'] <= 0.01 and x['boot95']['hi'] <= 0.02)
    if 'pairs_mixed' in res:
        out[f'R5_{g}_pairs_vs_sz_within_1pct'] = bool(c('pairs_mixed', f'{g} vs sz')['rel'] <= 0.01)
    if 'long_severe' in res:
        out[f'R6_{g}_long_severe_beats_sz_10pct'] = A.beats(c('long_severe', f'{g} vs sz'), 0.10)
    if 'long_mixed' in res:
        out[f'R7_{g}_long_mixed_beats_sz_5pct'] = A.beats(c('long_mixed', f'{g} vs sz'), 0.05)
        out[f'R7_{g}_long_mixed_beats_all_3pct'] = A.beats(c('long_mixed', f'{g} vs sz_all'), 0.03)
    if 'd9_hwlike' in res:
        out[f'R8_{g}_hwlike_beats_sz_10pct'] = A.beats(c('d9_hwlike', f'{g} vs sz'), 0.10)
    return out


def pooled(tests, a, b):
    rs = sum((runs(t) for t in tests), [])
    x = A.compare(rs, a, b); x['boot95'] = A.bootstrap(rs, a, b)
    return x


def main():
    res = {}; rules = {}
    for test in SEEDS:
        rs = runs(test)
        if not rs:
            continue
        R = dict(seeds=len(rs), totals=A.totals(rs))
        for a, b in PAIRS:
            R[f'{a} vs {b}'] = A.compare(rs, a, b)
            R[f'{a} vs {b}']['boot95'] = A.bootstrap(rs, a, b)
        R['watch_returns'] = {g: returns(rs, g) for g in ('sz_w13', GATE)}
        R['hole_named'] = [r['info'][GATE].get('hole_named') for r in rs]
        for g in ('sz_w13', GATE, 'cut'):
            pc = A.policy_checks(rs, g)
            pc['failures'] = pc['failures'][:40]
            R[f'policy_{g}'] = pc
        res[test] = R
        mp = merged_prior(test)
        if mp:
            Q = dict(seeds=len(mp), totals=A.totals(mp))
            Q['main_stream_check: sz == sz_prior'] = bool(all((r['fails'][r['names'].index('sz')] ==
                                                                r['fails'][r['names'].index('sz_prior')]).all() for r in mp))
            for a, b in QPAIRS:
                Q[f'{a} vs {b}'] = A.compare(mp, a, b); Q[f'{a} vs {b}']['boot95'] = A.bootstrap(mp, a, b)
            for g in ('sieg', 'sieg_rw'):
                pc = A.policy_checks(mp, g)
                pc['failures'] = pc['failures'][:40]
                Q[f'policy_{g}'] = pc
            res[f'prior_{test}'] = Q
    rules.update(rules_for(GATE, res))
    if all(t in res for t in SEEDS):
        x = pooled(SEEDS, GATE, 'sz_w13'); res['C1_pooled_all: sz_w14 vs sz_w13'] = x
        rules['C1_sz_w14_vs_sz_w13_all_within_0.25pct'] = bool(x['rel'] <= C1_MAX)
        thr = PRIOR['cut']
        x = pooled(SEEDS, GATE, 'cut'); res['P1_pooled_all: sz_w14 vs cut'] = x
        rules[f'P1_sz_w14_beats_cut_all_{round(100 * thr)}pct'] = bool(x['rel'] <= -thr and x['z'] < 0 and x['p'] < 0.01)
    mps = {t: merged_prior(t) for t in SEEDS}
    if all(mps.values()):
        rs = sum(mps.values(), [])
        res['P_main_stream_check: sz == sz_prior (32 runs)'] = all(res[f'prior_{t}']['main_stream_check: sz == sz_prior'] for t in SEEDS)
        for i, p in ((2, 'sieg'), (3, 'sieg_rw')):
            thr = PRIOR[p]
            x = A.compare(rs, GATE, p); x['boot95'] = A.bootstrap(rs, GATE, p)
            res[f'P{i}_pooled_prior_subset: sz_w14 vs {p}'] = x
            rules[f'P{i}_sz_w14_beats_{p}_subset_{round(100 * thr)}pct'] = bool(x['rel'] <= -thr and x['z'] < 0 and x['p'] < 0.01)
    if all(t in res for t in LONG):
        x = pooled(LONG, GATE, 'sz_w13'); res['C2_pooled_long: sz_w14 vs sz_w13'] = x
        rules['C2_sz_w14_fewer_failures_than_sz_w13_long_pooled'] = bool(x['rel'] < 0 and x['z'] < 0 and x['p'] < 0.01)
    res['rules'] = rules
    return res


if __name__ == '__main__':
    print(json.dumps(main(), indent=1))
